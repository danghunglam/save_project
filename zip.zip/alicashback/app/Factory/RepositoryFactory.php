<?php

namespace App\Factory;

use App\Repository\FeedbackRepository;
use App\Repository\ProductRepository;
use App\Repository\ShopMetaRepository;
use App\Repository\ShopRepository;

class RepositoryFactory
{
	/**
	 * @return ShopRepository
	 */
	public static function shopRepository()
	{
		return app(ShopRepository::class);
	}


	/**
	 * @return ShopMetaRepository
	 */
	public static function shopMetaRepository()
	{
		return app(ShopMetaRepository::class);
	}

	/**
	 * @return ProductRepository
	 */
	public static function productRepository()
	{
		return app(ProductRepository::class);
	}

	/**
	 * @return FeedbackRepository
	 */
	public static function feedbackRepository(){
		return app(FeedbackRepository::class);
	}
}