<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendCustomer extends Mailable
{
    use Queueable, SerializesModels;
    protected $_data;

    private $_shop;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($data, $shop)
    {
        $this->_data = $data;
        $this->_shop = $shop;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $data = $this->_data;
        $shop = $this->_shop;
        return $this->from($shop->email, $shop->name)
            ->replyTo($shop->email, $shop->name)
            ->subject($data['title'])->view('mails.templates.sendcustomer')->with(['data' => $data]);
    }
}
