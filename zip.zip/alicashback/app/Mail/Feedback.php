<?php

namespace App\Mail;

use App\Helpers\Helpers;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class Feedback extends Mailable
{
	use Queueable, SerializesModels;

	private $request;

	/**
	 * Create a new message instance.
	 *
	 */
	public function __construct($request)
	{

		$this->request = $request;
	}

	/**
	 * Build the message.
	 *
	 * @return $this
	 */
	public function build()
	{
		Helpers::saveLog('info', ['message' => 'Send mail feedback']);

		$data = $this->request;
		$this->from('support@fireapps.io', 'Ali Orders');
		return $this->subject('New Feedback From Shopify Store - Ali Orders')->view('mails.templates.feedback', ['data' => $data]);
	}
}
