<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class ImportProductModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'import_product';

    /**
     * @var string
     */
    protected $primaryKey = 'id';
    /*
     * @var array
     */
    protected $fillable = [
        'id',
        'title',
        'handle',
        'body_html',
        'image',
        'custom_collection',
        'tag',
        'status',
        'source',
        'aliexpress_product_id',
        'source_product_link',
        'supplier_id',
        'shop_id',
        'is_import',
        'auto_update_price',
        'title_source',
        'price_range',
        'product_type'
    ];

    /**
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productVariant()
    {
        return $this->hasMany('App\Models\ImportProductVariantModel', 'product_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function shop()
    {
        return $this->belongsTo('App\Models\ShopModel', 'shop_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function supplier()
    {
        return $this->belongsTo('App\Models\SupplierModel', 'supplier_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productImage()
    {
        return $this->hasMany('App\Models\ImportProductImageModel', 'product_id', 'id');
    }

    /**
     * @param $value
     */
    public function setCustomCollectionAttribute($value)
    {
        $this->attributes['custom_collection'] = json_encode($value);
    }


    public function getCustomCollectionAttribute($custom_collection)
    {
        return json_decode($custom_collection, true);
    }

    public function getIdAttribute($id)
    {
        return (string) $id;
    }
}
