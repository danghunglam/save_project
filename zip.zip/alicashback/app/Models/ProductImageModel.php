<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductImageModel extends Model
{
    use SoftDeletes;
    /**
     * @var string
     */
    protected $table = 'product_image';

    /**
     * @var array
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'product_id',
        'src',
        'width',
        'height',
        'status',
        'in_variant',
        'sort'
    ];
    /**
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at'
    ];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function product()
    {
        return $this->belongsTo('App\Models\ProductModel', 'product_id', 'id');
    }


    public function getIdAttribute($id)
    {
        return (string) $id;
    }

}