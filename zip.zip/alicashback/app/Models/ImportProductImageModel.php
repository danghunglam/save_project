<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class ImportProductImageModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'import_product_image';

    /**
     * @var array
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'product_id',
        'src',
        'status',
        'sort',
        'in_variant'
    ];
    /**
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function product()
    {
        return $this->belongsTo('App\Models\ImportProductModel', 'product_id', 'id');
    }
}