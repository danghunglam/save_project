<?php
declare(strict_types=1);
namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class SupplierModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'supplier';

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'name',
        'url',
        'email',
        'phone'
    ];

    /**
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function product()
    {
        return $this->hasMany('App\Models\ProductModel', 'supplier_id', 'id');
    }

}