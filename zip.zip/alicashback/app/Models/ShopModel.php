<?php
declare(strict_types=1);
namespace App\Models;


use Illuminate\Database\Eloquent\Model;

/**
 * Class ShopModel
 *
 * @package App\Models
 */
class ShopModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'shop';

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'name',
        'email',
        'domain',
        'country',
        'province',
        'address1',
        'zip',
        'city',
        'phone',
        'currency',
        'iana_timezone',
        'shop_owner',
        'plan_name',
        'myshopify_domain',
        'status',
        'is_version_app',
        'access_token',
        'public_token',
        'is_hide_video',
        'onboarding',
        'primary_location_id',
        'is_vote',
        'order_type_sync',
        'token_status',
        'plan_start_at',
        'plan_end_at',
        'plan_charge_name'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'plan_start_at',
        'plan_end_at'
    ];

    /**
     * @var array
     */
    protected $hidden = [
        // 'access_token'
    ];
    public function getIdAttribute($value)
    {
        return (float)($value);
    }
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function order()
    {
        return $this->hasMany('App\Models\OrdersModel', 'shop_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function setting()
    {
        return $this->hasMany('App\Models\SettingModel','shop_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function metas()
    {
        return $this->hasMany('App\Models\ShopMetaModel','shop_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function product()
    {
        return $this->hasMany('App\Models\ProductModel', 'shop_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subscribe()
    {
        return $this->hasMany('App\Models\SubscribeModel', 'shop_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function importProduct()
    {
        return $this->hasMany('App\Models\ImportProductModel', 'shop_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productType()
    {
        return $this->hasMany('App\Models\ProductTypeModel', 'shop_id', 'id')->where('product_type.type', 1);
    }
}