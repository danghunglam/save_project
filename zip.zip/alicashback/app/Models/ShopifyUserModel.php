<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShopifyUserModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'shopify_user';

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'first_name',
        'last_name',
        'email',
        'locale'
    ];

    /**
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    public function userShop()
    {
        return $this->hasMany('App\Models\UserShopModel', 'user_id', 'id');
    }
}