<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class ImportProductVariantModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'import_product_variant';

    /**
     * @var string
     */
    protected $primaryKey = 'id';
    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'aliexpress_sku_property',
        'aliexpress_options',
        'product_id',
        'image_id',
        'option1',
        'option2',
        'option3',
        'options',
        'title',
        'sku',
        'source_quantity',
        'source_price',
        'price',
        'compare_at_price',
        'selected'
    ];
    protected $dates = [
        'created_at',
        'updated_at'
    ];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function product()
    {
        return $this->belongsTo('App\Models\ImportProductModel', 'product_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function productImage()
    {
        return $this->belongsTo('App\Models\ImportProductImageModel', 'image_id','id');
    }
}