<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShopMetaModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'shop_meta';

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'key',
        'value',
        'shop_id'
    ];

    protected $dates = [
        'created_at',
        'updated_at'
    ];

    public function getIdAttribute($value)
    {
        return (float)($value);
    }
}
