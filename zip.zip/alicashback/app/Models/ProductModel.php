<?php
declare(strict_types=1);

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductModel extends Model
{
    use SoftDeletes;
    /**
     * @var string
     */
    protected $table = 'product';

    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'title',
        'handle',
        'body_html',
        'image',
        'custom_collection',
        'tag',
        'status',
        'source',
        'aliexpress_product_id',
        'source_product_link',
        'supplier_id',
        'shop_id',
        'auto_update_price',
        'total_quantity',
        'options',
        'deleted_at',
        'product_type',
        'title_source',
        'price_range'
    ];

    /**
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productVariant()
    {
        return $this->hasMany('App\Models\ProductVariantModel', 'product_id', 'id');
    }

    public function productVariantWithTrashed()
    {
        return $this->hasMany('App\Models\ProductVariantModel', 'product_id', 'id')->withTrashed();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function shop()
    {
        return $this->belongsTo('App\Models\ShopModel', 'shop_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function supplier()
    {
        return $this->belongsTo('App\Models\SupplierModel', 'supplier_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productImage()
    {
        return $this->hasMany('App\Models\ProductImageModel', 'product_id', 'id');
    }


    public function getIdAttribute($id)
    {
        return (string) $id;
    }
}
