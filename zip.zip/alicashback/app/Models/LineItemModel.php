<?php
declare(strict_types=1);

namespace App\Models;


use App\Events\UpdateTrackingCodeEvent;
use App\Helpers\Helpers;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class LineItemModel extends Model
{
    use Notifiable;
    /**
     * @var string
     */
    protected $table = 'line_item';

    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;

    /**
     * @var array
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'orders_id',
        'product_variant_id',
        'status',
        'quality',
        'price',
        'aliexpress_order_no',
        'tracking_code',
        'fulfillment_status',
        'fee_ship',
        'fee_tax',
        'price_order_aliexpress',
    ];


    /**
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

//    protected $appends = array('shop_id', 'rate_currency');

//    protected $dispatchesEvents = [
//        'updated' => UpdateTrackingCodeEvent::class
//    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function productVariant()
    {
        return $this->belongsTo('App\Models\ProductVariantModel', 'product_variant_id', 'id')->withTrashed();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function order()
    {
        return $this->belongsTo('App\Models\OrdersModel', 'orders_id', 'id');
    }

    /**
     * Accessor line_item_id
     * @return string
     */
//    public function getIdAttribute()
//    {
//        return (string) $this->attributes['id'];
//    }

//    public function getCreatedAtAttribute()
//    {
//        return date("Y-m-d\Th:i:s\Z", strtotime($this->attributes['created_at']));
//    }
//
//    public function getUpdatedAtAttribute()
//    {
//        return date("Y-m-d\Th:i:s\Z", strtotime($this->attributes['updated_at']));
//    }

    public function getPriceAttribute()
    {
        return (double) $this->attributes['price'];
    }

    public function getQualityAttribute()
    {
        return (int) $this->attributes['quality'];
    }

    public function getFeeShipAttribute()
    {
        return (double) $this->attributes['fee_ship'];
    }

    /**
     * @return float
     */
    public function getFeeTaxAttribute()
    {
        return (double) $this->attributes['fee_tax'];
    }

    public function getPriceOrderAliexpressAttribute()
    {
        return (double) $this->attributes['price_order_aliexpress'];
    }
}