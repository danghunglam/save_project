<?php
declare(strict_types=1);

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class PlanModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'plan';

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'plan_name',
        'trial',
        'price',
        'is_free',
        'created_at',
        'updated_at'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subscribe()
    {
        return $this->hasMany('App\Models\SubscribeModel', 'plan_id', 'id');
    }
}