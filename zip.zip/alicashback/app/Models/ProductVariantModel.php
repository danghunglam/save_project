<?php
declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductVariantModel extends Model
{
    use SoftDeletes;
    /**
     * @var string
     */
    protected $table = 'product_variant';
    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;
    /**
     * @var string
     */
    protected $primaryKey = 'id';
    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'aliexpress_sku_property',
        'aliexpress_options',
        'product_id',
        'image_id',
        'option1',
        'option2',
        'option3',
        'options',
        'title',
        'sku',
        'source_quantity',
        'source_price',
        'price',
        'compare_at_price',
        'aliexpress_product_id',
        'source_product_link',
        'supplier_id',
        'deleted_at',
        'inventory_item_id',
    ];
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function lineItem()
    {
        return $this->hasMany('App\Models\LineItemModel', 'product_variant_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function product()
    {
        return $this->belongsTo('App\Models\ProductModel', 'product_id', 'id')->withTrashed();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function productImage()
    {
        return $this->belongsTo('App\Models\ProductImageModel', 'image_id','id')->withTrashed();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function supplier()
    {
        return $this->belongsTo('App\Models\SupplierModel', 'supplier_id', 'id');
    }
    public function getIdAttribute($id)
    {
        return (string) $id;
    }
}