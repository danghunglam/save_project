<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserShopModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'user_shop';

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'user_id',
        'shop_id'
    ];

    /**
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\belongsTo
     */
    public function shop()
    {
        return $this->belongsTo('App\Models\ShopModel', 'shop_id', 'id');
    }
}