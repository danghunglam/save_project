<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductTypeModel extends Model
{
    use SoftDeletes;
    /**
     * @var string
     */
    protected $table = 'product_type';

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'name',
        'type',
        'shop_id',
        'deleted_at',
    ];

}
