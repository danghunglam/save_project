<?php
declare(strict_types=1);

namespace App\Models;


use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class SettingModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'setting';

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'shop_id',
        'key',
        'value',
        'created_at',
        'updated_at'
    ];

    public function shop()
    {
        $this->belongsTo('App\Models\ShopModel', 'id', 'shop_id');
    }

    /**
     * @param $value
     * @return mixed
     */
    public function getValueAttribute($value)
    {
        if($this->getAttribute('key') === 'price_rule')
            return \GuzzleHttp\json_decode($value);

        return $value;
    }

    /**
     * @param $value
     */
    public function setValueAttribute($value)
    {
        if($this->getAttribute('key') === 'price_rule')
            $this->attributes['value'] = \GuzzleHttp\json_encode($value);
        else
            $this->attributes['value'] = $value;
    }

}