<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
/**
 * Class AliexpressOrderHistory
 * @package App\Models
 */
class AliexpressOrderHistory extends Model
{
    /**
     * @var string
     */
    protected $table = 'aliexpress_order_history';
    /**
     * @var string
     */
    protected $primaryKey = 'id';
    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'line_item_id',
        'orders_id',
        'aliexpress_order_no',
        'fee_ship',
        'fee_tax',
        'price_order_aliexpress',
        'captcha',
        'shop_id'
    ];
}