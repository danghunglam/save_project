<?php
declare(strict_types=1);

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class SubscribeModel extends Model
{
    /**
     * @var string
     */
    protected $table = 'subscribe';

    /**
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'shop_id',
        'plan_id',
        'subscribe_date',
        'start_charged_date',
        'unsubscribe_date',
        'created_at',
        'updated_at'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function shop()
    {
        return $this->belongsTo('App\Models\ShopModel', 'shop_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function plan()
    {
        return $this->belongsTo('App\Models\PlanModel', 'plan_id', 'id');
    }

}