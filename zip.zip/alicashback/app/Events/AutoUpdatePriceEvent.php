<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class AutoUpdatePriceEvent
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * @var
     */
    public $_autoUpdate;
    /**
     * @var
     */
    public $_primaryEmailAddress;
    /**
     * @var
     */
    public $_shop;
    /**
     * @var
     */
    public $_productId;

    /**
     * @var
     */
    public $_data;

    /**
     * AutoUpdatePrice constructor.
     * @param $auto_update
     * @param $primary_email_address
     * @param $shop
     * @param $productId
     */
    public function __construct($auto_update, $primary_email_address, $shop, $productId, $data)
    {
        $this->_autoUpdate = $auto_update;
        $this->_primaryEmailAddress = $primary_email_address;
        $this->_shop = $shop;
        $this->_productId = $productId;
        $this->_data = $data;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
