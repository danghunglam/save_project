<?php

namespace App\Events;

use App\Models\LineItemModel;
use App\Models\ShopModel;
use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class UpdateAliexpressEvent
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $_lineItemModel;

    public $_status;

    public $_type;
    /**
     * UpdateTrackingCodeEvent constructor.
     *
     * @param LineItemModel $lineItem
     * @param               $status
     * @param $type
     */
    public function __construct(LineItemModel $lineItem, $status, $type)
    {
        $this->_lineItemModel = $lineItem;

        $this->_status = $status;

        $this->_type = $type;

    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
