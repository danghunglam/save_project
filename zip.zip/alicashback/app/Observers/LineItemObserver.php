<?php

namespace App\Observers;


use App\Models\LineItemModel;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;

class LineItemObserver
{
    public function created(LineItemModel $model)
    {

    }

    public function updated(LineItemModel $model)
    {
    }

    public function deleted(LineItemModel $model)
    {

    }
}