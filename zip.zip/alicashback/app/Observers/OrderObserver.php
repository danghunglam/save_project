<?php

namespace App\Observers;


use App\Models\OrdersModel;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;

class OrderObserver
{
    public function created(OrdersModel $model)
    {
        $client = new Client();
        $data = [
            'id' => $model['id'],
            'body' => [
                'order_number' => isset($model['order_number']) ? $model['order_number'] : null,
                'order_name' => isset($model['order_name']) ? $model['order_name'] : null,
                'first_name' => isset($model['first_name']) ? $model['first_name'] : null,
                'last_name' => isset($model['last_name']) ? $model['last_name'] : null,
                'city' => isset($model['city']) ? $model['city'] : null,
                'country' => isset($model['country']) ? $model['country'] : null,
                'country_code' => isset($model['country_code']) ? $model['country_code'] : null,
                'province' => isset($model['province']) ? $model['province'] : null,
                'province_code' => isset($model['province_code']) ? $model['province_code'] : null,
                'address1' => isset($model['address1']) ? $model['address1'] : null,
                'address2' => isset($model['address2']) ? $model['address2'] : null,
                'zip' => isset($model['zip']) ? $model['zip'] : null,
                'phone' => isset($model['phone']) ? $model['phone'] : null,
                'email' => isset($model['email']) ? $model['email'] : null,
                'fulfillment_status' => isset($model['fulfillment_status']) ? $model['fulfillment_status'] : null,
                'financial_status' => isset($model['financial_status']) ? $model['financial_status'] : null,
                'created_at' => isset($model['created_at']) ? $model['created_at'] : null,
                'updated_at' => isset($model['updated_at']) ? $model['updated_at'] : null,
                'currency' => isset($model['currency']) ? $model['currency'] : null,
                'shop_id' => isset($model['shop_id']) ? $model['shop_id'] : null,
                'phone_code' => isset($model['phone_code']) ? $model['phone_code'] : null,
                'full_name' => isset($model['full_name']) ? $model['full_name'] : null
            ]
        ];

    }

    public function updated(OrdersModel $model)
    {
        $client = new Client();
//        $client->request('post', 'https://hooks.slack.com/services/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',
//            [
//                'headers' => [
//                    'Content-Type' => 'application/json',
//                ],
//                'body' => json_encode([
//                    'text' => 'OrderObserver updated'
//                ])
//            ]
//        );
        $data = [
            'id' => $model['id'],
            'body' => [
                'order_number' => isset($model['order_number']) ? $model['order_number'] : null,
                'order_name' => isset($model['order_name']) ? $model['order_name'] : null,
                'first_name' => isset($model['first_name']) ? $model['first_name'] : null,
                'last_name' => isset($model['last_name']) ? $model['last_name'] : null,
                'city' => isset($model['city']) ? $model['city'] : null,
                'country' => isset($model['country']) ? $model['country'] : null,
                'country_code' => isset($model['country_code']) ? $model['country_code'] : null,
                'province' => isset($model['province']) ? $model['province'] : null,
                'province_code' => isset($model['province_code']) ? $model['province_code'] : null,
                'address1' => isset($model['address1']) ? $model['address1'] : null,
                'address2' => isset($model['address2']) ? $model['address2'] : null,
                'zip' => isset($model['zip']) ? $model['zip'] : null,
                'phone' => isset($model['phone']) ? $model['phone'] : null,
                'email' => isset($model['email']) ? $model['email'] : null,
                'fulfillment_status' => isset($model['fulfillment_status']) ? $model['fulfillment_status'] : null,
                'financial_status' => isset($model['financial_status']) ? $model['financial_status'] : null,
                'created_at' => isset($model['created_at']) ? $model['created_at'] : null,
                'updated_at' => isset($model['updated_at']) ? $model['updated_at'] : null,
                'currency' => isset($model['currency']) ? $model['currency'] : null,
                'shop_id' => isset($model['shop_id']) ? $model['shop_id'] : null,
                'phone_code' => isset($model['phone_code']) ? $model['phone_code'] : null,
                'full_name' => isset($model['full_name']) ? $model['full_name'] : null
            ]
        ];
//        $client->request('post', 'https://hooks.slack.com/services/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',
//            [
//                'headers' => [
//                    'Content-Type' => 'application/json',
//                ],
//                'body' => json_encode([
//                    'text' => json_encode($data)
//                ])
//            ]
//        );

    }
}