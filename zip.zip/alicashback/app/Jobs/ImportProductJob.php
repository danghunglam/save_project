<?php

namespace App\Jobs;

use App\Events\AppsErrorEvent;
use Exception;
use App\Events\ImportProductEvent;
use App\Helpers\Helpers;
use App\Helpers\ProductHelper;
use App\Helpers\ProductTypeHelper;
use App\ShopifyApi\CollectsApi;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Bus\Queueable;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Repository\ImportProductRepository;
use App\ShopifyApi\ProductsApi;
use App\ShopifyApi\ProductImageApi;
use App\ShopifyApi\InventoryLevelApi;
use App\ShopifyApi\ShopsApi;
use App\Repository\ProductRepository;
use App\Repository\ProductVariantRepository;
use App\Repository\ProductImageRepository;
use App\Repository\ShopRepository;
use App\Repository\ShopMetaRepository;
use App\Models\ShopModel;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use Pusher\Pusher;

class ImportProductJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shopId;
    private $_shopDomain;
    private $_accessToken;
    private $_product;
    private $_created = false;

    /**
     * ImportProductJob constructor.
     *
     * @param $shopId
     * @param $shopDomain
     * @param $accessToken
     * @param $products
     */
    public function __construct($shopId, $_product, $shopDomain, $accessToken)
    {
        $this->_shopId = $shopId;
        $this->_product = $_product;
        $this->_shopDomain = $shopDomain;
        $this->_accessToken = $accessToken;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $productApi = new ProductsApi($this->_shopDomain, $this->_accessToken);
        $collectApi = new CollectsApi($this->_shopDomain, $this->_accessToken);
        $shopRepository = new ShopRepository();
        // $isLimit = $shopRepository->checkLimitProduct($this->_shopId);   
        // $planInfo = $shopRepository->serviceGetPlanInfo($this->_shopId, ['product']);
        // if($planInfo['product']['current_product'] >= $planInfo['product']['limit_product']) {
        //     $this->restoreProduct();
        //     $this->setOverrideQueueCache(null, 'error');
        //     event(new AppsErrorEvent());
        //     return false;
        // }

        $product = $this->_product;
        $productVariants = $product['variants'];
        $product['variants'] = [];

        $customCollection = $product['custom_collection'];
        $resource = [
            'title' => $product['title'],
            'body_html' => $product['body_html'],
            'tags' => $product['tag'],
            'product_type' => $product['product_type']
        ];

        //Add big image
        $resource['images'][] = [
            'src' => $product['image']
        ];

//        $resource_first = $resource;


        $total_inventory_quantity = 0;

        $images = collect($product['images'])->sortBy('sort');
        //Add product and image
        foreach ($images as $image)
        {
            if($image['status'] && ! $image['in_variant'] && $image['id'] !== config('common.product_image_id_default'))
                $resource['images'][] = [
                    'src' => $image['src']
                ];
        }
        foreach ($productVariants as $k => $variant)
        {
            if($variant['selected']){
                $resource['variants'][] = [
                    'option1'               => isset($variant['option1']) ? $variant['option1'] : 'Default title '.$k,
                    'option2'               => isset($variant['option2']) ? $variant['option2'] : null,
                    'option3'               => isset($variant['option3']) ? $variant['option3'] : null,
                    'price'                 => isset($variant['price']) ? floatval($variant['price']) : 0,
                    'image'                 => $variant['image'],
                    'compare_at_price'      => $variant['compare_at_price']==null? null : floatval($variant['compare_at_price']),
                    'inventory_quantity'    => $variant['inventory_quantity'],
                    'sku'                   => $variant['sku'],
                    'inventory_management' => 'shopify'
                ];
                $total_inventory_quantity = $total_inventory_quantity+$variant['inventory_quantity'];
                $product['variants'][] = $variant;
            }
        }
        if(empty($product['options']) || (isset($product['options'][0]) && empty($product['options'][0])))
            $resource['options'] = [
                [
                    'name' => 'Title',
                    'position' => 1
                ]
            ];
        else
            $resource['options'] = $product['options'];

        //Add first product
        $lastProduct = $this->firstAdd($resource, $product, $total_inventory_quantity);
        if(! $lastProduct) {
            return false;
        }

//        $resProduct = $productApi->update($lastProduct->id, $resource);
//        if( ! $resProduct['status']) {
//            $this->writeLog(['error' => 'Update product api error']);
//            return false;
//        }


        //Get info last product created
//        $lastProduct = $lastProduct['data']->product;

        if(is_array($customCollection))
        {
            //Update collection to product
            foreach($customCollection as $collect)
                $collectApi->create($lastProduct->id, $collect);
        }
        //Update variant image
        $this->updateVariantImage($lastProduct, $product);

        //Re get last product update and update database
        $lastProduct = $productApi->detail(['id','title','handle', 'variants', 'images', 'image', 'product_type'], $lastProduct->id);
        //Insert product to database
        if($lastProduct['status'])
            if( ! $this->insertProduct($this->_shopId, $lastProduct['data']->product, $product))
            {
                event(new AppsErrorEvent());
            }

        //Delete product in database
        if( ! $this->deleteImportProduct($this->_shopId, $product))
        {
            event(new AppsErrorEvent());
        }

    }

    public function failed(Exception $exception) {
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );
        //Set override process
        $product = $this->_product;
        $productTrigger = [
            'status' => 'error',
            'id' => $product['id']
        ];
        $productTrigger['tooltip_message'] = 'Please reload and push product again';
        if(!$this->_created) {
            $this->restoreProduct();
        }
        $trigged = $pusher->trigger(strval($this->_shopId), 'import_product', ['product' => $productTrigger]);
    }

    private function restoreProduct() {
        $product = $this->_product;
        $importProductRepo = app(ImportProductRepository::class);
        $importProductRepo->update($this->_shopId, $product['id'], ['is_import' => null]);
    }

    /**
     * Insert product to database
     * @param $shopId
     * @param $productApi
     * @param $product
     *
     * @return bool
     */
    private function insertProduct($shopId, $productApi, $product)
    {
        $productRepo = new ProductRepository($shopId);
        $inventoryLevelApi = new InventoryLevelApi($this->_shopDomain, $this->_accessToken);
//        $shopsApi = new ShopsApi($this->_shopDomain, $this->_accessToken);
        $productVariantRepo = app(ProductVariantRepository::class);
        $productImageRepo = app(ProductImageRepository::class);
        $shopRepository = new ShopRepository();
        $shop = ShopModel::find($shopId);

        $productApi = json_decode(json_encode($productApi), true);
//        $shopsApiData = $shopsApi->get();
//        $shopsApiData = (array) $shopsApiData['data']->shop;
        if( ! $shop)
            return false;

        $productApi['aliexpress_product_id'] = $product['aliexpress_product_id'];
        $productApi['source_product_link'] = $product['source_product_link'];
        $productApi['supplier_id'] = $product['supplier_id'];
        $productApi['auto_update_price'] = ($product['auto_update_price']) ? config('product.auto_update_price.automatic_price_updates_on') : config('product.auto_update_price.price_update_off');
        $productApi['image'] = isset($product['image']) ? $product['image'] : config('common.default_image');
        $productApi['options'] = json_encode($product['options'],JSON_UNESCAPED_UNICODE);
        $productApi['title_source'] = $product['title_source'];
        $productApi['price_range'] = $product['price_range'];
        $productApi['tag'] = $product['tag'];
        $productApi['custom_collection'] = json_encode($product['custom_collection']);
        if(isset($product['total_quantity'])) {
            $productApi['total_quantity'] = $product['total_quantity'];
        }

        if($productRepo->save($productApi))
        {
            //Save Product Image
            $productImageRepo->saveMany($productApi['id'], $productApi['images']);
            $total_inventory_quantity = 0;
            //Save Product Variant
            foreach ($productApi['variants'] as $variant)
            {
                foreach ($product['variants'] as $prd_variant)
                {
                    if($variant['sku'] === $prd_variant['sku'])
                    {
                        $variant['aliexpress_options'] = $prd_variant['aliexpress_options'];
                        $variant['source_price'] = $prd_variant['source_price'];
                    }
                }
                $variant['source_quantity'] = $variant['inventory_quantity'];
                $variant['aliexpress_product_id'] = $product['aliexpress_product_id'];
                $variant['source_product_link'] = $product['source_product_link'];
                $variant['supplier_id'] = $product['supplier_id'];
                $total_inventory_quantity += ($variant['source_quantity'] ? $variant['source_quantity'] : 0);
                $productVariantRepo->save($productApi['id'], $variant);
                // Import inventory_quantity for product with default primary_location_id
                // sleep(rand(0, 3));
                // $inventoryLevelApi->setAvailable($variant['inventory_item_id'], $shop->primary_location_id , $variant['source_quantity']);
            }
            // $productRepo->update($productApi['id'], ['total_quantity' => $total_inventory_quantity]);
            if($productApi['product_type']) {
                ProductTypeHelper::createProductType($this->_shopId, $productApi['product_type']);
            }
            return true;
        }
        return false;
    }

    /**
     * Handle delete product import from database after save api product
     * @param $shopId
     * @param $product
     *
     * @return bool
     */
    private function deleteImportProduct($shopId, $product)
    {
        $importProductRepo = app(ImportProductRepository::class);

        if( ! $importProductRepo->delete($shopId, $product['id']))
            return false;

        return true;
    }

    private function updateVariantImage($lastProduct, $product)
    {
        $list_image = [];
        $obj_images_variant = [];
        $productImageApi = new ProductImageApi($this->_shopDomain, $this->_accessToken);

        foreach ($product['variants'] as $k => $variant)
        {
            if($variant['image_status']) {
                if($check = $this->checkImageInVariant($list_image, $variant['image'])) {
                    $obj_images_variant[$check['key']]['src'] = $variant['image'];
                    $obj_images_variant[$check['key']]['variant_ids'][] = $lastProduct->variants[$k]->id;
                } else {
                    $list_image[] = [
                        'link' => $variant['image'],
                        'key' => $k
                    ];
                    $obj_images_variant[$k]['src'] = $variant['image'];
                    $obj_images_variant[$k]['variant_ids'][] = $lastProduct->variants[$k]->id;
                }
            }
        }
        foreach ($obj_images_variant as $image_variant)
        {
            $product = $productImageApi->create($lastProduct->id, $image_variant);
            sleep(1);
        }
    }


    private function firstAdd($resource, $product, $total_inventory_quantity)
    {
        $productApi = new ProductsApi($this->_shopDomain, $this->_accessToken);
        $shopMetaRepo = new ShopMetaRepository();
        $last = $productApi->create($resource);
        if($last['status'])
        {
            $this->_created = true;
            $last = $last['data']->product;
            $last->variants[0]->inventory_quantity = $total_inventory_quantity;
            // Code get alireview frontend backup in branch -> backup-source-import-review-in-import-list
            $this->setOverrideQueueCache($last->id, 'success');
            $product['total_quantity'] = $total_inventory_quantity;
            $this->insertProduct($this->_shopId, $last, $product);
            // $shopMetaRepo->incrementLimitProduct($this->_shopId);
            return $last;
        }
        $this->setOverrideQueueCache(null, 'error');
        $this->restoreProduct();
        $this->writeLog($resource, $last);
        return false;
    }

    private function writeLog($resource, $data) {
        Log::info([
            'resource' => $resource,
            'data' => $data
        ]);
    }


    private function setOverrideQueueCache($productId, $status)
    {
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );
        //Set override process
        $product = $this->_product;
        $productTrigger = [
            'product_link' => 'https://' . $this->_shopDomain . '/admin/products/' . $productId,
            'status' => $status,
            'id' => $product['id']
        ];
        $productTrigger['tooltip_message'] = ($status == 'success') ? 'Push product to shop successfully' : 'Please reload and push product again';
        $trigged = $pusher->trigger(strval($this->_shopId), 'import_product', ['product' => $productTrigger]);
        $product['status'] = $status;
        $overrideProcess = Helpers::getOverrideProcessCache($this->_shopId, 'import_product');
        foreach($overrideProcess as $key => $process) {
            if( (isset($process['status']) &&  $process['status'] === 'success') 
                || (isset($process['id']) &&  $process['id'] === $product['id']))
            {
                unset($overrideProcess[$key]);
            }
        }
        Helpers::setOverrideProcessCache($this->_shopId, $overrideProcess, 'import_product');
    }

    private function checkImageInVariant($list_image, $link)
    {
        foreach($list_image as $image) {
            if($link == $image['link'])
                return $image;
        }
        return false;
    }
}
