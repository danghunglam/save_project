<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use App\Events\UpdateAliexpressEvent;
use App\Models\LineItemModel;
use App\Models\OrdersModel;
use App\Models\ShopModel;
use App\Repository\LineItemRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\OrderRepository;
use App\ShopifyApi\FulfillmentApi;
use App\ShopifyApi\OrdersApi;


class RefulfillJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    
    private $_order_id;

    private $_shop_id;
    
    private $_shop_domain;
    
    private $_access_token;

    private $_fulfillment_services;

    /**
     * RefulfillJob constructor.
     * @param $line_items
     * @param $tracking_code
     * @param $shop_id
     * @param $shop_domain
     * @param $access_token
     */
    public function __construct($order_id, $shop_id, $shop_domain, $access_token, $fulfillment_services)
    {
        $this->_order_id = $order_id;

        $this->_shop_id = $shop_id;

        $this->_shop_domain = $shop_domain;

        $this->_access_token = $access_token;

        $this->_fulfillment_services = $fulfillment_services;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $order_id = $this->_order_id;
        $shop_id = $this->_shop_id;
        $fulfillmentServices = $this->_fulfillment_services;
        $order = OrdersModel::find($order_id);

        // Get shop info -> location_id
        $shop = ShopModel::find($shop_id);
        $primary_location_id = $shop->primary_location_id;

        if(!$order)
            return false;
        

        $ordersApi = new OrdersApi($this->_shop_domain, $this->_access_token);
        $orderDetail = $ordersApi->detail($order_id, ['id', 'line_items']);
        if(!$orderDetail['status']) {
            return false;
        } else {
            $orderLineItems = $orderDetail['data']->order->line_items;
            $fulfillment_service_name = null;
            $lineItemsDB = collect(LineItemModel::where('orders_id', $order_id)->get())->keyBy('id'); // get list lineItem in db
            foreach($orderLineItems as $orderLineItem) {
                if($orderLineItem->fulfillment_status != 'fulfilled') {
                    $locationId = $primary_location_id;
                    $isUseFulfillService = false;
                    if($orderLineItem->fulfillment_service != 'manual') {
                        if(isset($fulfillmentServices[$orderLineItem->fulfillment_service])) {
                            $locationId = $fulfillmentServices[$orderLineItem->fulfillment_service]->location_id;
                            $isUseFulfillService = true;
                        }
                    }
                    $this->fulfillLineItems($orderLineItem->id, $lineItemsDB[$orderLineItem->id]->tracking_code, $locationId, $isUseFulfillService);
                }
            }
        }
    }

    public function fulfillLineItems($lineItemId, $trackingCode, $locationId, $isUseFulfillService) {
        $fulfillment = [
            'location_id' => $locationId,
            'tracking_number' => $trackingCode,
            'line_items' => [
                [
                    'id' => $lineItemId
                ]
            ]
        ];
        // call api to create fulfillment
        $fulfillmentApi = new FulfillmentApi($this->_shop_domain, $this->_access_token);
        $isUpdateFulfillment = $fulfillmentApi->create($this->_order_id, $fulfillment);

        if(!$isUpdateFulfillment['status']) {
            sleep(2);
            $isUpdateFulfillment = $fulfillmentApi->create($this->_order_id, $fulfillment);
            if(!$isUpdateFulfillment['status']) {
                return false;
            }
        }

        if($isUpdateFulfillment['status'] == false) {
            if($isUpdateFulfillment['response']) {
                $responseMessage = json_encode($isUpdateFulfillment['response']);
                if(strpos($responseMessage, 'is already fulfilled')) {
                    $allCurrentFulfillment = $fulfillmentApi->all($this->_order_id);
                    if($allCurrentFulfillment['status'] && isset($allCurrentFulfillment['data']->fulfillments)) {
                        $fulfillmentData = $allCurrentFulfillment['data']->fulfillments;
                        foreach ($fulfillmentData as $key => $fulfill) {
                            if($fulfill->status == 'pending') {
                                $correntFulfillment = count(array_filter($fulfill->line_items, function ($line_item) use ($lineItemId) {
                                    return $lineItemId == $line_item->id;
                                }));
                                if($correntFulfillment > 0) {
                                    $fulfillmentApi->complete($this->_order_id, $fulfill->id);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if($isUseFulfillService) {
                if(isset($isUpdateFulfillment['data']->fulfillment)) {
                    $fulfillmentFromSpf = $isUpdateFulfillment['data']->fulfillment;
                    if($fulfillmentFromSpf->status == 'pending') {
                        $fulfillmentApi->complete($this->_order_id, $fulfillmentFromSpf->id);
                    }
                }
            }
        }        
    }
}
