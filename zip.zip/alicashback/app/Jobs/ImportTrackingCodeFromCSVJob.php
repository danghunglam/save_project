<?php
/**
 * Created by PhpStorm.
 * User: hunglam
 * Date: 26/07/2018
 * Time: 11:36
 */

namespace App\Jobs;

use App\Helpers\Helpers;
use App\Repository\TrackingCodeRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use PHPExcel;
use PHPExcel_IOFactory;
use PHPExcel_Writer_CSV;
use Pusher\Pusher;

class ImportTrackingCodeFromCSVJob
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_data;

    /**
     * ImportTrackingCodeFromCSVJob constructor.
     * @param $data
     */
    public function __construct($data)
    {

        $this->_data = $data;
    }

    /**
     * Execute the job.
     *
     * @return mixed
     */
    public function handle()
    {
//
        $data = $this->_data['data']['data'];

        for ($i=0; $i < count($data) ; ++$i){
            if($i==0) continue;
            $a = array_column($data[$i],0);
            $datas[$data[$i][0]][] = $data[$i];

        }

        $trackingCodeRepository = new TrackingCodeRepository();
        $import = $trackingCodeRepository->import($datas);
        if($import){
            $this->setOverrideQueueCache($import);
            return true;
        }
    }

    private function setOverrideQueueCache($import)
    {
        $shopId = session('shopId');
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );

        $pusher->trigger(strval($shopId), 'tracking_code_from_file', ['product' =>['id'=>$this->_data['data']['time']]]);

        //Set override process
        $product = $import;
        $product['status'] = 'success';
        $overrideProcess = Helpers::getOverrideProcessCache($shopId, 'tracking_code_from_file');
        array_push($overrideProcess, $product);
        Helpers::setOverrideProcessCache($shopId, $overrideProcess, 'tracking_code_from_file');
    }
}