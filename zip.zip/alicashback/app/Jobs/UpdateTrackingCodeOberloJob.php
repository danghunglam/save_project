<?php

namespace App\Jobs;

use App\Models\LineItemModel;
use App\Models\ShopModel;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\OrderRepository;
use App\ShopifyApi\FulfillmentApi;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\ShopifyApi\OrdersApi;
use App\ShopifyApi\FulfillmentServiceApi;

class UpdateTrackingCodeOberloJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_data;

    private $_publicToken;

    /**
     * UpdateMultiTrackingCodeOberloJob constructor.
     * @param $data
     * @param $publicToken
     */
    public function __construct($data, $publicToken)
    {
        $this->_data = $data;
        $this->_publicToken = $publicToken;
    }

    /**
     * Execute the job.
     *
     * @return mixed
     */
    public function handle()
    {
        $data = $this->_data;
        $shopRepo = app(ShopRepository::class);
        $shop = $shopRepo->getAttributes(['public_token' => $this->_publicToken]);
        if( ! $shop)
            return false;

        $lineItems = LineItemModel::where('aliexpress_order_no', $data['aliexpress_order_no'])->update([
            'tracking_code' => $data['tracking_code'],
            'status' => config('order.status.shipped'),
            'fulfillment_status' => config('order.fulfillment_status.fulfilled'),
        ]);
        if($lineItems)
        {
            $lineItems = LineItemModel::where('aliexpress_order_no', $data['aliexpress_order_no'])->get();

            /**
             * @var SettingRepository
             */
            $settingRepo = new SettingRepository($shop->id);
            $notification_email_customer_fulfillment = $settingRepo->getKey('notification_email_customer_fulfillment');
            $default_fulfillment_tracking_url = $settingRepo->getKey('default_fulfillment_tracking_url');
            foreach ($lineItems as $lineItem)
            {

                // Get location id
                $ordersApi = new OrdersApi($shop->myshopify_domain, $shop->access_token);
                $fulfillmentServiceApi = new FulfillmentServiceApi($shop->myshopify_domain, $shop->access_token);
                $orderRepo = app(OrderRepository::class);

                $location_id = $orderRepo->getFulfillLocationId($shop->myshopify_domain, $shop->access_token, $lineItem->order->id, $lineItem->id);

                $isUseFulfillService = ($location_id != $shop->primary_location_id) ? true : false;
                // end get location

                $fulfillment = [
                    'location_id' => $location_id,
                    'tracking_number' => $data['tracking_code'],
                    'line_items' => [
                        [
                            'id' => $lineItem->id
                        ]
                    ],
                    'notify_customer' => false
                ];

                if(isset($notification_email_customer_fulfillment->value) and $notification_email_customer_fulfillment->value == 1)
                    $fulfillment['notify_customer'] = true;

                if(isset($default_fulfillment_tracking_url->value) and  filter_var($default_fulfillment_tracking_url->value, FILTER_VALIDATE_URL))
                    $fulfillment['tracking_url'] = $default_fulfillment_tracking_url->value;
                
                //Update Fulfillment api
                $fulfillmentApi = new FulfillmentApi($shop->myshopify_domain, $shop->access_token);

                $fulfillmentFromSpf = $fulfillmentApi->create($lineItem->order->id, $fulfillment);

                // update status fulfillment if current status is pending and use fulfill service
                if($isUseFulfillService) {
                    if(isset($isUpdateFulfillment['data']->fulfillment)) {
                        $fulfillmentFromSpf = $isUpdateFulfillment['data']->fulfillment;
                        if($fulfillmentFromSpf->status == 'pending') {
                            $fulfillmentApi->complete($orderId, $fulfillmentFromSpf->id);
                        }
                    }
                }
                //

                sleep(3);
            }
        }
    }
}
