<?php
/**
 * Created by PhpStorm.
 * User: hunglam
 * Date: 28/02/2019
 * Time: 09:24
 */

namespace App\Jobs;

use App\Contracts\Services\CurrencyRate;
use App\Repository\Extension\ExtensionImportProductRepository;
use App\Helpers\SettingHelper;
use App\Models\ImportProductModel;
use App\Models\SettingModel;
use App\Repository\ImportProductVariantRepository;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\Log;
use Pusher\Pusher;
use App\Helpers\PusherHelper;

class AddRuleImportSettingsToProductImportListJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shopId ;

    private $_shop;

    private $_total_products;

    /**
     * OverrideProductJob constructor.
     * @param $shopId
     * @param $shop
     */
    public function __construct($shopId,$shop)
    {
        $this->_shopId = $shopId;
        $this->_shop = $shop;
    }

    public function handle(){

        $shop = $this->_shop;
        $settings = $shop->setting;
        $settings = SettingHelper::decodeSettings($settings);
        $currency_rate = app(CurrencyRate::class);
        $setNewPrice = app(ExtensionImportProductRepository::class);
        $importProductVariantRepo = app(ImportProductVariantRepository::class);

//        $settings = json_decode($settings,true);
        $isConvertCurrency = SettingModel::where('shop_id', $this->_shopId)->where('key', 'is_convert_currency')->first();
        $isConvertCurrency = ($isConvertCurrency && $isConvertCurrency->value == "1") ? true : false;
        $currency = $isConvertCurrency ? $shop->currency : 'USD';
        $currencyExchange = $currency_rate->convertFromUsd(1, $currency);

        $priceRule = $settings['price_rule'];
        $restPriceRule = $settings['rest_of_the_price_ranges'];
        $isComparedPrice = $settings['is_compared_price'];
        $centPrice = [
            'assign_cent_price_check' => $settings['assign_cent_price_check'],
            'assign_cent_price' => $settings['assign_cent_price'],
            'assign_cent_compare_at_check' => $settings['assign_cent_compare_at_check'],
            'assign_cent_compare_at' => $settings['assign_cent_compare_at']
        ];

        $products = $shop->importProduct;

        if(! $products) {
            $this->confirm(-1);
            return false;
        }

        $count_product = count($products);

        $this->_total_products = $count_product;


        foreach ($products as $product){

            $product = ImportProductModel::find($product['id']);

            $variants = $product->productVariant;

            if(!$variants) {

                $this->confirm(-1);
                return false;
            }

            foreach ($variants as $variant){

                $new_price = $setNewPrice->setPrice($variant['source_price'], $priceRule, $restPriceRule, $isComparedPrice, $currencyExchange, $isConvertCurrency, $centPrice);

                // set new value for variant
                $variant['price'] = $new_price['price'];
                $variant['compare_at_price'] = 0;

                if($isComparedPrice)
                    $variant['compare_at_price'] = $new_price['compare_at_price'];

                //-------------------------------------------

                $importProductVariantRepo->update($variant['id'],json_decode(json_encode($variant), true));

            }

            $this->confirm(--$count_product);

        }
    }

    public function confirm($count_product){
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );

        $pusher->set_logger(new PusherHelper());
        $pusher->trigger(strval($this->_shopId), 'add_rule_product', ['product' => ['count_product' => $count_product, 'total_products'=>$this->_total_products, 'status' => 'pending' ]]);

//        Helpers::removeProcessCache($this->_shopId, $product, 'add_rule_product');
    }
}