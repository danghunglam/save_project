<?php

namespace App\Jobs;

use App\Helpers\ProductHelper;
use App\Helpers\ProductTypeHelper;
use App\Repository\ProductImageRepository;
use App\Repository\ProductRepository;
use App\Repository\ProductVariantRepository;
use App\Repository\ShopRepository;
use App\ShopifyApi\CollectsApi;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class UpdateProductWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop;

    private $_data;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($shop, $data)
    {
        $this->_shop = $shop;

        $this->_data = $data;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $objectShop = $this->_shop;
        $res = $this->_data;
        $collectApi = new CollectsApi($objectShop->myshopify_domain, $objectShop->access_token);
        $currentCollectSpf = $collectApi->get(['product_id' => $res['id']]);
        if($currentCollectSpf['status']) {
            if(isset($currentCollectSpf['data']->collects)) {
                $collects = $currentCollectSpf['data']->collects;
                $collectDB = [];
                $collectDB = array_map(function ($collect) {
                    return $collect->collection_id;
                }, $collects);
                $res['custom_collection'] = json_encode($collectDB);
            }
        }
        $shopRepo = new ShopRepository();
        $productRepo = new ProductRepository($objectShop->id);
        $productVariantRepo = new ProductVariantRepository();
        $productImageRepo = new ProductImageRepository();

        if ($objectShop )
        {
            $res['image'] = isset($res['image']['src']) ? $res['image']['src'] : config('common.default_image');
            $res['options'] = ProductHelper::convertOptions($res['options']);
            $res['tag'] = $res['tags'];
            ProductTypeHelper::editProductType($objectShop->id, $res['id'], $res['product_type']);
            $create = $productRepo->save($res);
            if($create)
            {
                $productImageRepo->deleteByProductId($res['id']);
                $productVariantRepo->deleteByProductId($res['id']);
                $productImageRepo->saveMany($res['id'], $res['images']);
                $productVariantRepo->saveMany($res['id'], $res['variants']);
                $shopRepo->updateSingleTotalQuantityProduct($res['id']);
            }
        }
    }
}
