<?php

namespace App\Jobs;

use App\Models\ShopModel;
use App\Repository\ShopRepository;
use App\ShopifyApi\ShopsApi;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class UpdateLocationShopJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $shopRepo = new ShopRepository();
        $shops = ShopModel::where('status',1)->get();

        foreach ($shops as $shop){

            $shopApi = new ShopsApi($shop->myshopify_domain, $shop->access_token);

            $shopInfoApi = $shopApi->get();

            if(!$shopInfoApi['status']) continue;

            $shopRepo->createOrUpdate($shop->id, ["primary_location_id"=>$shopInfoApi['data']->shop->primary_location_id]);
        }
    }
}
