<?php

namespace App\Jobs;

use GuzzleHttp\Client;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Repository\OrderRepository;
use App\Repository\ShopRepository;

class FulfillmentWithTrackingCodeJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop_id;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($shop_id)
    {
        $this->_shop_id = $shop_id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $orderRepo = app(OrderRepository::class);
        $shopRepo = new ShopRepository();
        $shop = $shopRepo->detail($this->_shop_id);
        $lineItems = $orderRepo->getLineItemUnfulfillHasTrackingCode($this->_shop_id);
        $fulfillmentData = [];
        if(count($lineItems) > 0) {
            foreach($lineItems->toArray() as $lineItem) {
                if(!isset($fulfillmentData[$lineItem['orders_id']])) {
                    $fulfillmentData[$lineItem['orders_id']][$lineItem['tracking_code']] = [$lineItem['id']];
                } else {
                    if(!isset($fulfillmentData[$lineItem['orders_id']][$lineItem['tracking_code']])) {
                        $fulfillmentData[$lineItem['orders_id']][$lineItem['tracking_code']] = [$lineItem['id']];
                    } else {
                        $fulfillmentData[$lineItem['orders_id']][$lineItem['tracking_code']][] = $lineItem['id'];
                    }
                }
            }
        }
        foreach($fulfillmentData as $orderId => $trackingCodes) {
            foreach($trackingCodes as $trackingCode => $lineItemIds) {
                $fulfillment = [
                    'location_id' => $shop->primary_location_id,
                    'tracking_number' => $trackingCode
                ];
                $orderRepo->fulFillmentMultipleLineItem($shop->myshopify_domain, $shop->access_token, $orderId, $fulfillment, $lineItemIds);
            }
        }
    }
}
