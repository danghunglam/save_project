<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use App\Events\UpdateAliexpressEvent;
use App\Models\LineItemModel;
use App\Repository\LineItemRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\OrderRepository;
use App\ShopifyApi\FulfillmentApi;


class UpdateTrackingCodeAliexpressJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_line_items;

    private $_tracking_code;

    private $_shop_id;

    private $_shop_domain;

    private $_access_token;

    private $_auto_update_tracking_code;

    /**
     * UpdateTrackingCodeAliexpressJob constructor.
     * @param $line_items
     * @param $tracking_code
     * @param $shop_id
     * @param $shop_domain
     * @param $access_token
     */
    public function __construct($line_items, $tracking_code, $shop_id, $shop_domain, $access_token, $autoUpdateTrackingCode)
    {
        $this->_line_items = $line_items;

        $this->_tracking_code = $tracking_code;

        $this->_shop_id = $shop_id;

        $this->_shop_domain = $shop_domain;

        $this->_access_token = $access_token;

        $this->_auto_update_tracking_code = $autoUpdateTrackingCode;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $lineItems = $this->_line_items;
        $trackingCode = $this->_tracking_code;
        $shopId = $this->_shop_id;
        $shopDomain = $this->_shop_domain;
        $accessToken  = $this->_access_token;
        $req['tracking_code'] = $trackingCode;
        $req['status'] = config('order.status.shipped');
        $req['fulfillment_status'] = config('order.fulfillment_status.fulfillment');

        /**
         * @var LineItemRepository
         */
        $lineItemRepo = app(LineItemRepository::class);

        /**
         * @var SettingRepository
         */
        $settingRepo = new SettingRepository($shopId);
        $shopRepo = app(ShopRepository::class);
        $notification_email_customer_fulfillment = $settingRepo->getKey('notification_email_customer_fulfillment');
        $default_fulfillment_tracking_url = $settingRepo->getKey('default_fulfillment_tracking_url');

        $shop = $shopRepo->detail($shopId);
        if( ! $shop)
            return response()->json(['status' => false, 'shop not found']);

        foreach ($lineItems as $lineItemId) {
            //If tracking code not found
            if(empty($trackingCode))
            {
                if($lineItem = LineItemModel::find($lineItemId))
                    if(!$this->_auto_update_tracking_code) {
                        event(new UpdateAliexpressEvent($lineItem, false, 'tracking_code'));
                    }

                continue;
            }

            //If tracking code found in AliExpress
            //Update tracking code in database
            $lineItemId = (string)$lineItemId;
            $lineItemRepo->update($lineItemId, $req);
            if($lineItem = LineItemModel::find($lineItemId))
            {
                //Update view event
                if(!$this->_auto_update_tracking_code) {
                    event(new UpdateAliexpressEvent($lineItem, true, 'tracking_code'));
                }

                $orderRepo = app(OrderRepository::class);
                $location_id = $orderRepo->getFulfillLocationId($shopDomain, $accessToken, $lineItem->order->id, $lineItemId);
                $isUseFulfillService = ($location_id != $shop->primary_location_id) ? true : false;

                $fulfillment = [
                    'location_id' => $location_id,
                    'tracking_number' => $trackingCode,
                    'line_items' => [
                        [
                            'id' => $lineItemId
                        ]
                    ],
                    'notify_customer' => false
                ];

                if(isset($notification_email_customer_fulfillment->value) and $notification_email_customer_fulfillment->value == 1)
                    $fulfillment['notify_customer'] = true;

                if(isset($default_fulfillment_tracking_url->value) and  filter_var($default_fulfillment_tracking_url->value, FILTER_VALIDATE_URL))
                    $fulfillment['tracking_url'] = $default_fulfillment_tracking_url->value;

                //Update Fulfillment api
                $fulfillmentApi = new FulfillmentApi($shopDomain, $accessToken);

                $fulfillmentFromSpf = $fulfillmentApi->create($lineItem->order->id, $fulfillment);

                // run again one time
                if(!isset($isUpdateFulfillment['data']->fulfillment)) {
                    sleep(3);
                    $fulfillmentFromSpf = $fulfillmentApi->create($lineItem->order->id, $fulfillment);
                }

                // update status fulfillment if current status is pending and use fulfill service
                if($isUseFulfillService) {
                    if(isset($isUpdateFulfillment['data']->fulfillment)) {
                        $fulfillmentFromSpf = $isUpdateFulfillment['data']->fulfillment;
                        if($fulfillmentFromSpf->status == 'pending') {
                            $fulfillmentApi->complete($lineItem->order->id, $fulfillmentFromSpf->id);
                        }
                    }
                }
                //
            }

        }
    }
}
