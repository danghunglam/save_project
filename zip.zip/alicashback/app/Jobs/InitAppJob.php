<?php

namespace App\Jobs;

use App\Helpers\SettingHelper;
use App\Repository\SettingRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class InitAppJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shopId;
    /**
     * InitAppJob constructor.
     *
     * @param $shopId
     */
    public function __construct($shopId)
    {
        $this->_shopId = $shopId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $settingsRepo = new SettingRepository($this->_shopId);
        $setting = json_decode(json_encode(config('setting_default')));

        $setting = SettingHelper::decodeSettings($setting);

        $settingsRepo->saveMany($setting);
    }
}
