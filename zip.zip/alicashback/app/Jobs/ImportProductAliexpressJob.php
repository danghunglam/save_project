<?php

namespace App\Jobs;

use App\Contracts\Repository\Extension\ExtensionImportProductRepositoryInterface;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class ImportProductAliexpressJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_products;
    /**
     * Create a new job instance.
     * @param $products
     *
     * @return void
     */
    public function __construct($products)
    {
        $this->_products =  $products;
    }

    /**
     * Execute the job.
     * @param ExtensionImportProductRepositoryInterface $repository
     *
     * @return void
     */
    public function handle(ExtensionImportProductRepositoryInterface $repository)
    {
        $public_token = ! empty($this->_products[0]['public_token']) ? $this->_products[0]['public_token'] : '';

        foreach ($this->_products as $product) {
            $product_detail = ! empty($product['product']) ? $product['product'] : [];
            $variants = ! empty($product['variants']) ? $product['variants'] : [];
            $images = ! empty($product['images']) ? $product['images'] : [];
            $supplier = ! empty($product['supplier']) ? $product['supplier'] : [];
            $repository->importProduct($public_token, $product_detail, $variants, $images, $supplier);
        }

    }
}
