<?php

namespace App\Jobs;

use App\Helpers\ProductHelper;
use App\Repository\ProductRepository;
use App\Repository\ProductVariantRepository;
use App\Repository\SupplierRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\ShopMetaRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;

class BulkImportAliexpressOberloJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop;

    private $_products;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($shop, $products)
    {
        $this->_shop = $shop;
        $this->_products = $products;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $products = $this->_products;
        $shop = $this->_shop;
        $shopRepo = new ShopRepository(); 
        $productRepo = new ProductRepository($shop->id);
        $productVariantRepo = app(ProductVariantRepository::class);
        $supplierRepo = app(SupplierRepository::class);
        $settingRepo = new SettingRepository($shop->id);
        $shopRepository = new ShopRepository();
        $shopMetaRepo = new ShopMetaRepository();
        foreach ($products as $product)
        {
            $isLimit = $shopRepository->checkLimitProduct($shop->id);
            if($isLimit) {
                return false;
            }
            $supplierId = null;
            $supplier = isset($product['supplier']) ? $product['supplier'] : null;
            if($supplier)
                if($supplierRepo->createOrUpdate($supplier['id'], $supplier))
                    $supplierId = $supplier['id'];

            $productObj = $productRepo->detail($product['id_shopify']);

            if( empty($productObj->source_product_link))
            {

                $productData = [
                    'source_product_link' => 'https://www.aliexpress.com/item/-/'.$product['id_aliexpress'].'.html',
                    'aliexpress_product_id' => $product['id_aliexpress'],
                    'supplier_id' => $supplierId
                ];

                $auto_update_when_product_cost_change_aliexpress = $settingRepo->getKey('auto_update_when_product_cost_change_aliexpress');
                if( (!$auto_update_when_product_cost_change_aliexpress) || $auto_update_when_product_cost_change_aliexpress->value == config('setting.auto_update_when_product_cost_change_aliexpress.do_nothing'))
                    $productData['auto_update_price'] = config('product.auto_update_price.price_update_off');
                elseif( $auto_update_when_product_cost_change_aliexpress->value == config('setting.auto_update_when_product_cost_change_aliexpress.update_automatically'))
                    $productData['auto_update_price'] = config('product.auto_update_price.automatic_price_updates_on');

                $productRepo->update($product['id_shopify'], $productData);
            }
            $variants = $product['variants'];
            foreach ($variants as $variant)
            {
                $variantObj = empty($variant['options']) ? ProductHelper::getVariantId($product['id_shopify']) : ProductHelper::getVariantId($product['id_shopify'], $variant['options']);
                if($variantObj)
                {
                    if(empty($variantObj->source_product_link))
                    {
                        $productVariantRepo->update($variantObj->id, [
                            'aliexpress_options' => $variant['aliexpress_option'],
                            'source_quantity' => $variant['stock'],
                            'source_price' => $variant['price'],
                            'aliexpress_product_id' => $product['id_aliexpress'],
                            'source_product_link' => 'https://www.aliexpress.com/item/-/'.$product['id_aliexpress'].'.html',
                            'supplier_id' => $supplierId
                        ]);
                    }
                }
            }
            $shopRepo->updateSingleTotalQuantityProduct($product['id_shopify']);
            // $shopMetaRepo->incrementLimitProduct($shop->id);
        }
    }
}
