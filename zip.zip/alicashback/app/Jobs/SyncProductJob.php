<?php

namespace App\Jobs;

use App\Events\AppsErrorEvent;
use App\Events\InitAppEvent;
use App\Models\ProductModel;
use App\Repository\ProductImageRepository;
use App\Repository\ProductRepository;
use App\Repository\ProductVariantRepository;
use App\ShopifyApi\ProductsApi;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;

class SyncProductJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 3;

    /**
     * The number of seconds the job can run before timing out.
     *
     * @var int
     */
    public $timeout = 1000;

    private $_shopId;

    private $_shopDomain;

    private $_accessToken;

    private $_field = ['id','title','handle','image', 'variants', 'images', 'product_type', 'tags'];

    private $_status = 'any';

    private $_filters = [];

    private $_limit = 250;

    /**
     * SyncProductJob constructor.
     *
     * @param $shopId
     * @param $shopDomain
     * @param $accessToken
     */
    public function __construct($shopId, $shopDomain, $accessToken)
    {
        $this->_shopId = $shopId;
        $this->_shopDomain = $shopDomain;
        $this->_accessToken = $accessToken;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
//        event(new InitAppEvent($this->_shopId, 'start_sync_product'));
        $productApi = new ProductsApi($this->_shopDomain, $this->_accessToken);
        $productRepo = new ProductRepository($this->_shopId);
        $productVariantRepo = app(ProductVariantRepository::class);
        $productImageRepo = app(ProductImageRepository::class);

        $count = $productApi->count($this->_filters, $this->_status);
        if ($count['status']) {
            $count = $count['data']->count;

            $page = ceil($count / $this->_limit);
            for($i = 1; $i <= $page; $i++)
            {
                $products = $productApi->all($this->_field, $this->_filters, $i, $this->_limit, $this->_status);
                //Convert object to array
                $products = $products['data']->products;
                $products = json_decode(json_encode($products), true);

                foreach ($products as $product)
                {
                    $product['image'] = isset($product['image']['src']) ? $product['image']['src'] : config('common.default_image');
                    $product['images'] = isset($product['images']) ? $product['images'] : [];
                    $product['tag'] = $product['tags'];
                    if($productRepo->save($product))
                    {
                        //Save Product Image
                        $productImageRepo->saveMany($product['id'], $product['images']);
                        //Save Product Variant
                        $productVariantRepo->saveMany($product['id'], $product['variants']);
                    }
                    else
                    {
                        event(AppsErrorEvent::class);
                    }
                }
                sleep(5);
            }
        }

    }

    public function fail($exception = null)
    {
        event(AppsErrorEvent::class);
    }
}
