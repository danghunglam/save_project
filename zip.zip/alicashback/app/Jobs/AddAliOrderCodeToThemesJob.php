<?php

namespace App\Jobs;

use App\Helpers\Helpers;
use App\ShopifyApi\AssetsApi;
use App\ShopifyApi\ThemesApi;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\File;

class AddAliOrderCodeToThemesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 3;

    private $_shopId;
    private $_shopDomain;
    private $_accessToken;

    /**
     * AddShippingCodeToThemesJob constructor.
     * @param $shopDomain
     * @param $accessToken
     * @param $shopId
     */
    public function __construct($shopDomain, $accessToken, $shopId)
    {
        $this->_accessToken = $accessToken;
        $this->_shopDomain = $shopDomain;
        $this->_shopId = $shopId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $editProductHtml = File::get(storage_path('/app/html/edit_product.blade.php'));
        $assetsApi = app(AssetsApi::class);
        $assetsApi->setParameter($this->_shopDomain, $this->_accessToken);
        $aliOrderTemplates = "snippets/fireapps-aliorder-bulk-action-edit-product.liquid";
        $themesApi = app(ThemesApi::class);
        $themesApi->setParameter($this->_shopDomain, $this->_accessToken);
        $allThemes = $themesApi->getAllTheme();
        $assetFiles = "layout/theme.liquid";
        $includeCode = '{% include "fireapps-aliorder-bulk-action-edit-product" %}';
        if($allThemes['status']) {
            $allThemes = $allThemes['data']->themes;
            foreach($allThemes as $theme) {
                $assetsApi->updateAssetValue($theme->id, $aliOrderTemplates, $editProductHtml);
                $assetContent = $this->getAssetsContent($theme->id, $assetFiles);
                if(!empty($assetContent)) {
                    $assetContentSplit = preg_split('/\{% include "fireapps-aliorder-bulk-action-edit-product" %}/', $assetContent);
                    if(count($assetContentSplit) <= 1) {
                        $newAssetContent = $assetContent . $includeCode;
                        $assetsApi->updateAssetValue($theme->id, $assetFiles, $newAssetContent);
                    }
                }
            }
        }
    }

    private function getAssetsContent($currentTheme, $assetFile)
    {
        $assetsApi = app(AssetsApi::class);
        $assetsApi->setParameter($this->_shopDomain, $this->_accessToken);
        $assetValue = $assetsApi->getAssetValue($currentTheme, $assetFile);
        if ($assetValue['status']) {
            return $assetValue['data']->asset->value;
        }
        return false;
    }
}
