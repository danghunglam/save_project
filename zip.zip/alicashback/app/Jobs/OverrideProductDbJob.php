<?php

namespace App\Jobs;

use Exception;
use App\Helpers\Helpers;
use App\Helpers\ProductHelper;
use App\Helpers\ProductTypeHelper;
use App\Repository\ProductImageRepository;
use App\Repository\ProductRepository;
use App\Repository\ProductVariantRepository;
use App\Repository\SupplierRepository;
use App\Repository\ShopRepository;
use App\ShopifyApi\ProductsApi;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Pusher\Pusher;
use App\Helpers\PusherHelper;

class OverrideProductDbJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shopId;

    private $_shopDomain;

    private $_accessToken;

    private $_variantNotHasOrder;

    private $_override;

    private $_current;

    private $_options;

    private $_variantMerge;

    /**
     * OverrideProductJob constructor.
     * @param $shopId
     * @param $shopDomain
     * @param $accessToken
     * @param $override
     * @param $current
     * @param $options
     * @param $variantNotHasOrder
     * @param $variantMerge
     */
    public function __construct($shopId, $shopDomain, $accessToken, $override, $current, $options, $variantNotHasOrder, $variantMerge)
    {
        $this->_shopId = $shopId;

        $this->_shopDomain = $shopDomain;

        $this->_accessToken = $accessToken;

        $this->_variantNotHasOrder = $variantNotHasOrder;

        $this->_override = $override;

        $this->_current = $current;

        $this->_options = $options;

        $this->_variantMerge = $variantMerge;
    }


    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $supplierId = null;
        $override = $this->_override;
        $overrideVariants = $this->_override['variants'];
        $overrideSupplier = $this->_override['supplier'];
        $currentProduct = $this->_current;
        $productApi = new ProductsApi($this->_shopDomain, $this->_accessToken);
        $productRepo = new ProductRepository($this->_shopId);
        $productVariantRepo = app(ProductVariantRepository::class);
        $productImageRepo = app(ProductImageRepository::class);
        $supplierRepo = app(SupplierRepository::class);
        $shopRepository = new ShopRepository();

        Cache::put('override_' . $currentProduct['id'], '[DB] Apply data to override (1/6)', 2000);
        $productSpf = $productApi->detail(['title','body_html', 'images', 'variants', 'image', 'product_type'], $currentProduct['id']);
        $productSpf = $productSpf['data']->product;

        //Update supplier
        if($supplierRepo->createOrUpdate($overrideSupplier['id'], $overrideSupplier))
            $supplierId = $overrideSupplier['id'];

        //Update products
        $product = [
            'image' => isset($override['product_image']) ? $override['product_image'] : config('common.default_image'),
            'source_product_link' => isset($override['source_product_link']) ? Helpers::filterAliexpressDetailLink($override['source_product_link']) : null,
            'aliexpress_product_id' => isset($override['aliexpress_product_id']) ? $override['aliexpress_product_id'] : null,
            'supplier_id' => $supplierId,
            'auto_update_price' => isset($override['auto_update_price']) ? $override['auto_update_price'] : 0,
            'title_source' => $override['title_source'],
            'product_type' => $productSpf->product_type
        ];

        if($this->_options['title'])
        {
            $product['title'] = $productSpf->title;
            $product['body_html'] = $productSpf->body_html;
        }

        $product['options'] = json_encode($override['options'],JSON_UNESCAPED_UNICODE);

        ProductTypeHelper::editProductType($this->_shopId, $currentProduct['id'], $product['product_type']);

        Cache::put('override_' . $currentProduct['id'], '[DB] Updating product data (2/6)', 2000);
        $productRepo->update($currentProduct['id'], $product);

        //Update created_at để soft lại màn products
        DB::table('product')->where('id', $currentProduct['id'])->update(['created_at' => Carbon::now()->format('Y-m-d H:i:s')]);
        

        Cache::put('override_' . $currentProduct['id'], '[DB] Deleting old variant data (3/6)', 2000);
        //Delete variant old
        $productVariantRepo->deleteVariantNotHasOrder($currentProduct['id'], $this->_variantNotHasOrder);


        Cache::put('override_' . $currentProduct['id'], '[DB] Add image product (4/6)', 2000);
        //Add images
        $productImageRepo->saveMany($currentProduct['id'], json_decode(json_encode($productSpf->images), true));

        Cache::put('override_' . $currentProduct['id'], '[DB] Override variants (5/6)', 2000);
        //Add new override variants
        $variantsData = json_decode(json_encode($productSpf->variants), true);
        $variantsData = array_map(function($variant) { 
            $variant['source_quantity'] = $variant['inventory_quantity'];
            return $variant;
        }, $variantsData);

        $variantsData = $productVariantRepo->customVariantNotHasOrder($variantsData, $product);

        $test = $productVariantRepo->saveMany($currentProduct['id'], $variantsData);
        
        //Merge variant aliexpress options
        foreach ($productSpf->variants as $variant)
            $this->mergeAliexpressOptions($variant, $overrideVariants, $supplierId);

        //Update variant has orders
        if( ! empty($this->_variantMerge))
            $this->mergeVariant($supplierId);

        Cache::put('override_' . $currentProduct['id'], '[DB] Updating total quantity (6/6)', 2000);
        $shopRepository->updateSingleTotalQuantityProduct($currentProduct['id']);
        Cache::forget('override_' . $currentProduct['id']);
        //Set override queue to cache
        $this->setOverrideQueueCache();
    }

    public function failed(Exception $exception) {
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );
        $pusher->set_logger(new PusherHelper());
        $pusher->trigger(strval($this->_shopId), 'override_product', ['product' => ['id' => $this->_current['id'], 'status' => 'error']]);

        //Set override process
        $product = $this->_current;
        $product['status'] = 'success';

        Helpers::removeProcessCache($this->_shopId, $product, 'override_product');
    }

    /**
     * Merge variant new
     * @param $spfVariant
     * @param $overrideVariants
     * @param $supplierId
     */
    private function mergeAliexpressOptions($spfVariant, $overrideVariants, $supplierId)
    {
        $productVariantRepo = app(ProductVariantRepository::class);
        foreach ($overrideVariants as $variant)
        {
            if($variant['sku'] === $spfVariant->sku)
            {
                $tmp = [
                    'aliexpress_options' => isset($variant['aliexpress_options']) ? $variant['aliexpress_options'] : config('common.aliexpress_options_default'),
                    'source' => 'aliexpress',
                    'aliexpress_product_id' => isset($variant['aliexpress_product_id']) ? $variant['aliexpress_product_id'] : null,
                    'source_product_link' => isset($variant['source_product_link']) ? Helpers::filterAliexpressDetailLink($variant['source_product_link']) : null,
                    'source_quantity' => isset($variant['source_quantity']) ? $variant['source_quantity'] : 0,
                    'source_price' => isset($variant['source_price']) ? $variant['source_price'] : 0,
                    'price' => isset($variant['item_price']) ? $variant['item_price'] : 0,
                    'compare_at_price' => isset($variant['compare_at_price']) ? $variant['compare_at_price'] : 0,
                    'supplier_id' => $supplierId
                ];
                $productVariantRepo->update($spfVariant->id, $tmp);
            }
        }
    }

    /**
     * Merge variant if variant has order
     * @param $supplierId
     */
    private function mergeVariant($supplierId)
    {
        $productVariantRepo = app(ProductVariantRepository::class);
        foreach ($this->_variantMerge as $key => $variant)
        {
            $productVariantRepo->restore($variant['id']);

            if(count($variant) > 1)
            {
                $variant['options'] = isset($variant['options']) ? json_encode($variant['options']) : null;
                $variant['source_product_link'] = isset($variant['source_product_link']) ? Helpers::filterAliexpressDetailLink($variant['source_product_link']) : null;
                $variant['supplier_id'] = $supplierId;
                $productVariantRepo->update($variant['id'], $variant);
            }
        }
    }

    private function setOverrideQueueCache()
    {
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );
        $pusher->set_logger(new PusherHelper());
        $pusher->trigger(strval($this->_shopId), 'override_product', ['product' => ['id' => $this->_current['id'], 'status' => 'success']]);

        //Set override process
        $product = $this->_current;
        $product['status'] = 'success';

        Helpers::removeProcessCache($this->_shopId, $product, 'override_product');
    }
}
