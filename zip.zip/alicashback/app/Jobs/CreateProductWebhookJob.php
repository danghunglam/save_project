<?php

namespace App\Jobs;

use App\Helpers\ProductHelper;
use App\Helpers\ProductTypeHelper;
use App\Repository\ProductRepository;
use App\Repository\ProductVariantRepository;
use App\Repository\ShopRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class CreateProductWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop;

    private $_data;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($shop, $data)
    {
        $this->_shop = $shop;
        $this->_data = $data;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $res = $this->_data;
        $shopRepo = new ShopRepository();
        $productRepo = new ProductRepository($this->_shop->id);
        $productVariantRepo = new ProductVariantRepository();
        if ($this->_shop)
        {
            $res['image'] = isset($res['image']['src']) ? $res['image']['src'] : config('common.default_image');
            $res['options'] = ProductHelper::convertOptions($res['options']);
            $res['tag'] = $res['tags'];
            $create = $productRepo->save($res);
            if($create)
            {
                ProductTypeHelper::createProductType($this->_shop->id, $res['product_type']);
                $productVariantRepo->saveMany($res['id'], $res['variants']);
                $shopRepo->updateSingleTotalQuantityProduct($res['id']);
            }
        }
    }
}
