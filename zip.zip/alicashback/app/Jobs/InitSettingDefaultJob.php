<?php

namespace App\Jobs;

use App\Helpers\SettingHelper;
use App\Models\ShopModel;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;

class InitSettingDefaultJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shopId;

    /**
     * InitSettingDefaultJob constructor.
     *
     * @param $shopId
     */
    public function __construct($shopId)
    {
        $this->_shopId = $shopId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $shopRepo = app(ShopRepository::class);
        $shopInfo = $shopRepo->detail($this->_shopId);
        $settingDefault = config('setting_default');
        $settingDefault['time_zone'] = isset($shopInfo->iana_timezone) ? $shopInfo->iana_timezone : 'UTC';
        $settingDefault['primary_email_address'] = isset($shopInfo->email) ? $shopInfo->email : null;
        $settingDefault = SettingHelper::encodeSettings($settingDefault);

        $settingRepo = new SettingRepository($this->_shopId);
        $settingRepo->saveMany($settingDefault);
    }
}
