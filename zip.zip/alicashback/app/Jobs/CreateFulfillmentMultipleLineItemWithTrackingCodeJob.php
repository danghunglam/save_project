<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use App\Events\UpdateAliexpressEvent;
use App\Models\LineItemModel;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\OrderRepository;
use App\ShopifyApi\FulfillmentApi;
use Illuminate\Support\Facades\Log;

class CreateFulfillmentMultipleLineItemWithTrackingCodeJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop_domain;

    private $_access_token;

    private $_order_id;

    private $_fulfillment;

    private $_line_item_id;

    /**
     * UpdateTrackingCodeAliexpressJob constructor.
     * @param $line_items
     * @param $tracking_code
     * @param $shop_id
     * @param $shop_domain
     * @param $access_token
     */
    public function __construct($shopDomain, $accessToken, $orderId, $fulfillment, $lineItemId)
    {
        $this->_shop_domain = $shopDomain;

        $this->_access_token = $accessToken;

        $this->_order_id = $orderId;

        $this->_fulfillment = $fulfillment;

        $this->_line_item_id = $lineItemId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        // Handle location for fulfill
        $orderRepo = app(OrderRepository::class);
        $orderRepo->fulFillmentMultipleLineItem($this->_shop_domain, $this->_access_token, $this->_order_id, $this->_fulfillment, $this->_line_item_id);
    }
}
