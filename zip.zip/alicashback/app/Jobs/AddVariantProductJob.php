<?php
/**
 * Created by PhpStorm.
 * User: hunglam
 * Date: 13/02/2019
 * Time: 16:33
 */

namespace App\Jobs;

use App\Helpers\Helpers;
use App\Helpers\PusherHelper;
use App\Repository\SupplierRepository;
use Exception;
use App\Repository\ProductImageRepository;
use App\Repository\ProductVariantRepository;
use App\ShopifyApi\ProductImageApi;
use App\ShopifyApi\ProductVariantApi;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\Log;
use Pusher\Pusher;

class AddVariantProductJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shopDomain ;

    private $_accessToken ;

    private $new_product ;

    private $_product_id ;

    private $_shopId ;

    /**
     * OverrideProductJob constructor.
     * @param $shopDomain
     * @param $accessToken
     * @param $new_product
     * @param $product_id
     */
    public function __construct($shopId ,$shopDomain, $accessToken, $new_product,$product_id)
    {
        $this->_shopDomain = $shopDomain;

        $this->_accessToken = $accessToken;

        $this->new_product  = $new_product;

        $this->_product_id = $product_id;

        $this->_shopId = $shopId;
    }

    public function handle(){
        $supplierId = null;
        $variants = $this->new_product['variants'];
        $supplier = $this->new_product['supplier'];
        $product_id = $this->_product_id;

        $error = ['status'=>'false', 'message'=>''];

        $variantApi = new ProductVariantApi($this->_shopDomain, $this->_accessToken);
        $imageApi = new ProductImageApi($this->_shopDomain, $this->_accessToken);
        $supplierRepo = app(SupplierRepository::class);
        $productVariantRepo = app(ProductVariantRepository::class);
        $productImageRepo = app(ProductImageRepository::class);

        foreach (($variants) as $k=>$variant) {

            //add image shopify
            $imgsApi['src'] = isset($variant['image']) ? $variant['image'] : null;

            $lastAddImageApi = $imageApi->create($product_id,$imgsApi);

            if (!$lastAddImageApi['status']){
                $error['message'] = $lastAddImageApi;
                $this->confirm($error);
                return false;
            }

            $image_id = $lastAddImageApi['data']->image->id;

            // add variant shopify
            $resourceApi = [
                'option1'              => isset($variant['option1']) ? $variant['option1'] : 'Default title ' . $k .time(),
                'option2'              => isset($variant['option2']) ? $variant['option2'] : null,
                'option3'              => isset($variant['option3']) ? $variant['option3'] : null,
                'price'                => isset($variant['item_price']) ? $variant['item_price'] : 0,
                'image'                => isset($variant['image']) ? $variant['image'] : null,
                'image_id'             => $image_id,
                'compare_at_price'     => isset($variant['compare_at_price']) ? $variant['compare_at_price'] : 0,
                'inventory_quantity'   => isset($variant['source_quantity']) ? $variant['source_quantity'] : 0,
                'sku'                  => isset($variant['sku']) ? $variant['sku'] : 0,
                'inventory_management' => 'shopify'
            ];

            $lastAddVariantApi =  $variantApi->create($product_id,$resourceApi);

            if(!$lastAddVariantApi['status']){
                $error['message'] = $lastAddVariantApi;
                Log::info($k);
                Log::info($variant);
                $this->confirm($error);
                return false;
            }

            //create supplier
            if($supplierRepo->createOrUpdate($supplier['id'], $supplier))
                $supplierId = $supplier['id'];

            //Add images DB

            $imgDB = [
                'id'         => $lastAddImageApi['data']->image->id,
                'product_id' =>$product_id,
                'width'      => $lastAddImageApi['data']->image->width,
                'height'     => $lastAddImageApi['data']->image->height,
                'src'        => isset($variant['image']) ? $variant['image'] : null
            ];


            $lastAddImageDB = $productImageRepo->create($product_id, $imgDB);

            if(!$lastAddImageDB) return false;

            //add variant DB
            $resourceDB = [
                'id'                    => $lastAddVariantApi['data']->variant->id,
                'aliexpress_options'    => isset($variant['aliexpress_options']) ? $variant['aliexpress_options'] : null,
                'product_id'            => $product_id,
                'image_id'              => $image_id,
                'option1'               => isset($variant['option1']) ? $variant['option1'] : 'Default title ' . $k,
                'option2'               => isset($variant['option2']) ? $variant['option2'] : null,
                'option3'               => isset($variant['option3']) ? $variant['option3'] : null,
                'title'                 => $lastAddVariantApi['data']->variant->title == 'Default title 0'? $lastAddVariantApi['data']->variant->title . time() : $lastAddVariantApi['data']->variant->title,
                'sku'                   => isset($variant['sku']) ? $variant['sku'] : 0,
                'source_quantity'       => isset($variant['source_quantity']) ? $variant['source_quantity'] : null,
                'source_price'          => isset($variant['source_price']) ? $variant['source_price'] : null,
                'price'                 => isset($variant['item_price']) ? $variant['item_price'] : null,
                'compare_at_price'      => isset($variant['compare_at_price']) ? $variant['compare_at_price'] : null,
                'aliexpress_product_id' => isset($variant['aliexpress_product_id']) ? $variant['aliexpress_product_id'] : null,
                'source_product_link'   => isset($variant['source_product_link']) ? $variant['source_product_link'] : null,
                'supplier_id'           => $supplierId
            ];

            $productVariantRepo->save($product_id,$resourceDB);

        }

        $error['status'] = 'success';
        $error['message'] = 'success';
        $this->confirm($error);
    }

    public function failed(Exception $exception) {
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );
        $pusher->set_logger(new PusherHelper());
        $pusher->trigger(strval($this->_shopId), 'add_variant_product', ['product' => ['id' => $this->_product_id, 'status' => 'error']]);

        //Set override process
        $product['id'] = $this->_product_id;
        $product['status'] = 'success';
        Helpers::removeProcessCache($this->_shopId, $product, 'add_variant_product');
    }

    public function confirm($error){
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );
        $pusher->set_logger(new PusherHelper());
        $pusher->trigger(strval($this->_shopId), 'add_variant_product', ['product' => ['id' => $this->_product_id, 'status' => $error['status'], 'message'=>$error]]);

        //Set override process
        $product['id'] = $this->_product_id;
        $product['status'] = 'success';

        Helpers::removeProcessCache($this->_shopId, $product, 'add_variant_product');
    }
}