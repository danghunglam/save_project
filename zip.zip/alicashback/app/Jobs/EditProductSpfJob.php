<?php

namespace App\Jobs;

use App\Repository\SupplierRepository;
use App\ShopifyApi\ProductImageApi;
use App\ShopifyApi\ProductsApi;
use App\ShopifyApi\CollectsApi;
use App\ShopifyApi\InventoryLevelApi;
use App\ShopifyApi\ProductVariantApi;
use App\Repository\ShopRepository;
use App\Models\ShopModel;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;

class EditProductSpfJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shopDomain;

    private $_accessToken;

    private $_product;

    private $_current;
    
    private $_variant;

    private $_variantRemove;

    private $_imageRemove;


    /**
     * EditProductJob constructor.
     * @param $shopDomain
     * @param $accessToken
     * @param $product
     */
    public function __construct($shopDomain, $accessToken, $current, $product, $variant, $variantRemove, $imageRemove)
    {
        $this->_shopDomain = $shopDomain;

        $this->_accessToken = $accessToken;

        $this->_product = $product;

        $this->_current = $current;

        $this->_variant = $variant;

        $this->_variantRemove = $variantRemove;

        $this->_imageRemove = $imageRemove;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $productApi = new ProductsApi($this->_shopDomain, $this->_accessToken);
        $collectApi = new CollectsApi($this->_shopDomain, $this->_accessToken);
        $shopRepository = new ShopRepository();
        $product = $this->_product;

        $product['tags'] = $product['tag'];
        unset($product['tag']);
        $product['images'] = $product['product_image'];
        $productApi->update($product['id'], $product);

        $currentCollectSpf = $collectApi->get(['product_id' => $product['id']]);
        $currentCollect = [];
        foreach ($currentCollectSpf['data']->collects as $key => $value) {
            $currentCollect[$value->collection_id] = $value->id;
        }
        
        $collectCreate = array_filter($product['custom_collection'], function ($collect) use ($currentCollect) {
            return !in_array($collect, array_keys($currentCollect));
        });
        
        $collectDelete = array_filter($currentCollect, function ($collect) use ($product) {
            return !in_array($collect, array_keys($product['custom_collection']));
        });
        
        foreach($collectCreate as $collect)
            $collectApi->create($product['id'], $collect);
        
        foreach($collectDelete as $collect)
            $collectApi->delete($collect);
        
        $this->deleteImage($product['id'], $this->_imageRemove);
        $this->updateVariant($this->_variant);
        $shopRepository->updateSingleTotalQuantityProduct($product['id']);
        $this->deleteVariant($product['id'], $this->_variantRemove);
    }

    /**
     * Check status image variants selected
     *
     * @param $variant
     * @param $images
     * @return bool
     */
    public function checkImageVariantSelected($variant, $images)
    {
        foreach ($images as $image)
        {
            if(isset($image['aliexpress_options']) && ($image['aliexpress_options'] === $variant['aliexpress_options']))
                return $image['status'];
        }
        return false;
    }

    //Delete variant shopify
    private function deleteVariant($productId, $variants)
    {
        $productVariantApi = new ProductVariantApi($this->_shopDomain, $this->_accessToken);
        foreach ($variants as $variant)
        {
            $productVariantApi->delete($productId, $variant);

            sleep(3);
        }
    }

    //Delete image shopify
    private function deleteImage($productId, $images)
    {
        $productImageApi = new ProductImageApi($this->_shopDomain, $this->_accessToken);
        foreach ($images as $image)
        {
            $productImageApi->delete($productId, $image);

            sleep(3);
        }
    }
    
    //
    private function updateVariant($variants) {
        $productVariantApi = new ProductVariantApi($this->_shopDomain, $this->_accessToken);
        $inventoryLevelApi = new InventoryLevelApi($this->_shopDomain, $this->_accessToken);
        if($shop = ShopModel::where('myshopify_domain', $this->_shopDomain)->first()) {
            foreach ($variants as $variant)
            {
                $productVariatnUpdate = $productVariantApi->update($variant['id'], $variant);
                if($productVariatnUpdate['status']) {
                    if($productVariatnUpdate['data']->variant->inventory_management != 'shopify') {
                        $productVariantApi->update($variant['id'], ['inventory_management' => 'shopify']);
                    }
                    if($inventory_item_id = $productVariatnUpdate['data']->variant->inventory_item_id) {
                        $inventoryLevelApi->setAvailable($inventory_item_id, $shop->primary_location_id, $variant['source_quantity']);
                    }
                }
                
                sleep(3);
            }
        }
    }
    

    //Update variant image
    private function updateVariantImage($lastUpdateProduct, $resource)
    {
        if($lastUpdateProduct['status'])
        {
            $lastUpdateProduct = $lastUpdateProduct['data']->product;
            $productImageApi = new ProductImageApi($this->_shopDomain, $this->_accessToken);

            foreach ($resource['variants'] as $k => $variant)
            {
                $imageVariantResource = [
                    'src' => $variant['image'],
                    'variant_ids' => [
                        $lastUpdateProduct->variants[$k]->id
                    ]
                ];

                $productImageApi->create($lastUpdateProduct->id, $imageVariantResource);

                sleep(2);
            }
        }
    }
}
