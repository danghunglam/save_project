<?php

namespace App\Jobs;

use Exception;
use App\Helpers\Helpers;
use App\Repository\SupplierRepository;
use App\ShopifyApi\ProductImageApi;
use App\ShopifyApi\ProductsApi;
use App\ShopifyApi\ProductVariantApi;
use App\ShopifyApi\InventoryLevelApi;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Pusher\Pusher;
use App\Helpers\PusherHelper;

class OverrideProductSpfJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shopId;

    private $_shopDomain;

    private $_accessToken;

    private $_override;

    private $_current;

    private $_options;


    /**
     * OverrideProductJob constructor.
     * @param $shopDomain
     * @param $accessToken
     * @param $override
     * @param $current
     * @param $options
     */
    public function __construct($shopId, $shopDomain, $accessToken, $override, $current, $options)
    {
        $this->_shopId = $shopId;

        $this->_shopDomain = $shopDomain;

        $this->_accessToken = $accessToken;

        $this->_override = $override;

        $this->_current = $current;

        $this->_options = $options;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $productApi = new ProductsApi($this->_shopDomain, $this->_accessToken);
        $variantApi = new ProductVariantApi($this->_shopDomain, $this->_accessToken);
        $supplierRepo = new SupplierRepository();
        $productCurrent = $this->_current;
        Cache::put('override_' . $productCurrent['id'], 'Apply data to send Shopify (1/5)', 2000);
        $productOverride = $this->_override;
        $overrideVariants = $productOverride['variants'];
        $overrideSupplier = $productOverride['supplier'];
        $overrideOptions = $this->_options;
        $resource = [];
        //Save supplier
        $supplierRepo->createOrUpdate($overrideSupplier['id'], $overrideSupplier);

        if($overrideOptions['title'])
        {
            $resource['title'] = $productOverride['title'];
            $resource['body_html'] = $productOverride['body_html'];
            if(isset($productOverride['product_type'])) {
                $resource['product_type'] = $productOverride['product_type'];
            }
        }

        $imagePosition = 1;
        if($overrideOptions['image'])
        {
            if(isset($productOverride['product_image']))
            {
                $resource['images'][] = [
                    'src' => $productOverride['product_image'],
                    'position' => 1
                ];
                $imagePosition++;
            }

            foreach ($productOverride['images'] as $image)
            {

                if($image['status'] && empty($image['aliexpress_options']) && $image['src'] != $productOverride['product_image']) {

                    $resource['images'][] = [
                        'src' => $image['src'],
                        'position' => $imagePosition
                    ];
                    $imagePosition++;
                }
            }
        }
        $options = [];
        $resource['variants'] = [];
        foreach ($overrideVariants as $k => $variant)
        {
            if($variant['selected']){
                $resource['variants'][] = [
                    'option1'               => isset($variant['option1']) ? $variant['option1'] : 'Default title '.$k,
                    'option2'               => isset($variant['option2']) ? $variant['option2'] : null,
                    'option3'               => isset($variant['option3']) ? $variant['option3'] : null,
                    'price'                 => isset($variant['item_price']) ? $variant['item_price'] : 0,
                    'image'                 => $this->checkImageVariantSelected($variant, $productOverride['images']) ? $variant['image'] : null,
                    'compare_at_price'      => isset($variant['compare_at_price']) ? $variant['compare_at_price'] : 0,
                    'inventory_quantity'    => isset($variant['source_quantity']) ? $variant['source_quantity'] : 0,
                    'sku'                   => isset($variant['sku']) ? $variant['sku'] : 0,
                    'inventory_management' => 'shopify'
                ];

                foreach ($variant['options'] as $key => $value)
                {
                    $options[$key]['name'] = $key;
                }
            }
        }
        if(! empty($options))
            $resource['options'] = array_values($options);
        else
            $resource['options'] = [
                'name' => 'Default title'
            ];

        Cache::put('override_' . $productCurrent['id'], 'Deleting all variant (2/5)', 2000);
        //Delete all variant
        $this->deleteAllVariant($productCurrent['id']);
        Cache::put('override_' . $productCurrent['id'], 'Updating product (3/5)', 2000);
        //Update product info
        $lastUpdateProduct = $productApi->update($productCurrent['id'], $resource);
        Cache::put('override_' . $productCurrent['id'], 'Updating variant image (4/5)', 2000);
        //Update variant image
        $this->updateVariantImage($lastUpdateProduct, $resource);
        Cache::put('override_' . $productCurrent['id'], 'Override shopify fisnish (5/5)', 2000);
    }

    public function failed(Exception $exception) {
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );
        $pusher->set_logger(new PusherHelper());
        $pusher->trigger(strval($this->_shopId), 'override_product', ['product' => ['id' => $this->_current['id'], 'status' => 'error']]);

        //Set override process
        $product = $this->_current;
        $product['status'] = 'success';

        Helpers::removeProcessCache($this->_shopId, $product, 'override_product');
    }

    /**
     * Check status image variants selected
     *
     * @param $variant
     * @param $images
     * @return bool
     */
    public function checkImageVariantSelected($variant, $images)
    {
        foreach ($images as $image)
        {
            if ($image['index'] == $variant['image_id'])
                return $image['status'];
        }
        return false;
    }

    //Delete all variant shopify
    private function deleteAllVariant($productId)
    {
        $productApi = new ProductsApi($this->_shopDomain, $this->_accessToken);
        $product = $productApi->detail(['variants'], $productId);
        $product = $product['data']->product;
        $productVariantApi = new ProductVariantApi($this->_shopDomain, $this->_accessToken);
        foreach ($product->variants as $variant)
        {
            $productVariantApi->delete($productId, $variant->id);

            sleep(3);
        }
    }

    //Update variant image
    private function updateVariantImage($lastUpdateProduct, $resource)
    {
        if($lastUpdateProduct['status'])
        {
            $lastUpdateProduct = $lastUpdateProduct['data']->product;
            $productImageApi = new ProductImageApi($this->_shopDomain, $this->_accessToken);
            $arrImageData = array();
            $arrProductImage = array();
            foreach ($resource['variants'] as $k => $variant)
            {
                if (!in_array($variant['image'], $arrImageData))
                    $arrImageData[] = $variant['image'];
                $arrProductImage[$variant['image']]['variant_ids'][] = $lastUpdateProduct->variants[$k]->id;
            }

            foreach ($arrProductImage as $k => $val)
            {
                $imageVariantResource = [
                    'src' => $k,
                    'variant_ids' => $val['variant_ids']
                ];
                $productImageApi->create($lastUpdateProduct->id, $imageVariantResource);
                sleep(2);
            }
        }
    }
}
