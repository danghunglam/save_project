<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use App\ShopifyApi\FulfillmentApi;

class UpdateTrackingCodeToShopifyJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop_domain;

    private $_access_token;

    private $_order_id;

    private $_fulfillment_id;

    private $_fulfillment = [];

    private $_tracking_code;

    /**
     * UpdateTrackingCodeAliexpressJob constructor.
     * @param $line_items
     * @param $tracking_code
     * @param $shop_id
     * @param $shop_domain
     * @param $access_token
     */
    public function __construct($shopDomain, $accessToken, $orderId, $fulfillmentId, $trackingCode)
    {
        $this->_shop_domain = $shopDomain;

        $this->_access_token = $accessToken;

        $this->_order_id = $orderId;

        $this->_fulfillment_id = $fulfillmentId;

        $this->_tracking_code = $trackingCode;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $fulfillmentApi = new FulfillmentApi($this->_shop_domain, $this->_access_token);
        $fulfillmentApi->update($this->_order_id, $this->_fulfillment_id, $this->_fulfillment, $this->_tracking_code);
        $fulfillmentApi->complete($this->_order_id, $this->_fulfillment_id);
    }
}
