<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use App\Events\UpdateAliexpressEvent;
use App\Models\ShopModel;
use App\Models\ProductModel;
use App\ShopifyApi\ProductsApi;
use App\ShopifyApi\ProductVariantApi;
use App\Repository\ProductVariantRepository;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class RestoreDataVariantFromTrashJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    
    private $_shop_id;

    private $_limit;

    private $_offset;

    private $_trashed;

    private $_ids;

    /**
     * RefulfillJob constructor.
     * @param $line_items
     * @param $tracking_code
     * @param $shop_id
     * @param $shop_domain
     * @param $access_token
     */
    public function __construct($shop_id, $limit, $offset, $trashed, $ids)
    {
        $this->_shop_id = $shop_id;

        $this->_limit = $limit;

        $this->_offset = $offset;

        $this->_trashed = $trashed;

        $this->_ids = $ids;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $shop_id = $this->_shop_id;
        $limit = $this->_limit;
        $offset = $this->_offset;
        $trashed = $this->_trashed;
        $ids = $this->_ids;
        $shop = ShopModel::find($shop_id);
        if(!$shop)
            return false;

        $productApi = new ProductsApi($shop->myshopify_domain, $shop->access_token);
        $productVariantApi = new ProductVariantApi($shop->myshopify_domain, $shop->access_token);
        $productVariantRepository = new ProductVariantRepository();

        $products = ProductModel::select(DB::raw('product.*'))
                    ->join('product_variant', 'product.id', '=', 'product_variant.product_id')
                    ->where('product.shop_id', $shop->id)
                    ->WhereRaw("DATE(product_variant.created_at) = '2019-03-18'")
                    ->with(['productVariantWithTrashed'])
                    ->whereNotNull('product.source_product_link')
                    ->groupBy('product.id')
                    ->orderBy('product.created_at', 'desc');
                        
        if(!empty($ids)) {
            $products = $products->whereIn('product.id', $ids);
        }
        $products = $products->skip($offset)->take($limit)->get();

        
        foreach($products as $product) {
            if(count($product->productVariantWithTrashed) > 1) {
                $trashedVariants = [];
                foreach($product->productVariantWithTrashed as $variant) {
                    if($variant->deleted_at) {
                        $trashedVariants[$variant->sku] = $variant;
                    }
                }
                foreach($product->productVariantWithTrashed as $variant) {
                    if($variant->created_at->format('Y-m-d') == '2019-03-18' && $variant->deleted_at == null) {
                        if(isset($trashedVariants[$variant->sku])) {
                            $baseVariant = $trashedVariants[$variant->sku];
                            $dataRecover = [
                                'aliexpress_options' => $baseVariant->aliexpress_options,
                                'source_quantity' => $baseVariant->source_quantity,
                                'aliexpress_product_id' => $baseVariant->aliexpress_product_id,
                                'source_product_link' => $baseVariant->source_product_link,
                                'supplier_id' => $baseVariant->supplier_id,
                                'source_price' => $baseVariant->source_price
                            ];
                            $productVariantRepository->update($variant->id, $dataRecover);
                        }
                    }
                }
            }
        }
    }
}
