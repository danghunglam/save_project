<?php

namespace App\Jobs;

use App\ShopifyApi\ProductImageApi;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;

class UpdateVariantImageJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_product;

    private $_lastProduct;

    private $_shopDomain;

    private $_accessToken;
    /**
     * UpdateVariantImageJob constructor.
     *
     * @param $product
     * @param $lastProduct
     * @param $shopDomain
     * @param $accessToken
     */
    public function __construct($product, $lastProduct, $shopDomain, $accessToken)
    {
        $this->_product = $product;
        $this->_lastProduct = $lastProduct;
        $this->_shopDomain = $shopDomain;
        $this->_accessToken = $accessToken;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $productImageApi = new ProductImageApi($this->_shopDomain, $this->_accessToken);
        foreach ($this->_product['variants'] as $k => $variant)
        {
            $imageVariantResource = [
                'src' => $variant['image'],
                'variant_ids' => [
                    $this->_lastProduct->variants[$k]->id
                ]
            ];

            $productImageApi->create($this->_lastProduct->id, $imageVariantResource);

            sleep(5);
        }
    }
}
