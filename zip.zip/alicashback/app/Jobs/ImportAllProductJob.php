<?php

namespace App\Jobs;

use App\Events\AppsErrorEvent;
use App\Helpers\Helpers;
use App\Helpers\ProductHelper;
use App\ShopifyApi\CollectsApi;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Repository\ImportProductRepository;
use App\ShopifyApi\ProductsApi;
use App\ShopifyApi\ProductImageApi;
use App\ShopifyApi\InventoryLevelApi;
use App\ShopifyApi\ShopsApi;
use App\Repository\ProductRepository;
use App\Repository\ProductVariantRepository;
use App\Repository\ProductImageRepository;
use App\Models\ShopModel;
use App\Models\ImportProductModel;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use Pusher\Pusher;
use App\Jobs\ImportProductJob;

class ImportAllProductJob implements ShouldQueue
{
    use Queueable, SerializesModels, DispatchesJobs;

    private $_shopId;
    private $_shopDomain;
    private $_accessToken;

    /**
     * ImportAllProductJob constructor.
     *
     * @param $shopId
     * @param $shopDomain
     * @param $accessToken
     * @param $products
     */
    public function __construct($shopId, $shopDomain, $accessToken)
    {
        $this->_shopId = $shopId;
        $this->_shopDomain = $shopDomain;
        $this->_accessToken = $accessToken;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $importProductRepo = app(ImportProductRepository::class);
        //Get all product ignore pagination
        $allProduct = $importProductRepo->all($this->_shopId, [], false);
        $products = $importProductRepo->filterDataProduct($allProduct);

        ImportProductModel::where('shop_id', $this->_shopId)
                    ->whereNull('is_import')
                    ->update(['is_import' => true]);

        foreach ($products as &$product)
        {
            // Set Option for variants
            $productOptions = [];
            array_slice($product['variants'], 0, 100);
            foreach ($product['variants'] as &$variant) {
                $number = 1;
                foreach ($variant['options'] as $key => $value) {
                    if($number > 3) break;
                    $productOptions[$number] = array(
                        'name' => $key,
                        'position' => $number
                    );
                    $variant['option' . $number] = $value;
                    $number++;
                }
            }
             $product['options'] = array_values($productOptions); // set column options for product
            $this->dispatch((new ImportProductJob($this->_shopId, $product, $this->_shopDomain, $this->_accessToken))->onQueue('import_product'));
            // $importProductRepo->update($this->_shopId, $product['id'], ['is_import' => true]);
            sleep(3);
        }
    }
}
