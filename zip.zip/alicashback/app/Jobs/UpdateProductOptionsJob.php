<?php

namespace App\Jobs;

use App\Events\AppsErrorEvent;
use Illuminate\Bus\Queueable;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Repository\ImportProductRepository;
use App\ShopifyApi\ProductsApi;
use App\Models\ShopModel;
use App\Models\ProductModel;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use Pusher\Pusher;

class UpdateProductOptionsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct()
    {
        
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $shops = ShopModel::where('status', 1)->get();
        foreach($shops as $shop) {
            $this->updateAllProduct($shop->myshopify_domain, $shop->access_token);
        }
    }

    private function updateAllProduct($shopDomain, $accessToken)
    {
        $limit = 250;
        $productApi = new ProductsApi($shopDomain, $accessToken);
        $total_product = $productApi->count([]);
        if( ! $total_product['status'])
            return false;
        $total_product = $total_product['data']->count;
        $page = ceil($total_product/$limit);
        for($i = 1; $i <= $page; $i++)
        {
            $this->updateOptionsFromSpf($shopDomain, $accessToken, $i);
        }
    }

    private function updateOptionsFromSpf($shopDomain, $accessToken, $page) {

        $productApi = new ProductsApi($shopDomain, $accessToken);
        $data = $productApi->all(['options', 'id'], [], $page);

        if( ! $data['status'])
            return false;

        foreach($data['data']->products as $product) {
            
            if($product->options) {
                $options = array_values(array_map(function($option) {
                    return array(
                        'name' => $option->name,
                        'position' => $option->position
                    );
                }, $product->options));
            } else {
                $options = [];
            }

            ProductModel::where('id', $product->id)->update(
                ['options' => json_encode($options, JSON_UNESCAPED_UNICODE)]
            );
        }

        return true;
    }
}
