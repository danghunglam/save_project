<?php

namespace App\Jobs;

use App\Events\AppsErrorEvent;
use Illuminate\Bus\Queueable;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Repository\ShopRepository;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use Pusher\Pusher;
use App\Models\ShopModel;

class UpdateTotalQuantityJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shopId;

    public function __construct($shopId)
    {
        $this->_shopId = $shopId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $shopRepository = new ShopRepository();
        $shop = ShopModel::find($this->_shopId);
        if(!$shop)
            return false;
        $products = $shop->product;
        foreach($products as $product) {
            $shopRepository->updateSingleTotalQuantityProduct($product->id);
        }
    }
}