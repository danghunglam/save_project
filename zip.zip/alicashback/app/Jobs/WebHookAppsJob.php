<?php

namespace App\Jobs;

use App\Events\InitAppEvent;
use App\Helpers\Helpers;
use App\ShopifyApi\WebHookApi;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Routing\UrlGenerator;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;


class WebHookAppsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

	/**
	 * The number of times the job may be attempted.
	 *
	 * @var int
	 */
	public $tries = 3;

    /**
     * @var WebHookApi
     */
    private $_webHookApi;

    /**
     * @var
     */
    private $_accessToken;

    /**
     * @var
     */
    private $_shopDomain;

    private $_shopId;

    /**
     * WebHookAppsJob constructor.
     * @param $accessToken
     * @param $shopDomain
     * @param $shopId
     */
    public function __construct($accessToken, $shopDomain, $shopId)
    {
        $this->_webHookApi = app(WebHookApi::class);
        $this->_accessToken = $accessToken;
        $this->_shopDomain = $shopDomain;
        $this->_shopId = $shopId;
    }

    /**
     * @return array
     */
    private function listWebHook()
    {
        $webhook_domain = env('WEBHOOK_ALIORDER_DOMAIN');

        return [
            [
                'address' => $webhook_domain . '/webhook/app_uninstalled',
                'topic'   => 'app/uninstalled'
            ],
            [
                'address' => $webhook_domain . '/webhook/shop_update',
                'topic'   => 'shop/update'
            ],
	        [
		        'address' => $webhook_domain . '/webhook/orders_updated',
		        'topic'   => 'orders/updated'
	        ],
            [
                'address' => $webhook_domain . '/webhook/orders_paid',
                'topic'   => 'orders/paid'
            ],
            [
                'address' => $webhook_domain . '/webhook/created_product',
                'topic'   => 'products/create'
            ],
            [
                'address' => $webhook_domain . '/webhook/updated_product',
                'topic'   => 'products/update'
            ],
	        [
		        'address' => $webhook_domain . '/webhook/delete_product',
		        'topic'   => 'products/delete'
	        ],
            [
                'address' => $webhook_domain . '/webhook/update_fulfillments',
                'topic'   => 'fulfillments/update'
            ],
            [
                'address' => $webhook_domain . '/webhook/create_fulfillments',
                'topic'   => 'fulfillments/create'
            ],
        ];
    }

    /**
     * Execute the job.
     *
     * @return mixed
     */
    public function handle()
    {
        event(new InitAppEvent($this->_shopId, 'start_webhook'));

        $this->_webHookApi->setParameter($this->_shopDomain, $this->_accessToken);
        //Delete all webHook before add Web Hook
        if( ! $this->deleteAllWebHook())
            return false;

        foreach ($this->listWebHook() as $k => $v)
        {
            $this->_webHookApi->addWebHook($v['address'], $v['topic']);
        }

        event(new InitAppEvent($this->_shopId, 'end_webhook'));
    }

    /**
     * @return bool
     */
    public function deleteAllWebHook()
    {
        $webHook = $this->_webHookApi->allWebHook();
        if( ! $webHook['status'])
        {
            Helpers::saveLog('error', ['message' => $webHook['message'], 'line' => __LINE__, 'file' => __FILE__, 'function' => __FUNCTION__, 'domain' => $this->_shopDomain]);
            return false;
        }

        foreach ($webHook['data']->webhooks as $k => $v)
        {
            $isDelete = $this->_webHookApi->delete($v->id);
            if( ! $isDelete['status'])
                Helpers::saveLog('error', ['message' => $isDelete['message'], 'line' => __LINE__, 'function' => __FUNCTION__, 'domain' => $this->_shopDomain]);

        }

        return true;
    }

}
