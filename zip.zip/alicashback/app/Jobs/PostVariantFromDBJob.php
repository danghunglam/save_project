<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use App\Events\UpdateAliexpressEvent;
use App\Models\LineItemModel;
use App\Models\OrdersModel;
use App\Models\ShopModel;
use App\Models\ProductModel;
use App\Repository\LineItemRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\OrderRepository;
use App\ShopifyApi\FulfillmentApi;
use App\ShopifyApi\OrdersApi;
use App\ShopifyApi\ProductsApi;
use App\ShopifyApi\ProductVariantApi;


class PostVariantFromDBJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    
    private $_shop_id;

    private $_limit;

    private $_offset;

    private $_trashed;

    private $_ids;

    /**
     * RefulfillJob constructor.
     * @param $line_items
     * @param $tracking_code
     * @param $shop_id
     * @param $shop_domain
     * @param $access_token
     */
    public function __construct($shop_id, $limit, $offset, $trashed, $ids)
    {
        $this->_shop_id = $shop_id;

        $this->_limit = $limit;

        $this->_offset = $offset;

        $this->_trashed = $trashed;

        $this->_ids = $ids;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $shop_id = $this->_shop_id;
        $limit = $this->_limit;
        $offset = $this->_offset;
        $trashed = $this->_trashed;
        $ids = $this->_ids;
        $shop = ShopModel::find($shop_id);
        if(!$shop)
            return false;

        $productApi = new ProductsApi($shop->myshopify_domain, $shop->access_token);
        $productVariantApi = new ProductVariantApi($shop->myshopify_domain, $shop->access_token);
        
        $products = ProductModel::where('shop_id', $shop_id)
                        ->with(['productVariant'])
                        ->whereNotNull('source_product_link');
        if(!empty($ids)) {
            $products = $products->whereIn('id', $ids);
        }
        $products = $products->skip($offset)->take($limit)->get();
        foreach($products as $product) {
            if(count($product->productVariant) > 0) {
                $data = $productApi->detail(['variants', 'id', 'images'], $product->id);
                
                if($data['status']) {
                    if(count($data['data']->product->variants) == 1) {
                        $currentId = $data['data']->product->variants[0]->id;
                        $listImages = array_map(function($image) {
                            return $image->id;
                        }, $data['data']->product->images);
                        foreach($product->productVariant as $variant) {
                            if($variant->id != $currentId) {
                                // create
                                $variantPostData = [
                                    'title' => $variant->title,
                                    'sku' => $variant->sku,
                                    'option1' => $variant->option1,
                                    'option2' => $variant->option2,
                                    'option3' => $variant->option3,
                                    'price' => $variant->price,
                                    'compare_at_price' => $variant->compare_at_price,
                                    'inventory_management' => 'shopify',
                                    'inventory_quantity' => $variant->source_quantity
                                ];
                                if($variant->image_id && in_array($variant->image_id, $listImages)) {
                                    $variantPostData['image_id'] = $variant->image_id;
                                }
                                $productVariantApi->create($product->id, $variantPostData);
                            }
                        }
                    }
                }
            }
        }
    }
}
