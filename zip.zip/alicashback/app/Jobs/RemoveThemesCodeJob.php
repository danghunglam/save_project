<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\ShopifyApi\AssetsApi;
use App\ShopifyApi\ThemesApi;

class RemoveThemesCodeJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    private $_shopDomain;
    private $_accessToken;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct( $shopDomain, $accessToken )    {

        $this->_shopDomain = $shopDomain;
        $this->_accessToken = $accessToken;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $assetsApi = app(AssetsApi::class);
        $assetsApi->setParameter($this->_shopDomain, $this->_accessToken);
        $themesApi = app(ThemesApi::class);
        $themesApi->setParameter($this->_shopDomain, $this->_accessToken);
        $allThemes = $themesApi->getAllTheme();
        $aliOrderTemplates = "snippets/fireapps-aliorder-bulk-action-edit-product.liquid";
        $assetFiles = "layout/theme.liquid";
        if($allThemes['status']) {
            $allThemes = $allThemes['data']->themes;
            foreach($allThemes as $theme) {
                $assetsApi->deleteAssetFile($theme->id, $aliOrderTemplates);
                $assetContent = $this->getAssetsContent($theme->id, $assetFiles);
                if(!empty($assetContent)) {
                    $assetContentSplit = preg_split('/\{% include "fireapps-aliorder-bulk-action-edit-product" %}/', $assetContent);
                    if(count($assetContentSplit) > 1) {
                        $newAssetContent = $assetContentSplit[0];
                        $assetsApi->updateAssetValue($theme->id, $assetFiles, $newAssetContent);
                    }
                }
            }
        }
    }

    private function getAssetsContent($currentTheme, $assetFile)
    {
        $assetsApi = app(AssetsApi::class);
        $assetsApi->setParameter($this->_shopDomain, $this->_accessToken);
        $assetValue = $assetsApi->getAssetValue($currentTheme, $assetFile);
        if ($assetValue['status']) {
            return $assetValue['data']->asset->value;
        }
        return false;
    }
}
