<?php

namespace App\Jobs;

use App\Events\InitAppEvent;
use App\Helpers\LineItemHelper;
use App\Helpers\OrderHelper;
use App\Repository\LineItemRepository;
use App\Repository\OrderRepository;
use App\Repository\ProductVariantRepository;
use App\ShopifyApi\OrdersApi;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;
use App\Models\ShopModel;
use Pusher\Pusher;

class SyncOrderJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 2;

    /**
     * The number of seconds the job can run before timing out.
     *
     * @var int
     */
    public $timeout = 5000;

    private $_shopId;
    private $_shopDomain;
    private $_accessToken;
    private $_limit = 250;

    private $_fields = [
        'id',
        'email',
        'created_at',
        'updated_at',
        'order_number',
        'name',
        'line_items',
        'shipping_address',
        'contact_email',
        'fulfillment_status',
        'financial_status',
        'fulfillments',
        'currency',
        'total_price',
        'subtotal_price',
        'total_tax',
        'total_discounts',
        'total_line_items_price'
    ];

    private $_filters = [];

    private $_financial_statuses = ['paid', 'partially_refunded', 'refunded'];

    private $_fulfillment_status;

    private $_status = 'any';

    private $_add_order_sync = 0;

    private $_created_at_min = '';

    private $_created_at_max = '';

    /**
     * SyncOrderFromShopifyJob constructor.
     *
     * @param $shopId
     * @param $shopDomain
     * @param $accessToken
     * @param $fulfillmentStatus
     */
    public function __construct($shopId, $shopDomain, $accessToken, $fulfillmentStatus, $addOrderSync = 0, $createdAtMin = '', $createdAtMax = '')
    {
        $this->_shopId = $shopId;
        $this->_shopDomain = $shopDomain;
        $this->_accessToken = $accessToken;
        $this->_fulfillment_status = $fulfillmentStatus;
        $this->_add_order_sync = $addOrderSync;
        $this->_created_at_min = $createdAtMin;
        $this->_created_at_max = $createdAtMax;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
//        event(new InitAppEvent($this->_shopId, 'start_sync_order'));
        $orderApi = new OrdersApi($this->_shopDomain, $this->_accessToken);
        /**
         * @var OrderRepository
         */
        $orderRepo = app(OrderRepository::class);
        /**
         * @var ProductVariantRepository
         */
        $variantRepo = app(ProductVariantRepository::class);
        /**
         * @var LineItemRepository
         */
        $lineItemRepo = app(LineItemRepository::class);
        foreach($this->_financial_statuses as $financial_status) {
            $countOrder = $orderApi->countAll($this->_filters, $this->_fulfillment_status, $financial_status, $this->_status);
            if($countOrder['status'])
            {
                $countOrder = $countOrder['data']->count;
                $pages = ceil($countOrder/$this->_limit);

                for($i = 1; $i <= $pages; $i++)
                {
                    $orders = $orderApi->getAll($this->_fields, $this->_filters, $this->_fulfillment_status, $financial_status, $this->_status, $this->_limit, $i, $this->_created_at_min, $this->_created_at_max);
                    $orders = $orders['data']->orders;
                    //Loop orders
                    foreach($orders as $order)
                    {
                        //Save line item

                        $lineItems = $order->line_items;
                        //Convert order to object
                        $order = json_decode(json_encode($order));
                        //Save Order

                        if ($orderRepo->save($this->_shopId, OrderHelper::convertOrderApiToOrderModel($order)))
                        {
                            foreach ($lineItems as $lineItem)
                            {
                                //Check variant id
                                if ($variantRepo->getDetail($lineItem->variant_id)) {
                                    $lineItemRepo->save(
                                        $order->id,
                                        LineItemHelper::convertLineItemApiToLineItemModel($lineItem)
                                    );
                                } else
                                {
                                    $orderRepo->delete($order->id);
                                }
                            }
                            if ( ! empty($order->fulfillments)) {
                                foreach ($order->fulfillments as $fulfillment) {
                                    $lineItemRepo->updateTrackingCodeByOrder(
                                        $fulfillment->tracking_number,
                                        $fulfillment->line_items
                                    );
                                }
                            }
                        }
                    }

                    sleep(5);
                }
            }
        }
        // if(!empty($this->_add_order_sync)) => Add $this->_add_order_sync
        if(!empty($this->_add_order_sync)) {
            $shop = ShopModel::find($this->_shopId);
            $shop->increment('order_type_sync', $this->_add_order_sync);
        }
        //Index line item to elaticsearch by shop id
        EsOrderBulkIndexShopJob::dispatch($this->_shopId)->onQueue('line_item_index');
        if ($this->_created_at_min != '' && $this->_created_at_max != '')
            $this->triggePusher($this->_fulfillment_status);
    }

    public function triggePusher($fulfillment)
    {
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'encrypted' => true
            ]
        );
        $trigged = $pusher->trigger(strval($this->_shopId), 'sync_all_orders', ['status' => true, 'fulfillment' => $fulfillment]);
    }

    public function fail($exception = null)
    {

    }
}
