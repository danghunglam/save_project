<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use App\Events\UpdateAliexpressEvent;
use App\Models\LineItemModel;
use App\Repository\LineItemRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\OrderRepository;
use App\ShopifyApi\FulfillmentApi;
use Illuminate\Support\Facades\Log;

class CreateFulfillmentWithTrackingCodeJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop_domain;

    private $_access_token;

    private $_order_id;

    private $_fulfillment;

    /**
     * UpdateTrackingCodeAliexpressJob constructor.
     * @param $line_items
     * @param $tracking_code
     * @param $shop_id
     * @param $shop_domain
     * @param $access_token
     */
    public function __construct($shopDomain, $accessToken, $orderId, $fulfillment)
    {
        $this->_shop_domain = $shopDomain;

        $this->_access_token = $accessToken;

        $this->_order_id = $orderId;

        $this->_fulfillment = $fulfillment;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $fulfillmentApi = new FulfillmentApi($this->_shop_domain, $this->_access_token);

        // Handle location for fulfill
        $orderRepo = app(OrderRepository::class);
        if(isset($this->_fulfillment['line_items']) && is_array($this->_fulfillment['line_items']) && count($this->_fulfillment['line_items']) > 0) {
            $lineItemId = $this->_fulfillment['line_items'][0]['id'];
            $location_id = $orderRepo->getFulfillLocationId($this->_shop_domain, $this->_access_token, $this->_order_id, $lineItemId);
            $isUseFulfillService = ($location_id != $this->_fulfillment['location_id']) ? true : false;
            $this->_fulfillment['location_id'] = $location_id;
        }
        // -----

        $isUpdateFulfillment = $fulfillmentApi->create($this->_order_id, $this->_fulfillment);

        if( ! $isUpdateFulfillment['status']) {
            return false;
        }
            

        // update status fulfillment if current status is pending and use fulfill service
        if($isUseFulfillService) {
            if(isset($isUpdateFulfillment['data']->fulfillment)) {
                $fulfillmentFromSpf = $isUpdateFulfillment['data']->fulfillment;
                if($fulfillmentFromSpf->status == 'pending') {
                    $fulfillmentApi->complete($this->_order_id, $fulfillmentFromSpf->id);
                }
            }
        }
        //
    }
}
