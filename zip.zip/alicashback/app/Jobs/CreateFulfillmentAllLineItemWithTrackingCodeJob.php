<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use App\Events\UpdateAliexpressEvent;
use App\Models\LineItemModel;
use App\Repository\LineItemRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\OrderRepository;
use App\ShopifyApi\FulfillmentApi;
use App\ShopifyApi\OrdersApi;
use Illuminate\Support\Facades\Log;
use App\ShopifyApi\FulfillmentServiceApi;

class CreateFulfillmentAllLineItemWithTrackingCodeJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop_domain;

    private $_access_token;

    private $_order_id;

    private $_fulfillment;

    /**
     * UpdateTrackingCodeAliexpressJob constructor.
     * @param $line_items
     * @param $tracking_code
     * @param $shop_id
     * @param $shop_domain
     * @param $access_token
     */
    public function __construct($shopDomain, $accessToken, $orderId, $fulfillment)
    {
        $this->_shop_domain = $shopDomain;

        $this->_access_token = $accessToken;

        $this->_order_id = $orderId;

        $this->_fulfillment = $fulfillment;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $fulfillmentApi = new FulfillmentApi($this->_shop_domain, $this->_access_token);
        $ordersApi = new OrdersApi($this->_shop_domain, $this->_access_token);
        $shopRepo = new ShopRepository();
        $shop = $shopRepo->getAttributes(['myshopify_domain' => $this->_shop_domain]);
        if(!$shop)
            return false;

        // 1st: Get and group line_item by fulfillment_serivice
        $order =  $ordersApi->getOrder($this->_order_id);
        if($order['status']) {
            $orderObject = $order['data']->order;
            $fulfillments = $orderObject->fulfillments;
            if(count($fulfillments) == 0) {
                $lineItems = $orderObject->line_items;
                $groupFulfillmentSerice = [];
                foreach($lineItems as $lineItem) {
                    if(!isset($groupFulfillmentSerice[$lineItem->fulfillment_service])) {
                        $groupFulfillmentSerice[$lineItem->fulfillment_service] = [
                            'line_items' => [
                                [
                                    'id' => $lineItem->id
                                ]
                            ]
                        ];
                    } else {
                        $groupFulfillmentSerice[$lineItem->fulfillment_service]['line_items'][] = ['id' => $lineItem->id];
                    }
                }
            }
        }

        // 2nd: Get location for fulfillment
        $fulfillmentServiceApi = new FulfillmentServiceApi($this->_shop_domain, $this->_access_token);
        $location_id = $shop->primary_location_id; // need replace
        $fulfillmentServices = $fulfillmentServiceApi->getAll(['scope' => 'all']);
        if(!$fulfillmentServices['status']) {
            $location_id = $shop->primary_location_id;
        } else {
            $fulfillmentServices = $fulfillmentServices['data']->fulfillment_services;
            foreach($groupFulfillmentSerice as $serviceName => $serviceData) {
                $groupFulfillmentSerice[$serviceName]['location_id'] = $location_id;
                foreach($fulfillmentServices as $fulfillmentService) {
                    if($fulfillmentService->handle == $serviceName) {
                        $groupFulfillmentSerice[$serviceName]['location_id'] = $fulfillmentService->location_id;
                        break;
                    }
                }
                
            }
        }

        // 3rd: Create full fillment
        foreach($groupFulfillmentSerice as $serviceName => $serviceData) {
            $fulfillmentData = $this->_fulfillment;
            $fulfillmentData['line_items'] = $serviceData['line_items'];
            $fulfillmentData['location_id'] = $serviceData['location_id'];
            $isUpdateFulfillment = $fulfillmentApi->create($this->_order_id, $fulfillmentData);
            // update status fulfillment if current status is pending and use fulfill service
            if($fulfillmentData['location_id'] != $shop->primary_location_id && $isUpdateFulfillment['status']) {
                if(isset($isUpdateFulfillment['data']->fulfillment)) {
                    $fulfillmentFromSpf = $isUpdateFulfillment['data']->fulfillment;
                    if($fulfillmentFromSpf->status == 'pending') {
                        $fulfillmentApi->complete($this->_order_id, $fulfillmentFromSpf->id);
                    }
                }
            }
            //
            sleep(3);
        }

    }
}
