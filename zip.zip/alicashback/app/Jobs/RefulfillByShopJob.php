<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

use App\Events\UpdateAliexpressEvent;
use App\Models\LineItemModel;
use App\Models\OrdersModel;
use App\Models\ShopModel;
use App\Repository\LineItemRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\OrderRepository;
use App\ShopifyApi\FulfillmentApi;
use App\ShopifyApi\FulfillmentServiceApi;
use App\ShopifyApi\OrdersApi;
use App\Jobs\RefulfillJob;
use Illuminate\Support\Facades\Log;

class RefulfillByShopJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop_id;

    private $_limit;

    /**
     * UpdateTrackingCodeAliexpressJob constructor.
     * @param $line_items
     * @param $tracking_code
     * @param $shop_id
     * @param $shop_domain
     * @param $access_token
     */
    public function __construct($shop_id, $limit)
    {
        $this->_shop_id = $shop_id;

        $this->_limit = $limit;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $shopId = $this->_shop_id;
        $shop = ShopModel::find($shopId);
        if(!$shop)
            return false;

        // query to get all orders
        $orders = $shop->order();
        $orders->select('orders.*');
        $orders->with(['lineItem' => function ($query) {
            $query->whereNull('tracking_code');
        }]);
        $orders->where('orders.fulfillment_status', '<>', config('order.fulfillment_status.fulfilled'))
            ->join('line_item', 'orders.id', '=', 'line_item.orders_id')
            ->join('product_variant', 'line_item.product_variant_id', '=', 'product_variant.id')
            ->join('product', 'product_variant.product_id', '=', 'product.id')
            ->orderBy('orders.id', 'desc')
            ->groupBy('orders.id')
            ->limit($this->_limit);

        
        $orderFulfillment = $orders->get();

        $fulfillmentServiceApi = new FulfillmentServiceApi($shop->myshopify_domain, $shop->access_token);
        $fulfillmentServices = $fulfillmentServiceApi->getAll(['scope' => 'all']);
        if($fulfillmentServices['status']) {
            $fulfillmentServices = $fulfillmentServices['data']->fulfillment_services;
            $fulfillmentServices = collect($fulfillmentServices);
            $fulfillmentServices = $fulfillmentServices->keyBy('handle');
        } else {
            $fulfillmentServices = [];
        }

        foreach($orderFulfillment as $order) {
            if(count($order->lineItem) == 0) {
                RefulfillJob::dispatch(
                    $order->id, 
                    $shopId, 
                    $shop->myshopify_domain, 
                    $shop->access_token,
                    $fulfillmentServices)->onQueue('refulfill');
            }
        }
    }

}
