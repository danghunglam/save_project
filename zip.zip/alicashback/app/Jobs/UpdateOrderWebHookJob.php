<?php

namespace App\Jobs;

use App\Helpers\LineItemHelper;
use App\Helpers\OrderHelper;
use App\Repository\LineItemRepository;
use App\Repository\OrderRepository;
use App\Repository\ProductVariantRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Log;

class UpdateOrderWebHookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $_shop;

    private $_data;

    /**
     * Create a new job instance.
     * @param $shop
     * @param $data
     * @return void
     */
    public function __construct($shop, $data)
    {
        $this->_shop = $shop;

        $this->_data = $data;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $orderRepo = app(OrderRepository::class);
        $variantRepo = app(ProductVariantRepository::class);
        $lineItemRepo = app(LineItemRepository::class);
        $shop = $this->_shop;
        $data = $this->_data;
        $has_order = false;
        //Check if order first insert
        if($orderRepo->get($data->id))
            $has_order = true;

        $create = $orderRepo->save($shop->id, OrderHelper::convertOrderApiToOrderModel($data));
        if($create)
        {
            $isSave = 0;
            foreach ($data->line_items as $lineItem)
            {
                if ($variant = $variantRepo->getDetail($lineItem->variant_id))
                {
                    if( ! $variant->trashed()){
                        $lineItemRepo->save($data->id, LineItemHelper::convertLineItemApiToLineItemModel($lineItem));
                        $isSave++;
                    }
                }
            }
            //Nếu không lưu được line_item nào thì xóa order đi
            if( $isSave <= 0 && ! $has_order) {
                $orderRepo->delete($data->id);
            } else//restore order
                $orderRepo->restore($data->id);

            //Nếu order đã fulfillments thì update lại tracking code
            if ( ! empty($data->fulfillments))
            {
                foreach($data->fulfillments as $fulfillment )
                {
                    $lineItemRepo->updateTrackingCodeByOrder($fulfillment->tracking_number, $fulfillment->line_items);
                }
            }

            //Update es index
            EsOrderWebhookIndexJob::dispatch($data->id)->onQueue('line_item_index');
        }
    }
}
