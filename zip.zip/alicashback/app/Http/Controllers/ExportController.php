<?php

namespace App\Http\Controllers;

use App\Repository\OrderRepository;
use App\Repository\ShopRepository;
use App\Helpers\LineItemHelper;
use App\Repository\TrackingCodeRepository;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class ExportController extends Controller
{
	public function orders(Request $request)
	{
	    $filters = $request->all();
	    $shop_id = session('shopId');

//	    $shopRepo = app(ShopRepository::class);
	    $orderRepo = app(OrderRepository::class);

//		$shopInfo = $shopRepo->detail($shop_id);
		$orders = $orderRepo->all($shop_id, $filters);


		$itemMergeArray = [];
		if( ! empty( $orders ) )
		{
			foreach($orders as $order)
			{
				$itemMerge = LineItemHelper::mergeOderLineItemToArray( $order, $order->lineItem);
				$itemMergeArray = array_merge( $itemMergeArray, $itemMerge );
			}
			$exportArray = LineItemHelper::sortExportKeyArray( $itemMergeArray );

			$fileName = 'order_'.$shop_id.'_'.time();
            $this->download_send_headers($fileName.".csv");
            echo $this->arrayToCsv($exportArray);
            die();
//            $partSource = storage_path('app/public/exports');
//
//			Excel::create($fileName, function($excel) use ($exportArray) {
//				$excel->sheet('Order' , function($sheet) use ($exportArray)
//				{
//					$sheet->fromArray($exportArray);
//				});
//			})->store($type, $partSource);

//            return response()->json(['status' => true]);
		}
		return response()->json(['status' => false]);
	}

	public function trackingCode(Request $request){
        $filters = $request->input('filters');
        $shop_id = $request->input('shop_id');

        $type = $request->input('type');
        $shopRepo = app(ShopRepository::class);
        $trackingCodeRepo = app(TrackingCodeRepository::class);

        $shopInfo = $shopRepo->detail($shop_id);
        $orders = $trackingCodeRepo->getOrders($request);

        $itemMergeArray = [];
        if( ! empty( $orders ) )
        {
            foreach($orders['ordersData'] as $order)
            {
                $itemMerge = LineItemHelper::mergeTrackingCodeLineItemToArray( $order, $order['line_items']);
                $itemMergeArray = array_merge( $itemMergeArray, $itemMerge );
            }
            $exportArray = LineItemHelper::sortTrackingCodeExportKeyArray( $itemMergeArray );

            $fileName = 'TrackingCode_'.str_slug($shopInfo->name).'_'.time();
            $partSource = storage_path('app/public/exports');

            Excel::create($fileName, function($excel) use ($exportArray) {
                $excel->sheet('TrackingCode' , function($sheet) use ($exportArray)
                {
                    $sheet->fromArray($exportArray);
                });
            })->store($type, $partSource);

            return response()->json(compact('fileName', 'partSource', 'type'));
        }
    }

    private function arrayToCsv(array $array)
    {
        if (count($array) == 0) {
            return null;
        }
        ob_start();
        $df = fopen("php://output", 'w');
        fputcsv($df, array_keys(reset($array)));
        foreach ($array as $row) {
            fputcsv($df, $row);
        }
        fclose($df);
        return ob_get_clean();
    }

    private function download_send_headers($filename) {
        // disable caching
        $now = gmdate("D, d M Y H:i:s");
        header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
        header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
        header("Last-Modified: {$now} GMT");

        // force download
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");

        // disposition / encoding on response body
        header("Content-Disposition: attachment;filename={$filename}");
        header("Content-Transfer-Encoding: binary");
    }

}