<?php

namespace App\Http\Controllers;


use App\Repository\ShopRepository;
use App\Repository\ShopMetaRepository;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public function update(Request $request)
    {
        $data = $request->all();
        $shopId = $request->input('shop_id', '');
        $shopRepo = app(ShopRepository::class);
        if($shopRepo->createOrUpdate($shopId, $data))
            return response()->json(['status' => true]);

        return response()->json(['status' => false]);

    }

    public function checkLimitProduct(Request $request) {
        $shopId = session('shopId');
        $shopRepo = app(ShopRepository::class);
        $stock = $shopRepo->checkLimitProduct($shopId);
        return response()->json([
                                    'is_limited' => $stock > 0 ? false : true,
                                    'stock' => $stock
                                ]);
    }
}