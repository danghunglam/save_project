<?php
/**
 * Created by PhpStorm.
 * User: buicongdang
 * Date: 3/8/18
 * Time: 10:06 AM
 */

namespace App\Http\Controllers;


use App\Contracts\Repository\StatisticRepositoryInterface;
use App\Models\ShopModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\Helpers;
use Carbon\Carbon;

class StatisticController extends Controller
{
    private $_perPaged = 10;

    private function toDate()
    {
        return date('Y-m-d', strtotime('+1 day', strtotime(now())));
    }

    private function fromDate()
    {
        return date('Y-m-d', strtotime('-30 days', strtotime(now())));
    }

    private function get_first_day_of_month_current()
    {
        return date('Y-m-01');
    }

    private function get_last_month()
    {
        return date('Y-m-01');
    }

    public function index()
    {
        return view('statistic.index');
    }

    public function totalLastMonthSummary()
    {
        $response = app(StatisticRepositoryInterface::class);
        $shopId = session('shopId');
        $from = date("Y-n-j", strtotime("first day of previous month"));

        $to =  date("Y-n-j", strtotime("last day of previous month"));
        $summary = $response->getTotalSummary($shopId, $from, $to);
        if(! $summary)
            return response()->json(['status' => false]);

        return response()->json(['totalOrder' => $summary['totalOrder'], 'totalRevenue' => round($summary['totalRevenue'],2), 'totalCost' => round($summary['totalCost'], 2)]);
    }
    public function totalThisMonthSummary()
    {
        $response = app(StatisticRepositoryInterface::class);
        $shopId = session('shopId');
        $from = $this->get_first_day_of_month_current();
        $to = $this->toDate();

        $summary = $response->getTotalSummary($shopId, $from, $to);
        if(! $summary)
            return response()->json(['status' => false]);

        return response()->json(['totalOrder' => $summary['totalOrder'], 'totalRevenue' => round($summary['totalRevenue'],2), 'totalCost' => round($summary['totalCost'], 2)]);
    }

    public function totalSummary()
    {
        $response = app(StatisticRepositoryInterface::class);
        $shopId = session('shopId');
        $from_this_month = date("Y-n-j", strtotime("first day of this month"));
        $to_this_month = date("Y-n-j", strtotime("last day of this month"));
        $from_last_month = date("Y-n-j", strtotime("first day of previous month"));
        $to_last_month =  date("Y-n-j", strtotime("last day of previous month"));
        $summary_this_month = $response->getTotalSummary($shopId, $from_this_month, $to_this_month);
        $summary_last_month = $response->getTotalSummary($shopId, $from_last_month, $to_last_month);
        return response()->json([
            'this_total_order' => $summary_this_month['totalOrder'],
            'this_total_revenue' => round($summary_this_month['totalRevenue'],2),
            'this_total_cost' => round($summary_this_month['totalCost'], 2),
            'last_total_order' => $summary_last_month['totalOrder'],
            'last_total_revenue' => round($summary_last_month['totalRevenue'],2),
            'last_total_cost' => round($summary_last_month['totalCost'], 2),
        ]);
    }
    public function listTotalSummaryLast30day()
    {
        $shop = ShopModel::find(session('shopId'));
        if( ! $shop)
            return response()->json(['status' => false]);
        $dateList = [];
        $ordersList = [];
        $revenueList = [];
        $costList = [];
        $feeList = [];
        $first_day = $this->get_first_day_of_month_current();
        $to = $this->toDate();
        $from = $this->fromDate();

        $numDate = (strtotime($to) - strtotime($first_day)) / (60*60*24);
        for($i = 0; $i <= $numDate; $i++)
        {
            $sumCost = 0;
            $sumRevenue = 0;
            $sumFeeShip = 0;
            $date = date("Y-m-d", strtotime($first_day . "+$i days"));
            $orders = $shop->order()->whereDate('created_at', $date);
            $dateList[] = date("m-d", strtotime($first_day . "+$i days"));
            $ordersList[] = $orders->count('id');
            $orders = $orders->whereIn('financial_status', [config('order.financial_status.paid'), config('order.financial_status.partially_paid')])
                ->get();
            foreach ($orders as $order)
            {
                $sumRevenue += $order->lineItem->sum(function ($row) {
                    return $row->price * $row->quality;
                });
                $sumCost += $order->lineItem->sum(function($row){
                    return $row->price_order_aliexpress;
                });
                $sumFeeShip += $order->lineItem->sum(function($row) {
                    return $row->fee_ship;
                });
            }
            $feeList[] = round($sumFeeShip,2);
            $costList[] = round($sumCost,2);
            $revenueList[] = round($sumRevenue,2);
        }
        return response()->json(['dateList' => $dateList, 'orders' => $ordersList, 'revenue' => $revenueList, 'cost' => $costList, 'fee' => $feeList]);
    }

    public function listStatistic(Request $request)
    {
        $dateList = [];
        $orderArgs = [];
        $costArgs = [];
        $earningArgs = [];
        $revenueArgs = [];

        $shop = ShopModel::find(session('shopId'));
        if( ! $shop)
            return response()->json(['status' => false]);

        $from = $request->input('from');
        $to = $request->input('to');

        $numDate = (strtotime($to) - strtotime($from)) / (60*60*24);

        $max = date("Y-m-d", strtotime($to . "-0 days"));
        $min = date("Y-m-d", strtotime($to . "-$numDate days"));
        $orderQuery = $shop->order()->with('lineItem')->whereDate('created_at', '>=', $min)
            ->whereDate('created_at', '<=', $max)
            ->whereIn('financial_status', [config('order.financial_status.paid'), config('order.financial_status.partially_paid')]);
        $orders = $orderQuery->get();
        $orderGroup = [];
        foreach($orders as $order) {
            $date = Carbon::parse($order->created_at)->format('Y-m-d');
            if(!isset($orderGroup[$date])) {
                $orderGroup[$date] = [];
            }
            $orderGroup[$date][] = $order;
        }

        for($i = 0; $i <= $numDate; $i++) {
            $revenue = 0;
            $price_order_aliexpress = 0;
            $fee_ship = 0;
            $date = date("Y-m-d", strtotime($to . "-$i days"));
            $dateList[] = date("m-d", strtotime($to . "-$i days"));

            if(isset($orderGroup[$date])) {
                $orderArgs[] = count($orderGroup[$date]);
                foreach ($orderGroup[$date] as $order)
                {
                    $price_order_aliexpress += $order->lineItem->sum(function($row) use ($order) {
                        return Helpers::converttoUSD($order->currency,$row->price_order_aliexpress);
                    });
                    $fee_ship += $order->lineItem->sum(function($row) use ($order) {
                        return Helpers::converttoUSD($order->currency,$row->fee_ship);
                    });
                    $revenue += $order->lineItem->sum(function ($row) use ($order) {
                        return Helpers::converttoUSD($order->currency,$row->price) * $row->quality;
                    });
                }
            } else {
                $orderArgs[] = 0;
            }

            $revenueArgs[] = round($revenue, 2);
            $costArgs[] = round($price_order_aliexpress + $fee_ship, 2);
            $earningArgs[] = round($revenue - ($price_order_aliexpress + $fee_ship), 2);
        }

        return response()->json(['dateList' => $dateList, 'orders' => $orderArgs, 'revenue' => $revenueArgs, 'cost' => $costArgs, 'earning' => $earningArgs]);
    }

    private function getMinMaxCreatedAtOrder()
    {
        $totalDay = 0;
        $paged = 0;
        $shop = ShopModel::find(session('shopId'));
        if( ! $shop)
            return response()->json(['status' => false]);
        $min = $shop->order()->min('created_at');
        $max = date('Y-m-d H:i:s', time());
        if($min && $max)
        {
            $totalDay = ceil((strtotime($max) - strtotime($min)) / (60 * 60 * 24));
            $paged = ceil($totalDay/$this->_perPaged);
        }
        return compact('totalDay', 'paged', 'min', 'max');
    }

    public function listMinMaxCreatedAtOrder()
    {
        $param = $this->getMinMaxCreatedAtOrder();
        return response()->json($param);
    }

    public function listReference(Request $request)
    {
        $dateList = [];
        $orderArgs = [];
        $costArgs = [];
        $earningArgs = [];
        $revenueArgs = [];
        $shop = ShopModel::find(session('shopId'));
        $paged = $request->input('paged', 1);
        $param = $this->getMinMaxCreatedAtOrder();
        $maxDate = $param['max'];
        $from = date('Y-m-d H:i:s', strtotime('-'.$this->_perPaged*$paged.' days'. ($maxDate) ));

        for($i = 1; $i<= $this->_perPaged; $i++)
        {
            $revenue = 0;
            $price_order_aliexpress = 0;
            $fee_ship = 0;
            $fee_tax = 0;
            $date = date("Y-m-d", strtotime($from . "+$i days"));
            $dateList[] =  date("M d, Y", strtotime($from . "+$i days"));;
            $orders = $shop->order()->whereDate('created_at', $date)->whereIn('financial_status', [config('order.financial_status.paid'), config('order.financial_status.partially_paid')]);
            $orderArgs[] = $orders->count();
            $orders = $orders->get();

            foreach ($orders as $order)
            {
                $price_order_aliexpress += $order->lineItem->sum(function($row) {
                    return $row->price_order_aliexpress;
                });
                $fee_ship += $order->lineItem->sum(function($row) {
                    return $row->fee_ship;
                });
                $fee_tax +=  $order->lineItem->sum(function($row) {
                    return $row->fee_tax;
                });

                $revenue += $order->lineItem->sum(function ($row) use ($order) {
                    return Helpers::converttoUSD($order->currency, $row->price) * $row->quality;
                });
            }
            $revenueArgs[] = round($revenue,2);
            $costArgs[] = round($price_order_aliexpress+$fee_ship+$fee_tax, 2);
            $earningArgs[] = round($revenue - ($price_order_aliexpress+$fee_ship+$fee_tax),2);
        }
        return response()->json(['dateList' => $dateList, 'orders' => $orderArgs, 'revenue' => $revenueArgs, 'cost' => $costArgs, 'earning' => $earningArgs]);
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function quickSummary()
    {
        $shop = ShopModel::find(session('shopId'));
        if( ! $shop)
            return response()->json(['status' => false]);

        $toOrder = 0;
        $orderPlace = 0;
        $productLowStock = 0;
        $productOutOfStock = 0;
        $productGoneFromAliexpress = 0;

        $toOrder  = $shop->order()->whereHas('lineItem', function($query) {
            $query->where('line_item.status', config('order.status.to_order'));
        })->count();
        $orderPlace = $shop->order()->whereHas('lineItem', function($query) {
            $query->where('line_item.status', config('order.status.order_placed'));
        })->count();

        $productOutOfStock = $shop->product()
            ->where('product.source_product_link', '!=', null)
            ->where('product.source_product_link', '!=', '')->where('total_quantity', '<=', 0)->count();


        $productLowStock = $shop->product()
            ->where('total_quantity', '<=', 10)
            ->where('total_quantity', '>', 0)
            ->count();

        $productGoneFromAliexpress = $shop->product()
            ->where('product.status', 3)
            ->where('product.source_product_link', '!=', null)
            ->where('product.source_product_link', '!=', '')
            ->count();

        return response()->json(['to_order' => $toOrder, 'order_place' => $orderPlace,
            'product_low_stock' => $productLowStock, 'product_out_stock' => $productOutOfStock,
            'product_gone_from_aliexpress' => $productGoneFromAliexpress]);
    }
}
