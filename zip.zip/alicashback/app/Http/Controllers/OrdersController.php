<?php

namespace App\Http\Controllers;

use App\Helpers\ApiHelper;
use App\Helpers\Helpers;
use App\Helpers\SettingHelper;
use App\Mail\SendCustomer;
use App\Models\LineItemModel;
use App\Models\OrdersModel;
use App\Repository\LineItemRepository;
use App\Repository\OrderRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\ProductVariantRepository;
use App\ShopifyApi\FulfillmentApi;
use App\ShopifyApi\OrdersApi;
use App\ShopifyApi\FulfillmentServiceApi;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Jobs\CreateFulfillmentWithTrackingCodeJob;
use App\Jobs\CreateFulfillmentMultipleLineItemWithTrackingCodeJob;
use App\Jobs\FulfillmentWithTrackingCodeJob;
use App\Jobs\SyncOrderJob;
use Illuminate\Support\Facades\Cache;

class OrdersController extends Controller
{

    /**
     * @param Request $request
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public  function index(Request $request)
    {
        $shopId = session('shopId');
        $accessToken = session('accessToken');
        $shopDomain = session('shopDomain');
        $ordersData = [];
        $settingRepository = new SettingRepository($shopId);
        $settings = $settingRepository->getAll();
        $settings = SettingHelper::decodeSettings($settings);
        $timezone = (isset($settings['time_zone']) && $settings['time_zone'] !== '') ? $settings['time_zone'] : 'UTC';

        $shop = session('shop');


        //set timezone
        date_default_timezone_set($timezone);

        $filters = $request->all();

        $reject_filter = (isset($filters['reject_filter'])) ? $filters['reject_filter'] : [];

        if(empty($filters['filter_date_to']) && ! in_array('filter_date_to', $reject_filter))
            $filters['filter_date_to'] = date('Y-m-d', time());


        if(empty($filters['filter_date_from']) && ! in_array('filter_date_from', $reject_filter))
            $filters['filter_date_from'] = date('Y-m-d', strtotime( '-30 days'));

        return view('orders.index',
            compact(
                'shopId',
                'accessToken',
                'shopDomain',
                'filters',
                'shop'));
    }

    public function getConfig()
    {
        $orderStatus = array_flip(config('order.status'));
        foreach ($orderStatus as $k => $v)
        {
            $orderStatus[$k] = Helpers::slugToString($v, '_');
        }
        $fulfillmentStatus = array_flip(config('order.fulfillment_status'));

        foreach ($fulfillmentStatus as $k => $v)
        {
            $fulfillmentStatus[$k] = Helpers::slugToString($v, '-');
        }
        $financialStatus = array_flip(config('order.financial_status'));
        foreach ($financialStatus as $k => $v)
        {
            $financialStatus[$k] = Helpers::slugToString(str_slug($v, '-'), '_');
        }
        $flags = config('order.flags');

        return response()->json(compact('orderStatus', 'fulfillmentStatus', 'financialStatus', 'flags'));
    }

    public function getOrders(Request $request)
    {
        $ordersData = [];

        $filters = $request->all();

        $paged = isset($filters['paged']) ? $filters['paged'] : 1;

        $orderRepository = new OrderRepository();
        $variantRepository = new ProductVariantRepository();
        $shopId = session('shopId');


        $orders = $orderRepository->all($shopId, $filters, config( 'common.paginate_default'), $paged);
        $pagination = [
            'total' => $orders->total(),
            'last_page' => $orders->lastPage(),
            'perPage' => $orders->perPage(),
            'current_page' => $orders->currentPage()
        ];

        foreach ($orders as $order)
        {
            $ordersData[$order->id] = $order->toArray();
            foreach ($order->lineItem as $line_item)
            {
                $productVariantImage = isset($line_item->productVariant->productImage->src) ?
                    $line_item->productVariant->productImage->src : ($line_item->productVariant->product->image ?
                    $line_item->productVariant->product->image : config('common.default_image'));
                //Neu variant da bi xoa di thi chuyen thanh hinh anh mac dinh
                if(isset($line_item->productVariant->deleted_at)) {
                    $productVariantImage = config('common.default_image');
                }

                $ordersData[$order->id]['line_items'][$line_item->id] = [
                    'id' => $line_item->id,
                    'status' => $line_item->status,
                    'aliexpress_order_no' => $line_item->aliexpress_order_no,
                    'product_title' => isset($line_item->productVariant->product->title) ? $line_item->productVariant->product->title : '',
                    'product_handle' => isset($line_item->productVariant->product->handle) ? $line_item->productVariant->product->handle : '',
                    'product_variant_image' => $productVariantImage,
                    'variant_sku' => isset($line_item->productVariant->sku) ? $line_item->productVariant->sku : '',
                    'variant_title' => isset($line_item->productVariant->title) ? $line_item->productVariant->title : '',
                    'tracking_code' => $line_item->tracking_code,
                    'quality' => $line_item->quality,
                    'price' => number_format($line_item->price,2),
                    'total_price_item' => $line_item->quality * $line_item->price,
                    'orders_id' => $line_item->orders_id,
                    'source_product_link' => isset($line_item->productVariant->source_product_link) ? $line_item->productVariant->source_product_link : '',
                    'aliexpress_options' => isset($line_item->productVariant->aliexpress_options) ? $line_item->productVariant->aliexpress_options : '',
                    'product_variant_id' => isset($line_item->productVariant->id) ? $line_item->productVariant->id : '',
                    'product_id' => isset($line_item->productVariant->product->id) ? $line_item->productVariant->product->id : '',
                    'aliexpress_product_id' => isset($line_item->productVariant->product->aliexpress_product_id) ? $line_item->productVariant->product->aliexpress_product_id : '',
                    'supplier' => isset($line_item->productVariant->supplier) ? $line_item->productVariant->supplier : '',
                    'supplier_id' => isset($line_item->productVariant->supplier) ? $line_item->productVariant->supplier->id : null,
                    'variant_deleted_at' => isset($line_item->productVariant->deleted_at) ? $line_item->productVariant->deleted_at : '',
                    'product_has_source_link' => isset($line_item->productVariant->product->source_product_link) ? $line_item->productVariant->product->source_product_link : '',
                    'product_in_app' => $line_item->productVariant->product->deleted_at ? 0 : 1
                ];
            }
        }
        return response()->json(['status' => true, 'ordersData' => $ordersData, 'pagination' => $pagination]);
    }

    public function countOrders(Request $request) {
        $filters = $request->all();
        $dataCountStatus = [
            'to_order' => 0,
            'order_placed' => 0,
            'shipped' => 0,
            'total' => 0
        ];
        $orderRepository = new OrderRepository();
        $shopId = session('shopId');
        
        $orders = $orderRepository->queryFilterAndGroupStatus($shopId, $filters);
        $totalOrders = $orderRepository->queryFilterAndAllStatus($shopId, $filters);
        foreach ($orders as $key => $value) {
            switch($value['status']) {
                case config('order.status.to_order'):
                    $dataCountStatus['to_order'] = $value['total_order'];
                    break;
                case config('order.status.order_placed'):
                    $dataCountStatus['order_placed'] = $value['total_order'];
                    break;
                case config('order.status.shipped'):
                    $dataCountStatus['shipped'] = $value['total_order'];
                    break;
            }
        }
        $dataCountStatus['total'] = $totalOrders['total_order'] ? $totalOrders['total_order'] : 0;
        return response()->json(['status' => true, 'data' => $dataCountStatus]);
    }

    public function getOrderPlace(Request $request)
    {
        $repository = app(OrderRepository::class);
        $place_options = $request->input('place_options', 1);
        $current_page = $request->input('current_page', 1);
        $filters = $request->input('filters', '[]');


        $filters = json_decode($filters, true);
        if($place_options == 1)
            $current_page = 0;
        $settingRepo = new SettingRepository(session('shopId'));
        $settings = $settingRepo->getObjAll();
        $orders = $repository->allOrderPlace(session('shopId'), $current_page, $filters);
        if($orders)
        {
            $obj_order = [];

            foreach ($orders as $key => $order)
            {
                if($order->lineItem->count() > 0)
                {
                    $obj_order[$key] = [
                        "orderId" => $order->id,
                        "orderName" => $order->order_name,
                        "shipping_city" => Helpers::changeUtf8ToAscii($order->city),
                        "shipping_country" => Helpers::changeUtf8ToAscii($order->country),
                        "shipping_country_code" => $order->country_code,
                        "shipping_name" => Helpers::changeUtf8ToAscii($order->fullname),
                        "shipping_phone" => $order->phone,
                        "shipping_phone_code" => $order->phone_code,
                        "shipping_province" => Helpers::changeUtf8ToAscii($order->province),
                        "shipping_province_code" => $order->province_code,
                        "shipping_email" => $order->email,
                        "shipping_zip" => $order->zip,
                        "currency" => $order->currency,
                        "shipping_address1" => Helpers::changeUtf8ToAscii($order->address1),
                        "shipping_address2" => Helpers::changeUtf8ToAscii($order->address2),
                        "total_price_order" => $order->total_price_order,
                    ];

                    $obj_order[$key]['orderitems']=[];
                    foreach ($order->lineItem as $line_item)
                    {

                        if(empty($line_item->aliexpress_order_no) && empty($line_item->tracking_code))
                        {

                            $obj_order[$key]['orderitems'][] = [
                                "ali_ext_id" => $line_item->productVariant->aliexpress_options,
                                "quantity" => $line_item->quality,
                                "product_ext_id" => $line_item->productVariant->aliexpress_product_id,
                                "source_product_link" => $line_item->productVariant->source_product_link,
                                "line_item_id" => $line_item->id,
                                "total_price_item" => $line_item->price
                            ];
                        }

                    }

                }
            }
            return response()->json(['orders' => array_values($obj_order), 'default_setting' => $settings]);
        }
        else
            return response()->json(['status' => false]);
    }
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request)
    {
        $dataOrder = $request->all();

        /**
         * @var OrderRepository;
         */
        $orderRepository = app(OrderRepository::class);
        if($orderRepository->update($dataOrder['orderId'], $dataOrder))
            return response()->json(['status' => true]);

        return response()->json(['status' => false]);
    }

    /**
     * Update aliOrderNo in line_item
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateAliOrderNo(Request $request)
    {
        /**
         * @var LineItemRepository
         */
        $lineItemRepository = app(LineItemRepository::class);
        $lineItemIds = $request->input('lineItemId', []);
        // return response()->json(['status' => false]);
        $dataResponse = [];
        foreach($lineItemIds as $id) {
            $lineItem = LineItemModel::find($id);
            if( ! $lineItem) {
                $dataResponse[$id]['status'] = false;
                continue;
            }
            $data = [];
            $data['aliexpress_order_no'] = $request->input('aliexpress_order_no','');
            if(in_array($lineItem->status, [config('order.status.to_order'), config('order.status.order_placed')]))
            {
                if($data['aliexpress_order_no'] != '')
                    $data['status'] = config('order.status.order_placed');
                else
                    $data['status'] = config('order.status.to_order');
            }

            if($lineItemRepository->update($id, $data))
            {
                $lastUpdate = $lineItemRepository->get($id);
                $dataResponse[$id] = ['status' => true, 'lastUpdate' => $lastUpdate];
            }
        }
        return response()->json(['status' => true, 'data' => $dataResponse]);
    }

    public function updateTrackingCode(Request $request)
    {
        $lineItem = $request->input('item');
        $sendMailCustomer = $request->input('send_mail_customer', false);

        $lineItemId = $lineItem['id'];
        $trackingCode = $lineItem['tracking_code'];
        $orderId = $lineItem['orders_id'];

        $status = config('order.status.shipped');
        $lineItemRepo = app(LineItemRepository::class);
        $shopRepo = app(ShopRepository::class);
        $settingRepo = new SettingRepository(session('shopId'));

        $shop = $shopRepo->detail(session('shopId'));
        $default_fulfillment_tracking_url = $settingRepo->getKey('default_fulfillment_tracking_url');

        $fulfillment = [
            'location_id' => $shop->primary_location_id,
            'tracking_number' => $trackingCode,
            'line_items' => [
                [
                    'id' => $lineItemId
                ]
            ],
            'notify_customer' => $sendMailCustomer
        ];


        if(isset($default_fulfillment_tracking_url->value) and filter_var($default_fulfillment_tracking_url->value, FILTER_VALIDATE_URL))
            $fulfillment['tracking_url'] = $default_fulfillment_tracking_url->value;

        //Update Fulfillment api
        
        $fulfillmentApi = new FulfillmentApi(session('shopDomain'), session('accessToken'));
        
        CreateFulfillmentWithTrackingCodeJob::dispatch(session('shopDomain'), session('accessToken'), $orderId, $fulfillment)->onQueue('tracking_code_aliexpress');

        // if( ! $isUpdateFulfillment['status'])
        //     return response()->json(['status' => false, 'message' => $isUpdateFulfillment['message']]);

        if($lineItemRepo->update($lineItemId, ['tracking_code' => $trackingCode, 'status' => $status]))
        {
            $lineItemUpdate = $lineItemRepo->get($lineItemId);
            return response()->json(['status' => true, 'lineItemUpdate' => $lineItemUpdate]);
        }


        return response()->json(['status' => false, 'message' => $isUpdateFulfillment['message']]);

    }

    public function updateMultipleTrackingCode(Request $request)
    {
        $datas = $request->input('data');
        // Foreach data to map new data

        
        $lineItem = $request->input('item');
        $sendMailCustomer = $request->input('send_mail_customer', false);
        $trackingCode = $request->input('tracking_code', false);
        
        $shopRepo = app(ShopRepository::class);
        $settingRepo = new SettingRepository(session('shopId'));

        $shop = $shopRepo->detail(session('shopId'));
        $default_fulfillment_tracking_url = $settingRepo->getKey('default_fulfillment_tracking_url');

        $fulfillment = [
            'location_id' => $shop->primary_location_id,
            'tracking_number' => $trackingCode,
            'line_items' => [],
            'notify_customer' => $sendMailCustomer
        ];
        $orderId = null;
        foreach($datas as $data) {
            $orderId = $data['orders_id'];
            $fulfillment['line_items'][] = $data['id'];
        }

        if(isset($default_fulfillment_tracking_url->value) and filter_var($default_fulfillment_tracking_url->value, FILTER_VALIDATE_URL))
            $fulfillment['tracking_url'] = $default_fulfillment_tracking_url->value;

        $orderRepo = app(OrderRepository::class);
        $lineItemRepo = app(LineItemRepository::class);
        CreateFulfillmentMultipleLineItemWithTrackingCodeJob::dispatch(session('shopDomain'), session('accessToken'), $orderId, $fulfillment, $fulfillment['line_items'])->onQueue('tracking_code_aliexpress');
        $lineItemUpdate = [];
        foreach($datas as $data) {
            if($lineItemRepo->update($data['id'], ['tracking_code' => $trackingCode, 'status' => config('order.status.shipped')]))
            {
                $lineItemUpdate[] = $lineItemRepo->get($data['id']);
            }
        }
        return response()->json(['status' => true, 'lineItemUpdate' => $lineItemUpdate]);
    }

    public function sendMailCustomer(Request $request)
    {
        $data = $request->all();
        $shopRepo = new ShopRepository();
        $shop = $shopRepo->detail(session('shopId'));

        Mail::to($data['email'])->send(new SendCustomer($data, $shop));
        return response()->json(['status' => true]);
    }

    public function reFulfillOrders(Request $request) {
        $orderRepo = app(OrderRepository::class);
        $shopRepo = new ShopRepository();
        $shopId = session('shopId');
        $shop = $shopRepo->detail($shopId);
        if(Cache::get('fulfillmented_with_tracking_code_'.$shopId, false)) {
            $currentNumber = Cache::get('fulfillmented_with_tracking_code_'.$shopId);
            FulfillmentWithTrackingCodeJob::dispatch($shopId)->onQueue('fulfillment_with_tracking_code');
            Helpers::setStatusAutoFulfillment($shopId, $currentNumber + 1);
        }
        return response()->json(['status' => true]);
    }

    public function syncOrdersToday(Request $request) 
    {
        $filters = $request->all();
        $shopId = session('shopId');
        $shopDomain = session('shopDomain');
        $accessToken = session('accessToken');            
        SyncOrderJob::dispatch($shopId, $shopDomain, $accessToken, 'unfulfilled', 0, $filters['createdAtMin'], $filters['createdAtMax'])->onQueue('sync_order');
        SyncOrderJob::dispatch($shopId, $shopDomain, $accessToken, 'partial', 0, $filters['createdAtMin'], $filters['createdAtMax'])->onQueue('sync_order');
        SyncOrderJob::dispatch($shopId, $shopDomain, $accessToken, 'shipped', 0, $filters['createdAtMin'], $filters['createdAtMax'])->onQueue('init_app_before');
    }
}
