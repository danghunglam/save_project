<?php

namespace App\Http\Controllers;

use App\Contracts\Repository\ProductImageRepositoryInterface;
use App\Contracts\Repository\ProductRepositoryInterface;
use App\Contracts\Services\CurrencyRate;
use App\Events\ImportProductEvent;
use App\Http\Requests\ImportProductRequest;
use App\Jobs\ImportProductJob;
use App\Jobs\ImportAllProductJob;
use App\Repository\ImportProductImageRepository;
use App\Repository\ImportProductRepository;
use App\Repository\ImportProductVariantRepository;
use App\Repository\ShopRepository;
use App\Repository\ProductImageRepository;
use App\Repository\ProductRepository;
use App\ShopifyApi\CustomCollectionsApi;
use App\ShopifyApi\ProductsApi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use App\Models\ShopModel;
use App\Models\SettingModel;
use App\Models\ImportProductModel;
use App\Events\PushProductEvent;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\Redis;

class ImportController extends Controller
{
    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     */
	public function index()
	{
        $shop = ShopModel::find(session('shopId'));

        $currency_rate = app(CurrencyRate::class);

        $currency = $this->getCurrency();

        if($currency == 'USD') {
            $exchange = 1;
        } else {
            $exchange = $currency_rate->convertFromUsd(1, $currency);
        }

		return view('import.index', compact('totalProduct', 'shop', 'exchange', 'currency'));
	}


    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getPaginationProductImport(Request $request)
    {
        $filters = $request->all();

        $importProductRepo = app(ImportProductRepository::class);

        $productObj = [];
        $products = $importProductRepo->all(session('shopId'), $filters);

        if( ! $products)
            return response()->json(['status' => false]);

        $pagination = [
            'total' => $products->total(),
            'last_page' => $products->lastPage(),
            'perPage' => $products->perPage(),
            'current_page' => $products->currentPage()
        ];

        $totalProducts = $products->total();

        //Filter product data
        $productObj = $importProductRepo->filterDataProduct($products);

        return response()->json(['status' => true,
                                 'productObj' => $productObj,
                                 'totalProduct' => $totalProducts,
                                 'pagination' => $pagination]);
    }

    public function getAllProductType() {
        $shop = ShopModel::find(session('shopId'));
        if(!$shop)
            return response()->json(['status' => false, 'product_type' => []]);
        return response()->json(['status' => true, 'product_type' => $shop->productType]);
    }

    /*public function getAllProductType() {
        $shop = ShopModel::find(session('shopId'));
        if(!$shop)
            return response()->json(['status' => false, 'product_type' => []]);
        return response()->json(['status' => true, 'product_type' => $shop->productType]);
    }*/

    public function getAllCollection()
    {
        $customCollectionApi  = app(CustomCollectionsApi::class);
        $customCollectionApi->setParameter(session('shopDomain'), session('accessToken'));

        //get customCollection
        $customCollection = $customCollectionApi->custom();
        if( ! $customCollection['status'])
            return response()->json(['status' => false]);
        $customCollection = $customCollection['data']->custom_collections;

        //get smartCollection
        $smartCollection = $customCollectionApi->smart();
        if( ! $smartCollection['status'])
            return response()->json(['status' => false]);
        $smartCollection = $smartCollection['data']->smart_collections;

        $allCollectionApi = array_merge($customCollection,$smartCollection);

        return response()->json(['status' => true, 'custom_collection' => $allCollectionApi]);
    }

    /**
     * Update image info
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function selectImage(Request $request)
    {
        $id = $request->input('id');
        $req = $request->all();
        $productImageRepo = app(ImportProductImageRepository::class);
        if($productImageRepo->update($id, $req))
            return response()->json(['status' => true]);

        return response()->json(['status' => false]);
    }

    public function variant(Request $request)
    {
        $variantId = $request->input('id');
        $variant = $request->all();
        if(is_array($variant['options']))
            $variant['options'] = json_encode($variant['options']);
        $productVariantRepo = app(ImportProductVariantRepository::class);

        if( ! $productVariantRepo->update($variantId, $variant))
            return response()->json(['status' => false]);

        return response()->json(['status' => true]);
    }

    /**
     * Update variants info
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function variants(Request $request)
    {
        $productVariantRepo = app(ImportProductVariantRepository::class);
        $variants = $request->all();

        $arg_str = [];
        foreach ($variants as $variant)
        {   $str = '';
            foreach ($variant['options'] as $key=>$value)
            {
                $str .= str_replace(' ','',$value);
            }
            $arg_str[] = $str;
        }
        $checkDuplicateOptions = array_count_values($arg_str);
        if(count($checkDuplicateOptions) != array_sum($checkDuplicateOptions))
            return response()->json(['status' => 402]);

        foreach ($variants as $variant)
        {
            if(is_array($variant['options']))
                $variant['options'] = json_encode($variant['options']);

            $productVariantRepo->update($variant['id'], $variant);
        }
        return response()->json(['status' => true]);
    }

    /**
     * @param ImportProductRequest $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function products(ImportProductRequest $request)
    {
        $productRepo = app(ImportProductRepository::class);
        $product = $request->input('product');
        $productId = $product['id'];
        $product['custom_collection'] = json_encode($product['custom_collection']);
        $product['tag'] = is_array($product['tag']) ? implode(',',$product['tag']) : (! empty($product['tag']) ? $product['tag'] : '');
        if($productRepo->update(session('shopId'), $productId, $product))
            return response()->json(['status' => true]);

        return response()->json(['status' => false]);
    }

    public function contentProducts(Request $request){
        $data = $request->all();
        $productRepo = app(ImportProductRepository::class);
        $productId = $data['productId'];
        $product['body_html'] = $data['content'];
        if($productRepo->update(session('shopId'), $productId, $product))
            return response()->json(['status' => true]);
        return response()->json(['status' => false]);
    }

    /**
     * push one or selected product
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function pushProduct(Request $request)
    {
        $products = $request->all();
        $shopId = session('shopId');
        $productIds = [];
        foreach ($products as $product) {
            array_push($productIds, (double)$product['id']);
        }


        if(!empty($products)) {
            Helpers::pushProcessCache(session('shopId'), $products, 'import_product', 180);
        }


        $importProductRepo = app(ImportProductRepository::class);
        $products = $importProductRepo->getProductsByIds($shopId, $productIds);
        if(empty($products)) return response()->json(['status' => false]);
        $shopRepo = app(ShopRepository::class);
        $shop = $shopRepo->getAttributes(['id'=>$shopId]);
        $isVote = (int)($shop->is_vote);
        event(new PushProductEvent($shopId, count($products)));
        $count_import_product = Cache::get('push_product_'.$shopId);
        $fails = $this->handleImport($products);

        return response()->json(['status' => true, 'fails' => $fails, 'isVote' => $isVote, 'count_import_product'=>$count_import_product , 'message' => 'Importing...']);
    }
    
    public function pushAllProduct(Request $request) {
        $shopId = session('shopId');
        $shopDomain = session('shopDomain');
        $accessToken = session('accessToken');

        $importProductRepo = app(ImportProductRepository::class);
        $total_product_import = $importProductRepo->count($shopId);

        if($total_product_import)
            event(new ImportProductEvent($shopId, $total_product_import));

        $count_import_product = Cache::get('push_product_'.$shopId);
        $shopRepo = app(ShopRepository::class);
        $shop = $shopRepo->getAttributes(['id'=>$shopId]);
        $isVote = (int)($shop->is_vote);
        $this->dispatch((new ImportAllProductJob($shopId, $shopDomain, $accessToken))->onQueue('import_all_product'));
        return response()->json(['status' => true, 'isVote' => $isVote, 'count_import_product'=>$count_import_product , 'message' => 'Importing...']);
    }

    /**
     * Delete multi products, handle from delete view
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteProducts(Request $request)
    {
        $products = $request->all();
        $importProductRepo = app(ImportProductRepository::class);
        foreach ($products as $product)
        {
            if( ! $importProductRepo->delete(session('shopId'), $product['id']))
                return response()->json(['status' => false]);
        }
        return response()->json(['status' => true]);
    }

    public function deleteAllProducts(Request $request)
    {
        $products = $request->all();
        $importProductRepo = app(ImportProductRepository::class);
        if( ! $importProductRepo->deleteAllByShopId(session('shopId')))
            return response()->json(['status' => false]);
        return response()->json(['status' => true]);
    }

    /**
     * vote App
     * @return mixed
    */
    public function voteApp(){
        $shopId = session('shopId');
        $shopRepo = app(ShopRepository::class);
        $shopUpdate = $shopRepo->createOrUpdate($shopId, ['is_vote' => 1]);
        return response()->json(['status'=>$shopUpdate]);
    }

    private function handleImport($products) {

        $shopId = session('shopId');
        $shopDomain = session('shopDomain');
        $accessToken = session('accessToken');
        $importProductRepo = app(ImportProductRepository::class);
        $products = $importProductRepo->filterDataProduct($products);
        $fails = [];
        foreach ($products as $product)
        {
            if(!$product['id']) continue;
            if( ! ImportProductModel::find($product['id'])) {
                $fails[] = $product['id'];
                continue;
            }

            if(!$product['variants']) $product['variants'] = [];

            // Set Option for variants
            $productOptions = [];
            array_slice($product['variants'], 0, 100);
            $tmp_options = [];
            $count = 0;
            foreach ($product['variants'] as &$variant) {
                $number = 1;
                $str_tmp = '';
                $is_option = false;
                foreach ($variant['options'] as $key => $value) {
                    if($number > 3) break;
                    $str_tmp .= str_slug($value);
                }
                if( ! in_array($str_tmp, $tmp_options))
                    $tmp_options[] = $str_tmp;
                else {
                    $is_option = true;
                }
                foreach($variant['options'] as $key => $value) {
                    if($number > 3) break;
                    if($is_option) {
                        $key = $key;
                        $value = $value.$count;

                        $count++;
                    }
                    $productOptions[$number] = array(
                        'name' => $key,
                        'position' => $number
                    );
                    $variant['option' . $number] = $value;
                    $number++;
                }
            }

            $product['options'] = array_values($productOptions); // set column options for product
            $this->dispatch((new ImportProductJob($shopId, $product, $shopDomain, $accessToken))->onQueue('import_product'));


            $importProductRepo->update($shopId, $product['id'], ['is_import' => true]);
        }
        return $fails;
    }

    private function getCurrency() {
        $shopId = session('shopId');
        $isConvertCurrency = SettingModel::where('shop_id', $shopId)->where('key', 'is_convert_currency')->first();
        if($isConvertCurrency && $isConvertCurrency->value == "1") {
            $shop = ShopModel::find($shopId);
            $currency = $shop->currency ? $shop->currency : 'USD';
        } else {
            $currency = 'USD';
        }
        return $currency;
    }

    public function updateProductImage(Request $request)
    {
        $product_id = $request->input('product_id');
        $images = $request->input('images');
        $product_repository = app(ImportProductRepository::class);
        $product_image_repository = app(ImportProductImageRepository::class);
        $product = [
            'image' => $images[0]['src']
        ];
        if($product_repository->update(session('shopId'), $product_id, $product)) {
            foreach($images as $image) {
                if($image['id'] !== config('common.product_image_id_default'))
                    $product_image_repository->update($image['id'], $image);
            }

            return response()->json(['status' => true]);
        }
        return response()->json(['status' => false]);
    }

    public function relicateProduct(Request $request) {
        $product_id = $request->input('product_id');
        $variant_selected = $request->input('variant_selected', []);
        $importProduct = ImportProductModel::find($product_id);
        if(!$importProduct || $importProduct->shop_id != session('shopId')) {
            return response()->json(['stauts' => false]);
        }
        // call funciton
        $productRepository = app(ImportProductRepository::class);
        $productRepository->replicateImportProduct($product_id, $variant_selected);
        return response()->json(['stauts' => true]);
    }
}
