<?php

namespace App\Http\Controllers;

use App\Jobs\ImportProductsFromApi;
use App\Jobs\InitDatabaseApps;
use App\Jobs\ScriptTagApps;
use App\Jobs\WebHookAppsJob;
use App\Repository\ShopsRepository;
use App\ShopifyApi\ChargedApi;
use App\ShopifyApi\ShopsApi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;

/**
 * Class ChargedController
 *
 * @package App\Http\Controllers
 */
class ChargedController extends Controller
{
	/**
	 * @var \Illuminate\Foundation\Application|mixed
	 */
	private $_chargedApi;
	/**
	 * @var \Illuminate\Foundation\Application|mixed
	 */
	private $_shopRepo;
	/**
	 * @var \Illuminate\Foundation\Application|mixed
	 */
	private $_shopApi;
	
	public function __construct()
	{
		/**
		 * @var ChargedApi
		 */
		$this->_chargedApi = app( ChargedApi::class );
		
		/**
		 * @var ShopsRepository
		 */
		$this->_shopRepo = app( ShopsRepository::class );
		
		/**
		 * @var ShopsApi
		 */
		$this->_shopApi = app( ShopsApi::class );
	}
	
	/**
	 * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|string
	 */
	public function addCharged()
	{
		$this->_chargedApi->setParameter(session('accessToken'), session('shopDomain'));
		$addCharged = $this->_chargedApi->addCharge();
		if ( ! $addCharged['status'] ) {
			return view('page_errors.404', ['message' => Lang::get('auth.reinstall_noti')]);
		}
		
		if ( ! filter_var( $addCharged['addCharge']->confirmation_url,
			FILTER_VALIDATE_URL )
		) {
			return view( 'page_errors.404', [ 'message' => 'URL charged confirmation not validate' ] );
		}
		
		return redirect( $addCharged['addCharge']->confirmation_url );
	}
	
	/**
	 * @param Request $request
	 *
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|\Illuminate\View\View
	 */
	public function chargeHandle( Request $request )
	{
		$idCharged = $request->input( 'charge_id' );
		$this->_chargedApi->setParameter( session( 'accessToken' ), session( 'shopDomain' ) );
		
		$detailCharged = $this->_chargedApi->detailCharge( $idCharged );
		if ( ! $detailCharged['status'] ) {
			return view( 'page_errors.404', [ 'message' => $detailCharged['message'] ] );
		}
		
		$detailCharged = $detailCharged['detailCharge'];
		if ( $detailCharged->status == 'accepted' ) {
			$activeCharge = $this->_chargedApi->activeCharge( $idCharged );
			if ( ! $activeCharge['status'] ) {
				return view( 'page_errors.404', [ 'message' => $activeCharge['message'] ] );
			}
			
			$activeCharge = $activeCharge['activeCharge'];
			//Get Shop info in api
			$this->_shopApi->setParameter( session( 'accessToken' ), session( 'shopDomain' ) );
			$shopInfo = $this->_shopApi->get();
			//Array record shop save database
			if ( $shopInfo['status'] ) {
				$shopInfo     = $shopInfo['shop'];
				$recordShop   = [
					'shop_id'      => $shopInfo->id,
					'shop_name'    => isset( $shopInfo->myshopify_domain ) ? $shopInfo->myshopify_domain : null,
					'shop_email'   => isset( $shopInfo->email ) ? $shopInfo->email : null,
					'shop_status'  => config( 'common.status.publish' ),
					'shop_country' => isset( $shopInfo->country ) ? $shopInfo->country : null,
					'shop_owner'   => isset( $shopInfo->shop_owner ) ? $shopInfo->shop_owner : null,
					'plan_name'    => isset( $shopInfo->plan_name ) ? $shopInfo->plan_name : null,
					'app_version'  => config( 'common.app_version', null ),
					'billing_id'   => isset( $activeCharge->id ) ? $activeCharge->id : null,
					'billing_on'   => isset( $activeCharge->billing_on ) ? $activeCharge->billing_on : null,
					'access_token' => session( 'accessToken', null )
				];
				$saveInfoShop = $this->_shopRepo->insert( $recordShop );
				if ( $saveInfoShop['status'] ) {
					//Import Database
					$this->dispatch( new ImportProductsFromApi( session( 'shopId' ), session( 'accessToken' ), session( 'shopDomain' ) ) );
					//Add WebHooks
					$this->dispatch( new WebHookAppsJob( session( 'accessToken' ), session( 'shopDomain') ) );
					//Add Script Tags
					$this->dispatch( new ScriptTagApps( session( 'accessToken' ), session( 'shopDomain' ) ) );
					//Init Database
					$this->dispatch( new InitDatabaseApps( session( 'shopId' ) ) );
					//Add AliReview Code To Theme
					$this->dispatch( new AddCodeAliReviewsToThemeApps( session( 'accessToken' ), session( 'shopDomain' ) ) );
					
					$this->dispatch( new MetaFieldApps( session( 'accessToken' ), session( 'shopDomain' ), session( 'shopId' ) ) );
					
					return redirect( route( 'apps.charge_thank' ) );
				}
				
				
				return view( 'page_errors.404', [ 'message' => $shopInfo['message'] ] );
			}
			
			return view( 'page_errors.404', [ 'message' => $shopInfo['message'] ] );
			
		} else {
			return view( 'chargedApp.decline' );
		}
	}
	
	public function chargeThank()
	{
		return view( 'chargedApp.thank' );
	}
}
