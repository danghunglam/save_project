<?php

namespace App\Http\Controllers;


use App\Events\AutoUpdatePriceEvent;
use App\Events\UpdateAliexpressEvent;
use App\Events\OrderFulfillmentEvent;
use App\Helpers\Helpers;
use App\Helpers\TokenHelper;
use App\Jobs\BulkImportAliexpressOberloJob;
use App\Jobs\UpdateTrackingCodeAliexpressJob;
use App\Jobs\UpdateTrackingCodeOberloJob;
use App\Jobs\UpdateTrackingCodeToShopifyJob;
use App\Jobs\CreateFulfillmentWithTrackingCodeJob;
use App\Jobs\CreateFulfillmentAllLineItemWithTrackingCodeJob;
use App\Models\LineItemModel;
use App\Models\AliexpressOrderHistory;
use App\Models\OrderFulfillment;
use App\Repository\ProductRepository;
use App\Repository\LineItemRepository;
use App\Repository\ProductVariantRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\SupplierRepository;
use App\Repository\OrderRepository;
use App\Services\ApiLayerCurrencyRate;
use App\ShopifyApi\FulfillmentApi;
use App\ShopifyApi\OrdersApi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Contracts\Services\CurrencyRate;
use GuzzleHttp\Client;


class ExtensionController extends Controller
{
    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function syncProducts(Request $request)
    {
        $reqData = $request->json()->all();

        /**
         * @var \App\Repository\ProductRepository
         */
        $productRepo = app(ProductRepository::class);

        $isUpdate = $productRepo->update($reqData['id'], $reqData['myshopify_domain'], $reqData);

        if ($isUpdate['status'])
            return response()->json(['status' => true, 'id' => $reqData['id'], 'message' => $isUpdate['message']]);

        return response()->json(['status' => false, 'message' => $isUpdate['message']]);
    }

    /**
     * param key variant_title in table *product_variant* | order_id in table *product_variant* | aliexpress_product_id in table *product*
     * param value aliexpress_options
     * @param Request $request
     * @return resource
     */
    public function syncProductVariant(Request $request)
    {
        $redData = $request->json()->all();
        $aliexpressOptions = $redData['aliexpress_options'];
        $orderId = $redData['order_id'];
        $aliexpressProductId = $redData['aliexpress_product_id'];
        $variantTitle = $redData['variant_title'];
        $sql = "UPDATE product_variant 
                INNER JOIN line_item ON product_variant.id = line_item.product_variant_id 
                INNER JOIN product ON product_variant.product_id = product.id
                SET product_variant.aliexpress_options='$aliexpressOptions' 
                WHERE line_item.orders_id='$orderId' 
                    AND line_item.variant_title='$variantTitle' 
                    AND product.aliexpress_product_id='$aliexpressProductId'";

        try {
            $updateSQL = DB::update($sql);
            if ($updateSQL)
                return response()->json(['status' => true, 'message' => 'Update success']);
        } catch (\Exception $exception) {
            return response()->json(['status' => false, 'message' => $exception->getMessage()]);
        }
    }


    /**
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\JsonResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function getAllCountryPhoneCode()
    {
        $file = storage_path('json/country_code_phone.json');
        if (!file_exists($file))
            return response()->json(['status' => false, 'message' => 'File source json country code phone not exist']);

        $phoneCode = file_get_contents($file);
        $phoneCode = json_decode($phoneCode, true);

        return response(['status' => true, 'phoneCode' => $phoneCode]);
    }

    /**
     * Sync info before fulfillment
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Container\EntryNotFoundException
     */
    public function saveAliOrderNumber(Request $request)
    {
        $req = $request->json()->all();

        $publicToken = $req['public_token'];
        $orderItems = $req['saved_order_items'];

        $lineItemRepo = app(LineItemRepository::class);
        $currency_rate = app(ApiLayerCurrencyRate::class);
        $shopRepo = new ShopRepository();
        $shopInfo = $shopRepo->getAttributes(['public_token' => $publicToken]);
        if(!$shopInfo) {
            return response()->json(['status' => false, 'message' => 'wrong public token']);
        }
        //
        if(count($orderItems) > 0) {
            if(isset($orderItems[0]['orderId'])) {
                $orderId = $orderItems[0]['orderId'];
            }
        }
        // if order do chua co trong table thi moi check
        // $orderHadFulfilled = false;
        // if(OrderFulfillment::find($orderId)) {
        //     $orderHadFulfilled = true;
        // }

        // if($orderHadFulfilled) {
        //     $planInfo = $shopRepository->serviceGetPlanInfo($shopInfo->id, ['order']);
        //     if($planInfo['order']['current_order'] >= $planInfo['order']['limit_order']) {
        //         return response()->json([
        //             'status' => false,
        //             'message' => 'limit'
        //         ]);
        //     }
        // }

        //
        foreach ($orderItems as $lineItem)
        {
            // for count order fulfillment
            $AliexpressOrderNo = isset($lineItem['aliexpressOrderNumber']) ? $lineItem['aliexpressOrderNumber'] : null;
            if(!empty($AliexpressOrderNo)) {
                $lineItemInfo = $lineItemRepo->getAttributes(['aliexpress_order_no' => $AliexpressOrderNo]);
                if(empty($lineItemInfo) && !empty($publicToken)) {
                    if($shopInfo) {
                        $shopId = $shopInfo->id;
                        event(new OrderFulfillmentEvent($shopId));
                    }
                }
            
                $line_item = [
                    'status' => config('order.status.order_placed'),
                    'fee_ship' => isset($lineItem['fee_ship']) ? $currency_rate->convertToUsd($lineItem['fee_ship'], $lineItem['currency']) : 0,
                    'price_order_aliexpress' => isset($lineItem['price_order_aliexpress']) ? $currency_rate->convertToUsd($lineItem['price_order_aliexpress'], $lineItem['currency']) : 0,
                    'aliexpress_order_no' => isset($lineItem['aliexpressOrderNumber']) ? $lineItem['aliexpressOrderNumber'] : null,
                    'fee_tax' =>  isset($lineItem['fee_tax']) ? $currency_rate->convertToUsd($lineItem['fee_tax'], $lineItem['currency']) : 0
                ];

                $aliexpressOrderHistory = $line_item;

                $aliexpressOrderHistory['line_item_id'] = $lineItem['line_item_id'];
                $aliexpressOrderHistory['captcha'] = null;
                $aliexpressOrderHistory['shop_id'] = isset($shopInfo->id) ? $shopInfo->id : null;
                $lineItemRepo->update($lineItem['line_item_id'], $line_item);
                
                
                try {
                    $lineItemInfoDB = $lineItemRepo->get($lineItem['line_item_id']);
                    if($lineItemInfoDB && $lineItemInfoDB->orders_id) {
                        $aliexpressOrderHistory['orders_id'] = $lineItemInfoDB->orders_id;
                    }
                    unset($aliexpressOrderHistory['status']);
                    AliexpressOrderHistory::create($aliexpressOrderHistory);
                } catch(\Exception $e) {
                    $client = new Client();
                    $response = $client->request('post', 'https://hooks.slack.com/services/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',
                        [
                            'headers' => [
                                'Content-Type' => 'application/json',
                            ],
                            'body' => json_encode(['text' => $e->getMessage()])
                        ]
                    );
                }
            }

            $lineItem = $lineItemRepo->get($lineItem['line_item_id']);
            event(new UpdateAliexpressEvent($lineItem, true, 'ali_order_number'));
        }
        // if($orderHadFulfilled) {
        //     $planInfo = $shopRepository->serviceGetPlanInfo($shopInfo->id, ['order']);
        //     if($planInfo['order']['current_order'] >= $planInfo['order']['limit_order']) {
        //         return response()->json([
        //             'status' => false,
        //             'message' => 'limit'
        //         ]);
        //     }
        // }

        return response()->json(['status' => true]);
    }

    /**
     * Xử lý hành động update sau khi fulfillment xong bằng extension
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function saveAutoTrackingCode(Request $request)
    {
        $req = $request->json()->all();

        return response(['status' => true, 'data' => $req]);
        /**
         * @var LineItemRepository
         */
        $lineItemRepo = app(LineItemRepository::class);

        $shopRepo = app(ShopRepository::class);

        $aliexpressOrderNo = $req['aliexpress_order_no'];
        $trackingCode = $req['tracking_code'];

        $shopId = $req['shop_id'];

        $feeShip = $req['fee_ship'];
        $priceOrderAliexpress = $req['price_order_aliexpress'];

        $shop = $shopRepo->detail($shopId);
        if( ! $shop)
            return response()->json(['status' => false, 'shop not found']);

        $shopDomain = $shop->myshopify_domain;
        $accessToken = $shop->access_token;

        $lineItems = $lineItemRepo->getAttr(['aliexpress_order_no', $aliexpressOrderNo]);

        if( ! $lineItems)
            return response(['status' => false, 'message' => 'Line Item not found']);

        $req['status'] = config('order.status.shipped');
        $req['fulfillment_status'] = config('order.fulfillment_status.fulfillment');


        /**
         * @var SettingRepository
         */
        $settingRepo = new SettingRepository($shopId);
        $notification_email_customer_fulfillment = $settingRepo->getKey('notification_email_customer_fulfillment');
        $default_fulfillment_tracking_url = $settingRepo->getKey('default_fulfillment_tracking_url');

        foreach ($lineItems as $lineItemId) {
            //If tracking code not found
            if(empty($trackingCode))
            {
                if($lineItem = LineItemModel::find($lineItemId))
                    event(new UpdateAliexpressEvent($lineItem, false, 'tracking_code'));

                return response()->json(['status' => false]);
            }

            //If tracking code found in AliExpress
            //Update tracking code in database
            $lineItemRepo->update($lineItemId, $req);
            if($lineItem = LineItemModel::find($lineItemId))
            {
                //Update view event
                event(new UpdateAliexpressEvent($lineItem, true, 'tracking_code'));

                $fulfillment = [
                    'location_id' => $shop->primary_location_id,
                    'tracking_number' => $trackingCode,
                    'line_items' => [
                        [
                            'id' => $lineItemId
                        ]
                    ],
                    'notify_customer' => false
                ];

                if(isset($notification_email_customer_fulfillment->value) and $notification_email_customer_fulfillment->value == 1)
                    $fulfillment['notify_customer'] = true;

                if(isset($default_fulfillment_tracking_url->value) and  filter_var($default_fulfillment_tracking_url->value, FILTER_VALIDATE_URL))
                    $fulfillment['tracking_url'] = $default_fulfillment_tracking_url->value;

                //Update Fulfillment api
                $fulfillmentApi = new FulfillmentApi($shopDomain, $accessToken);

                $isFulfillment = $fulfillmentApi->create($lineItem->order->id, $fulfillment);
                if(isset($isFulfillment['data']->fulfillment)) {
                    $fulfillmentFromSpf = $isFulfillment['data']->fulfillment;
                    if($fulfillmentFromSpf->status == 'pending') {
                        $fulfillmentApi->complete($lineItem->order->id, $fulfillmentFromSpf->id);
                    }
                }
            }

        }
        return response()->json(['status' => true]);
    }

    /**
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\JsonResponse|\Symfony\Component\HttpFoundation\Response
     */
    public function saveTrackingCode(Request $request)
    {
        $req = $request->json()->all();

        $shopId = $req['shop_id'];
        $accessToken = $req['access_token'];
        $shopDomain = $req['shop_domain'];
        $datas = $req['data'];
        $autoUpdateTrackingCode = isset($req['auto_update_tracking_code']) ? $req['auto_update_tracking_code']: false;
        $ordersApi = new OrdersApi($shopDomain, $accessToken);
        $fulfillmentApi = new FulfillmentApi($shopDomain, $accessToken);
        $shopRepo = new ShopRepository();
        foreach ($datas as $data)
        {
            $line_items = isset($data['line_item_id']) ? $data['line_item_id'] : '';
            $tracking_code = isset($data['tracking_code']) ? $data['tracking_code'] : '';
            UpdateTrackingCodeAliexpressJob::dispatch($line_items, $tracking_code, $shopId, $shopDomain, $accessToken, $autoUpdateTrackingCode)->onQueue('tracking_code_aliexpress');
            // if is auto update tracking code
            if($autoUpdateTrackingCode && $tracking_code != '') {
                $order_id = $data['order_id'];
                $order =  $ordersApi->getOrder($order_id);
                if($order['status']) {
                    $orderObject = $order['data']->order;
                    $fulfillments = $orderObject->fulfillments;
                    if(count($fulfillments) > 0) {
                        foreach($fulfillments as $fulfill) {
                            UpdateTrackingCodeToShopifyJob::dispatch($shopDomain, $accessToken, $order_id, $fulfill->id, $tracking_code)->onQueue('tracking_code_aliexpress');
                        }
                    } else {
                        $shop = $shopRepo->detail($shopId);
                        $fulfillment = [
                            'location_id' => $shop->primary_location_id,
                            'tracking_number' => $tracking_code,
                            'notify_customer' => false
                        ];

                        CreateFulfillmentAllLineItemWithTrackingCodeJob::dispatch($shopDomain, $accessToken, $order_id, $fulfillment)->onQueue('tracking_code_aliexpress');

                        // $fulfillmentApi->create($order_id, $fulfillment);
                    }
                }
            }
        }

        return response()->json(['status' => true]);
    }

    /**
     * Auto merge variant by sku key
     * @param $variant
     * @param $skus
     */
    public function updateAliOption($variant, $skus)
    {
        $productVariantRepo = app(ProductVariantRepository::class);

        foreach ($skus as $key => $value)
        {
            $value = (array) $value;
            $args = [
                'source_quantity' => $value['inventory'],
                'aliexpress_options' => $value['aliexpress_options'],
                'source_price' => (float) $value['price'],
                'aliexpress_product_id' => $variant['aliexpress_product_id'],
                'source_product_link' => $variant['source_product_link'],
                'supplier_id' => $variant['supplier_id']
            ];

            $slug = str_slug($key);
            if(preg_match('/^([0-9])+\-'.$slug.'$/', $variant->sku))
            {
                $productVariantRepo->update($variant->id, $args);
            }
        }
    }

    /**
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function importVariant(Request $request)
    {
        $req = $request->all();
        $shopRepository = new ShopRepository();

        $productId = $request->input('product_id');
        $skus = $request->input('skus');
        $sourceProductLink = $request->input('source_product_link');
        $supplierName = $request->input('supplier_name');
        $supplierUrl = $request->input('supplier_url');
        $supplierId = $request->input('supplier_id');

        if(! empty($sourceProductLink))
            $sourceProductLink = Helpers::filterAliexpressDetailLink($sourceProductLink);


        $productVariantRepo =  app(ProductVariantRepository::class);
        $productRepo = new ProductRepository(session('shopId'));
        $supplierRepo = app(SupplierRepository::class);
        $settingRepo = new SettingRepository(session('shopId'));

        //Update Supplier
        $supplierRepo->createOrUpdate($supplierId, ['id' => $supplierId,'name' => $supplierName, 'url' => $supplierUrl]);

        //Check product is not product_source_link
        $product = $productRepo->detail($productId);
        //update product link aliexpress
        if(empty($product->source_product_link))
            $productData = [
                'aliexpress_product_id' => Helpers::getAliexpressProductId($sourceProductLink),
                'source' => 'aliexpress',
                'source_product_link' => $sourceProductLink,
                'supplier_id' => $supplierId];
            
            $auto_update_when_product_cost_change_aliexpress = $settingRepo->getKey('auto_update_when_product_cost_change_aliexpress');
            if( (!$auto_update_when_product_cost_change_aliexpress) || $auto_update_when_product_cost_change_aliexpress->value == config('setting.auto_update_when_product_cost_change_aliexpress.do_nothing'))
                $productData['auto_update_price'] = config('product.auto_update_price.price_update_off');
            elseif( $auto_update_when_product_cost_change_aliexpress->value == config('setting.auto_update_when_product_cost_change_aliexpress.update_automatically'))
                $productData['auto_update_price'] = config('product.auto_update_price.automatic_price_updates_on');

            $productRepo->update(($productId), $productData);

        $productVariant = $productVariantRepo->getVariantInProduct($productId);

        foreach ($productVariant as $variant)
        {
            if(empty($variant->source_product_link))
            {
                $variant['source_product_link'] = $sourceProductLink;
                $variant['aliexpress_product_id'] = Helpers::getAliexpressProductId($sourceProductLink);
                $variant['supplier_id'] = $supplierId;
                $variant['aliexpress_options'] = isset($variant['aliexpress_options']) ? $variant['aliexpress_options'] : config('common.aliexpress_options_default');
                $this->updateAliOption($variant, $skus);
            }
        }
        $shopRepository->updateSingleTotalQuantityProduct($productId);
        $productVariantAliOptionNull = $productVariantRepo->getVariantAliOptionNullInProduct(($productId));

        return response()->json(['status' => true, 'product_variant_ali_option_null' => $productVariantAliOptionNull]);
    }

    public function mergeVariant(Request $request)
    {
        $variants = $request->input('variant');
        $product_id = $request->input('product_id');
        $productVariantRepo = app(ProductVariantRepository::class);
        $shopRepository = new ShopRepository();
        foreach ($variants as $variantId => $variant)
        {
            $variant['aliexpress_options'] = isset($variant['aliexpress_options']) ? $variant['aliexpress_options'] : 'fire_apps';
            $productVariantRepo->update($variantId, [
                'aliexpress_options' => $variant['aliexpress_options'],
                'source_quantity' => isset($variant['inventory']) ? $variant['inventory'] : 1,
                'source_price' => isset($variant['price']) ? $variant['price'] : 0,
                'aliexpress_product_id' => Helpers::getAliexpressProductId($variant['source_product_link']),
                'source_product_link' => Helpers::filterAliexpressDetailLink($variant['source_product_link']),
                'supplier_id' => $variant['supplier_id']
            ]);
        }
        // Log::info($product_id);
        // Log::info($shopRepository->updateSingleTotalQuantityProduct($product_id));
        return response()->json(['status' => true]);
    }

    /**
     * Get all product is link aliexpress is update price
     * @param $shopId
     * @return \Illuminate\Http\JsonResponse
     */
    public function linkAliexpress($shopId)
    {
        $productRepo = new ProductRepository($shopId);
        $products = $productRepo->productAutoUpdateAliexpress();
        if( ! $products)
            return response()->json(['status' => false]);

        return response()->json($products);
    }

    /**
     * Xử lý hành động update lại stock price và gửi mail
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateStockPrice(Request $request)
    {
        $shopId = $request->input('shopId');
        $productId = $request->input('productId');
        $data = $request->input('data');
        return response()->json($data);


        $shopRepo = app(ShopRepository::class);
        $setting = new SettingRepository($shopId);
        $shop = $shopRepo->detail($shopId);

        if( ! $setting)
            return response()->json(['status' => false]);

        $auto_update = [
            'product_no_longer_available_aliexpress' => $setting->getKey('auto_update_when_product_no_longer_available_aliexpress'),
            'product_no_longer_available_aliexpress_notify' => $setting->getKey('auto_update_when_product_no_longer_available_aliexpress_notify'),
            'product_variant_no_longer_available_aliexpress' => $setting->getKey('auto_update_when_product_variant_no_longer_available_aliexpress'),
            'product_variant_no_longer_available_aliexpress_notify' => $setting->getKey('auto_update_when_product_variant_no_longer_available_aliexpress_notify'),
            'product_cost_change_aliexpress' => $setting->getKey('auto_update_when_product_cost_change_aliexpress'),
            'product_cost_change_aliexpress_notify' => $setting->getKey('auto_update_when_product_cost_change_aliexpress_notify'),
            'when_one_product_is_out_of_stock_on_aliexpress' => $setting->getKey('when_one_product_is_out_of_stock_on_aliexpress'),
            'when_one_product_is_out_of_stock_on_aliexpress_notify' => $setting->getKey('when_one_product_is_out_of_stock_on_aliexpress_notify')
        ];
        $primary_email_address = $setting->getKey('primary_email_address');

        event(new AutoUpdatePriceEvent($auto_update, $primary_email_address, $shop, $productId, $data));
    }


    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function bulkImportAliexpressOberlo(Request $request)
    {
        $request = $request->json()->all();
        $shopRepo = app(ShopRepository::class);
        $shopDomain = $request['shop_domain'];
        $shop = $shopRepo->getAttributes(['myshopify_domain' => $shopDomain]);
        if( ! $shop || ! $shop->status)
            return response()->json(['status' => false]);

        $productRepo = new ProductRepository($shop->id);
        $products = $request['products'];

        if(count($products) == 1) {
            $product = $productRepo->detail($products[0]['id_shopify']);
            if(!$product) {
                return response()->json(['status' => true, 'total_update' => count($products), 'not_found_product' => true]);
            }
            if(!empty($product->source_product_link)) {
                return response()->json(['status' => true, 'total_update' => count($products), 'imported_already' => true]);
            }
        }
        BulkImportAliexpressOberloJob::dispatch($shop, $products)->onQueue('bulk_import_aliexpress_oberlo');
        return response()->json(['status' => true, 'total_update' => count($products)]);
    }

    /**
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function getVariantsProduct($id)
    {
        $productVariantRepo = app(ProductVariantRepository::class);
        $variants = $productVariantRepo->getVariantInProduct($id);
        if( ! $variants)
            return response()->json(['status' => false]);

        return response()->json(['status' => true, 'variants' => $variants]);
    }
    /**
     * Update tracking code from oberlo
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateMultiTrackingCode(Request $request)
    {
        $publicToken = $request->input('public_token');
        $datas = $request->input('data');
        $shopRepo = app(ShopRepository::class);
        $shop = $shopRepo->getAttributes(array('public_token' => $publicToken));
        if($shop == false)
            return response()->json(['status' => false, 'message' => 'Can not find Shop']);

        foreach ($datas as $data)
        {
            UpdateTrackingCodeOberloJob::dispatch($data, $publicToken)->onQueue('update_tracking_code_oberlo');
        }

        return response()->json(['status' => true, 'message' => 'Update success']);
    }   


    /**
     * Get oberlo tracking code null and aliexpress_order_no not null
     * @param string $public_token
     *
     * @return mixed
     */
    public function getOrdersLineItemTrackingCodeNull($public_token)
    {
        $shopRepo = app(ShopRepository::class);
        $shopId = $shopRepo->getShopId($public_token);
        $argsOrder = [];
        if($shopId)
        {
            $orderRepo = app(OrderRepository::class);
            $orders = $orderRepo->getOrderId($shopId->id);
            if($orders)
            {
                foreach ($orders as $order)
                {
                    $argsOrder[] = $order['id'];
                }

                $lineItemRepo = app(LineItemRepository::class);
                $ali_order_number = $lineItemRepo->getTrackingCodeNull($argsOrder);

                return response()->json([
                    'public_token' => $public_token,
                    'data' => $ali_order_number
                ]);
            }
            return response()->json(['status' => false]);
        }
        return response()->json(['status' => false]);
    }



    public function convertExchangeCurrency(Request $request)
    {
        $currencyRate = app(CurrencyRate::class);
        $currency = $request->input('currency', null);
        $value = $request->input('value', null);
        $currencyRate = app(CurrencyRate::class);
        if( ! $currency || ! $value)
            return response()->json(['status' => false, 'message' => 'parameter invalid']);

        $convert = $currencyRate->convertFromUsd($value, $currency);

        if($convert)
            return response()->json(['status' => true, 'currency' => 'USD', 'value' => $convert]);

        return response()->json(['status' => false, 'message' => 'Cannot convert currency']);
    }

    public function setLastTimeUpdate(Request $request) {
        if(! Helpers::setLastUpdateTime(session('shopId')))
            return response()->json(['status' => false]);


        if(! $token = TokenHelper::createToken(['shop_id' => session('shopId')], 172800))
            return response()->json(['status' => false]);

        return response()->json(['status' => true, 'token' => $token]);
    }

    public function setLastTimeUpdateTrackingCode(Request $request) {
        $numberOfDate = $request->numberOfDate;
        $shopId = session('shopId');

        if(! Helpers::setLastUpdateTrackingCodeTime($shopId, $numberOfDate))
            return response()->json(['status' => false]);

//        if(! $token = TokenHelper::createToken(['shop_id' => $shopId], 1440))
//            return response()->json(['status' => false]);
        Helpers::setStatusAutoFulfillment($shopId, 1);
        $orderRepository = new OrderRepository();
        $shopId = session('shopId');
        $shopRepo = new ShopRepository();
        $shop = $shopRepo->detail($shopId);
        $orderRepo =  $orderRepository->getOrderId($shopId);
        $orderIds = [];
        $orderArr = [];
        foreach($orderRepo as $order) {
            array_push($orderIds, $order['id']);
        }

        $lineItemRepository = new LineItemRepository();

        $lineItemTrackingCodeNull = $lineItemRepository->getLineItemTrackingCodeNull($orderIds);

        foreach($lineItemTrackingCodeNull as $k=>$lineItem) {
            if(!empty($lineItem->aliexpress_order_no)) {
                $orderArr[$k]['ali_order_no'] = $lineItem->aliexpress_order_no;
            }
            $orderArr[$k]['line_item_id'] = [(double)$lineItem->id];
            $orderArr[$k]['order_id'] = (double)$lineItem->orders_id;
        }
        for($i=0; $i<count($orderArr)-1; $i++) {
            for($j=$i+1; $j<count($orderArr); $j++) {
                if($orderArr[$i]['ali_order_no'] === $orderArr[$j]['ali_order_no']) {
                    $orderArr[$i]['line_item_id'] = array_merge($orderArr[$i]['line_item_id'], $orderArr[$j]['line_item_id']);
                    array_splice($orderArr, $j, 1);
                }
            }
        }

        return response()->json(['status' => true, 'lineItemTrackingCodeNull' => $orderArr, 'shop' => $shop]);
    }

    public function checkOrderTypeSync(Request $request) {
        $shopId = session('shopId');
        $shopRepo = new ShopRepository();
        $shop = $shopRepo->detail($shopId);
        if(isset($shop->order_type_sync) && $shop->order_type_sync >= 3) {
            $shopRepo->createOrUpdate($shopId, ['order_type_sync' => 0]);
            return response()->json(['status' => true]);
        }
        return response()->json(['status' => false]);
    }

    public function shopInfo($public_token)
    {
        $shop_repository = app(ShopRepository::class);
        $shop = $shop_repository->getAttributes(['public_token' => $public_token]);
        return response()->json($shop);
    }

    public function shopInfoPlan($public_token)
    {
        $shop_repository = app(ShopRepository::class);
        $shop = $shop_repository->getAttributesWithPlan(['public_token' => $public_token]);
        return response()->json($shop);
    }

    public function getAliexpressAddress(Request $request) {
        $req = $request->json()->all();

        if(!$req['country']) {
            return response()->json([]);
        }
        $country = $req['country'];
        $province = isset($req['province']) ? $req['province'] : null;
        $getAliexpressAddress = Helpers::getAliexpressAddress();
        if(isset($getAliexpressAddress[$country])) {
            $data = array_values($getAliexpressAddress[$country]);
            if($province) {
                $data = array_filter($data, function ($item) use ($province) {
                    return strtolower($item['n']) == strtolower($province);
                });
            }
            return response()->json([
                'province' => array_values($data)
            ]);
        }
        
        return response()->json([
            'message' => 'country_not_found'
        ]);
    }
}
