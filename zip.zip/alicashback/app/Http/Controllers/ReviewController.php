<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\ApiHelper;
use App\Helpers\SettingHelper;
class ReviewController extends Controller
{
    public function getDefaultReview()
    {
        $url = env('ALIREVIEW_DOMAIN');
        $request = $url.'/v1/settings/default';
        $settingDefault = ApiHelper::getApi($request);
        $countries = SettingHelper::getCountryCode();
        $data = [
            'settingDefault' => $settingDefault,
            'countries' => $countries
        ];

        return response()->json(['data'=>$data, 200]);
    }


}
