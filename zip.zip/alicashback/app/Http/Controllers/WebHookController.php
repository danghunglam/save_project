<?php

namespace App\Http\Controllers;


use App\Helpers\Helpers;
use App\Jobs\CreateProductWebhookJob;
use App\Jobs\UpdateOrderWebHookJob;
use App\Jobs\UpdateProductWebhookJob;
use App\Mail\UninstallApps;
use App\Repository\ProductImageRepository;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use App\Repository\OrderRepository;
use App\Repository\LineItemRepository;
use App\Repository\ProductRepository;
use App\Repository\ProductVariantRepository;
use App\Repository\ShopRepository;
use App\Helpers\ProductHelper;
use App\Helpers\ProductTypeHelper;
use App\Helpers\OrderHelper;
use App\Helpers\LineItemHelper;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use App\Mail\UninstallApp;
use App\Events\AppsErrorEvent;
use App\Events\UninstallAppEvent;
use App\ShopifyApi\CollectsApi;

class WebHookController extends Controller {
	
	/**
	 * @param Request $request
	 */
	public function uninstallApp(Request $request ) {
		$res = $request->all();
        event(new UninstallAppEvent($res['id']));
		$shopRepo = new ShopRepository();
		$shopRepo->createOrUpdate($res['id'],
			[
				'status' => config( 'common.status.unpublish' ),
				'access_token' => '',
				'updated_at' => date('Y-m-d H:i:s',time()),
			]);
	}
	
	/**
	 * @param Request $request
     * @return resource
	 */
	public function ordersPaid(Request $request)
	{
		$res = $request->all();
        $res = json_decode(json_encode($res));
        $shopRepo = app(ShopRepository::class);
        $shop_name = $request->server('HTTP_X_SHOPIFY_SHOP_DOMAIN');

		$objectShop = $shopRepo->getAttributes(['myshopify_domain' => $shop_name]);

		if($objectShop) {
            UpdateOrderWebHookJob::dispatch($objectShop, $res)->onQueue('webhook_order_update');
        }

        $this->slackPush($shop_name);

        return response()->json(['status' => true]);
	}
	
	/**
	 * @param Request $request
     * @return resource
	 */
	public function ordersUpdated(Request $request)
	{
		$res = $request->all();
        $res = json_decode(json_encode($res));
        $financialStatus = $res->financial_status;
        if( $financialStatus != 'pending' && $financialStatus != 'unpaid' && $financialStatus != null )
        {
            $shopRepo = app(ShopRepository::class);
            $shop_name = $request->server('HTTP_X_SHOPIFY_SHOP_DOMAIN');
            $objectShop = $shopRepo->getAttributes(['myshopify_domain' => $shop_name ]);
            if ($objectShop){
                UpdateOrderWebHookJob::dispatch($objectShop, $res)->onQueue('webhook_order_update');
            }

        }
        return response()->json(['status' => true]);
	}
	
	/**
	 * @param Request $request
     *
     * @return mixed
	 */
	public function createdProduct(Request $request)
    {
	    $res = $request->all();
	    $shopRepo = new ShopRepository();
	    $shop_name = $request->server('HTTP_X_SHOPIFY_SHOP_DOMAIN');
	    $objectShop = $shopRepo->getAttributes(['myshopify_domain' => $shop_name]);
        if(! isset($objectShop->id))
            return response()->json(['status' => false]);

	    CreateProductWebhookJob::dispatch($objectShop, $res)->onQueue('webhook_update_product');

	    $this->slackPush($shop_name);

	    return response()->json(['status' => true]);
    }
	
	/**
	 * @param Request $request
	 */
    public function updatedProduct(Request $request)
    {
	    $res = $request->all();
        $shopRepo = new ShopRepository();
        $shop_name = $request->server('HTTP_X_SHOPIFY_SHOP_DOMAIN');


        $objectShop = $shopRepo->getAttributes(['myshopify_domain' => $shop_name]);
        if(! isset($objectShop->id))
            return response()->json(['status' => false]);

        UpdateProductWebhookJob::dispatch($objectShop, $res)->onQueue('webhook_update_product');

        return response()->json(['status' => true]);
    }
	
	/**
	 * @param Request $request
     * @return mixed
	 */
	public function deleteProduct( Request $request )
	{
		$res = $request->all();
		$shopRepo = new ShopRepository();
		$shop_name = $request->server('HTTP_X_SHOPIFY_SHOP_DOMAIN');
		$objectShop = $shopRepo->getAttributes(['myshopify_domain' => $shop_name]);
        if(! isset($objectShop->id))
            return response()->json(['status' => false]);

		$productRepo = new ProductRepository($objectShop->id);
        $productVariantRepo = new ProductVariantRepository();
        $productImageRepo = new ProductImageRepository();
		if ($objectShop)
		{
            $productImageRepo->deleteByProductId($res['id']);
            $productVariantRepo->deleteByProductId($res['id']);
			$productRepo->delete($res['id']);
        }
	}

    /**
     * @param Request $request
     */
	public function updateFulfillments(Request $request)
    {
        $res = $request->all();
        $res = json_decode(json_encode($res));
        $lineItemRepo = app(LineItemRepository::class);
        $lineItemRepo->updateTrackingCodeByOrder($res->tracking_number, $res->line_items);
    }

    public function createFulfillments(Request $request)
    {
        $res = $request->all();
        $res = json_decode(json_encode($res));
        $lineItemRepo = app(LineItemRepository::class);
        $lineItemRepo->updateTrackingCodeByOrder($res->tracking_number, $res->line_items);
    }

    public function shopUpdate(Request $request)
    {
        $data = $request->all();
        $shopId = $request->input('id', '');
        unset($data['id']);
        Log::info(json_encode($request->all()));
        $shopRepo = app(ShopRepository::class);
        if($shopRepo->createOrUpdate($shopId, $data))
            return response()->json(['status' => true]);

        return response()->json(['status' => false]);
    }


    public function customersRedact(Request $request)
    {
        Log::info('customersRedact');
        return response([], 200);
    }

    public function shopRedact(Request $request)
    {
        Log::info('shopRedact');
        return response([], 200);
    }

    public function refundsCreate(Request $request)
    {
        Log::info('refundsCreate');
        Log::info($request->all());
    }
    public function ordersFulfilled(Request $request)
    {
        Log::info('ordersFulfilled');
        Log::info($request->all());
    }
    public function ordersPartiallyFulfilled(Request $request)
    {
        Log::info('ordersPartiallyFulfilled');
        Log::info($request->all());
    }

    private function slackPush($data)
    {
        $client = new Client();
        $client->request('post', 'https://hooks.slack.com/services/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',
            [
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'body' => json_encode(['text' => json_encode($data)])
            ]
        );
    }
}
