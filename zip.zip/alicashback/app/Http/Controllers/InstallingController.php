<?php

namespace App\Http\Controllers;

use App\Factory\RepositoryFactory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use DateTime;
use DateInterval;

class InstallingController extends Controller
{
    public function __construct()
    {

    }

    public function index(Request $request)
    {
        $dashboardPage = 'dashboard-page';
        return view('dashboard.dashboard');
    }
}
