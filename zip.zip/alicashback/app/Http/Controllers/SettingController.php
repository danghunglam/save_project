<?php

namespace App\Http\Controllers;


use App\Helpers\Helpers;
use App\Helpers\SettingHelper;
use App\Jobs\InitSettingDefaultJob;
use App\Models\ShopModel;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function index()
    {
        $timeZone = Helpers::listTimezone();

        return view('settings.index', compact('timeZone'));
    }

    public function import()
    {
        return view('settings.import-setting');
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function product()
    {
        return view('settings.product-settings');
    }

    public function order()
    {
        return view('settings.order-settings');
    }

    public function manage_account()
    {
        return view('sign_in.manage_account');
    }

    public function settingHandle(Request $request)
    {
        $dataSettings = $request->all();

        $dataSettings = SettingHelper::encodeSettings($dataSettings);

        $settingRepo = new SettingRepository(session('shopId'));
        if($settingRepo->saveMany($dataSettings))
            return response()->json(['status' => true, 'message' => 'Save setting success']);

        return response()->json(['status' => false, 'message' => 'Save setting error']);
    }

    public function getSetting()
    {
        $settingRepository = new SettingRepository(session('shopId'));
        $shop = session('shop');

        $settings = $settingRepository->getObjAll();
        if( ! $shop || ! $settings)
            return response(['status' => false]);

        $setting_default = config('setting_default');
        $setting_default = array_merge($setting_default, [
            'time_zone' => isset($shop['iana_timezone']) ? $shop['iana_timezone'] : null,
            'primary_email_address' => isset($shop['email']) ? $shop['email'] : '',
            'currency' => isset($shop['currency']) ? $shop['currency'] : 'USD'
        ]);

        return response()->json(['status' => true, 'settings' => $settings, 'setting_default' => $setting_default]);
    }

    public function addRuleProduct(Request $request)
    {

        $repo = ['status' => false, 'message' => 'Apply setting for product error'];
        if( ! $shop = ShopModel::find(session('shopId')))
            return response()->json($repo);

        $count_product = count($shop->importProduct);

        if( $count_product <= 0 ) return response()->json($repo);

        $dataSettings = $request->all();

        $dataSettings = SettingHelper::encodeSettings($dataSettings);

        $settingRepo = new SettingRepository(session('shopId'));

        if( ! $settingRepo->saveMany($dataSettings)) return response()->json($repo);

        if(! $settingRepo->addRuleProduct()) return response()->json($repo);

        $repo['status'] = true;
        $repo['message'] = 'Apply setting for product success';
        $repo['count_product'] = $count_product;
        return response()->json($repo);
    }

}
