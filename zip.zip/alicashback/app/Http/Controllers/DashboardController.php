<?php

namespace App\Http\Controllers;

use App\Factory\RepositoryFactory;
use App\Repository\ShopRepository;
use Illuminate\Http\Request;
use App\Models\ShopModel;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use Illuminate\Support\Facades\Cookie;
use DateTime;
use DateInterval;

class DashboardController extends Controller
{
    protected $_commentRepo;
    protected $_productRepo;
    protected $_shopRepo;
    protected $_discountRepo;

    public function __construct()
    {

    }

    public function index(Request $request)
    {
        $shop = session('shop');
        $shopModel = ShopModel::find(session('shopId'));
        $minDate = '';
        $maxDate = '';
        if(!empty($shop->order)) {
            $minDate = $shop->order()->min('created_at');
            $minDate = date('M d, Y',strtotime($minDate));
            $maxDate = date('M d, Y', time());
        }
        $shopRepo = app(ShopRepository::class);
        $shopRepo->createOrUpdate(session('shopId'), ['onboarding' => 0]);

        return view('dashboard.dashboard', compact('shop', 'minDate', 'maxDate'));
    }
}
