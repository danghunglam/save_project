<?php

namespace App\Http\Controllers;


use App\Contracts\Repository\TrackingCodeRepositoryInterface;
use App\Helpers\SettingHelper;
use App\Jobs\ImportTrackingCodeFromCSVJob;
use App\Repository\SettingRepository;
use Illuminate\Http\Request;

class TrackingCodeController extends Controller
{
    protected $trackingCodeRepository;

    public function __construct(TrackingCodeRepositoryInterface $trackingCodeRepository)
    {
        $this->trackingCodeRepository = $trackingCodeRepository;
    }

    public function index(Request $request)
    {
        $shopId = session('shopId');
        $accessToken = session('accessToken');
        $shopDomain = session('shopDomain');
        $shop = session('shop');
        $settingRepository = new SettingRepository($shopId);
        $settings = $settingRepository->getAll();
        $settings = SettingHelper::decodeSettings($settings);
        $timezone = (isset($settings['timezone']) && $settings['timezone'] !== '') ? $settings['timezone'] : 'UTC';

        //set timezone
        date_default_timezone_set($timezone);

        $filters = $request->all();

        $reject_filter = (isset($filters['reject_filter'])) ? $filters['reject_filter'] : [];

        if(empty($filters['filter_date_to']) && ! in_array('filter_date_to', $reject_filter))
            $filters['filter_date_to'] = date('Y-m-d', time());


        if(empty($filters['filter_date_from']) && ! in_array('filter_date_from', $reject_filter))
            $filters['filter_date_from'] = date('Y-m-d', strtotime( '-30 days'));

        return view('tracking_code.index',
            compact(
                'shopId',
                'accessToken',
                'shopDomain',
                'filters',
                'shop'));

    }

    public function getOrders(Request $request)
    {
        $filters = $request->all();
        $getOrders =$this->trackingCodeRepository->getOrders($filters);
        return response()->json($getOrders);
    }
    public function import(Request $request)
    {
        $request = $request->all();
        ImportTrackingCodeFromCSVJob::dispatch($request)->onQueue('import_trackingCode_csv');

        return response()->json(['status' => true]);
    }
}