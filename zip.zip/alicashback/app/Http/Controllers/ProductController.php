<?php
namespace App\Http\Controllers;
use App\Contracts\Services\CurrencyRate;
use App\Helpers\ProductHelper;
use App\Jobs\AddVariantProductJob;
use App\Jobs\OverrideProductDbJob;
use App\Jobs\OverrideProductSpfJob;
use App\Jobs\UpdateTotalQuantityJob;
use App\Jobs\EditProductSpfJob;
use App\Jobs\UpdateProductOptionsJob;
use App\Jobs\AddAliOrderCodeToThemesJob;
use App\Models\ProductModel;
use App\Models\ShopModel;
use App\Models\ProductVariantModel;
use App\Models\ProductImageModel;
use App\Models\SettingModel;
use App\Repository\OrderRepository;
use App\Repository\ProductRepository;
use App\Repository\ProductVariantRepository;
use App\Repository\ProductImageRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\ShopifyApi\ProductsApi;
use App\ShopifyApi\ProductVariantApi;
use DateTime;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Helpers\ProductTypeHelper;
use App\Helpers\Helpers;
class ProductController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(Request $request)
    {
        $filters = $request->all();
        $currency_rate = app(CurrencyRate::class);
        $current_page = $request->input('page', 1);
        $products = [];
        $currency = $this->getCurrency();
        if($currency == 'USD') {
            $exchange = 1;
        } else {
            $exchange = $currency_rate->convertFromUsd(1, $currency);
        }
        return view('products.index', compact('products', 'filters', 'current_page', 'currency', 'exchange'));
    }
    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function getProducts(Request $request)
    {
        $filters = $request->all();
        $current_page = $request->input('page', 1);
        $productRepo = new ProductRepository(session('shopId'));
        $products = $productRepo->all($filters);
        $pagination =  $products->setPath('products')->appends($filters)->links('vendor.pagination.fireapps');
        return response()->json([
            'products' => $products,
            'pagination_html' => $pagination->toHtml(),
        ]);
    }
    public function getProductsByIds(Request $request)
    {
        $current_page = $request->input('page', 1);
        $shop_id = $request->input('shop_id');
        $ids = $request->input('ids', []);
        if(!$shop_id) {
            return response()->json([
                'status' => false
            ]);
        }
        $productRepo = new ProductRepository($shop_id);
        $products = $productRepo->allForAlireview($ids);
        return response()->json([
            'status' => true,
            'products' => $products
        ]);
    }
    public function index_test()
    {
        $productRepo = new ProductRepository(session('shopId'));
        $products = $productRepo->all([]);
        return response()->json($products);
    }
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function delete(Request $request)
    {
        $isDeleteProductShopify = $request->input('is_delete_product_shopify');
        $productId = $request->input('product_id');
        /**
         * @var ProductRepository
         */
        $productRepo = new ProductRepository(session('shopId'));
        $productVariantRepo = app(ProductVariantRepository::class);
        $productImageRepo = app(ProductImageRepository::class);
        $productApi = new ProductsApi(session('shopDomain'), session('accessToken'));
        DB::beginTransaction();
        if($productRepo->delete($productId))
        {
            $productImageRepo->deleteByProductId($productId);
            $productVariantRepo->deleteByProductId($productId);
            if($isDeleteProductShopify)
            {
                //Delete product in shopify
                if($productApi->delete($productId))
                {
                    DB::commit();
                    return response()->json(['status' => true]);
                }
                DB::rollBack();
                return response()->json(['status' => false]);
            }
            DB::commit();
            return response()->json(['status' => true]);
        }
        return response()->json(['status' => false]);
    }
    /**
     * Xử lý việc override products
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function overrideProduct(Request $request)
    {
        $shopId = session('shopId');
        $override = $request->input('override');
        $current = $request->input('current');
        $options = $request->input('options');
        $variantMerge = $request->input('variant_merge', null);
        $productRepo = new ProductRepository($shopId);
        $productVariantRepo = app(ProductVariantRepository::class);
        $variantHasOrder = [];
        $variantInProduct = [];
        //Get all orders product

        if(isset($current['id']))
        {
            $productProcess = [
                'id' => $current['id'],
                'status' => 'pending',
                'product_link' => 'https://' . session('shopDomain') . '/admin/products/' . $current['id']
            ];
            Helpers::pushProcessCache(session('shopId'), [$productProcess], 'override_process', 180);
            $variantHasOrder = $productRepo->productHasOrder($current['id']);
            $variantInProduct = $productVariantRepo->getVariantInProduct($current['id']);
        }
        $variantHasOrder = collect($variantHasOrder);
        $variantNotHasOrder = $variantInProduct->diff($variantHasOrder);
        if($variantHasOrder->count() > 0 && empty($variantMerge))
            return response()->json(['status' => true, 'variant_has_order' => $variantHasOrder]);
        OverrideProductSpfJob::withChain([
            new OverrideProductDbJob(
                session('shopId'),
                session('shopDomain'),
                session('accessToken'),
                $override,
                $current,
                $options,
                $variantNotHasOrder,
                $variantMerge
            )
        ])->dispatch(
            session('shopId'),
            session('shopDomain'),
            session('accessToken'),
            $override,
            $current,
            $options)->allOnQueue('override_product');
        return response()->json(['status' => true]);
    }
    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function productStatus()
    {
        $productsNotify=[];
        $shopId = session('shopId');
        return view('products.product-status',compact('productsNotify','shopId'));
    }
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updatePrice(Request $request){
        $request = $request->all();
        $productRepo = new ProductRepository(session('shopId'));
        $update =  $productRepo->update($request['productId'],['auto_update_price'=>$request['checked'] ? 1:2]);
        return response()->json($update);//['status' => true]
    }
    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit($id, $shopDomain = null)
    {
        // Neu khac shop domain
        $shopRepo = new ShopRepository();
        if(!empty($shopDomain)) {
            $shop = $shopRepo->checkShopDomain($shopDomain);
            if(empty($shop) || (!empty($shop) && $shop->myshopify_domain != session('shopDomain'))) {
                return view('errors.store_error', compact('shopDomain'));
            }
        }
        $shopId = session('shopId');
        $repository = new ProductRepository($shopId);
        $currency = $this->getCurrency();
        $currency_rate = app(CurrencyRate::class);
        $exchange = 1;
        if($currency != 'USD') {
            $exchange = $currency_rate->convertFromUsd(1, $currency);
        }
        $product = $repository->detail($id);
        if( ! $product)
            return abort(404);
        return view('products.edit', compact('product', 'id', 'currency', 'exchange'));
    }
    private function getCurrency() {
        $shopId = session('shopId');
        $isConvertCurrency = SettingModel::where('shop_id', $shopId)->where('key', 'is_convert_currency')->first();
        if($isConvertCurrency && $isConvertCurrency->value == "1") {
            $shop = ShopModel::find($shopId);
            $currency = $shop->currency ? $shop->currency : 'USD';
        } else {
            $currency = 'USD';
        }
        return $currency;
    }
    /**
     * Ajax load detail product
     *
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function detail($id)
    {
        $repository = new ProductRepository(session('shopId'));
        $product = $repository->detailEdit($id);
        if( ! $product)
            return response()->json(['status' => false, 'message' => 'Product not found']);
        return response()->json(['status' => true, 'product' => $product]);
    }
    /**
     * Handle edit product
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function editHandle(Request $request)
    {
        $product = $request->input('product');
        $collectApi = new  \App\ShopifyApi\CollectsApi(session('shopDomain'), session('accessToken'));
        $currentCollectSpf = $collectApi->get(['product_id' => $product['id']]);
        $shopId = session('shopId');
        $current = ProductModel::findOrFail($product['id']);
        $product['body_html'] = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $product['body_html']);
        $productDb = $product;
        $productSfp = $product;
        // variant
        $productRepo = new ProductRepository($shopId);
        $productVariantRepo = app(ProductVariantRepository::class);
        $variantHasOrder = [];
        $variantInProduct = [];
        //Get all orders product
        if(isset($product['id']))
        {
            $variantHasOrder = $productRepo->productHasOrder($product['id']);
            $variantInProduct = $productVariantRepo->getVariantInProduct($product['id']);
        }
        $imageHasOrder = [];
        $imageHasVariant = [];
        $imageForceDelete = [];
        $imageSoftDelete = [];
        $variantRemoveSpf = [];
        $variantHasOrder = collect($variantHasOrder);
        $variantHasOrderId = array_map(function ($variant) use ($variantHasOrder) {
            if($variant['product_image']['id']) {
                $imageHasOrder[] = $variant['product_image']['id'];
            }
            return $variant['id'];
        }, $variantHasOrder->toArray());
        // remove variant in db
        foreach ($product['product_variant'] as $key => $variant) {
            if( !$variant['selected'] && !in_array($variant['id'], $variantHasOrderId)) {
                $variantRemoveSpf[] = $variant['id'];
            }
            if( $variant['selected'] && isset($variant['product_image']['id'])) {
                $imageHasVariant[] = $variant['product_image']['id'];
            }
        }

        // Delete and update variants
        ProductVariantModel::where('product_id', $product['id'])
            ->whereIn('id', $variantRemoveSpf)
            ->forceDelete();
        foreach ($product['product_variant'] as $key => &$variant) {
            $variant['image_id'] = isset($variant['product_image']['id']) ? $variant['image_id'] : null;
            $productVariantRepo->update($variant['id'], $variant);
        }

        // remove images in db
        // Get list image's id need remove
        foreach ($product['product_image'] as $key => $image) {
            if( ! $image['selected'] && ! in_array($image['id'], $imageHasOrder)) {
                if( ! in_array($image['id'], $imageHasVariant)) {
                    $imageForceDelete[] = $image['id'];
                } else {
                    $imageSoftDelete[] = $image['id'];
                }
            }
        }
        // Remove image has not variant
        ProductImageModel::where('product_id', $product['id'])
            ->whereIn('id', $imageForceDelete)
            ->forceDelete();
        // Remove image has variant
        ProductImageModel::where('product_id', $product['id'])
            ->whereIn('id', $imageSoftDelete)
            ->delete();
        $productDb['custom_collection'] = json_encode($product['custom_collection']);
        $fillableEdit = [
            'id',
            'title',
            'body_html',
            'custom_collection',
            'image',
            'shop_id',
            'tag',
            'auto_update_price',
            'product_type',
            'product_image'
        ];
        if(!empty($productDb['product_type'])){
            ProductTypeHelper::editProductType($shopId, $productDb['id'], $productDb['product_type']);
        }
        $productRepo->update($productDb['id'], array_only($productDb, $fillableEdit));

        $this->dispatch((new EditProductSpfJob(
            session('shopDomain'),
            session('accessToken'),
            $current,
            array_only($productSfp, $fillableEdit),
            $product['product_variant'],
            $variantRemoveSpf,
            $imageForceDelete
        ))->onQueue('edit_product'));
        return response()->json(['product' => $request->all()]);
    }
    /**
     * Get order in place all
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getProductPlace(Request $request)
    {
        $repo = ['status' => false, 'products' => null, 'mess'=>"Can't get reviews. Please check your product source & try again."];
        $request =$request->all();
        $filters_products =[];
        $currentPage = 1;
        $filters_options = json_decode($request['filters_options'],true);
        if(!empty($request['filters_products'])){
            $filters_products = json_decode($request['filters_products'],true);
            if(!empty($filters_products['page'])) $currentPage = $filters_products['page'];
        }
        $productRepo = new ProductRepository(session('shopId'));
        $products = $productRepo->allProductPlace($filters_products,$filters_options['paged_option'],$currentPage);
        if(empty($products )) return response()->json($repo);
        // Get Products
        $datas=[];
        foreach ($products as $product){
            if(empty($product['source_product_link'])) continue;
            $datas[]=[
                'aliorders_product_id' => $product['id'],
                'source_product_link' => $product['source_product_link'],
                'aliexpress_product_id'=>$product['aliexpress_product_id'],
                'product_title'=>$product['title'],
                'product_image'=>$product['image'],
                'product_handle'=>$product['handle'],
            ];
        }
        if(empty($datas)) return response()->json($repo);
        //get setting
//        $setting = $this->getSettingReview(session('shopId'));
//        if(!$setting ) {
//            $repo['mess'] = 'setting';
//            return response()->json($repo);
//        }
        //reviews_old_options
        $remove_old_reviews = $filters_options['keep_reviews']== 2 ? true : false;
        if($filters_options['keep_reviews']==3){
            $checkReviewProduct = $this->checkReviewProduct($datas);
            $productGetReview = [];
            foreach ($datas as $key=>$data){
                if( array_search($data['aliorders_product_id'],$checkReviewProduct) !== false){
                    $productGetReview[] = $data;
                }
            }
            $datas = $productGetReview ;
        }
        $productGetReview = [
            'settings'=>['remove_old_reviews'=>$remove_old_reviews],
            'products'=>$datas
        ];
        $repo['status'] = true;
        $repo['products'] = $productGetReview;
        $repo['mess'] = 'success';
        return response()->json($repo);
    }
    /**
     * @param $datas product
     *
     * return product not review
     *
     */
    private function checkReviewProduct($datas){
        $product_list_id = [
            'product_list_id'=>array_map(function ($x){ return $x['aliorders_product_id'];},$datas)
        ];
        $url = env('ALIREVIEW_API');
        $request = $url.'/v1/shops/'. explode('.', session('shopDomain'))[0] .'/products/check_review_exist_product';
        $client = new Client();
        $response = $client->post($request,['form_params' => $product_list_id]);
        $response = json_decode( $response->getBody()->getContents(),true);
        return $response['result']['data'];
    }
    /**
     * @param $shopId
     *
     * @return settings
     */
//    public function getSettingReview($shopId){
//        return false;
//        $url = env('SETTING_ALIREVIEW_DOMAIN');
//        //$request = $url.'/v1/shops/me/'.$shopId;
//        $request = $url.'/v1/shops/'. explode('.', session('shopDomain'))[0] .'/view/popup_setting_get_review';
//
//        $client = new Client();
//        $response = $client->get($request);
//        $response = json_decode( $response->getBody()->getContents(),true);
//        if(empty($response['result']['sections'])) return false;
//        $settings = $response['result']['sections'];
//
//        //get only star
//        $get_only_star = [];
//        $fivestar = $settings['get_only_star']['options'][0]['value'];
//        $fourstar = $settings['get_only_star']['options'][1]['value'];
//
//        if($fivestar) array_push($get_only_star,5);
//        if($fourstar) array_push($get_only_star,4);
//        if(!$fivestar && !$fourstar) $get_only_star = [1,2,3,4,5];
//
//        //get only picture
//        $get_only_picture = [true,false];
//        $with_picture = $settings['get_only_picture']['options'][0]['value'];
//        $without_picture = $settings['get_only_picture']['options'][1]['value'];
//
//        if($with_picture && !$without_picture ) $get_only_picture = [true];
//        if(!$with_picture && $without_picture ) $get_only_picture = [false];
//
//        //get only content
//        $get_only_content = [true,false];
//        $with_content = $settings['get_only_content']['options'][0]['value'];
//        $without_content = $settings['get_only_content']['options'][1]['value'];
//
//        //country_get_review
//        $selected_country_get_review = $settings['country_get_review']['options'][0]['selected'];
//        $options_country_get_review  = $settings['country_get_review']['options'][0]['options'];
//
//        if($with_content && !$without_content ) $get_only_content = [true];
//        if(!$with_content && $without_content ) $get_only_content = [false];
//        $data = [
//            'shop_id' => $shopId,
//            'shop_domain'=>session('shopDomain'),
//            'stype' => 3,
//            'setting'=>[
//                'get_only_star' => $get_only_star,
//                'get_only_picture' => $get_only_picture,
//                'get_only_content' => $get_only_content,
//                'translate_reviews' => $settings['translate_reviews']['options'][0]['value'] ? 1 : 0,
//                'get_max_number_review' => $settings['get_max_number_review']['options'][0]['value'],
//                'except_keyword' => $settings['except_keyword']['options'][0]['value'],
//                'country_get_review' => count($selected_country_get_review) == count($options_country_get_review) ? [] : $selected_country_get_review
//
//            ]
//        ];
//        return ['data'=>$data, 200];
//    }
    /**
     * Handle multi import reviews
     * @param Request $request
     */
    public function handleMultiImportReviews(Request $request)
    {
    }
    public function updateOptions(Request $request) {
        UpdateProductOptionsJob::dispatch()->onQueue('update_options_all_product');
        return response()->json(['status' => true, 'message' => 'Updating...']);
    }
    public function updateTotalQuantity($shopDomain) {
        $domain = $shopDomain.'.myshopify.com';
        $shop_repository = app(ShopRepository::class);
        $shop = $shop_repository->getAttributes(['myshopify_domain' => $domain]);
        if($shop) {
            UpdateTotalQuantityJob::dispatch($shop->id)->onQueue('update_total_quantity');
            return response()->json(['status' => true, 'message' => 'Updating...']);
        }
        return response()->json(['status' => false, 'message' => 'Error']);
    }
    public function updateCodeEditProductShopify()
    {
        return view('products.update-theme-edit-product');
    }
    public function updateCodeEditProductShopifyHandle()
    {
        $shopDomain = session('shopDomain');
        $shop_repository = app(ShopRepository::class);
        $shop = $shop_repository->getAttributes(['myshopify_domain' => $shopDomain]);
        if(!$shop) {
            return response()->json(['status' => false, 'message' => 'Shop not found!']);
        }
        AddAliOrderCodeToThemesJob::dispatch($shop->myshopify_domain, $shop->access_token, $shop->id)->onQueue('init_app_before');
        return response()->json(['status' => true, 'message' => 'Update theme success!']);
    }
    public function getProductNoSource(Request $request) {
        $shopRepo = app(ShopRepository::class);
        $shopDomain = $request->get('shop_domain');
        $shop = $shopRepo->getAttributes(['myshopify_domain' => $shopDomain]);
        if( ! $shop || ! $shop->status)
            return response()->json(['status' => false]);

        $productRepo = new ProductRepository($shop->id);
        $productNoLink = $productRepo->getProductNoLink();
        if($productNoLink) {
            $productNoLink = collect($productNoLink)->map(function ($product) {
                return [
                    'id_aliexpress' => $product->aliexpress_product_id,
                    'id_shopify' => $product->id
                ];
            });
        } else {
            $productNoLink = [];
        }

        return response()->json(['status' => true, 'shop_id' => $shop->id, 'products' => $productNoLink]);
    }
    public function getOrderNoSource(Request $request) {
        $shopRepo = app(ShopRepository::class);
        $shopDomain = $request->get('shop_domain');
        $shop = $shopRepo->getAttributes(['myshopify_domain' => $shopDomain]);
        if( ! $shop || ! $shop->status)
            return response()->json(['status' => false]);

        $orderRepo = app(OrderRepository::class);
        $orderNoAliOrderNumber = $orderRepo->getOrderHasNotAliOrderNo($shop->id);
        if($orderNoAliOrderNumber) {
            $orderNoAliOrderNumber->toArray();
            $orderNoAliOrderNumber = [
                'shopify_order_name_minimum' => $orderNoAliOrderNumber->order_name,
                'shopify_order_id' => $orderNoAliOrderNumber->id,
            ];
        } else {
            $orderNoAliOrderNumber = [];
        }

        // $orderNoAliOrderNumber = collect($orderNoAliOrderNumber)->map(function ($order) {
        //     $lineItems = collect($order->lineItem)->filter(function ($lineItem) {
        //                     return isset($lineItem->productVariant);
        //                 })->map(function ($lineItem) {
        //                     return [
        //                         'sku' => isset($lineItem->productVariant->sku) ? $lineItem->productVariant->sku : null,
        //                         'product_ext_id' => $lineItem->productVariant->aliexpress_product_id
        //                     ];
        //                 });
        //     return [
        //         'id' => $order->id,
        //         'shopify_order_name' => $order->order_name,
        //         'orderItems' => $lineItems
        //     ];
        // });
        return response()->json(['status' => true, 'shop_id' => $shop->id, 'orders' => $orderNoAliOrderNumber]);
    }
    public function addVariant(Request $request)
    {
        $req = $request->all();
        $new_product = $req['add_variant_product'];
        $current_product_id = $req['current_product']['id'];
        if($current_product_id)
        {
            $productProcess = [
                'id' => $current_product_id,
                'title'=> $req['current_product']['title'],
                'status' => 'pending',
                'product_link' => 'https://' . session('shopDomain') . '/admin/products/' . $current_product_id
            ];
            Helpers::pushProcessCache(session('shopId'), [$productProcess], 'add_variant_product', 180);
        }
        AddVariantProductJob::dispatch(
            session('shopId'),
            session('shopDomain'),
            session('accessToken'),
            $new_product,
            $current_product_id)->allOnQueue('add_variant');
        return response()->json(['status' => true]);
    }
}