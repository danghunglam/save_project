<?php

namespace App\Http\Controllers;

use App\Jobs\SyncOrderFromShopifyJob;
use App\Jobs\SyncProductFromShopifyJob;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendCustomer;
use App\ShopifyApi\FulfillmentApi;
use App\ShopifyApi\OrdersApi;
use App\ShopifyApi\ProductsApi;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use App\ShopifyApi\ShopsApi;
use App\ShopifyApi\ChargedApi;
use App\Repository\ShopRepository;
use App\Repository\ProductVariantRepository;
use App\Helpers\LineItemHelper;

class TestController extends Controller
{
    public function getShop()
    {
        $shopApi = new ShopsApi();
	    $shopApi->setParameter(session('accessToken'), session('shopDomain'));
        $shop = $shopApi->get();
        dd( $shop );
    }
    
    public function getAllCharge()
    {
	    $chargeApi = new ChargedApi();
	    $chargeApi->setParameter(session('accessToken'), session('shopDomain'));
	    $charge = $chargeApi->allCharge();
	    dd($charge);
    }
    
    public function activeCharge(Request $request)
    {
    	$id = '6754641';
	    $chargeApi = new ChargedApi();
	    $chargeApi->setParameter(session('accessToken'), session( 'shopDomain'));
	    $charge = $chargeApi->activeCharge($id);
	    dd($charge);
    }

    public function productApi()
    {
        $productApi = new ProductsApi();
        $productApi->getAccessToken();

        dd($productApi->all());

        $productApi->create([]);

        $productApi->delete('');

        $productApi->count([]);

        $productApi->detail([], '');

    }

    public function test()
    {
        $shopId = '24060221';
        $shopDomain = 'bcd2.myshopify.com';
        $accessToken = 'fb57d7c34d4d598a815fd42330039749';
        $_limit = 250;

        $_fields = [
            'id',
            'name',
            'email',
            'created_at',
            'updated_at',
            'total_price',
            'order_number',
//            'line_items',
//            'shipping_address',
            'contact_email',
            'fulfillment_status',
            'financial_status'
        ];

        $_filters = [];

        $_financial_status = 'any';


        $orderApi = new OrdersApi($shopDomain, $accessToken);
        $orders = $orderApi->all($_fields, $_filters, $_limit, 1, $_financial_status);
        echo '<pre>';
        var_dump($orders);
        echo '</pre>';
        die;



        $productApi = new ProductsApi('bcd2.myshopify.com', 'fb57d7c34d4d598a815fd42330039749');
        $field = [
            'id',
            'title',
            'handle',
            'image',
            'images',
            'variants'
        ];
        $productsInfo = $productApi->all($field, [], 1, 250);

        dd($productsInfo);

        $fulfillment =  [
                'tracking_number' => '123456789',
                'line_items' => [
                    [
                        'id' => 307504054302
                    ],
                    [
                        'id' => 307504087070
                    ],
//                    [
//                        'id' => 307504021534
//                    ]

                ],
                'notify_customer' => true
            ];
        $fulfillmentApi = new FulfillmentApi('bcd2.myshopify.com', 'fb57d7c34d4d598a815fd42330039749');


        $addFulfillment = $fulfillmentApi->create('164700389406', $fulfillment);

        var_dump($addFulfillment);

        return response()->json(['status' => true]);

        //Test get request
//        $products = $spfService->getRequest('products.json', $param);
//        dd($products);

        //Test post request
//        $dataPost = [
//            'product' => [
//                'title' => 'Burton Custom Freestyle 151'
//            ]
//        ];
//        $addProduct = $spfService->postRequest('products.json', $dataPost);
//        dd($addProduct);

        //Test put product

//        $dataPut = [
//            'product' => [
//                'title' => 'qxacscdas1234 Edit Burtom customer freestyle'
//            ]
//        ];
//        $putProduct = $spfService->putRequest('products/9184756933.json', $dataPut);
//        dd($putProduct);

        //Test Delete product

//        $deleteProduct = $spfService->deleteRequest('products/9184756933.json');
//
//        dd($deleteProduct);
    }



    public function runJob()
    {
        $shopId = '24060221';
        $shopDomain = 'bcd2.myshopify.com';
        $accessToken = 'fb57d7c34d4d598a815fd42330039749';


//        $this->dispatch(new SyncProductFromShopifyJob($shopId, $shopDomain, $accessToken));
//        $productApi = new ProductsApi($shopDomain, $accessToken);
//        $productRepo = new ProductRepository($shopId);
//        $products = $productApi->all(['id', 'title', 'handle', 'variants', 'image', 'images'],[], 1, 10);
//
//        if($productRepo->saveMany($products))
//            return response()->json(['status' => true]);
//
//        return response()->json(['status' => false]);
//        $this->dispatch(new SyncProductFromShopifyJob($shopId, $shopDomain, $accessToken));

        return response()->json(['status' => true]);
    }
    
    public function runWebhook(){
	   
    }

    public function sendMailCustomer(Request $request)
    {
        $res = $request->all();
        Mail::to($res['email'])->send(new SendCustomer( $res ));
    }
}
