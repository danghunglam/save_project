<?php

namespace App\Http\Controllers\Extension;


use App\Contracts\Repository\Extension\OrderRepositoryInterface;
use App\Http\Controllers\Controller;
use App\Repository\Extension\OrderRepository;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function syncOrderNumberFromOberlo(Request $request)
    {
        $data = $request->all();
        /**
         * @var OrderRepository
         */
        $repo = app(OrderRepositoryInterface::class);
        if($repo->syncOrderNumberFromOberlo($data))
            return response()->json(['status' => true]);

        return response()->json(['status' => false]);
    }
}