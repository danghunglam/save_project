<?php

namespace App\Http\Controllers\Extension;


use App\Helpers\SettingHelper;
use App\Http\Controllers\Controller;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;

class SettingController extends Controller
{
    /**
     * @param $publicToken
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getSettings($publicToken)
    {
        $shopRepo = new ShopRepository();
        $shopInfo = $shopRepo->getAttributes(['public_token' => $publicToken]);


        if ($shopInfo) {
            $settingRepo = new SettingRepository($shopInfo->id);
            $settings = $settingRepo->getObjAll();

            if($settings)
                return response()->json(['status' => true, 'settings' => $settings]);
        }
        return response()->json(['status' => false]);
    }
}