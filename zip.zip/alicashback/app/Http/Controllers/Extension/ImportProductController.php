<?php

namespace App\Http\Controllers\Extension;


use App\Contracts\Repository\Extension\ExtensionImportProductRepositoryInterface;
use App\Http\Controllers\Controller;
use App\Jobs\ImportProductAliexpressJob;
use App\Models\ShopModel;
use App\Repository\ShopRepository;
use App\Repository\ShopMetaRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class ImportProductController extends Controller
{
    private $_repository;

    public function __construct(ExtensionImportProductRepositoryInterface $repository)
    {
        $this->_repository = $repository;
    }


    /**
     * Xử lý việc import 1 sản phẩm
     *
     * @param Request $request
     * @return mixed
     */
    public function importProductAliexpress(Request $request)
    {
        $shopMetaRepo = new ShopMetaRepository();
        $shopRepo = new ShopRepository();
        $public_token = $request->input('public_token', '');
        $product = $request->input('product', []);
        $variants = $request->input('variants', []);
        $images = $request->input('images', []);
        $supplier = $request->input('supplier', []);
        $shopDetail = $shopRepo->getShopId($public_token);
        if($shopDetail) {
            $shopId = $shopDetail->id;
            $importedProduct = 0;
            $key = 'imported_product';
            $shopMetaDetail = $shopMetaRepo->findWithKey($shopId, $key);
            $shopMetaData = [];
            if($shopMetaDetail) {
                $importedProduct = $shopMetaDetail->value;
                $shopMetaData['id'] = $shopMetaDetail->id;
            }
            $importedProduct++;
            $shopMetaData['key'] = $key;
            $shopMetaData['value'] = $importedProduct;
            $shopMetaData['shop_id'] = $shopId;
            $shopMetaRepo->createOrUpdate($shopMetaData);
        }

        return $this->_repository->importProduct($public_token, $product, $variants, $images, $supplier);
    }

    /**
     * Xử lý việc import nhiều product
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */

    public function multiImportProduct(Request $request)
    {
        $products = $request->all();
        ImportProductAliexpressJob::dispatch($products)->onQueue('import_product_aliexpress');

        return response()->json(['status' => true, 'message' => 'Multi import product add job', 'count' => count($products)]);
    }

    /**
     * Xử lý việc xóa sản phẩm ở extension khi import product
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteProductImport(Request $request)
    {
        $product_id = $request->input('product');
        $public_token = $request->input('public_token');

        return response()->json($this->_repository->deleteProduct($product_id, $public_token));
    }
    /**
     * Kiểm tra số lượng sản phẩm đã import
     *
     * @return
     * */
    public function checkProductImport(Request $request)
    {
        $public_token = $request->input('public_token', '');
        $shopRepo = app(ShopRepository::class);

        $shop = $shopRepo->getAttributes(['public_token' => $public_token]);
        if( ! $shop)
            return response()->json(['status' => false, 'message' => 'Shop not found']);

        $shopId = intval($shop->id);

        $shopModel = ShopModel::find($shopId);

        $countmportProduct = $shopModel->importProduct()->whereNull('is_import')->count();
        $import_product_maximum = config('import_product.import_product_maximum');
        return response()->json(['status' => true, 'total_product_import' => $countmportProduct, 'import_product_maximum' => $import_product_maximum]);
    }
}