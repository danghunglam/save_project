<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Helpers\ProductHelper;
use App\Helpers\SettingHelper;
use App\Http\Requests\InstallAppsRequest;
use App\Jobs\AddAliOrderCodeToThemesJob;
use App\Jobs\InitAppJob;
use App\Jobs\InitSettingDefaultJob;
use App\Jobs\SyncOrderJob;
use App\Jobs\SyncProductJob;
use App\Mail\InstallApps;
use App\Models\ShopModel;
use App\Services\SpfService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\ShopifyApi\ShopsApi;
use App\Repository\ShopRepository;
use App\Jobs\WebHookAppsJob;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Cache;
use App\Models\UserShopModel;
use App\Models\ShopifyUserModel;
use App\Jobs\AffiliateJob;

class AppsController extends Controller
{
	/**
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 */
	public function installApp()
    {
        session(['shopDomain' => null]);
		return view( 'apps.install_app');
	}

	/**
	 * @param InstallAppsRequest $request
	 *
	 * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
	 */
	public function installAppHandle(InstallAppsRequest $request)
    {
        $spfService = new SpfService();
		$urlStore   = $request->input('shop', null);

		return redirect($spfService->installURL($urlStore));
    }

    public function switchAppHandle(InstallAppsRequest $request)
    {
        $spfService = new SpfService();
		$urlStore   = $request->input('shop', null);
		return redirect($spfService->installSwitchURL($urlStore));
    }
    public function addAppHandle(InstallAppsRequest $request)
    {
        $spfService = new SpfService();
		$urlStore   = $request->input('shop', null);

		return redirect($spfService->installAddURL($urlStore));
    }



	public function storeError($shopDomain)
    {
        return view('errors.store_error', compact('shopDomain'));
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Exception
     */
	public function auth(Request $request)
	{
		$request = $request->all();
		return $this->authWithRequest($request, 'auth');
    }

    public function switch(Request $request)
	{
		$request = $request->all();
		return $this->authWithRequest($request, 'switch');
    }

    public function add(Request $request)
	{
		$request = $request->all();
		return $this->authWithRequest($request, 'add');
    }

    public function getToken(Request $request)
	{
		$request = $request->all();
		return $this->authWithRequest($request, 'get_token');
    }

    public function removeOwnStore(Request $request) {
        $shopId = $request->input('shop_id', null);
        if($shopId) {
            $shopUser = UserShopModel::where(['user_id' => session('user_id'), 'shop_id' => $shopId])->first();
            if($shopUser) {
                $shopUser->forceDelete();
                $userShop = session('user_shop', []);
                $userShop = array_filter($userShop, function ($shop) use ($shopId) {
                    return $shop['shop']['id'] != $shopId;
                });
                session(['user_shop' => $userShop]);
                return response()->json(['status'=> true]);
            }
        }
        return response()->json(['status'=> false]);
    }

    public function saveAffiliate()
    {

        $data = [
            'partner_id' => empty($_COOKIE['partner_id']) ? '' : $_COOKIE['partner_id'],
            'campaign'   => empty($_COOKIE['utm_campaign']) ? '' : $_COOKIE['utm_campaign'],
            'source'     => empty($_COOKIE['utm_source']) ? '' : $_COOKIE['utm_source'],
            'medium'     => empty($_COOKIE['utm_medium']) ? '' : $_COOKIE['utm_medium'],
            'store_name' => session('shopDomain'),
            'accessToken'=> session('accessToken'),
            'app'        => 'aliorders',
            'status'     => 'free',
            'price'      => 0
        ];

        AffiliateJob::dispatch($data)->allOnQueue('affiliate');
    }

    public function checkShop($shopDomain)
    {
        $shopRepo = new ShopRepository();
        $shopStatus = $shopRepo->checkShopStatus($shopDomain);
        return response()->json(['data' => $shopStatus]);
    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function errors()
    {
        $shopId = session('shopId');
        return view('errors.404', compact('shopId'));
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function logout(Request $request)
    {
        $request->session()->flush();
        return redirect(route('dashboard.index'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function installData()
    {
        $shopId = session('shopId');
        return view('apps.install_data', compact('shopId'));
    }

    /**
     * @param $type
     * @return \Illuminate\Http\JsonResponse
     */
    public function getToastProcess(Request $request)
    {
        $types = $request->get('type');
        $process = [];
        foreach ($types as $key => $type) {
            $process[] = [
                'type' => $type,
                'data' => Helpers::getOverrideProcessCache(session('shopId'), $type)
            ];
        }
        return response()->json($process);
    }

    /**
     * @param Request $request
     */
    public function pushToastProcess(Request $request)
    {
        $product = $request->input('product', []);
        $type = $request->input('type');
        if(!empty($product) && !empty($type)) {
            Helpers::pushProcessCache(session('shopId'), $product, $type);
        }
    }

    /**
     * @param Request $request
     */
    public function setToastProcess(Request $request)
    {
        $products = $request->input('products', []);
        $type = $request->input('type', []);
        foreach ($products as $key => $product) {
            if(in_array($product['type'], $type)) {
                Helpers::setOverrideProcessCache(session('shopId'), $product['data'], $product['type']);
            }
        }
    }

    /**
     * @return object countries
     */
    public function getCountriesReview()
    {
        $countries = SettingHelper::getCountryCode();
        return response()->json(['status'=>true, 'countries'=>$countries]);
    }


    public function healthCheck()
    {
        $response = [];
        $status = false;
        $db_status = false;
        $status_code = 200;
        try{
            DB::connection()->getPdo();
            $db_status = true;
            $status_code = 200;
        } catch(\Exception $e)
        {
            $db_status = false;
            $status_code = 500;
        }


        if($db_status)
            $status = true;

        return response()->json([
            'status' => $status,
            'mysql_status' => $db_status
        ], $status_code);
    }

    public function authWithRequest($request, $type = 'auth') {
        $spfService = new SpfService($request['shop']);
        $accessData = $spfService->authApp($request);
        if (!isset($accessData->access_token))
        {
            if ($type == 'auth') {
                return redirect(route( 'apps.installApp'))->with('error', 'Not verify request, contact Support FireApps- support@fireapps.io');
            } else {
                return redirect(route('dashboard.index'))->with('error', 'Not verify request, contact Support FireApps- support@fireapps.io');
            }
        }

        if(isset($accessData->associated_user)) {
            session(['user_auth' => $accessData->associated_user]);
        }
        $accessToken = $accessData->access_token;
        if($type == 'auth') {
            return redirect($spfService->installGetTokenURL($request['shop']));
        }

        if($type == 'get_token') {
            $type = 'auth';
        }

        if(session('user_auth')) {
            $associatedUser = session('user_auth');
        }

        // $accessToken = $accessData->access_token;
        // $associatedUser = $accessData->associated_user;
        $shopDomain  = $request['shop'];
        $shopApi = new ShopsApi($shopDomain, $accessToken);
        $shopRepo = new ShopRepository();
        $shopInfoApi = $shopApi->get();
        if( ! $shopInfoApi['status']) {
            if($type == 'auth') {
                return redirect(route('apps.installApp'))->with('error', 'Error request');
            } else {
                return redirect(route('dashboard.index'))->with('error', 'Error request');
            }
        }
        $shopInfoApi = (array) $shopInfoApi['data']->shop;
        $shopInfoApi['access_token'] = $accessToken;
        $shopInfoApi['status'] = config('common.status.publish');
        // $shopInfoApi['token_status'] = 1;
        //Check shop database
        $shopInfo = $shopRepo->detail($shopInfoApi['id']);
        //Update access token
        if(in_array($type, ['auth', 'add']) || empty($shopInfo->access_token)) {
            $shopRepo->createOrUpdate($shopInfoApi['id'], ['access_token' => $accessToken]);
        } else {
            
        }
        // need optimize
        $user = ShopifyUserModel::find($associatedUser->id);
        if(!$user) {
            $userModel = new ShopifyUserModel();
            $userData = json_decode(json_encode($associatedUser), true);
            $userData = array_only($userData, $userModel->getFillable());
            $userModel->firstOrCreate($userData);
        }
        $userShop = UserShopModel::where(['user_id' => $associatedUser->id, 'shop_id' => $shopInfoApi['id']])->first();
        if(!$userShop) {
            $userShopModel = new UserShopModel();
            $userShopModel->firstOrCreate(['user_id' => $associatedUser->id, 'shop_id' => $shopInfoApi['id']]);
        }
        if(session('user_id') && in_array($type, ['add', 'switch'])) {
            if(session('user_id') != $associatedUser->id) {
                $oldUserShop = UserShopModel::where(['user_id' => session('user_id')])->get()->map(function ($shop) {
                    return $shop->shop_id;
                });;
                $currentUserShop = UserShopModel::where(['user_id' => $associatedUser->id])->get()->map(function ($shop) {
                    return $shop->shop_id;
                });
                foreach ($oldUserShop as $key => $shop) {
                    if(!in_array($shop, $currentUserShop->toArray())) {
                        UserShopModel::create(['user_id' => $associatedUser->id, 'shop_id' => $shop]);
                    }
                }
                foreach ($currentUserShop as $key => $shop) {
                    if(!in_array($shop, $oldUserShop->toArray())) {
                        UserShopModel::create(['user_id' => session('user_id'), 'shop_id' => $shop]);
                    }
                }
            }
        }
        if(in_array($type, ['auth', 'switch'])) {
            //Save session accessToken and shopDomain
            session(['accessToken' => $accessToken, 'shopDomain'  => $shopDomain, 'shopId' => $shopInfoApi['id'],
            'shopOwner' => $shopInfoApi['shop_owner'], 'shopEmail' => $shopInfoApi['email'],
            'created_at' => strtotime($shopInfoApi['created_at']), 'goodToken' => 1]);
        }
        $shops = UserShopModel::where(['user_id' => $associatedUser->id])
                            ->with(['shop' => function($query) {
                                $query->select(['id', 'myshopify_domain', 'name','shop_owner']);
                            }])->get()->toArray();
                            $spfServicez = new SpfService();
        $shops = array_map(function ($shop) use ($spfServicez) {
            $shop['auth'] = $spfServicez->installSwitchURL($shop['shop']['myshopify_domain']);
            return $shop;
        }, $shops);
        // end need optimize
        session(['user_id' => $associatedUser->id, 'user_shop' => $shops]);
        if( !$shopInfo || empty($shopInfo->status))
        {
            if($shopRepo->createOrUpdate($shopInfoApi['id'], $shopInfoApi))
            {
                SyncProductJob::withChain([
                    (new SyncOrderJob($shopInfoApi['id'], $shopDomain, $accessToken, 'unfulfilled', 1))->onQueue('sync_order'),
                    (new SyncOrderJob($shopInfoApi['id'], $shopDomain, $accessToken, 'partial', 1))->onQueue('sync_order'),
                    (new SyncOrderJob($shopInfoApi['id'], $shopDomain, $accessToken, 'shipped', 1))->onQueue('init_app_before')
                ])->dispatch($shopInfoApi['id'], $shopDomain, $accessToken)->onQueue('init_app');
                //Add webhook
                WebHookAppsJob::dispatch($accessToken, $shopDomain, $shopInfoApi['id'])->onQueue('init_app');
    //
                //add setting default
                InitSettingDefaultJob::dispatch($shopInfoApi['id'])->onQueue('init_app');
                //Add AliOrder Code To Theme
                dispatch(new AddAliOrderCodeToThemesJob($shopDomain, $accessToken, $shopInfoApi['id']))->onQueue('init_app_before');
                //get data save Affiliate
                $this->saveAffiliate();
                return redirect(route('apps.installData'));
            }
        }
        if($type == 'add') {
            return redirect(route('dashboard.index'))->with('success', 'Add new store successfully');
        }
        return redirect(route('dashboard.index'));
    }
}
