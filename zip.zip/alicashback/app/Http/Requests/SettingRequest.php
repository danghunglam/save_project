<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SettingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [];
        if ( ! is_null( $this->request->get('default_fulfillment_tracking_url') ) ) {
        	$rules['default_fulfillment_tracking_url'] = 'url';
        }
        if ( ! is_null( $this->request->get( 'primary_email_address' ) ) ) {
	        $rules['primary_email_address'] = 'email';
        }
	    foreach($this->request->get('cost_range' ) as $key => $val)
	    {
		    if ( $key != 'rest_of_the_price_ranges' ) {
			    $size = '';
			    $maxSize = '';
			    $prevKey = $this->getPrevKey( $key, $this->request->get('cost_range' ) );
			    if ( $prevKey ) {
				    $min = $this->request->get('cost_range' )[$prevKey]['max'];
				    if ( isset( $val['min'] ) && $val['min'] <= $min ) {
					    $size = '|size:>'.$min;
				    }
			    }
			    if( isset($val['max']) && isset($val['min']) && $val['max'] <= $val['min'] ) {
				    $maxSize = '|size:>'.$val['min'];
			    }
			    $rules['cost_range.'.$key.'.min'] = 'required|numeric|min:0'.$size;
		        $rules['cost_range.'.$key.'.max'] = 'required|numeric|min:0'.$maxSize;
			    $rules['cost_range.'.$key.'.item_price'] = 'required|numeric|min:0';
		        if ( $this->request->get('pricing_compared_price' ) ) {
			        $rules[ 'cost_range.' . $key . '.compared_price' ] = 'required|numeric|min:0';
		        }
		    } else {
			    $rules['cost_range.rest_of_the_price_ranges.item_price'] = 'required|numeric|min:0';
			    if ( $this->request->get('pricing_compared_price' ) ) {
				    $rules['cost_range.rest_of_the_price_ranges.compared_price'] = 'required|numeric|min:0';
			    }
		    }
	    }
	    return $rules;
    }
	
	public function messages()
	{
		$messages = [];
		foreach($this->request->get('cost_range') as $key => $val)
		{
			if ( $key != 'rest_of_the_price_ranges' ) {
				$prevKey = $this->getPrevKey( $key, $this->request->get('cost_range' ) );
				$min = 0;
				if ( $prevKey ) {
					$min = $this->request->get('cost_range' )[$prevKey]['max'];
				}
				$messages[ 'cost_range.' . $key . '.min.required' ] = 'Please enter a value min cost';
				$messages[ 'cost_range.' . $key . '.min.numeric' ] = 'The cost min must be a number';
				$messages[ 'cost_range.' . $key . '.min.min' ] = 'Please enter a value greater than 0';
				$messages[ 'cost_range.' . $key . '.min.size' ] = 'Please enter a value greater than ' . $min;
				$messages[ 'cost_range.' . $key . '.max.required' ] = 'Please enter a value max cost';
				$messages[ 'cost_range.' . $key . '.max.numeric' ] = 'The cost max must be a number';
				$messages[ 'cost_range.' . $key . '.max.min' ] = 'Please enter a value greater than 0';
				$messages[ 'cost_range.' . $key . '.max.size' ] = 'Please enter a value greater than '. $val['min'];
				$messages[ 'cost_range.' . $key . '.item_price.required' ]  = 'Please enter a value item price';
				$messages[ 'cost_range.' . $key . '.item_price.numeric' ]  = 'The cost item price must be a number';
				$messages[ 'cost_range.' . $key . '.item_price.min' ]  = 'Please enter a value greater than 0';
				$messages[ 'cost_range.' . $key . '.compared_price.required' ] = 'Please enter a value compared price';
				$messages[ 'cost_range.' . $key . '.compared_price.numeric' ] = 'The cost compared price must be a number';
				$messages[ 'cost_range.' . $key . '.compared_price.min' ] = 'Please enter a value greater than 0';
			} else {
				$messages['cost_range.rest_of_the_price_ranges.item_price.required' ]  = 'Please enter a value rest item price';
				$messages['cost_range.rest_of_the_price_ranges.item_price.numeric' ]  = 'The cost rest of item price must be a number';
				$messages['cost_range.rest_of_the_price_ranges.item_price.min' ]  = 'Please enter a value greater than 0';
				$messages['cost_range.rest_of_the_price_ranges.compared_price.required' ]  = 'Please enter a value rest compared price';
				$messages['cost_range.rest_of_the_price_ranges.compared_price.numeric' ]  = 'The cost rest of compared price must be a number';
				$messages['cost_range.rest_of_the_price_ranges.compared_price.min' ]  = 'Please enter a value greater than 0';
			}
		}
		return $messages;
	}
	
	function getPrevKey($key, $hash = array())
	{
		$keys = array_keys($hash);
		$foundIndex = array_search($key, $keys);
		if ($foundIndex === false || $foundIndex === 0)
			return false;
		return $keys[$foundIndex-1];
	}
}
