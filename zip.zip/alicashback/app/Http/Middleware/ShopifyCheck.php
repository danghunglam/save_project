<?php

namespace App\Http\Middleware;

use App\Models\ShopModel;
use App\Repository\ShopRepository;
use App\Services\SpfService;
use App\ShopifyApi\ShopsApi;
use Closure;
use Illuminate\Support\Facades\Lang;

class ShopifyCheck {
	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request $request
	 * @param  \Closure                 $next
	 *
	 * @return mixed
	 */
	public function handle( $request, Closure $next )
	{
		if(env('TEST_APP'))
		{
			session(['shopDomain' => env('SHOPIFY_TEST_SHOP_DOMAIN'), 'shopId' => env('SHOPIFY_TEST_SHOP_ID'), 'accessToken' => env('SHOPIFY_TEST_ACCESS_TOKEN')]);
			return $next($request);
		}
		$req = $request->all();
        /**
         * @var SpfService
         */
        $spfService = app(SpfService::class);
        $shopRepo = app(ShopRepository::class);
        //if request from list shopify apps
		if(isset($req['shop']))
		{
			//Re auth
			$installUrl = $spfService->installURL($req['shop']);
			return redirect($installUrl);
		}
		try {
		    if(session('shopId') && session('shopDomain'))
        	{
            	$shop = $shopRepo->detail(session('shopId'));
            	// if ($shop->token_status == 0) {
				// 	      return redirect(route('apps.installApp'))->with('error', @trans('shopify.check.token'));
				//       }
				
				if(isset($shop->order_type_sync)) {
					session(['order_type_sync' => $shop->order_type_sync]);
				}
                if( ! empty($shop->status) && ! empty($shop->access_token)) {
					if(!session('user_id')) {
						$spfService = new SpfService();
						return redirect($spfService->installURL(session('shopDomain')));
					}
                    return $next($request);
				}
                //nếu không thì sẽ chuyển đến màn install
                $installUrl = $spfService->installURL(session('shopDomain'));
                return redirect($installUrl);
            } else
                return redirect(route('apps.installApp'))->with('error', @trans('auth.shopify.check.fail'));

		    
		} catch (\Exception $exception) {
			return redirect(route('apps.installApp'))->with('error', $exception->getMessage());
		}
	}
}
