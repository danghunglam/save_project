<?php

namespace App\Http\Middleware;

use App\Services\SpfService;
use App\ShopifyApi\ShopsApi;
use Closure;

class AccessTokenCheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(env('TEST_APP'))
            return $next($request);

        $shopApi = new ShopsApi(session('shopDomain'), session('accessToken'));
        $shop = $shopApi->get();
        if(isset($shop['status']) && ! $shop['status'])
        {
            $installUrl = $shopApi->installURL(session('shopDomain'));
            return redirect($installUrl);
        }

        return $next($request);
    }
}
