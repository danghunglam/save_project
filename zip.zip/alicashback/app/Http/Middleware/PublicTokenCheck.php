<?php

namespace App\Http\Middleware;

use App\Helpers\Helpers;
use App\Repository\ShopRepository;
use Closure;

class PublicTokenCheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $shopRepo = app(ShopRepository::class);

        if($shop = $shopRepo->detail(session('shopId')))
        {
            //Public token
            $publicToken = Helpers::generalPublicToken(session('shopDomain'));
            session(['publicToken' => $publicToken]);
            if( ! $shop->public_token || $shop->public_token !== $publicToken)
            {
                //Update public_token
                $shopRepo->createOrUpdate(session('shopId'), ['public_token' => $publicToken]);
            }
        }

        return $next($request);
    }
}
