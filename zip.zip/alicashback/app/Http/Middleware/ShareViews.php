<?php

namespace App\Http\Middleware;

use App\Repository\ImportProductRepository;
use App\Repository\ShopRepository;
use App\Repository\ShopMetaRepository;
use Illuminate\Support\Facades\View;

use Closure;

class ShareViews
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $route = str_replace('.', '_', request()->route()->getName());
        
        $shopId = session('shopId') ? session('shopId') : '';
    
        $shopRepo = app(ShopRepository::class);
        $shop = $shopRepo->detail($shopId);
        $importProductRepo = app(ImportProductRepository::class);
        $totalImportProduct = $importProductRepo->count($shopId);
        $shopMetaRepo = app(ShopMetaRepository::class);
        $shopMetaDetail = $shopMetaRepo->findWithKey($shopId, 'imported_product');
        if($shopMetaDetail) {
            $importedProductIntercom = $shopMetaDetail->value;
            View::share('imported_product', $importedProductIntercom);
        }

        View::share('total_import_product', $totalImportProduct);
        
        session(['current_route_name' => $route,'shop' => $shop]);


        return $next($request);
    }
}
