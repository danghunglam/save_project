<?php

namespace App\Contracts\Services;


interface CurrencyRate
{
    /**
     * @return mixed
     */
    public function save() ;

    /**
     * @param $amount
     * @param $currency
     * @return mixed
     */
    public function convertToUsd($amount, $currency);

    /**
     * @param $amount
     * @param $currency
     * @return mixed
     */
    public function convertFromUsd($amount, $currency);

    /**
     * @param $from
     * @param $to
     * @return mixed
     */
    public function rate($from, $to) ;
}