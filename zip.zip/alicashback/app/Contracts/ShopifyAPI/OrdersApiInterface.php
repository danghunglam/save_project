<?php

namespace App\Contract\ShopifyAPI;


interface OrdersApiInterface
{
    /**
     * @param array $fields
     * @param array $filters
     * @param int $limit
     * @param int $page
     * @param string $status
     * @return mixed
     */
    public function all(array $fields = [], array $filters = [], int $limit, int $page, string $status = 'paid') ;

    /**
     * @param array  $filters
     * @param string $status
     *
     * @return int
     */
    public function count(array $filters = [], string $status) : int ;

    /**
     * @param string $orderId
     * @param array  $fields
     *
     * @return array
     */
    public function detail(string $orderId, array $fields = []): array ;

    /**
     * @param array $order
     * @return bool
     */
    public function create(array $order) : bool ;

    /**
     * @param string $orderId
     * @param array $data
     * @return array
     */
    public function update(string $orderId, array $data) : array;

    /**
     * @param string $orderId
     * @return bool
     */
    public function delete(string $orderId) : bool ;
}