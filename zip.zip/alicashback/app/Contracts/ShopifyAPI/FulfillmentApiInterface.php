<?php

namespace App\Contracts\ShopifyAPI;


interface FulfillmentApiInterface
{
    public function all(string $orderId);

    /**
     * @param string $orderId
     *
     * @return int
     */
    public function count(string $orderId) : int ;

    /**
     * @param string $orderId
     * @param string $fulfillmentId
     *
     * @return mixed
     */
    public function detail(string $orderId, string $fulfillmentId);

    /**
     * @param string $orderId
     * @param array $fulfillment
     *
     * @return mixed
     */
    public function create(string $orderId, array $fulfillment = []) ;

    /**
     * @param string $orderId
     * @param string $fulfillmentId
     * @param array $fulfillment
     *
     * @return bool
     */
    public function update(string $orderId, string $fulfillmentId, array $fulfillment = [], string $trackingCode = '');

    /**
     * @param string $orderId
     * @param string $fulfillmentId
     *
     * @return bool
     */
    public function toComplete(string $orderId, string $fulfillmentId) : bool ;

    /**
     * @param string $orderId
     * @param string $fulfillmentId
     *
     * @return bool
     */
    public function toOpen(string $orderId, string $fulfillmentId) : bool ;

    /**
     * @param string $orderId
     * @param string $fulfillmentId
     *
     * @return bool
     */
    public function toCancel(string $orderId, string $fulfillmentId) : bool ;
}