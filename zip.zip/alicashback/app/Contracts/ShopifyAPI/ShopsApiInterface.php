<?php

namespace App\Contracts\ShopifyAPI;


interface ShopsApiInterface
{
    /**
     * @return mixed
     */
    public function get();
}