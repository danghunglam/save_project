<?php
/**
 * Created by PhpStorm.
 * User: buicongdang
 * Date: 10/12/17
 * Time: 9:29 AM
 */

namespace App\Contracts\Repository;


interface SubscribeRepositoryInterface
{

}