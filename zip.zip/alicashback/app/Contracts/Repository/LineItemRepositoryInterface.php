<?php

namespace App\Contracts\Repository;


interface LineItemRepositoryInterface
{
    /**
     * @param array $data
     *
     * @return mixed
     */
    public function getAttributes( array $data = []);
    /**
     * @param string $orderId
     * @param array  $lineItem
     *
     * @return bool
     */
    public function save(string $orderId, array $lineItem) : bool ;

    /**
     * @param string $orderId
     * @param array  $lineItems
     *
     * @return bool
     */
    public function saveMany(string $orderId, array $lineItems) : bool ;

    /**
     * @param string   $lineItemId
     * @param array $lineItem
     *
     * @return bool
     */
    public function update(string $lineItemId, array $lineItem) : bool ;

    /**
     * @param string $lineItemId
     *
     * @return mixed
     */
    public function get(string $lineItemId);

    /**
     * @param string $orderId
     *
     * @return mixed
     */
    public function itemInOrder(string $orderId);

    /**
     * @param string $lineItemId
     *
     * @return bool
     */
    public function delete(string $lineItemId) : bool ;

    /**
     * @param array $attr
     * @param array $value
     *
     * @return bool
     */
    public function updateByAttr(array $attr, array $value) : bool ;

    /**
     * @param $trackingNumber
     * @param $lineItem
     * @return mixed
     */
    public function updateTrackingCodeByOrder($trackingNumber, $lineItem );
}