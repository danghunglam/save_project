<?php

namespace App\Contracts\Repository;


interface SettingRepositoryInterface
{
    /**
     * @return mixed
     */
    public function getAll() ;

    /**
     * @param string $key
     * @return mixed
     */
    public function getKey(string $key) ;

    /**
     * @param array $args
     * @return bool
     */
    public function saveMany(array $args) : bool ;

    /**
     * @return mixed
     */
    public function getObjAll();
}