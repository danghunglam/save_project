<?php

namespace App\Contracts\Repository;

/**
 * Interface ProductsRepositoryInterface
 * @package Contract\Repository
 */
interface ProductRepositoryInterface
{
    /**
     * @param array $filters
     * @param bool $isImport
     * @return mixed
     */
    public function all(array $filters = []) ;

    /**
     * @param array $product
     *
     * @return bool
     */
    public function save(array $product): bool ;

    /**
     * @param array $products
     *
     * @return bool
     */
    public function saveMany(array $products) : bool ;

    /**
     * @return mixed
     */
    public function productAutoUpdateAliexpress() ;
}