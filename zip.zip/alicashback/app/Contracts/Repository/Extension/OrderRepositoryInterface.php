<?php

namespace App\Contracts\Repository\Extension;


interface OrderRepositoryInterface
{
    public function syncOrderNumberFromOberlo(array $data) : bool ;
}