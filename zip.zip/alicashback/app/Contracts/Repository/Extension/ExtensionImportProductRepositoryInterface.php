<?php

namespace App\Contracts\Repository\Extension;


interface ExtensionImportProductRepositoryInterface
{
    /**
     * @param string $public_token
     * @param array $product
     * @param array $variants
     * @param array $images
     * @param array $supplier
     * @return mixed
     */
    public function importProduct(string $public_token, array $product, array $variants, array $images, array $supplier);

    /**
     * @param int $shop_id
     * @param string $public_token
     * @return array
     */
    public function deleteProduct(int $shop_id, string $public_token): array ;
}