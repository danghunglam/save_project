<?php

namespace App\Contracts\Repository;


interface ProductVariantRepositoryInterface
{
    /**
     * @param string $productId
     *
     * @return mixed
     */
    public function getVariantInProduct(string $productId);

    /**
     * @param string $productId
     *
     * @return mixed
     */
    public function getVariantAliOptionNullInProduct(string $productId);

    /**
     * @param string $productVariantId
     *
     * @return mixed
     */
    public function getDetail(string $productVariantId);

    /**
     * @param string $productVariantId
     * @param array  $args
     *
     * @return bool
     */
    public function update(string $productVariantId, array $args) : bool ;

    /**
     * @param string $productId
     * @param array  $variant
     *
     * @return bool
     */
    public function save(string $productId, array $variant) : bool ;

    /**
     * @param string $productId
     * @param array  $variants
     *
     * @return bool
     */
    public function saveMany(string $productId, array $variants) : bool ;

    /**
     * @param $productId
     * @return mixed
     */
    public function deleteByProductId($productId);
}