<?php

namespace App\Contracts\Repository;


interface ProductImageRepositoryInterface
{
    /**
     * @param $productId
     * @param array $args
     *
     * @return bool
     */
    public function saveMany(string $productId, array $args = []) : bool ;

    /**
     * @param string $productId
     * @param array  $arg
     *
     * @return bool
     */
    public function update(string $productId, array $arg = []) : bool ;

    /**
     * @param string $productId
     *
     * @return bool
     */
    public function delete(string $productId) : bool ;

    /**
     * @param string $productId
     * @param array  $field
     *
     * @return mixed
     */
    public function detail(string $productId, array $field = []);

    /**
     * @param array $field
     * @param array $filters
     * @param int   $limit
     *
     * @return mixed
     */
    public function all(array $field, array $filters, int $limit);

    /**
     * @param $productId
     * @return mixed
     */
    public function deleteByProductId($productId);
}