<?php

namespace App\Contracts\Repository;


interface SupplierRepositoryInterface
{
    /**
     * @param string $supplierId
     *
     * @return mixed
     */
    public function get(string $supplierId) ;

    /**
     * @param array $supplier
     *
     * @return bool
     */
    public function save(array $supplier = []) : bool ;

    /**
     * @param string $supplierId
     * @param array  $supplier
     *
     * @return bool
     */
    public function update(string $supplierId, array $supplier = []) : bool ;

    /**
     * @param string $supplierId
     * @param array  $supplier
     *
     * @return bool
     */
    public function createOrUpdate(string $supplierId, array $supplier = []) : bool ;
}