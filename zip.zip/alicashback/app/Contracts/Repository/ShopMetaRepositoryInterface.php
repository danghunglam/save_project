<?php

namespace App\Contracts\Repository;

/**
 * Interface ShopMetaRepositoryInterface
 * @package Contract\Repository
 */
interface ShopMetaRepositoryInterface
{
    public function createOrUpdate(array $data = []);
    public function findWithKey($shopId, string $key);
}
