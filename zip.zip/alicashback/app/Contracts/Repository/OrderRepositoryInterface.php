<?php

namespace App\Contracts\Repository;
use Illuminate\Database\Eloquent\Collection;

/**
 * Interface ProductsRepositoryInterface
 * @package Contract\Repository
 */
interface OrderRepositoryInterface
{
    /**
     * @param string $shopId
     * @param array  $order
     *
     * @return bool
     */
    public function save(string $shopId, array $order) : bool ;

    /**
     * @param string $shopId
     * @param array  $orders
     *
     * @return bool
     */
    public function saveMany(string $shopId, array $orders) : bool ;

    /**
     * @param string $orderId
     * @param array  $order
     *
     * @return bool
     */
    public function update(string $orderId, array $order) : bool ;

    /**
     * @param string $orderId
     *
     * @return mixed
     */
    public function get(string $orderId);

    /**
     * @param string $shopId
     * @param int $paginate
     * @param array $filters
     * @param int $paged
     *
     * @return mixed
     */
    public function all(string $shopId, array $filters, int $paginate, int $paged);

    /**
     * @param string $orderId
     *
     * @return bool
     */
    public function delete(string $orderId) : bool ;

    /**
     * @param int $shopId
     * @param array $filters
     * @param int $currentPage
     * @return mixed
     */
    public function allOrderPlace(int $shopId, int $currentPage, array $filters);

    /**
     * @param string $orderId
     * @return mixed
     */
    public function restore(string $orderId);
}