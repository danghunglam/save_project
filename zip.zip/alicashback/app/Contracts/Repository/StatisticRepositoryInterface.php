<?php

namespace App\Contracts\Repository;


interface StatisticRepositoryInterface
{
    /**
     * @param $shop_id
     * @param $from
     * @param $to
     * @return mixed
     */
    public function getTotalSummary($shop_id, $from, $to);
}