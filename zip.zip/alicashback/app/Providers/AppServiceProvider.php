<?php

namespace App\Providers;

use App\Contracts\Repository\Extension\ExtensionImportProductRepositoryInterface;
use App\Contracts\Repository\Extension\OrderRepositoryInterface;
use App\Contracts\Repository\StatisticRepositoryInterface;
use App\Contracts\Repository\TrackingCodeRepositoryInterface;
use App\Contracts\Services\CurrencyRate;
use App\Models\LineItemModel;
use App\Models\OrdersModel;
use App\Observers\LineItemObserver;
use App\Observers\OrderObserver;
use App\Repository\Extension\ExtensionImportProductRepository;
use App\Repository\Extension\OrderRepository;
use App\Repository\StatisticRepository;
use App\Repository\TrackingCodeRepository;
use App\Services\ApiLayerCurrencyRate;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider {
	/**
	 * Bootstrap any application services.
	 *
	 * @return void
	 */
	public function boot() {
		if( ! env('TEST_APP'))
			 $this->app['request']->server->set('HTTPS', 'on');
			 
		if(env('RUN_SUBDIR')) {
			$url = $this->app['url'];
			$url->forceRootUrl(env('APP_URL'));
		}
		
		Schema::defaultStringLength(191);
		//Observe order model
//		OrdersModel::observe(OrderObserver::class);
        //observer line item model
//		LineItemModel::observe(LineItemObserver::class);
	}

	/**
	 * Register any application services.
	 *
	 * @return void
	 */
	public function register() {
		$this->app->singleton(OrderRepositoryInterface::class, OrderRepository::class);
        $this->app->singleton(TrackingCodeRepositoryInterface::class, TrackingCodeRepository::class);
		$this->app->singleton(ExtensionImportProductRepositoryInterface::class, ExtensionImportProductRepository::class);
		$this->app->singleton(StatisticRepositoryInterface::class, StatisticRepository::class);
        $this->app->singleton(CurrencyRate::class, ApiLayerCurrencyRate::class);
	}
}
