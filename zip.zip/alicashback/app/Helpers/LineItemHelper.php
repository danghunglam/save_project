<?php
namespace App\Helpers;
class LineItemHelper
{
    public static function convertLineItemApiToLineItemModel($lineItem)
    {
        $price = self::convertPriceWithDiscount($lineItem);
        $data = [
            'id' => $lineItem->id,
            'product_variant_id' => $lineItem->variant_id,
            'status' => config('order.status.to_order'),
            'quality' => $lineItem->quantity,
            'price' => $price,
            'fulfillment_status' => config('lineitem.fulfillment_status.'.$lineItem->fulfillment_status) ? config('lineitem.fulfillment_status.'.$lineItem->fulfillment_status) : config('lineitem.fulfillment_status.null')
        ];
        if(in_array($lineItem->fulfillment_status, ['partial','fulfilled']))
        {
            $data['status'] = config('order.status.shipped');
        }
        return $data;
    }
    public static function convertPriceWithDiscount($lineItem)
    {
        $quantity = $lineItem->quantity;
        $totalPrice = $quantity * (double)$lineItem->price;
        if(!empty($lineItem->discount_allocations)) {
            $discountAllocations = $lineItem->discount_allocations;
            if(count($discountAllocations) > 0) {
                foreach($discountAllocations as $discount) {
                    $totalPrice = $totalPrice - (double)($discount->amount);
                }
            }
        }
        $price = round($totalPrice/$quantity,2);
        return $price;
    }
    public static function mergeOderLineItemToArray( $order, $lineItem )
    {
        $financialStatus = array(
            1 => 'Pending',
            2 => 'Paid',
            3 => 'Partially paid',
            4 => 'Refunded',
            5 => 'Partially refunded'
        );
        $orderStatus = array(
            1 => 'To order',
            2 => 'Order Placed',
            3 => 'Shipped',
            4 => 'Pending'
        );
        $fulfillment_status = array(
            1=> 'Unfulfillment',
            2=> 'Fulfilled',
            3=> 'Partial'
        );
        $itemArray = array();
        foreach( $lineItem as $item )
        {
            $item['Order#'] = '#'.$order['order_number'];
            $item['Created'] = $item['created_at'];
            $item['Financial_Status'] = $financialStatus[$order['financial_status']] ?? '';
            $item['Fulfillment_Status'] = $fulfillment_status[$order['fulfillment_status']] ?? '';
            $item['Note'] = $order['note'];
            $item['Supplier'] = isset( $item->productVariant->product->supplier->name ) ? $item->productVariant->product->supplier->name : null;
            $item['Product'] = isset( $item->productVariant->product->title ) ? $item->productVariant->product->title : null;
            $item['Variant_SKU'] = isset( $item->productVariant->sku ) ? $item->productVariant->sku : null;
            $item['Variant_Title'] = isset( $item->productVariant->title ) ? $item->productVariant->title : null;
            $item['Quantity'] = $item['quality'];
            $item['Ali_Order_No'] = $item['aliexpress_order_no'];
            $item['Tracking_Code'] = $item['tracking_code'];
            $item['Customer_Name'] = $order['first_name'].' '.$order['last_name'];
            $item['Address'] = $order['address1'];
            $item['Address2'] = $order['address2'];
            $item['City'] = $order['city'];
            $item['Zip'] = $order['zip'];
            $item['Country'] = $order['country'];
            $item['Province'] = $order['province'];
            $item['Phone'] = $order['phone'];
            $item['Status'] = $orderStatus[$item['status']] ?? '';
            $item = self::removeExportKeyArray( $item->toArray() );
            array_push($itemArray, $item);
        }
        return $itemArray;
    }
    public static function removeExportKeyArray($item)
    {
        $removeKeys = array('id', 'orders_id', 'product_variant_id', 'price', 'updated_at', 'product_variant', 'fee_tax',
            'fee_ship', 'price_order_aliexpress', 'status', 'quality', 'aliexpress_order_no', 'tracking_code', 'fulfillment_status', 'created_at');
        foreach($removeKeys as $key) {
            unset($item[$key]);
        }
        return $item;
    }
    public static function sortExportKeyArray( $itemMergeArray )
    {
        $exportArray = array();
        $order = array( 'Order#', 'Created', 'Financial_Status', 'Fulfillment_Status', 'Note', 'Supplier', 'Product', 'Variant_SKU', 'Variant_Title',
            'Quantity', 'Ali_Order_No', 'Tracking_Code', 'Customer_Name', 'Address', 'Address2', 'City', 'Zip', 'Country', 'Province', 'Phone', 'Status' );
        foreach($itemMergeArray as $item ) {
            array_push( $exportArray, array_merge(array_flip($order), $item));
        }
        return $exportArray;
    }
    public static function revert_data_TrackingCodeNull($item)
    {
        $array = array();
        foreach($item as $value)
        {
            $array[] = $value['id'];
        }
        return $array;
    }
    public static function mergeTrackingCodeLineItemToArray( $order, $lineItem )
    {
        $itemArray = array();
        foreach( $lineItem as $item )
        {
            $item['order_number'] = $order['order_number'];
            $item = self::removeTrackingCodeExportKeyArray( $item );
            array_push($itemArray, $item);
        }
        return $itemArray;
    }
    public static function sortTrackingCodeExportKeyArray( $itemMergeArray )
    {
        $exportArray = array();
        $order = array( 'order_number', 'supplier', 'product_title', 'variant_title', 'aliexpress_order_no', 'tracking_code');
        foreach($itemMergeArray as $item ) {
            array_push( $exportArray, array_merge(array_flip($order), $item));
        }
        return $exportArray;
    }
    public static function removeTrackingCodeExportKeyArray($item)
    {
        $removeKeys = array('id', 'status', 'product_handle', 'product_variant_image', 'variant_sku', 'quality', 'price', 'total_price_item', 'orders_id', 'source_product_link', 'aliexpress_options', 'product_variant_id', 'product_id', 'aliexpress_product_id', 'variant_deleted_at', 'created_at', 'updated_at', 'product_variant');
        foreach($removeKeys as $key) {
            unset($item[$key]);
        }
        return $item;
    }
}