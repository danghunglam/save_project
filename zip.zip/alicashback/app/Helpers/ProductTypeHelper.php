<?php

namespace App\Helpers;

use App\Models\ShopModel;
use App\Models\ProductModel;
use App\Models\ProductTypeModel;

class ProductTypeHelper
{
    public static function createProductType($shop_id, $name) {
        if((!$shop = ShopModel::find($shop_id)) || !$name || $name == "")
            return false;
        if(ProductTypeModel::where('name', $name)->first())
            return true;
        
        $newProductType = new ProductTypeModel();
        $newProductType->name = $name;
        $newProductType->type = 1;
        $newProductType->shop_id = $shop_id;
        return $newProductType->save();
    }

    public static function editProductType($shop_id, $product_id, $name) {
        if(! $shop = ShopModel::find($shop_id))
            return false;
        if(! $product = ProductModel::find($product_id))
            return false;

        if($product->product_type == null || $product->product_type == '') {
            return ProductTypeHelper::createProductType($shop_id, $name);
        }

        if(!ProductModel::where('shop_id', $shop_id)->where('product_type', $product->product_type)
                        ->where('id', '<>', $product->id)->first()) {
            ProductTypeModel::where('name', $product->product_type)->forceDelete();
        }
        if($name) {
            return ProductTypeHelper::createProductType($shop_id, $name);
        }

        return true;
    }
}
