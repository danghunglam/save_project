<?php
namespace App\Helpers;

use App\Factory\RepositoryFactory;
use App\Repository\CommentBackEndRepository;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Carbon\Carbon;

class Helpers
{
    /**
     * @param $currentPage
     * @param $totalItem
     * @param $itemInPage
     * @param $filterPagination
     * @return string
     */
    public static function paginationApi($currentPage, $totalItem, $itemInPage, $filterPagination)
    {
        $totalPage = ceil($totalItem/$itemInPage);
        $view = view('sections.paginations', compact('currentPage', 'totalPage', 'filterPagination'))->render();
        return $view;
    }

    /**
     * @return array|mixed
     */
    public static function getCountryCode()
    {
        $file = storage_path('json/country.json');
        $countryCode = [];
        $data = [];
        if( ! file_exists($file))
            return $countryCode;

        $source = file_get_contents($file);
        $countryCode = json_decode($source, true);

        foreach ($countryCode as $key => $value) {
            $data[$value['Code']] = $value['Name'];
        }
        return $data;
    }

    /**
     * @param $type
     * @param $arrayLog
     */
    public  static function saveLog($type, $arrayLog)
    {
        $message = isset($arrayLog['message']) ? $arrayLog['message'] : '';
        $file = isset($arrayLog['file']) ? ' File: '.$arrayLog['file'] : '';
        $line = isset($arrayLog['line']) ? ' Line: '.$arrayLog['line'] : '';
        $function = isset($arrayLog['function']) ? ' Function: '.$arrayLog['function'] : '';
        $domain =  isset($arrayLog['domain']) ? ' Domain: '.$arrayLog['domain'] : '';
        Log::$type($message.$file.$line.$function.$domain);
    }


    /**
     * @return string
     */
    public static function getAvatarAbstract() {
        $id = rand(1,199);
        return 'images/avatar/abstract/avatar'.$id.'.jpg';
    }


	public  static  function human_time_diff( $from, $to = '',$translate=array() ) {
		$since = '';
		if ( empty( $to ) ) {
			$to = time();
		}
		if(empty($translate)){
			$translate = config('settings')['translate'];
		}

		$diff = (int) abs( $to - $from );

		if ( $diff < config('custom.TIME_SECONDS.HOUR_IN_SECONDS')) {
			$mins = round( $diff / config('custom.TIME_SECONDS.MINUTE_IN_SECONDS') );
			if ( $mins <= 1 ) {
				$mins = 1;
				$since = $mins.' '.$translate['min'];
			} else
				$since = $mins.' '.$translate['mins'];
		} elseif ( $diff < config('custom.TIME_SECONDS.DAY_IN_SECONDS') && $diff >= config('custom.TIME_SECONDS.HOUR_IN_SECONDS') ) {
			$hours = round( $diff / config('custom.TIME_SECONDS.HOUR_IN_SECONDS') );
			if ( $hours <= 1 ) {
				$hours = 1;
				$since = $hours.' '.$translate['hour'];
			} else
				$since = $hours.' '.$translate['hours'];
		} elseif ( $diff < config('custom.TIME_SECONDS.WEEK_IN_SECONDS') && $diff >= config('custom.TIME_SECONDS.DAY_IN_SECONDS') ) {
			$days = round( $diff / config('custom.TIME_SECONDS.DAY_IN_SECONDS') );
			if ( $days <= 1 ) {
				$days = 1;
				$since = $days.' '.$translate['day'];
			} else
				$since = $days.' '.$translate['days'];
		} elseif ( $diff < config('custom.TIME_SECONDS.MONTH_IN_SECONDS') && $diff >= config('custom.TIME_SECONDS.WEEK_IN_SECONDS') ) {
			$weeks = round( $diff / config('custom.TIME_SECONDS.WEEK_IN_SECONDS') );
			if ( $weeks <= 1 ) {
				$weeks = 1;
				$since = $weeks.' '.$translate['week'];
			} else
				$since = $weeks.' '.$translate['weeks'];
		} elseif ( $diff < config('custom.TIME_SECONDS.YEAR_IN_SECONDS') && $diff >= config('custom.TIME_SECONDS.MONTH_IN_SECONDS') ) {
			$months = round( $diff / config('custom.TIME_SECONDS.MONTH_IN_SECONDS') );
			if ( $months <= 1 )
			{
				$months = 1;
				$since = $months.' '.$translate['month'];
			} else
				$since = $months.' '.$translate['months'];

		} elseif ( $diff >= config('custom.TIME_SECONDS.YEAR_IN_SECONDS') ) {
			$years = round( $diff / config('custom.TIME_SECONDS.YEAR_IN_SECONDS') );
			if ( $years <= 1 ) {
				$years = 1;
				$since = $years.' '.$translate['year'];
			} else
				$since = $years.' '.$translate['years'];
		}

		return $since.' ' .$translate['text_ago'];
	}

    public static function slugToString($slug, $str, $ucFirst = false )
    {
        
        if( ! $slug)
            return '';
        if($slug === 'null')
        {
            return 'unfulfilled';
        }
        if($slug === 'partial')
        {
            return 'Partially Fulfilled';
        }
        if($slug==='partially-paid')
        {
            return 'Partially Paid';
        }
        if($slug==='partially-refunded')
        {
            return 'Partially Refunded';
        }
        $slugs = explode($str, $slug);
        $str = '';
        foreach ($slugs as $text)
        {
            $str .= $text.' ';
        }
        if($ucFirst)
            $str = ucfirst($str);

        return ($str);
    }

    static function listTimezone()
    {
        $file = storage_path('json/timezone.json');
        if( ! file_exists($file))
            return false;

        $timezone = file_get_contents($file);
        $timezone = json_decode($timezone, true);

        return $timezone;
    }


    public static function generalPublicToken($keyword)
    {
        $keyword = md5('bui_cong_dang').md5($keyword.md5($keyword));
        return hash('sha1', $keyword);
    }


	public static function getBrowser()
	{
		$u_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
		$bname = 'Unknown';
		$platform = 'Unknown';
		$version= "";
		$ub = '';

		//First get the platform?
		if (preg_match('/linux/i', $u_agent)) {
			$platform = 'linux';
		}
		elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
			$platform = 'mac';
		}
		elseif (preg_match('/windows|win32/i', $u_agent)) {
			$platform = 'windows';
		}

		if (preg_match('/Mobile/i', $u_agent)) {
			$platform = 'mobile';
		}

		// Next get the name of the useragent yes seperately and for good reason
		if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent))
		{
			$bname = 'Internet Explorer';
			$ub = "MSIE";
		}
		elseif(preg_match('/Firefox/i',$u_agent))
		{
			$bname = 'Mozilla Firefox';
			$ub = "Firefox";
		}
		elseif(preg_match('/Chrome/i',$u_agent))
		{
			$bname = 'Google Chrome';
			$ub = "Chrome";
			if(preg_match('/Edge/i',$u_agent)){
				$bname = 'Edge';
				$ub = "Edge";
			}
		}
		elseif(preg_match('/Safari/i',$u_agent))
		{
			$bname = 'Apple Safari';
			$ub = "Safari";
		}
		elseif(preg_match('/Opera/i',$u_agent))
		{
			$bname = 'Opera';
			$ub = "Opera";
		}
		elseif(preg_match('/Netscape/i',$u_agent))
		{
			$bname = 'Netscape';
			$ub = "Netscape";
		}

		return array(
			'userAgent' => $u_agent,
			'name'      => $bname,
			'code'      => $ub,
			'version'   => $version,
			'platform'  => $platform,
		);
	}

	public static function filterAliexpressDetailLink($aliexpress)
    {
        $preg = '/[0-9]*\.html/';
        preg_match($preg, $aliexpress, $matches);
        if(! empty($matches))
            return 'https://www.aliexpress.com/item/-/'.$matches[0];

        return false;
    }

    public static function getAliexpressProductId($link_aliexpress)
    {
        $preg = '/[0-9]*.html/';
        if(preg_match($preg, $link_aliexpress, $match))
        {
            $product_id = explode('.', $match[0]);
            return $product_id[0];
        }

        return null;
    }

    /**
     * import products bằng loại tiền tệ khác thì luôn chuyển đổi qua USD
     * sử dụng API http://www.apilayer.net/api/live?access_key=eea4e76280037daf2869aac438728875
     * @param $currency
     * @param $price
     * @return $price
     */
    public static function converttoUSD($currency, $price)
    {
        if($currency=='USD') return $price;

        $filename= 'apiCurrency.txt';
        // Kiem tra neu co file thi doc tu file
        $data = self::checkFile($filename);

        if(is_string($data)){
            $data = unserialize($data);
            return round($price/$data[$currency],2);
        }
        // Neu chua co thi lưu file mới va kiem tra lai.
        if(!self::saveFile($filename)) return false;//$exchangeRates =

        $data = self::checkFile($filename);
        if(is_string($data)){
            $data = unserialize($data);
            return round($price/$data[$currency],2);
        }
        return 0;
    }

    public static function convertFromUSD($currency,$price)
    {
        if($currency=='USD') return $price;

        $filename= 'apiCurrency.txt';
        // Kiem tra neu co file thi doc tu file
        $data = self::checkFile($filename);

        if(is_string($data)){
            $data = unserialize($data);
            return round($price*$data[$currency],2);
        }
        // Neu chua co thi lưu file mới va kiem tra lai.
        if(!self::saveFile($filename)) return false;//$exchangeRates =

        $data = self::checkFile($filename);
        if(is_string($data)){
            $data = unserialize($data);
            return round($price*$data[$currency],2);
        }

        return 0;
    }

    static function saveFile($filename){
        // set API Endpoint and access key (and any options of your choice)
        $endpoint = env('CURRENCY_CONVERT_END_POINT');
//        dd($endpoint);
        $access_key = env('CURRENCY_CONVERT_ACCESS_KEY');

        // Initialize CURL:
        $ch = curl_init('http://apilayer.net/api/'.$endpoint.'?access_key='.$access_key.'');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);


        // Store the data:
        $json = curl_exec($ch);

        curl_close($ch);
        $exchangeRates =  json_decode($json, true);

        if(!$exchangeRates['success']) return false;// neu API tra ve loi thi khong luu vao file

        $currencyConverts = $exchangeRates['quotes'];

        foreach ($currencyConverts as $key=>$currencyConvert){
            $newKey = str_replace('USD','',$key);
            if($newKey == '') $newKey='USD';
            self::replaceKey($currencyConverts,$key,$newKey);
        }
        if (strlen($filename)<=0)return false;
        $folderPath = storage_path('app/public/convertRates');

        if (!file_exists($folderPath))
            mkdir($folderPath);

        $file = @fopen($folderPath . DIRECTORY_SEPARATOR . $filename,"w");
        if (!$file)return false;
        fwrite($file,serialize($currencyConverts));
        fclose($file);
        return 1;
    }
    static function readFile($filename){
        $filename = storage_path('app/public/convertRates/'.$filename);
        $file = @fopen($filename,"r");

        if (!$file)return false;

        $data = fread($file,filesize($filename));
        fclose($file);
        return $data;

    }
    static function checkFile($filename){
        if(empty(basename($filename))) return true;
        return self::readFile($filename);
    }

    static function replaceKey(&$array, $curkey, $newkey)
    {
        if(array_key_exists($curkey, $array))
        {
            $array[$newkey] = $array[$curkey];
            unset($array[$curkey]);
            return true;
        }
        return false;

    }

    public static function pushProcessCache($shopId, $datas, $type, $time = 180) {
        $currentProcess = json_decode(Cache::get($type.$shopId, '[]'), true);
        if(!is_array($currentProcess))
            $currentProcess = [];
        $newProcess = $currentProcess;
        
        foreach ($datas as $data) {
            $pushed = false;
            foreach ($currentProcess as $key => $product)
            {
                if(isset($product['id']) && isset($data['id']) && $data['id'] == $product['id']) {
                    if(isset($data['status'])) {
                        $newProcess[$key]['status'] = $data['status'];
                    }
                    $pushed = true;
                }
                if(isset($product['status']) && $product['status'] === 'success')
                {
                    unset($newProcess[$key]);
                }
            }
            if(!$pushed && isset($data['id']) && isset($data['status'])) {
                array_push($newProcess, $data);
            }
        }
        Cache::put($type.$shopId, json_encode($newProcess), $time);
    }

    public static function removeProcessCache($shopId, $data, $type) {
        $overrideProcess = Helpers::getOverrideProcessCache($shopId, $type);
        foreach($overrideProcess as $key => $process) {
            if( (isset($process['status']) &&  $process['status'] === 'success') 
                || (isset($process['id']) &&  $process['id'] === $data['id']))
            {
                unset($overrideProcess[$key]);
            }
        }
        Helpers::setOverrideProcessCache($shopId, $overrideProcess, $type);
    }

    public static function setOverrideProcessCache($shopId, $data, $type, $time = 1000)
    {
        Cache::put($type.$shopId, json_encode($data), $time);
    }

    public static function getOverrideProcessCache($shopId, $type)
    {
        $override_process = json_decode(Cache::get($type.$shopId, '[]'), true);
        if(!is_array($override_process))
            $override_process = [];
        foreach ($override_process as $key => $product)
        {
            if(!isset($product['status']) || $product['status'] === 'success')
            {
                unset($override_process[$key]);
            }
        }
        return $override_process;
    }

    public static function setLastUpdateTime($shopId) {
        $newLastTimeUpdate = Carbon::now('UTC')->timestamp;
        $currentLastTimeUpdate = Cache::get('last_time_update_'.$shopId);

        if(!$currentLastTimeUpdate || $newLastTimeUpdate - $currentLastTimeUpdate > 86400) { // first time update currentLastTimeUpdate will be null
            Cache::forever('last_time_update_'.$shopId, $newLastTimeUpdate);
            return true;
        }
        return false;
    }

    public static function clearLastUpdateTime($shopId) {
        Cache::forget('last_time_update_'.$shopId);
    }

    public static function setLastUpdateTrackingCodeTime($shopId, $numberOfDate) {
        $newLastTimeUpdate = Carbon::now('UTC')->timestamp;
        $currentLastTimeUpdate = Cache::get('last_time_update_tracking_code_'.$shopId);
        if(!$currentLastTimeUpdate || $newLastTimeUpdate - $currentLastTimeUpdate > $numberOfDate) { // first time update currentLastTimeUpdate will be null
            Cache::forever('last_time_update_tracking_code_'.$shopId, $newLastTimeUpdate);
            return true;
        }
        return false;
    }

    public static function setStatusAutoFulfillment($shopId, $status = 1) {
        Cache::forever('fulfillmented_with_tracking_code_'.$shopId, $status);
    }
    
    public static function getLastUpdateTime($shopId) {
        return Cache::get('last_time_update_'.$shopId);
    }

    /**
     * Convert utf-8 to ascii
     * @param $string
     * @return string
     */
    public static function changeUtf8ToAscii($string)
    {
        if(empty($string) || ! is_string($string))
            return '';

        $string = preg_replace('/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/', 'a', $string);
        $string = preg_replace('/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/', 'e', $string);
        $string = preg_replace('/ì|í|ị|ỉ|ĩ|ï/', 'i', $string);
        $string = preg_replace('/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/', 'o', $string);
        $string = preg_replace('/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ|ü/', 'u', $string);
        $string = preg_replace('/ỳ|ý|ỵ|ỷ|ỹ/', 'y', $string);
        $string = preg_replace('/đ/', 'd', $string);
        $string = preg_replace('/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/', 'A', $string);
        $string = preg_replace('/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/', 'E', $string);
        $string = preg_replace('/Ì|Í|Ị|Ỉ|Ĩ/', 'I', $string);
        $string = preg_replace('/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/', 'O', $string);
        $string = preg_replace('/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ|Ü/', 'U', $string);
        $string = preg_replace('/Ỳ|Ý|Ỵ|Ỷ|Ỹ/', 'Y', $string);
        $string = preg_replace('/Đ/', 'D', $string);
        $string = preg_replace('/ç/', 'c', $string);
        $string = preg_replace('/Ç/', 'C', $string);

        return $string;
    }

    public static function getAliexpressAddress()
    {
        $file = storage_path('json/constants_country.json');
        $aliexpressAddress = [];
        $data = [];
        if( ! file_exists($file))
            return $aliexpressAddress;
        $source = file_get_contents($file);
        $aliexpressAddress = json_decode($source, true);
        return $aliexpressAddress;
    }
}