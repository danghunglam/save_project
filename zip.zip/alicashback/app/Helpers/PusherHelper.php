<?php
namespace App\Helpers;

use Illuminate\Support\Facades\Log;

class PusherHelper {
    public function log($msg) {
        Log::info($msg);
    }
}