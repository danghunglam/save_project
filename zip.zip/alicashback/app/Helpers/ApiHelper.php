<?php

namespace App\Helpers;

use GuzzleHttp\Client;
class ApiHelper
{
    public static function getApi($request)
    {
        $client = new Client();
        $response = $client->get($request);
        $response = json_decode( $response->getBody()->getContents() );
        return $response;
    }

}