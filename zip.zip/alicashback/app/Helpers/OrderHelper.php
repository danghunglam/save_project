<?php

namespace App\Helpers;


class OrderHelper
{
    public static function convertOrderApiToOrderModel($order)
    {
    	$shipping = isset( $order->shipping_address ) ? $order->shipping_address : null;
        return [
            'id' => $order->id,
            'order_number' => $order->order_number,
            'order_name' => $order->name,
            'first_name' => isset($shipping->first_name) ? $shipping->first_name : null,
            'last_name' => isset($shipping->last_name) ? $shipping->last_name : null,
            'city' => isset($shipping->city) ? $shipping->city : null,
            'country' => isset($shipping->country) ? $shipping->country : null,
            'country_code' => isset($shipping->country_code) ? $shipping->country_code : null,
            'province' => isset($shipping->province) ? $shipping->province : null,
            'province_code' => isset($shipping->province_code) ? $shipping->province_code : null,
            'address1' => isset($shipping->address1) ? $shipping->address1 : null,
            'address2' => isset($shipping->address2) ? $shipping->address2 : null,
            'zip' => isset($shipping->zip) ? $shipping->zip : null,
            'phone' => isset($shipping->phone) ? $shipping->phone :
                (isset($order->phone) ? $order->phone : (isset($order->phone) ? $order->phone : null)),
            'email' => isset($shipping->email) ? $shipping->email :
                (isset($order->contact_email) ? $order->contact_email  : (isset($order->email) ? $order->email : null)),
            'fulfillment_status' => config( 'order.fulfillment_status.'.$order->fulfillment_status ) ? config( 'order.fulfillment_status.'.$order->fulfillment_status ) : config( 'order.fulfillment_status.null' ),
            'financial_status' => config( 'order.financial_status.'.$order->financial_status ),
            'created_at' => isset($order->created_at) ? date('Y-m-d H:i:s', strtotime($order->created_at)) : null,
            'updated_at' => isset($order->updated_at) ? date('Y-m-d H:i:s', strtotime($order->updated_at)) : null,
            'currency' => isset($order->currency) ? $order->currency : 'USD',
            'total_price' => isset($order->total_price) ? $order->total_price : 0,
            'subtotal_price' => isset($order->subtotal_price) ? $order->subtotal_price : 0,
            'total_tax' => isset($order->total_tax) ? $order->total_tax : 0,
            'total_discounts' => isset($order->total_discounts) ? $order->total_discounts : 0,
            'total_line_items_price' => isset($order->total_line_items_price) ? $order->total_line_items_price : 0
        ];
    }
}