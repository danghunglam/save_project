<?php
declare(strict_types=1);
namespace App\Helpers;


class SettingHelper
{
    /**
     * @return array
     */
    public static function getAllKey()
    {
        $settingDefault = config('setting_default');
        return array_keys($settingDefault);
    }
    
    public static function getPriceRange( $price_rule )
    {
	    unset($price_rule['rest_of_the_price_ranges']);
	    return $price_rule;
    }
	
	public static function removeNullRequestBeforeSave( $res )
	{
		foreach( $res as $key => $value ) {
			if ($value === null) {
				unset( $res[$key] );
			}
		}
		return $res;
	}
	
	public static function removeElementRequestByKey( $res, $key )
	{
		foreach ($res as $k => $costRange)
		{
			unset($costRange[$key]);
			$res[$k] = $costRange;
		}
		return $res;
	}

    /**
     * Convert setting in database to Array setting [key => '', value => ''] to [key => value]
     * @param $settings
     *
     * @return array
     */
	public static function decodeSettings( $settings )
	{
		$settingsArray = [];
		if( ! empty($settings))
            foreach ( $settings as $setting )
            {
                if(in_array($setting->key,['price_rule','rest_of_the_price_ranges']))
                    $settingsArray[$setting->key] = json_decode($setting->value, true);
                elseif(in_array($setting->key,
                    ['is_compared_price',
                        'notification_email_customer_fulfillment',
                        'auto_update_when_product_cost_change_aliexpress_notify',
                        'auto_update_when_product_no_longer_available_aliexpress_notify',
                        'auto_update_when_product_variant_no_longer_available_aliexpress_notify',
                        'when_one_product_is_out_of_stock_on_aliexpress_notify',
                        'is_shipping_max_price_alert']))
                    $settingsArray[$setting->key] = ($setting->value === '1') ? true : false;
                else
                    $settingsArray[$setting->key] = $setting->value;
            }
		return $settingsArray;
	}

    /**
     * Convert setting [key => value] to [key => '', value => '']
     * @param $settings
     *
     * @return array
     */
	public static function encodeSettings($settings)
    {
        $settingsArray = [];
        $i = 0;
        foreach ($settings as $key => $setting)
        {
            if(in_array($key,['price_rule', 'rest_of_the_price_ranges']))
                $setting = json_encode($setting);

            $settingsArray[$i]['key'] = $key;
            $settingsArray[$i]['value'] = $setting;
            $i++;
        }
        return $settingsArray;
    }

    /**
     * @param $country_code
     *
     * @return bool|string
     */
    public static function getPhoneCode($country_code)
    {
        $phoneCode = '+1';
        $source_path = storage_path('json/phoneList.json');
        if(file_exists($source_path))
        {
            $countryCode = file_get_contents($source_path);
            $countryCode = json_decode($countryCode, true);
            foreach ($countryCode as $country)
            {
                if($country_code === $country['alpha2'])
                    $phoneCode = '+'.$country['country_code'];
            }
        }

        return $phoneCode;
    }

    /**
     * @param $phone_number
     *
     * @return mixed
     */
    public static function filterPhoneNumber($phone_number)
    {
        return preg_replace('/^0/', '', $phone_number);
    }


    public static function splitPhoneNumberCode($phone_number)
    {
        if(empty($phone_number))
            return [
                'phone' => null,
                'phone_code' => null
            ];

        if(preg_match('/^\\+/',$phone_number))
        {
            return [
                'phone' => mb_substr($phone_number, 4),
                'phone_code' => mb_substr($phone_number, 0, 3)
            ];
        }

        return [
            'phone' => self::filterPhoneNumber($phone_number),
            'phone_code' => null
        ];
    }

    public static function getDefaultCountryCode(){
        $result = array();

        $listCountry = self::getCountryCode();
        //unset($listCountry['RU']);
        foreach ($listCountry as $k=> $v){
            $result[] = $k;
        }

        return $result;
    }

    public static function getCountryCode()
    {
        $file = storage_path('json/country.json');
        $countryCode = [];
        $data = [];
        if( ! file_exists($file))
            return $countryCode;
        $source = file_get_contents($file);
        $countryCode = json_decode($source, true);
        foreach ($countryCode as $key => $value) {
            $data[$value['Code']] = $value['Name'];
        }
        return $data;
    }
}