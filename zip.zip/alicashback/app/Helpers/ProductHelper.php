<?php

namespace App\Helpers;

use App\Models\ProductModel;


class ProductHelper
{
    public static function checkVariant($productId, $datas)
    {
        $product = ProductModel::find($productId);
        if( ! $product)
            return false;

        $variantNotAvailable = [];
        $variantChangePrice = [];
        $variantOutOfStock  = [];

        $variants = $product->productVariant()->get();

        foreach ($variants as $key => $variant) {
            foreach ($datas as $data)
            {
                if($variant->aliexpress_options === $data->aliexpress_options) {
                    $variantNotAvailable = array_slice($variants, $key, 1);
                    //Equal price
                    if($variant->source_price  !== $data->price) {
                        $range_price = $variant->price/$variant->source_price;
                        $range_compare_at_price = $variant->compare_at_price/$variant->source_price;
                        $variantChangePrice[] = [
                            'variant' => $variant,
                            'old_price' => $variant->source_price,
                            'new_price' => $data->price,
                            'range_price' => $range_price,
                            'range_compare_at_price' => $range_compare_at_price
                        ];
                    }
                    if($data->stock === 0) {
                        $variantOutOfStock[] = $variant;
                    }
                }
            }
        }
        return compact('variantNotAvailable', 'variantChangePrice', 'variantOutOfStock');

    }

    /**
     * Handle extension bulk sync product from oberlo
     * @param $productId
     * @param array $options
     *
     * @return mixed
     */
    public static function getVariantId($productId, $options = [])
    {
        $product = ProductModel::find($productId);
        if( ! isset($product->productVariant))
            return false;

        $variants = $product->productVariant;
        $length = count($options);
        foreach ($variants as $variant)
        {
            $product_options = [];
            if( ! empty($variant->option1))
                $product_options[]= str_slug($variant->option1);
            if( ! empty($variant->option2))
                $product_options[] = str_slug($variant->option2);
            if( ! empty($variant->option3))
                $product_options[] = str_slug($variant->option3);

            if($length === 1)
            {
                if(in_array(str_slug($options[0]['optionName']), $product_options))
                    return $variant;
            }
            if($length === 2) {
                if(in_array(str_slug($options[0]['optionName']), $product_options) && in_array(str_slug($options[1]['optionName']), $product_options))
                    return $variant;
            }
                

            if($length === 3) {
                if(in_array(str_slug($options[0]['optionName']), $product_options)
                    && in_array(str_slug($options[1]['optionName']), $product_options)
                    && in_array(str_slug($options[2]['optionName']), $product_options))
                    return $variant;
            }
        }
        if(count($options) == 0 && $variants->count() == 1) {
            return $variants->first();
        }
        return false;
    }

    public static function convertOptions($options)
    {
        $tmp = [];
        foreach ($options as $option)
        {
            $tmp[] = [
                'name' => $option['name'],
                'position' => $option['position']
            ];
        }
        return json_encode($tmp);
    }

}