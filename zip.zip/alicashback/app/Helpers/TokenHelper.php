<?php
namespace App\Helpers;

use Firebase\JWT\JWT;
use Carbon\Carbon;
use Exception;

class TokenHelper {
    
    public static function verifyToken($jwt = '') {
        try {
            $data = JWT::decode($jwt, env('ALIORDER_KEY'), array('HS256'));
            if(!$data->expired || $data->expired < Carbon::now('UTC')->timestamp)
                return false;
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public static function createToken(array $data = [], $expired = 1000) {
        try {
            $data['expired'] = Carbon::now('UTC')->timestamp + $expired * 60;
            return JWT::encode($data, env('ALIORDER_KEY'));
        } catch (Exception $e) {
            return false;
        }
    }

}