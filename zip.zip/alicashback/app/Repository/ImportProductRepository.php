<?php

namespace App\Repository;


use App\Models\ImportProductModel;
use App\Models\ProductModel;
use App\Models\ShopModel;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Log;

class ImportProductRepository
{
    /**
     * Get all products
     * @param $shopId
     * @param $filters
     * @param $pagination
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function all($shopId, array $filters = [], $pagination = true)
    {
        $shopModel = ShopModel::find($shopId);
        if( ! $shopModel)
            return response()->json(['status' => false]);

        $importProduct = $shopModel->importProduct()->whereNull('is_import')->with(['productVariant.productImage', 'productImage']);

        if(isset($filters['keyword']) && $filters['keyword']  !== '')
            $importProduct->where('title', 'like', '%'.$filters['keyword'].'%');

        $importProduct->orderBy('created_at', 'desc');

        if($pagination) {
            $currentPage = (isset($filters['paged']) && $filters['paged'] !== '') ? $filters['paged'] : 1;

            Paginator::currentPageResolver(function () use ($currentPage) {
                return $currentPage;
            });

            return $importProduct->paginate(config('common.paginate_import_product'));
        }
        return $importProduct->get();
    }

    /**
     * Create product
     * @param $product
     * @param $shopId
     *
     * @return array
     */
    public function create($product, $shopId)
    {
        $aliProductId = $product['aliexpress_product_id'];

        if( ! $shopModel = ShopModel::find($shopId))
            return ['status' => false, 'message' => 'Please login AliOrder'];

        if($productModel = $shopModel->importProduct()->where('aliexpress_product_id', $aliProductId)
            ->whereNull('is_import')->count())
        {
            return ['status' => false,'message' => 'Imported Already!'];
        } else {
            if($product = $shopModel->importProduct()->create($product))
                return ['status' => true, 'product' => $product];
        }

        return ['status' => false, 'message' => 'Error'];
    }

    /**
     * Handle update product
     * @param $shopId
     * @param $productId
     * @param $product
     *
     * @return bool
     */
    public function update($shopId, $productId, $product)
    {
        $productModel = new ImportProductModel();
        $filterArgs = array_only($product, $productModel->getFillable());

        $shop = ShopModel::find($shopId);

        //Check shop exist
        if( ! $shop)
            return false;

        if($product = $shop->importProduct()->where('id', $productId))
        {
            if($product->update($filterArgs))
                return true;
        }

        return false;
    }

    public function delete($shopId, $productId)
    {
        $shop = ShopModel::find($shopId);

        //Check shop exist
        if( ! $shop)
            return false;

        if($product = $shop->importProduct()->where('id', $productId))
        {
            if($product->delete())
                return true;
        }

        return false;
    }

    public function deleteAllByShopId($shopId)
    {
        $shop = ShopModel::find($shopId);

        //Check shop exist
        if( ! $shop)
            return false;

        if($shop->importProduct()->delete())
        {
            return true;
        }

        return false;
    }

    public function count($shopId)
    {
        $shop = ShopModel::find($shopId);

        //Check shop exist
        if( ! $shop)
            return false;

        if($count = $shop->importProduct()->whereNull('is_import')->count())
        {
            return $count;
        }

        return false;
    }

    public function getProductById($shopId,$productId){
        $shop = ShopModel::find($shopId);
        if( ! $shop)
            return false;
        $importProduct = $shop->importProduct()->where('id', $productId)->whereNull('is_import')->get();
        if(empty($importProduct)) return false;
        return $importProduct;
    }

    public function getProductsByIds($shopId,$productIds){
        $shop = ShopModel::find($shopId);
        if( ! $shop)
            return false;
        $importProducts = $shop->importProduct()->whereIn('id', $productIds)->whereNull('is_import')->get();
        if(empty($importProducts)) return false;
        return $importProducts;
    }

    public function filterDataProduct($products) {
        $productObj = [];
        foreach ($products as $k=>$product)
        {
            $productObj[$k] = [
                'id' => $product->id,
                'title' => $product->title,
                'image' => isset($product->image) ? $product->image : config('common.default_image'),
                'body_html' => $product->body_html,
                'source'  => $product->source,
                'source_product_link' => $product->source_product_link,
                'aliexpress_product_id' => $product->aliexpress_product_id,
                'supplier_id' => $product->supplier_id,
                'selected' => false,
                'custom_collection' => $product->custom_collection,
                'tag' => $product->tag,
                'options' => null,
                'auto_update_price' => ($product->auto_update_price == 1) ? true : false,
                'title_source' => $product->title_source,
                'country_shipping'=> $product->country_shipping,
                'price_range' => $product->price_range,
                'product_type' => $product->product_type,
                'shipTo'=>'',
                'price_shipping'=>0
            ];
            foreach ($product->productVariant as $variant)
            {
                $productObj[$k]['variants'][] = [
                    'id' => $variant->id,
                    'selected' => ($variant->selected == 1) ? true : false,
                    'aliexpress_options' => $variant->aliexpress_options,
                    'options' => json_decode($variant->options, true),
                    'image' => isset($variant->productImage) ? $variant->productImage->src : config('common.default_image'),
                    'image_id' => isset($variant->productImage) ? $variant->productImage->id : null,
                    'image_status' => ($variant->productImage && $variant->productImage->status == 1) ? true :  false,
                    'sku' => $variant->sku,
                    'cost' => $variant->source_price,
                    'price' => $variant->price,
                    'compare_at_price' => $variant->compare_at_price,
                    'source_price' => $variant->source_price,
                    'inventory_quantity' => $variant->source_quantity
                ];
            }
            $productObj[$k]['images'][] = [
                'id' => config('common.product_image_id_default'),
                'src' => isset($product->image) ? $product->image : config('common.default_image'),
                'status' => true,
                'in_variant' => false
            ];
            $productImages = $product->productImage->sortBy('sort');
            foreach ($productImages as $image)
            {
                $productObj[$k]['images'][] = [
                    'id' => $image->id,
                    'src' => $image->src,
                    'sort' => $image->sort,
                    'status' => ($image->status == 1) ? true : false,
                    'in_variant' => $image->in_variant
                ];
            }
        }
        return $productObj;
    }

    public function replicateImportProduct($id, $variant_ids = []) {
        // replicate product
        $importProduct = ImportProductModel::find($id);
        if(!$importProduct)
            return false;
        
        if(count($variant_ids) <= 0 || !is_array($variant_ids))
            return false;
        
        $replicateProduct = $importProduct->replicate();
        $replicateProduct->save();
        $imageIds = [];
        $images = $importProduct->productImage()->get();

        // replicate image and create array with key is old id and value is new id
        foreach($images as $image) {
            $replicateImage = $image->replicate();
            $replicateImage->product_id = $replicateProduct->id;
            $replicateImage->save();
            $imageIds[$image->id] = $replicateImage->id;
            unset($replicateImage);
        }

        // replicate variant,  change value of image_id
        $variants = $importProduct->productVariant()->get();
        foreach($variants as $variant) {
            $replicateVariant = $variant->replicate();
            $variant->selected = in_array($variant->id, $variant_ids) ? 0 : 1;
            $replicateVariant->selected = in_array($variant->id, $variant_ids) ? 1 : 0;
            if($variant->image_id && isset($imageIds[$variant->image_id])) {
                $replicateVariant->image_id = $imageIds[$variant->image_id];
            }
            $replicateVariant->product_id = $replicateProduct->id;
            $variant->save();
            $replicateVariant->save();
            unset($replicateVariant);
        }
        return true;
    }
}
