<?php

namespace App\Repository;


use App\Contracts\Repository\LineItemRepositoryInterface;
use App\Models\LineItemModel;
use App\Models\OrdersModel;
use App\Helpers\LineItemHelper;

class LineItemRepository implements LineItemRepositoryInterface
{
    private function filterModel($lineItem)
    {
        $lineItemModel = app(LineItemModel::class);
        $fillable = $lineItemModel->getFillable();
        return array_only($lineItem, $fillable);
    }

    public function getAttributes( array $data = [])
    {
        $lineItemInfo = LineItemModel::where( $data )->first();
        if($lineItemInfo)
            return $lineItemInfo;
        return false;
    }
    /**
     * @param string   $lineItemId
     * @param array $lineItem
     *
     * @return bool
     */
    public function update(string $lineItemId, array $lineItem): bool
    {
        $lineItemId = (double)$lineItemId;

        $lineItem = $this->filterModel($lineItem);

        $lineItemModel = LineItemModel::find($lineItemId);

        if( ! $lineItemModel)
            return false;


        foreach ($lineItem as $key => $value)
        {
            $lineItemModel->$key = $value;
        }

        if($lineItemModel->save())
            return true;

        return false;
    }

    /**
     * @param string $lineItemId
     *
     * @return bool
     */
    public function delete(string $lineItemId): bool
    {
        // TODO: Implement delete() method.
    }

    /**
     * @param string $lineItemId
     *
     * @return mixed
     */
    public function get(string $lineItemId)
    {
        return LineItemModel::find($lineItemId);
    }

    public function saveMany(string $orderId, array $lineItems): bool
    {
        // TODO: Implement saveMany() method.
    }

    public function save(string $orderId, array $lineItem): bool
    {
        $order = OrdersModel::find($orderId);

        if( ! $order)
            return false;
        
        $lineItemModel = $order->lineItem()->find($lineItem['id']);
//            ->where('id', $lineItem['id'])
//            ->where('orders_id', $orderId)->first();
        if($lineItemModel)
        {
            if( ! empty($lineItemModel->aliexpress_order_no))
                $lineItem['status'] = config('order.status.order_placed');

            if( ! empty($lineItemModel->tracking_code))
                $lineItem['status'] = config('order.status.shipped');

            if($lineItemModel->update($lineItem))
                return true;

            return false;
        }

        if($order->lineItem()->create($lineItem))
            return true;

        return false;
    }

    public function itemInOrder(string $orderId)
    {
        return LineItemModel::where('order_id', $orderId)->get();
    }

    /**
     * @param array $attr
     * @param array $value
     *
     * @return bool
     */
    public function updateByAttr(array $attr, array $value): bool
    {
        $lineItem = LineItemModel::where($attr);

        if( ! $lineItem->count())
            return false;

        if($lineItem->update($value))
            return true;

        return false;
    }

    /**
     * @param $trackingNumber
     * @param $lineItem
     *
     * @return mixed
     */
    public function updateTrackingCodeByOrder($trackingNumber, $lineItem )
    {
        foreach( $lineItem as $item )
        {
           $this->updateByAttr(['id' => $item->id],
               [
                    'tracking_code' => $trackingNumber,
                    'status'        => config('order.status.shipped'),
                    'fulfillment_status' => config('order.fulfillment_status.fulfilled')
               ]
           );
        }
        return true;
    }

    /**
     * @param array $orders
     * @return array|bool
     */
    public function getTrackingCodeNull(array $orders)
    {
        $lineItem = LineItemModel::select('aliexpress_order_no')
            ->whereIn('orders_id', $orders)
            ->where(function ($query) {
                $query->where('tracking_code', '')
                    ->orWhereNull('tracking_code');
            })->where(function ($query) {
                $query->where('aliexpress_order_no', '')
                    ->orWhereNotNull('aliexpress_order_no');
            })->groupBy('aliexpress_order_no')
            ->get();
        return $lineItem;
    }

    public function getLineItemTrackingCodeNull(array $orders)
    {
        $lineItem = LineItemModel::select('aliexpress_order_no', 'id', 'orders_id')
            ->whereIn('orders_id', $orders)
            ->where(function ($query) {
                $query->where('tracking_code', '')
                    ->orWhereNull('tracking_code');
            })->where(function ($query) {
                $query->where('aliexpress_order_no', '')
                    ->orWhereNotNull('aliexpress_order_no');
            })
            ->get();
        return $lineItem;
    }


    public function getAttr(array $args = [])
    {
        return  LineItemModel::where($args)->get();
    }

    public function updateTrackingCodeForOrderNo($order_id,$data)
    {
        foreach($data as $value)
        {
            $lineItem_order_no = LineItemModel::select('id')->where('orders_id',$order_id)->where('aliexpress_order_no',$value['aliexpress_order_number'])->get();
            
            foreach($lineItem_order_no as $key => $item)
            {
                if(isset($item['id']))
                {
                    $update_tracking_code = LineItemModel::where('id',$item['id'])->update(['tracking_code' => $value['tracking_code']]);
                }
            }
        }
    }
}

