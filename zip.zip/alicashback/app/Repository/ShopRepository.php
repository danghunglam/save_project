<?php
declare(strict_types=1);
namespace App\Repository;

use App\Contracts\Repository\ShopRepositoryInterface;
use App\Models\ShopModel;
use App\Models\ProductModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

/**
 * Class ShopsRepository
 * @package App\Repository
 */
class ShopRepository implements ShopRepositoryInterface
{
    /**
     *
     */
    public function all()
    {

    }
    
    /**
     * @return bool
     */
    public function delete(): bool
    {
        return true;
        // TODO: Implement delete() method.
    }

    /**
     * @param string $shopId
     * @return mixed
     */
    public function detail(string $shopId)
    {
        if($shopInfo = ShopModel::find($shopId))
            return $shopInfo;

        return false;
    }

    public function checkShopDomain($shopDomain)
    {
        return ShopModel::where('myshopify_domain', '=', $shopDomain)
            ->orWhere('domain', '=', $shopDomain)->first();
    }

    public function checkShopStatus($shopDomain)
    {
        return ShopModel::where('myshopify_domain', '=', $shopDomain)
            ->select('status')->first();
    }
    /**
     * @param array $data
     *
     * @return bool
     */
	public function getAttributes( array $data = [])
	{
		$shopInfo = ShopModel::where( $data )->first();
		if($shopInfo)
			return $shopInfo;
		return false;
    }
    
    /**
     * @param array $data
     *
     * @return bool
     */
	public function getAttributesWithMetas( array $data = [])
	{
		$shopInfo = ShopModel::where( $data )->with(['metas'])->first();
		if($shopInfo)
			return $shopInfo;
		return false;
    }
    
    public function getAttributesWithPlan( array $data = [] ) {
        $shopInfo = ShopModel::where( $data )->first();
        // $planName = $shopInfo->plan_name;
        // $plan = config('charged.plan');
		if($shopInfo)
			return $shopInfo;
		return false;
    }

    /**
     * @param string $shopId
     * @param array $data
     *
     * @return mixed
     */
    public function createOrUpdate(string $shopId, array $data = [])
    {
        $shopModel = new ShopModel();

        $filterData = array_only($data, $shopModel->getFillable());

        if($shop = $shopModel->find($shopId))
            return $shop->update($filterData);

        $filterData['id'] = $shopId;

        return $shopModel->firstOrCreate($filterData);
    }

    /**
     * @param array $find
     * @param array $data
     *
     * @return mixed
     */
    public function update(array $find = [], array $data = [])
    {
        $shopModel = new ShopModel();
        $update = $shopModel->where($find)->update($data);
        return $update;
    }

    /**
     * @param string $public_token
     * 
     * @return mixed
     */
    public function getShopId($public_token)
    {
        $shopId = ShopModel::where('public_token',$public_token)->select('id')->first();
        if($shopId)
            return $shopId;

        return false;
        
    }

    public function updateSingleTotalQuantityProduct($productId) {
        $product = ProductModel::find($productId);
        if(! $product) 
            return false;
        $product->total_quantity = $product->productVariant()->sum('source_quantity');
        return $product->save();
    }

    public function updateAllTotalQuantityProduct() {
        $queryUpdate = DB::table('product')
            ->join(DB::raw("(SELECT product_id, 
                                SUM(source_quantity) AS total_quantity
                            FROM product_variant
                            WHERE deleted_at IS NULL
                            GROUP BY product_id) product_variant_total"),
                            "product.id",
                            "product_variant_total.product_id");
        return $queryUpdate->update(['product.total_quantity' => DB::raw("product_variant_total.total_quantity")]);
    }

    public function checkLimitProduct($shopId) {
        $shopMetaRepo = app(ShopMetaRepository::class);
        $productHadLink = $shopMetaRepo->getProductHadLink($shopId);
        // check from shop plan
        return 5 - (int)$productHadLink;
    }

    public function checkLimitOrder($shopId) {
        $shopMetaRepo = app(ShopMetaRepository::class);
        $shopPlanInfo = []; // write service plan
        
        // check from shop plan
        return 5 - (int)$productHadLink;
    }

    public function serviceGetPlanInfo($shopId, $infoNeedGet = ['product', 'order']) {
        // get info shop
        $shop = ShopModel::find($shopId);
        if(!$shop)
            return false;

        $now = Carbon::now();
        
        if(!$shop->plan_start_at) {
            $shop->plan_start_at = $now;
            $shop->plan_end_at = $shop->plan_start_at->copy()->addDays(30);
            $shop->save();
        } elseif(Carbon::parse($shop->plan_end_at)->lt($now)) {
            $shop->plan_start_at = Carbon::parse($shop->plan_end_at)->copy()->addDays(1);
            $shop->plan_end_at = $shop->plan_start_at->copy()->addDays(30);
            $shop->save();
        }

        $plan_charge = config('charged.plan');
        if(!isset($plan_charge[$shop->plan_charge_name])) {
            $shop->plan_charge_name = 'basic';
            $shop->save();
        }
        $planInfo = [
            'plan' => [
                'shop_id' => $shop->id,
                'plan_charge_name' => $shop->plan_charge_name,
                'plan_start_at' => $shop->plan_start_at->format('Y-m-d'),
                'plan_end_at' => $shop->plan_end_at->format('Y-m-d')
            ],
            'plan_info' => $plan_charge[$shop->plan_charge_name]
        ];

        if(in_array('product', $infoNeedGet)) {
            $shopMetaRepo = app(ShopMetaRepository::class);
            $productHadLink = $shopMetaRepo->getProductHadLink($shop->id);
            $planInfo['product'] = [
                'current_product' => (int)$productHadLink,
                'limit_product' => $plan_charge[$shop->plan_charge_name]['products']
            ];
        }

        if(in_array('order', $infoNeedGet)) {
            $orderRepo = app(OrderRepository::class);
            $orderFulfillment = $orderRepo->orderHadFulfillment($shop->id, $shop->plan_start_at->format('Y-m-d h:i:s'));
            $planInfo['order'] = [
                'current_order' => $orderFulfillment,
                'limit_order' => $plan_charge[$shop->plan_charge_name]['orders']
            ];
        }

        return $planInfo;

    }
}