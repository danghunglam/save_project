<?php

namespace App\Repository;


use App\Contracts\Repository\StatisticRepositoryInterface;
use App\Contracts\Services\CurrencyRate;
use App\Helpers\Helpers;
use App\Models\ShopModel;
use Illuminate\Support\Facades\DB;

class StatisticRepository implements StatisticRepositoryInterface
{
    public function getTotalSummary($shop_id, $from, $to)
    {
        $shop = ShopModel::find($shop_id);
        $currency_rate = app(CurrencyRate::class);
        $totalRevenue = 0;
        $totalCost = 0;
        if(! $shop)
            return false;

        $order = $shop->order()->whereBetween(DB::raw('DATE(created_at)'),[$from, $to]);

        $totalOrder = $order->count();
        $orders = $order->whereIn('financial_status', [config('order.financial_status.paid'), config('order.financial_status.partially_paid')])
            ->get();
        foreach($orders as $order)
        {
            $revenue = $order->lineItem->sum(function ($row) use ($order, $currency_rate) {
                return $currency_rate->convertToUsd($row->price, $order->currency) * $row->quality;
            });

            $cost = $order->lineItem->sum(function($row) use ($order) {
                return $row->price_order_aliexpress + $row->fee_tax + $row->fee_ship;
            });

            $totalCost += $cost;
            $totalRevenue += $revenue;
        }

        return compact('totalOrder', 'totalCost', 'totalRevenue');
    }
}