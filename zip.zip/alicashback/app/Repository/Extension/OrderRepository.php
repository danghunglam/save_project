<?php

namespace App\Repository\Extension;


use App\Contracts\Repository\Extension\OrderRepositoryInterface;
use App\Repository\ShopRepository;

class OrderRepository implements OrderRepositoryInterface
{
    /**
     * @param array $data
     * @return bool
     */
    public function syncOrderNumberFromOberlo(array $data) : bool
    {
        $shopRepo = app(ShopRepository::class);
        $shop = $shopRepo->getAttributes(['public_token' => $data['public_token']]);
        if( ! $shop)
            return false;

        $data_orders = $data['orders'];
        foreach ($data_orders as $value)
        {
            $orders = $shop->order()->where(['order_name' => $value['shopify_order_name']])->first();

            if($orders)
            {
                //LineItem in database
                $lineItems = $orders->lineItem;

                //LineItem in param
                $orderItems = $value['orderItems'];
                $aliOrderNumber = [];
                foreach ($orderItems as $item)
                    $aliOrderNumber[$item['supplier_id']] = $item['ali_order_no'];

                foreach ($lineItems as $k => $lineItem) {
                    $obj = $lineItem->productVariant->supplier;
                    if($obj && empty($lineItem->aliexpress_order_no))
                    {
                        $dataUpdate = ['aliexpress_order_no' => isset($aliOrderNumber[$obj->id]) ? $aliOrderNumber[$obj->id] : null];
                        if($dataUpdate['aliexpress_order_no']) {
                            $dataUpdate['status'] = config('order.status.order_placed');
                        }
                        $lineItem->update($dataUpdate);
                    }
                }
            }
        }
        return true;
    }
}