<?php

namespace App\Repository\Extension;


use App\Contracts\Repository\Extension\ExtensionImportProductRepositoryInterface;
use App\Contracts\Services\CurrencyRate;
use App\Helpers\Helpers;
use App\Repository\ImportProductImageRepository;
use App\Repository\ImportProductVariantRepository;
use App\Repository\ImportProductRepository;
use App\Repository\SettingRepository;
use App\Repository\ShopRepository;
use App\Repository\SupplierRepository;
use App\Models\SettingModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ExtensionImportProductRepository implements ExtensionImportProductRepositoryInterface
{
    /**
     * Xử lý việc import 1 product
     * @param string $public_token
     * @param array $product
     * @param array $variants
     * @param array $images
     * @param array $supplier
     * @return array|\Illuminate\Http\JsonResponse|mixed
     */
    public function importProduct(string $public_token, array $product, array $variants, array $images, array $supplier)
    {
        if( ! $public_token)
            return ['status' => false, 'message' => 'Please login again '.env('APP_URL')];
        //Get shopId from publicToken
        $shopRepo = app(ShopRepository::class);
        $currency_rate = app(CurrencyRate::class);
        $shop = $shopRepo->getAttributes(['public_token' => $public_token]);
        if( ! $shop)
            return response()->json(['status' => false, 'message' => 'Shop not found']);

        $shopId = intval($shop->id);
        $isConvertCurrency = SettingModel::where('shop_id', $shopId)->where('key', 'is_convert_currency')->first();
        $isConvertCurrency = ($isConvertCurrency && $isConvertCurrency->value == "1") ? true : false;
        $currency = $isConvertCurrency ? $shop->currency : 'USD';
        $currencyExchange = $currency_rate->convertFromUsd(1, $currency);

        //Get setting
        $settingRepo = new SettingRepository($shopId);
        $auto_update_when_product_cost_change_aliexpress = $settingRepo->getKey('auto_update_when_product_cost_change_aliexpress');
        if( (!$auto_update_when_product_cost_change_aliexpress) || $auto_update_when_product_cost_change_aliexpress->value == config('setting.auto_update_when_product_cost_change_aliexpress.do_nothing'))
            $product['auto_update_price'] = config('product.auto_update_price.price_update_off');
        elseif( $auto_update_when_product_cost_change_aliexpress->value == config('setting.auto_update_when_product_cost_change_aliexpress.update_automatically'))
            $product['auto_update_price'] = config('product.auto_update_price.automatic_price_updates_on');

        if(isset($supplier['id']))
            $product['supplier_id'] = $supplier['id'];
        //Filter link aliexpress detail product link
        $product['source_product_link'] = isset($product['source_product_link']) ? Helpers::filterAliexpressDetailLink($product['source_product_link']) : null;
        $product['image'] = isset($product['product_image']) ? $product['product_image'] : config('common.default_image');
        //dhlam---------------------------------------
        $product['title_source'] = $product['title'];
        $product['price_range'] = json_encode(['minPrice'=>$product['minPrice'], 'maxPrice'=>$product['maxPrice']]) ;
        //endDhlam------------------------------------
        //Get price rule settings
        $settingRepo = new SettingRepository($shopId);
        $settings = $settingRepo->getObjAll();

        $priceRule = isset($settings['price_rule']) ? $settings['price_rule'] : config('setting_default.price_rule');
        $restPriceRule = isset($settings['rest_of_the_price_ranges']) ? $settings['rest_of_the_price_ranges'] : config('setting_default.rest_of_the_price_ranges');
        $isComparedPrice = isset($settings['is_compared_price']) ? $settings['is_compared_price'] : config('setting_default.is_compared_price');
        $centPrice = [
            'assign_cent_price_check' => isset($settings['assign_cent_price_check']) ?  $settings['assign_cent_price_check'] : config('setting_default.assign_cent_price_check'),
            'assign_cent_price' => isset($settings['assign_cent_price']) ? $settings['assign_cent_price'] : config('setting_default.assign_cent_price'),
            'assign_cent_compare_at_check' => isset($settings['assign_cent_compare_at_check']) ? $settings['assign_cent_compare_at_check'] : config('setting_default.assign_cent_compare_at_check'),
            'assign_cent_compare_at' => isset($settings['assign_cent_compare_at']) ? $settings['assign_cent_compare_at'] : config('setting_default.assign_cent_compare_at')
        ];

        $importProductRepo = app(ImportProductRepository::class);
        $importProductImageRepo = app(ImportProductImageRepository::class);
        $importProductVariantRepo = app(ImportProductVariantRepository::class);

        $supplierRepo = app(SupplierRepository::class);
        if(isset($supplier['id']))
            $supplierRepo->createOrUpdate($supplier['id'], $supplier);

        DB::beginTransaction();
        try{
            $createProduct = $importProductRepo->create($product, $shopId);

            if( ! $createProduct['status'])
            {
                DB::rollBack();
                return ['status' => false, 'message' => $createProduct['message']];
            }

            $createProduct = $createProduct['product'];

            $list_images = [];

            //Add images in variant
            $variantCount = 0;
            $sort = 0;
            foreach ($variants as $k => $variant)
            {
                if( ! $this->checkImageInList($list_images, $variant['image'])) {
                    $image = [
                        'src' => $variant['image'],
                        'status' => true,
                        'in_variant' => true,
                        'sort' => $sort
                    ];



                    if( ! $createProductImage = $importProductImageRepo->create($createProduct->id, $image))
                    {
                        DB::rollBack();
                        //delete product
                        return ['status' => false, 'message' => 'Import product image error'];
                    }
                    $sort++;

                    $lastProductImage = isset($createProductImage->id) ? $createProductImage->id :  null;
                    $list_images[] = [
                        'link' => $variant['image'],
                        'id' => $lastProductImage
                    ];
                } else {
                    $lastProductImage = $this->checkImageInList($list_images, $variant['image']);
                }

                $variant['options'] = json_encode($variant['options']);
                $variant['aliexpress_options'] = isset($variant['aliexpress_options']) ? $variant['aliexpress_options'] : 'fire_apps';
                //Set price and compare price in settings
                $variant['source_price'] = preg_replace('/\,/','', $variant['source_price']);

                $new_price = $this->setPrice($variant['source_price'], $priceRule, $restPriceRule, $isComparedPrice, $currencyExchange, $isConvertCurrency, $centPrice);
                $variant['price'] = $new_price['price'];
                if($isComparedPrice)
                    $variant['compare_at_price'] = $new_price['compare_at_price'];
                
                //Set selected variant
                if($variant['source_quantity'] > 0 && $variantCount < 100)
                {
                    $variant['selected'] = true;
                    $variantCount++;
                }


                if( ! $createProductVariant = $importProductVariantRepo->create($createProduct->id, $lastProductImage, $variant))
                {
                    DB::rollBack();
                    return ['status' => false, 'message' => 'Import product variant error'];
                }
            }

            //Add all images
            foreach ($images as $image)
            {
                $image['sort'] = $sort;
                $importProductImageRepo->create($createProduct->id, $image);
                $sort++;
            }

            DB::commit();
            return ['status' => true, 'product' => $createProduct->id, 'return_url' => url('import')];
        } catch (\Exception $exception)
        {
            DB::rollBack();
            return ['status' => false, 'message' => $exception->getMessage()];
        }

    }

    /**
     * Set price and compare price
     * @param $sourcePrice
     * @param $priceRule
     * @param $restPriceRule
     * @param $isComparedPrice
     * @param $currencyExchange
     * @param $isConvertCurrency
     * @param array $centPrice
     *
     * @return array
     */
    public function setPrice($sourcePrice, $priceRule, $restPriceRule, $isComparedPrice, $currencyExchange, $isConvertCurrency, array $centPrice)
    {
        $flag = false;


        $newPrice['source_price'] = $sourcePrice;

        if(is_array($priceRule))
        {
            foreach ($priceRule as $price)
            {
                $item_price_type = (isset($price['item_price_type']) && in_array($price['item_price_type'], ['multiply', 'plus'])) ? $price['item_price_type'] : 'multiply';
                $compared_price_type = (isset($price['compared_price_type']) && in_array($price['compared_price_type'], ['multiply', 'plus'])) ? $price['compared_price_type'] : 'multiply';

                if($sourcePrice >= $price['min'] && $sourcePrice <= $price['max'])
                {
                    if($item_price_type === 'multiply')
                        $newPrice['price'] =  $sourcePrice * $price['item_price'];
                    elseif($item_price_type === 'plus')
                        $newPrice['price'] =  $sourcePrice + $price['item_price'];
                    if($isComparedPrice) {
                        if($compared_price_type === 'multiply')
                            $newPrice['compare_at_price'] = $sourcePrice * $price['compared_price'];
                        elseif($compared_price_type === 'plus')
                            $newPrice['compare_at_price'] = $sourcePrice + $price['compared_price'];
                    }

                    $flag = true;
                }
            }
        }

        if(is_array($restPriceRule))
        {
            if( ! $flag)
            {
                $rest_item_price_type = (isset($restPriceRule['item_price_type']) && in_array($restPriceRule['item_price_type'], ['multiply', 'plus'])) ? $restPriceRule['item_price_type'] : 'multiply';
                $rest_compared_price_type = (isset($restPriceRule['compared_price_type']) && in_array($restPriceRule['compared_price_type'], ['multiply', 'plus'])) ? $restPriceRule['compared_price_type'] : 'multiply';

                if($rest_item_price_type === 'multiply')
                    $newPrice['price'] =  $sourcePrice * $restPriceRule['item_price'];
                elseif($rest_item_price_type === 'plus')
                    $newPrice['price'] =  $sourcePrice + $restPriceRule['item_price'];

                if($isComparedPrice)
                {
                    if($rest_compared_price_type === 'multiply')
                        $newPrice['compare_at_price'] = $sourcePrice * $restPriceRule['compared_price'];
                    elseif($rest_compared_price_type === 'plus')
                        $newPrice['compare_at_price'] = $sourcePrice + $restPriceRule['compared_price'];
                }

            }
        }

        //currency convert
        if(isset($newPrice['price'])) {
            if($isConvertCurrency) {
                $newPrice['price'] = $newPrice['price'] * $currencyExchange;
            } else {
                $newPrice['price'] = $newPrice['price'];
            }
        }

        if(isset($newPrice['compare_at_price'])) {
            if($isConvertCurrency) {
                $newPrice['compare_at_price'] = $newPrice['compare_at_price'] * $currencyExchange;
            } else {
                $newPrice['compare_at_price'] = $newPrice['compare_at_price'];
            }
        }

        //rounding cent
        if($centPrice['assign_cent_price_check']) {
            $arg = explode('.', $newPrice['price']);
            $assign_cent_price = ((int)$centPrice['assign_cent_price'] < 10) ? '0'.(int)$centPrice['assign_cent_price'] : $centPrice['assign_cent_price'];
            $newPrice['price'] = $arg[0].'.'.$assign_cent_price;
        }
        if($centPrice['assign_cent_compare_at_check'] && $isComparedPrice)
        {
            $arg = explode('.', $newPrice['compare_at_price']);
            $assign_cent_compare_at = ((int)$centPrice['assign_cent_compare_at'] < 10) ? '0'.(int)$centPrice['assign_cent_compare_at'] : $centPrice['assign_cent_compare_at'];
            $newPrice['compare_at_price'] =  $arg[0].'.'.$assign_cent_compare_at;
        }

//        Log::info($newPrice);

        return $newPrice;
    }




    /**
     * Xử lý việc xóa sản phẩm
     *
     * @param int $product_id
     * @param string $public_token
     * @return array
     */
    public function deleteProduct(int $product_id, string $public_token) : array
    {
        $shopRepo = app(ShopRepository::class);
        if( ! $shop = $shopRepo->getAttributes(['public_token' => $public_token]))
            return ['status' => false, 'message' => 'Shop not exist'];

        if($shop->importProduct()->where('id', $product_id)->delete())
            return ['status' => true, 'message' => 'Deleted success'];

        return ['status' => false, 'message' => 'Delete error'];
    }


    private function checkImageInList($list, $link)
    {
        foreach($list as $item) {
            if($link ==  $item['link'])
                return $item['id'];
        }
        return false;
    }
}