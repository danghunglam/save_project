<?php
declare(strict_types=1);
namespace App\Repository\Extension;

use App\Models\ProductModel;
use App\Models\ShopModel;

class ProductRepository
{
    /**
     * @param string $productId
     * @param string $myShopifyDomain
     * @param array  $args
     *
     * @return array
     */
    public function update(string $productId, string $myShopifyDomain, array $args = [])
    {
        $productModel = new ProductModel();
        $filterArgs = array_only($args, $productModel->getFillable());
        $shop = ShopModel::where('myshopify_domain', $myShopifyDomain)->first();

        //Check shop exist
        if( ! $shop)
            return ['status' => false, 'message' => 'Cannot find Shop'];


        if($product = $shop->product()->where('id', $productId))
        {
            if($product->update($filterArgs))
                return ['status' => true, 'message' => 'Update success'];

            return ['status' => false, 'message' => 'Update error'];
        }

        return ['status' => false, 'message' => 'Cannot find product Id '. $productId];
    }
}