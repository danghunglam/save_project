<?php

namespace App\Repository;


use App\Contracts\Repository\ProductImageRepositoryInterface;
use App\Models\ProductImageModel;
use App\Models\ProductModel;

class ProductImageRepository implements ProductImageRepositoryInterface
{
    public function all(array $field, array $filters, int $limit)
    {
        // TODO: Implement all() method.
    }

    public function delete(string $productId): bool
    {
        $product = ProductModel::find($productId);
        if( ! $product)
            return false;

        foreach ($variantHasOrder as $value)
        {
            if($variant = ProductModel::withTrashed()->find($value->id))
            {
                $variant->forceDelete();
            }
        }
        return true;
    }

    public function detail(string $productId, array $field = [])
    {
        // TODO: Implement detail() method.
    }

    /**
     * @param string $productId
     * @param array  $args
     *
     * @return bool
     */
    public function create(string $productId, array $args = []): bool
    {
        $product = ProductModel::find($productId);
        if( ! $product)
            return false;

        if($product->productImage()->create($args))
            return true;

        return false;
    }


    /**
     * @param string $productId
     * @param array  $args
     *
     * @return bool
     */
    public function saveMany(string $productId, array $args = []): bool
    {
        $product = ProductModel::find($productId);
        if( ! $product)
            return false;

        $arrID = array();
        foreach ($args as $k => $arg)
        {
            if (in_array($arg['id'], $arrID)) {
                unset($args[$k]);
                continue;
            } else {
                $arrID[] = $arg['id'];
            }
            if ($productImageModel = $product->productImage()->withTrashed()->find($arg['id']))
            {
                $arg['sort'] = $arg['position'];
                unset($args[$k]);
                $productImageModel->restore();
                $productImageModel->update($arg);
            }
        }

        if($product->productImage()->createMany($args))
            return true;

        return false;
    }
    public function update(string $productId, array $arg = []): bool
    {
         $productImage = ProductImageModel::find($productId);
         if( ! $productImage)
             return false;

         if($productImage->update($arg))
             return true;

         return false;
    }

    /**
     * @param $productId
     *
     * @return mixed
     */
    public function deleteByProductId($productId)
    {
        return ProductImageModel::where(['product_id' => $productId ])->delete();
    }
}