<?php

namespace App\Repository;


use App\Models\ImportProductImageModel;
use App\Models\ImportProductModel;

class ImportProductImageRepository
{
    /**
     * @param       $productId
     * @param array $productImageArg
     *
     * @return bool
     */
    public function create($productId, array $productImageArg = [])
    {
        $productModel = ImportProductModel::find($productId);
        if( ! $productModel)
            return false;

        if($productImage = $productModel->productImage()->create($productImageArg))
            return $productImage;

        return false;
    }

    /**
     * @param string $productImageId
     * @param array  $arg
     *
     * @return bool
     */
    public function update(string $productImageId, array $arg = []): bool
    {
        $productImage = ImportProductImageModel::find($productImageId);
        if( ! $productImage)
            return false;

        if($productImage->update($arg))
            return true;

        return false;
    }

    /**
     * @param $productImageId
     *
     * @return bool
     */
    public function delete($productImageId)
    {
        $productImageModel = ImportProductImageModel::find($productImageId);
        if( ! $productImageModel)
            return false;

        if( ! $productImageModel->delete())
            return false;

        return true;
    }
}