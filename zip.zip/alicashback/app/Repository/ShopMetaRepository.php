<?php
declare(strict_types=1);
namespace App\Repository;


use App\Models\ShopMetaModel;
use App\Contracts\Repository\ShopMetaRepositoryInterface;
use Illuminate\Support\Facades\Lang;
use App\Repository\ProductRepository;

/**
 * Class ShopMetaRepository
 * @package App\Repository
 */
class ShopMetaRepository implements ShopMetaRepositoryInterface {
	/**
	 * @var \Illuminate\Foundation\Application|mixed
	 */
	private $_model;

	/**
	 * ShopMetaRepository constructor.
	 */
	function __construct() {
		$this->_model = new ShopMetaModel();
	}

	/**
	 * Get shop meta detail by shop_id
	 *
	 * @param $shop_id
	 *
	 * @return \Illuminate\Database\Eloquent\Model|null|static
	 */
	public function detail( $shop_id ) {
		return $this->_model->where( 'shop_id', $shop_id )->first();
	}

    /**
     * Get shop meta by shopId and key input
     */

    public function findWithKey($shopId, string $key)
    {
        return $this->_model->where( 'shop_id', $shopId )->where('key', $key)->first();
    }

    /**
     * Insert data
     *
     * @param $data
     *
     * @return mixed
     */

    public function createOrUpdate(array $data = [])
    {
        $filterData = array_only($data, $this->_model->getFillable());

        if(isset($data['id']) && $shop = $this->_model->find($data['id']))
            return $shop->update($filterData);

        return $this->_model->firstOrCreate($filterData);
    }

	/**
	 * Convert data from form to db
	 *
	 * @param $data
	 *
	 * @return mixed
	 */
	public function convertDataImport( $data ) {
		if(!empty($data['setting']) && is_array($data['setting'])){
			$data['setting'] = json_encode($data['setting']);
		}

		if(!empty($data['translate']) && is_array($data['translate'])){
			$data['translate'] = json_encode($data['translate']);
		}

		if(!isset($data['approve_review'])){
			$data['approve_review'] = 0;
		}

		return $data;
	}

	/**
	 * Create shop meta
	 *
	 * @param array $data
	 *
	 * @return array
	 */
	public function create( array $data = array() ) {
		$result = array(
			'status'  => false,
			'message' => Lang::get( 'settings.failed' ),
		);
		if(isset($data['shop_id' ]) and $this->_model->find($data['shop_id']))
		    return $result;

		$data_save = $this->convertDataImport( $data );
		$insert    = $this->_model->create( $data_save );
		if ( $insert ) {
			$result = array(
				'status'  => true,
				'message' => Lang::get( 'settings.create_success' ),
			);
		}

		return $result;
	}
	
	public function incrementLimitProduct($shop_id) {
		$meta = $this->_model->where([
			'shop_id' => $shop_id,
			'key' => config('shopify.product_had_link')
		])->first();
		if($meta) {
			return $meta->increment('value');
		} else {
			$productRep = new ProductRepository($shop_id);
			$numberProductAfterPricing = $productRep->numberProductAfterPricing();
			if($numberProductAfterPricing) {
				$this->_model->create([
					'shop_id' => $shop_id,
					'key' => config('shopify.product_had_link'),
					'value' => $numberProductAfterPricing + 1
				]);
			}
		}
		return false;
	}

	public function getProductHadLink($shop_id) {
		$meta = $this->findWithKey($shop_id, config('shopify.product_had_link'));
		if($meta) {
			return $meta->value;
		}
		$productRep = new ProductRepository($shop_id);
		$numberProductAfterPricing = $productRep->numberProductAfterPricing();
		$this->_model->create([
			'shop_id' => $shop_id,
			'key' => config('shopify.product_had_link'),
			'value' => $numberProductAfterPricing
		]);
		return $numberProductAfterPricing;
	}


	/**
	 * Update shop meta
	 *
	 * @param int $shop_id
	 * @param array $data
	 *
	 * @return array
	 */
	public function update( $shop_id, array $data = array() ) {
		$result = array(
			'status'  => false,
			'message' => Lang::get( 'settings.failed' ),
		);
		$data_save = $this->convertDataImport( $data );

		$settings = $this->_model->find($shop_id);
		if ( $settings ) {

			$save = $settings->update( $data_save );

			if ( $save ) {
				$result = array(
					'status'  => true,
					'message' => Lang::get( 'settings.update_success' ),
				);
			}
		}

		return $result;
	}
}