<?php

namespace App\Repository;


use App\Contracts\Repository\OrderRepositoryInterface;
use App\Models\OrdersModel;
use App\Models\ShopModel;
use App\Models\LineItemModel;
use App\Models\OrderFulfillment;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\ShopifyApi\OrdersApi;
use App\ShopifyApi\FulfillmentServiceApi;
use App\ShopifyApi\FulfillmentApi;
use App\Repository\ShopRepository;

class OrderRepository implements OrderRepositoryInterface
{
    /**
     * @param string $shopId
     * @param array  $order
     *
     * @return mixed
     */
    public function save(string $shopId, array $order): bool
    {
        $shop = ShopModel::find($shopId);
        if( ! $shop)
            return false;

        if($orderModel = $shop->order()->withTrashed()->find($order['id']))
        {
            if($orderModel->update($order))
                return true;

            return false;
        }

        if($shop->order()->create($order))
            return true;

        return false;
    }

    /**
     * @param string $shopId
     * @param array  $orders
     *
     * @return bool
     */
    public function saveMany(string $shopId, array $orders): bool
    {
        // TODO: Implement saveMany() method.
    }

    /**
     * @param string $orderId
     * @param array  $order
     *
     * @return bool
     */
    public function update(string $orderId, array $order): bool
    {
        $orderModel = OrdersModel::find($orderId);

        //Filters orderModel fillable
        $order = array_only($order, $orderModel->getFillable());
        if( ! $orderModel)
            return false;

        foreach ($order as $key => $value)
        {
            $orderModel->$key = $value;
        }

        if($orderModel->save())
            return true;

        return false;
    }


    private function queryFilter(float $shopId, array $filters = [], string $orderBy = '')
    {
        $shop = ShopModel::find($shopId);
        if( ! $shop)
            return false;
        $orderModel = $shop->order();
        $orderModel->select('orders.*', DB::raw('sum(line_item.quality*line_item.price) as total_price_order'));
        $orderModel->with([
                    'lineItem.productVariant' => function ($query) {
                        $query->orderBy('supplier_id')->orderBy('aliexpress_options');
                    },
                    'lineItem.productVariant.productImage', 
                    'lineItem.productVariant.product', 
                    'lineItem.productVariant.supplier']);

        $orderModel->join('line_item', 'orders.id', '=', 'line_item.orders_id');
        $orderModel->join('product_variant', 'line_item.product_variant_id', '=', 'product_variant.id');
        $orderModel->join('product', 'product_variant.product_id', '=', 'product.id');
        $orderModel->leftjoin('supplier', 'product.supplier_id', '=', 'supplier.id');

        if(!empty($filters['keyword']) && $filters['keyword'] !== '')
        {
            $orderModel->where(function ($query) use ($filters) {
                $query->where('orders.order_number', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.order_name', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.first_name', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.last_name', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere(DB::raw('"?"',$filters['keyword']), 'like', DB::raw('CONCAT("%", orders.first_name, " ", orders.last_name, "%")'));
                $query->orWhere('orders.phone', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.email', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('line_item.aliexpress_order_no', $filters['keyword']);
                $query->orWhere('line_item.tracking_code', $filters['keyword']);
                $query->orWhere('product_variant.title', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('product.title', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('supplier.name', 'like', '%'.$filters['keyword'].'%');
            });
        } 
        
        if(!empty($filters['filter_date_from']) && $filters['filter_date_to'] != '')
        {
            $filters['filter_date_from'] = date('Y-m-d H:i:s', strtotime($filters['filter_date_from']));
            $filters['filter_date_to'] = date('Y-m-d H:i:s', strtotime($filters['filter_date_to'].'+ 24 hour'));
            $orderModel->whereBetween(DB::raw('date(orders.created_at)'), [$filters['filter_date_from'], $filters['filter_date_to']]);
        }

        if(!empty($filters['flag']) && $filters['flag'][0])
        {
            $orderModel->whereIn('flag', $filters['flag']);
        }

        $orderModel->groupBy('orders.id');

        if($orderBy !== '') {
            $orderModel->orderBy('orders.created_at', $orderBy);
        } else {
            $orderModel->orderBy('orders.created_at','desc');
        }
     
        return $orderModel;
    }

    // filter and count status
    public function queryFilterAndGroupStatus(int $shopId, array $filters = [])
    {
        $shop = ShopModel::find($shopId);
        if( ! $shop)
            return false;
        
        $orderModel = $shop->order();
        $orderModel->select('line_item.status', DB::raw('count(distinct orders.id) as total_order'));

        $orderModel->join('line_item', 'orders.id', '=', 'line_item.orders_id');
        $orderModel->join('product_variant', 'line_item.product_variant_id', '=', 'product_variant.id');
        $orderModel->join('product', 'product_variant.product_id', '=', 'product.id');
        $orderModel->leftjoin('supplier', 'product.supplier_id', '=', 'supplier.id');

        if(!empty($filters['keyword']) && $filters['keyword'] !== '')
        {
            $orderModel->where(function ($query) use ($filters) {
                $query->where('orders.order_number', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.order_name', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.first_name', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.last_name', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere(DB::raw('"?"', $filters['keyword']), 'like', DB::raw('CONCAT("%", orders.first_name, " ", orders.last_name, "%")'));
                $query->orWhere('orders.phone', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.email', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('line_item.aliexpress_order_no', $filters['keyword']);
                $query->orWhere('line_item.tracking_code', $filters['keyword']);
                $query->orWhere('product_variant.title', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('product.title', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('supplier.name', 'like', '%'.$filters['keyword'].'%');
            });
        }
        
        if(!empty($filters['filter_date_from']) && $filters['filter_date_to'] != '')
        {
            $filters['filter_date_from'] = date('Y-m-d H:i:s', strtotime($filters['filter_date_from']));
            $filters['filter_date_to'] = date('Y-m-d H:i:s', strtotime($filters['filter_date_to'].'+ 24 hour'));
            $orderModel->whereBetween('orders.created_at', [$filters['filter_date_from'], $filters['filter_date_to']]);
        }

        if(!empty($filters['financial_status']) && is_array($filters['financial_status']))
        {
            $orderModel->whereIn('orders.financial_status', $filters['financial_status']);
        }

        if(!empty($filters['fulfillment_status']) && $filters['fulfillment_status'] !== '')
        {
            $orderModel->whereIn('orders.fulfillment_status', $filters['fulfillment_status']);
            $orderModel->whereHas('lineItem', function ($query) use ($filters) {
                $query->whereIn('orders.fulfillment_status', $filters['fulfillment_status']);
            });
        }

        if(!empty($filters['flag']) && $filters['flag'][0])
        {
            $orderModel->whereIn('flag', $filters['flag']);
        }

        $orderModel->groupBy('line_item.status');
     
        return $orderModel->get();
    }

    public function queryFilterAndAllStatus(int $shopId, array $filters = [])
    {
        $shop = ShopModel::find($shopId);
        if( ! $shop)
            return false;
        
        $orderModel = $shop->order();
        $orderModel->select(DB::raw('count(distinct orders.id) as total_order'));

        $orderModel->join('line_item', 'orders.id', '=', 'line_item.orders_id');
        $orderModel->join('product_variant', 'line_item.product_variant_id', '=', 'product_variant.id');
        $orderModel->join('product', 'product_variant.product_id', '=', 'product.id');
        $orderModel->leftjoin('supplier', 'product.supplier_id', '=', 'supplier.id');
        $orderModel->whereIn('line_item.status', [1, 2, 3]);
        if(!empty($filters['keyword']) && $filters['keyword'] !== '')
        {
            $orderModel->where(function ($query) use ($filters) {
                $query->where('orders.order_number', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.order_name', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.first_name', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.last_name', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere(DB::raw('"?"',  $filters['keyword']), 'like', DB::raw('CONCAT("%", orders.first_name, " ", orders.last_name, "%")'));
                $query->orWhere('orders.phone', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('orders.email', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('line_item.aliexpress_order_no', $filters['keyword']);
                $query->orWhere('line_item.tracking_code', $filters['keyword']);
                $query->orWhere('product_variant.title', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('product.title', 'like', '%'.$filters['keyword'].'%');
                $query->orWhere('supplier.name', 'like', '%'.$filters['keyword'].'%');
            });
        }
        
        if(!empty($filters['financial_status']) && is_array($filters['financial_status']))
        {
            $orderModel->whereIn('orders.financial_status', $filters['financial_status']);
        }

        if(!empty($filters['fulfillment_status']) && $filters['fulfillment_status'] !== '')
        {
            $orderModel->whereIn('orders.fulfillment_status', $filters['fulfillment_status']);
            $orderModel->whereHas('lineItem', function ($query) use ($filters) {
                $query->whereIn('orders.fulfillment_status', $filters['fulfillment_status']);
            });
        }
        
        if(!empty($filters['filter_date_from']) && $filters['filter_date_to'] != '')
        {
            $filters['filter_date_from'] = date('Y-m-d H:i:s', strtotime($filters['filter_date_from']));
            $filters['filter_date_to'] = date('Y-m-d H:i:s', strtotime($filters['filter_date_to'].'+ 24 hour'));
            $orderModel->whereBetween('orders.created_at', [$filters['filter_date_from'], $filters['filter_date_to']]);
        }

        if(!empty($filters['flag']) && $filters['flag'][0])
        {
            $orderModel->whereIn('flag', $filters['flag']);
        }
     
        return $orderModel->first();
    }

    /**
     * @param string $shopId
     * @param $paginate
     * @param $filters
     * @param $paged
     *
     * @return bool
     */

    public function trackingCode(string $shopId, array $filters = [], int $paginate = 0, int $paged = 1){

        $order = $this->queryFilter($shopId, $filters);
        if( ! $order)
            return false;

        if( ! empty($filters['ali_order_no']) && $filters['ali_order_no'] == 2 ){

            $order->whereHas('lineItem', function ($query) use ($filters) {
                $query->whereNotNull('line_item.aliexpress_order_no');
                $query->Where('line_item.aliexpress_order_no','<>', '');
            });
        }

        if( ! empty($filters['ali_order_no']) && $filters['ali_order_no'] == 3 ){

            $order->whereHas('lineItem', function ($query) use ($filters) {
                $query->whereNull('line_item.aliexpress_order_no');
                $query->orWhere('line_item.aliexpress_order_no', '');
            });
        }

        if( ! empty($filters['tracking_code']) && $filters['tracking_code'] == 2 ){
            $order->whereHas('lineItem', function ($query) use ($filters) {
                $query->whereNotNull('line_item.tracking_code');
                $query->Where('line_item.tracking_code', '<>' , '');
            });
        }

        if( ! empty($filters['tracking_code']) && $filters['tracking_code'] == 3 ){
            $order->whereHas('lineItem', function ($query) use ($filters) {
                $query->whereNull('line_item.tracking_code');
                $query->orWhere('line_item.aliexpress_order_no', '');
            });
        }

        if( ! empty($filters['sort_by']) && $filters['sort_by'] == 2 ){

            $order->orderBy('orders.created_at','asc');
        }

        Paginator::currentPageResolver(function () use ($paged) {
            return $paged;
        });

        if($paginate > 0)
            return $order->paginate($paginate);
        else
            return $order->get();
    }

    /**
     * @param string $shopId
     * @param $paginate
     * @param $filters
     * @param $paged
     *
     * @return bool
     */
    public function all(string $shopId, array $filters = [], int $paginate = 0, int $paged = 1)
    {
        $shopId = (float)$shopId;
        $orderModel = $this->queryFilter($shopId, $filters);
        if( ! $orderModel)
            return false;

        if(!empty($filters['financial_status']) && is_array($filters['financial_status']))
        {
            $orderModel->whereIn('orders.financial_status', $filters['financial_status']);
        }

        if(!empty($filters['fulfillment_status']) && $filters['fulfillment_status'] !== '')
        {
            $orderModel->whereIn('orders.fulfillment_status', $filters['fulfillment_status']);
            $orderModel->whereHas('lineItem', function ($query) use ($filters) {
                $query->whereIn('orders.fulfillment_status', $filters['fulfillment_status']);
            });
        }

        if(!empty($filters['status']) && is_array($filters['status']))
        {
            $orderModel->whereHas('lineItem', function ($query) use ($filters) {
                $query->whereIn('status', $filters['status']);
            });
        }

        $orderModel->orderBy('orders.id', 'DESC');

        Paginator::currentPageResolver(function () use ($paged) {
            return $paged;
        });
        
        if($paginate > 0)
            return $orderModel->paginate($paginate);
        else
            return $orderModel->get();
    }

    /**
     * @param int $shopId
     * @param array $filters
     * @param int $currentPage
     *
     * @return mixed
     */
    public function allOrderPlace(int $shopId, int $currentPage = 0, array $filters = [])
    {
        $pagination = config('common.paginate_default');

        $order = $this->queryFilter($shopId, $filters, 'ASC');

        $order->where('financial_status' , config('order.financial_status.paid'));
        $order->with(['lineItem' => function ($query) {

            $query->where(function ($q) {
                $q->where('line_item.status', config('order.status.to_order'));
//                $q->where('line_item.fulfillment_status', config('order.fulfillment_status.null'));
//                $q->orWhere('line_item.fulfillment_status', null);
                $q->where('line_item.aliexpress_order_no',null);
                $q->orWhere('line_item.aliexpress_order_no','');
                $q->where('line_item.tracking_code',null);
                $q->orWhere('line_item.tracking_code','');
            });

            $query->whereHas('productVariant', function($q) {
                $q->where('product_variant.aliexpress_options', '!=', '')
                    ->where('product_variant.aliexpress_options', '!=', null)
                    ->where('product_variant.source_product_link', '!=', '')
                    ->where('product_variant.source_product_link', '!=', null);
            });
        }]);

        if(!empty($filters['status']) && is_array($filters['status']))
        {
            $order->whereHas('lineItem', function ($query) use ($filters) {
                $query->whereIn('status', $filters['status']);
            });
        }

        if($currentPage > 0)
        {
            $skip = $currentPage * $pagination -  $pagination;
            $take = $currentPage * $pagination - $skip;
            $order->skip($skip)->take($take);
        }

        $orders = $order->get();
        return $orders;
    }

    /**
     * @param string $orderId
     *
     * @return bool
     */
    public function delete(string $orderId): bool
    {
        $order = OrdersModel::find($orderId);
        if( ! $order)
            return false;
        return $order->delete();
    }

    /**
     * @param string $orderId
     *
     * @return mixed
     */
    public function get(string $orderId)
    {
        return OrdersModel::find($orderId);
    }


    /**
     * @param string $shopId
     *
     * @return bool
     */
    public function getOrderId($shopId)
    {
        $shop = ShopModel::find($shopId);
        if( ! $shop)
            return false;

        $orders = $shop->order()->get(['id']);
        return $orders->toArray();
    }

    /**
     *@param array $args
     *@return mixed; 
     */
    public function getAttr(array $args = [])
    {
        return  OrdersModel::where($args)->get();
    }

    public function restore(string $orderId)
    {
        $order = OrdersModel::withTrashed()->find($orderId);
        if( ! $order)
            return false;
        return $order->restore();
    }

    // Need refactor
    public function getFulfillLocationId($myshopify_domain, $access_token, $orderId, $lineItemId) {
        $shopRepository = new ShopRepository();
        $shop = $shopRepository->getAttributes(['myshopify_domain' => $myshopify_domain]);
        if(!$shop)
            return false;
        $ordersApi = new OrdersApi($myshopify_domain, $access_token);
        $fulfillmentServiceApi = new FulfillmentServiceApi($myshopify_domain, $access_token);

        $orderDetail = $ordersApi->detail($orderId, ['line_items']);
        if(!$orderDetail['status']) {
            $primary_location_id = $shop->primary_location_id;
        } else {
            $orderLineItems = $orderDetail['data']->order->line_items;
            $fulfillment_service_name = null;
            foreach($orderLineItems as $orderLineItem) {
                if($orderLineItem->id == $lineItemId) {
                    if($orderLineItem->fulfillment_service != 'manual') {
                        $fulfillment_service_name = $orderLineItem->fulfillment_service;
                    }
                }
            }
            if($fulfillment_service_name) {
                $fulfillmentServices = $fulfillmentServiceApi->getAll(['scope' => 'all']);
                if(!$fulfillmentServices['status']) {
                    $primary_location_id = $shop->primary_location_id;
                } else {
                    $fulfillmentServices = $fulfillmentServices['data']->fulfillment_services;
                    $primary_location_id = $shop->primary_location_id;
                    foreach($fulfillmentServices as $fulfillmentService) {
                        if($fulfillmentService->handle == $fulfillment_service_name) {
                            $primary_location_id = $fulfillmentService->location_id;
                        }
                    }
                }
            } else {
                $primary_location_id = $shop->primary_location_id;
            }
        }
        return $primary_location_id;
    }

    public function fulFillmentMultipleLineItem($myshopify_domain, $access_token, $orderId, $fulfillment, $lineItemsId) {
        $fulfillmentApi = new FulfillmentApi($myshopify_domain, $access_token);
        $ordersApi = new OrdersApi($myshopify_domain, $access_token);
        $shopRepo = new ShopRepository();
        $shop = $shopRepo->getAttributes(['myshopify_domain' => $myshopify_domain]);
        if(!$shop)
            return false;

        // 1st: Get and group line_item by fulfillment_serivice
        $order =  $ordersApi->getOrder($orderId);
        $location_id = $shop->primary_location_id; // need replace
        if($order['status']) {
            $orderObject = $order['data']->order;
            $lineItems = $orderObject->line_items;
            $groupFulfillmentSerice = [];
            foreach($lineItems as $lineItem) {
                // Need if to check
                if(in_array($lineItem->id, $lineItemsId)) {
                    if(!isset($groupFulfillmentSerice[$lineItem->fulfillment_service])) {
                        $groupFulfillmentSerice[$lineItem->fulfillment_service] = [
                            'line_items' => [
                                [
                                    'id' => $lineItem->id
                                ]
                            ]
                        ];
                    } else {
                        $groupFulfillmentSerice[$lineItem->fulfillment_service]['line_items'][] = ['id' => $lineItem->id];
                    }
                    $groupFulfillmentSerice[$lineItem->fulfillment_service]['location_id'] = $location_id;
                }
                
                // End if check
            }
        } else {
            return false;
        }
        
        // 2nd: Get location for fulfillment
        $fulfillmentServiceApi = new FulfillmentServiceApi($myshopify_domain, $access_token);
        $fulfillmentServices = $fulfillmentServiceApi->getAll(['scope' => 'all']);
        if(!$fulfillmentServices['status']) {
            $location_id = $shop->primary_location_id;
        } else {
            $fulfillmentServices = $fulfillmentServices['data']->fulfillment_services;
            foreach($groupFulfillmentSerice as $serviceName => $serviceData) {
                $groupFulfillmentSerice[$serviceName]['location_id'] = $location_id;
                foreach($fulfillmentServices as $fulfillmentService) {
                    if($fulfillmentService->handle == $serviceName) {
                        $groupFulfillmentSerice[$serviceName]['location_id'] = $fulfillmentService->location_id;
                        break;
                    }
                }
                
            }
        }
        // 3rd: Create full fillment
        foreach($groupFulfillmentSerice as $serviceName => $serviceData) {
            // Create data for _fulfillment
            $fulfillmentData = $fulfillment;
            $fulfillmentData['line_items'] = $serviceData['line_items'];
            $fulfillmentData['location_id'] = $serviceData['location_id'];
            $isUpdateFulfillment = $fulfillmentApi->create($orderId, $fulfillmentData);
            // update status fulfillment if current status is pending and use fulfill service
            if($fulfillmentData['location_id'] != $shop->primary_location_id && $isUpdateFulfillment['status']) {
                if(isset($isUpdateFulfillment['data']->fulfillment)) {
                    $fulfillmentFromSpf = $isUpdateFulfillment['data']->fulfillment;
                    if($fulfillmentFromSpf->status == 'pending') {
                        $fulfillmentApi->complete($orderId, $fulfillmentFromSpf->id);
                    }
                }
            }
            //
            sleep(3);
        }
    }

    public function countWrongFulfillment($shopId, $limit) {
        $shop = ShopModel::find($shopId);
        if(!$shop)
            return 0;

        // query to get all orders
        $orders = $shop->order();
        $orders->select('orders.*');
        $orders->with(['lineItem' => function ($query) {
            $query->whereNull('tracking_code');
        }]);
        $orders->where('orders.fulfillment_status', '<>', config('order.fulfillment_status.fulfilled'))
            ->join('line_item', 'orders.id', '=', 'line_item.orders_id')
            ->join('product_variant', 'line_item.product_variant_id', '=', 'product_variant.id')
            ->join('product', 'product_variant.product_id', '=', 'product.id')
            ->orderBy('orders.id', 'desc')
            ->groupBy('orders.id')
            ->limit($limit);

        $orderFulfillment = $orders->get();

        return $orderFulfillment->filter(function($order, $key) {
            return count($order->lineItem) == 0;
        });
    }

    public function getOrderHasNotAliOrderNo(string $shopId) {
        $shop = ShopModel::find($shopId);
        if(!$shop)
            return false;
        $orderModel = $shop->order()->select(['orders.id', 'orders.order_name'])->orderBy('id', 'asc');
        // $orderModel->with(['lineItem' => function ($query) {
        //     $query->whereNull('aliexpress_order_no');
        //     $query->select(['id', 'orders_id', 'product_variant_id']);
        // }, 'lineItem.productVariant' => function ($query) {
        //     // $query->whereNotNull('aliexpress_product_id');
        //     $query->select(['id', 'aliexpress_product_id', 'sku']);
        // }]);
        // $orderModel->join('line_item', 'orders.id', '=', 'line_item.orders_id');
        // // $orderModel->join('product_variant', 'line_item.product_variant_id', '=', 'product_variant.id');
        // $orderModel->whereNull('line_item.aliexpress_order_no');
        // // $orderModel->whereNotNull('product_variant.aliexpress_product_id');
        // $orderModel->groupBy('orders.id');
        return $orderModel->first();
    }

    public function getLineItemUnfulfillHasTrackingCode(string $shopId) {
        $shop = ShopModel::find($shopId);
        if(!$shop)
            return false;
        $orderModel = $shop->order();
        $orderModel->select(['line_item.id', 'line_item.tracking_code', 'line_item.orders_id']);
        $orderModel->join('line_item', 'orders.id', '=', 'line_item.orders_id');
        $orderModel->whereNotNull('line_item.tracking_code');
        $orderModel->Where(function ($query) {
                        $query->orWhereNotNull('line_item.fulfillment_status');
                        $query->orWhere('line_item.fulfillment_status', '<>', 1);
                    });
        return $orderModel->get();
    }

    public function isLimited($shopId) {
        // @limit fake code
        $limit = 10;
        
    }

    public function orderHadFulfillment($shopId, $dateFrom) {
        $orderAutoFulfillment = OrderFulfillment::where('shop_id', $shopId)->where('created_at', '>', $dateFrom)->count();
        return $orderAutoFulfillment;
    }
}