<?php
declare(strict_types=1);
namespace App\Repository;
use App\Contracts\Repository\ProductRepositoryInterface;
use App\Helpers\ProductHelper;
use App\Models\ProductModel;
use App\Models\ShopModel;
use App\Services\GzService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\ShopifyApi\ProductsApi;
class ProductRepository extends GzService implements ProductRepositoryInterface
{
    private $_shopId;
    public function __construct($shopId)
    {
        $this->_shopId = $shopId;
    }
    /**
     * @param array $filters
     *
     * @return bool
     */
    public function all( array $filters = [])
    {
        $shop = ShopModel::find($this->_shopId);
        if( ! $shop)
            return false;
        $product = $shop->product();
        if( ! empty($filters['title']))
            $product->where('title','like', '%'.$filters['title'].'%');
        if( ! empty($filters['status']))
        {
            if($filters['status'] == 1)
            {
                $product->where('total_quantity', '>', 0)
                    ->where('source_product_link', '!=', null)
                    ->where('product.source_product_link', '!=', '');
            }
            elseif($filters['status'] == 2)
                $product->where('total_quantity', '<=', 0)
                    ->where('source_product_link', '!=', null)
                    ->where('source_product_link', '!=', '');
            elseif($filters['status'] == 3)
                $product->where('product.status', 3)
                    ->where('product.source_product_link', '!=', null)
                    ->where('product.source_product_link', '!=', '');
            elseif($filters['status'] ==  4)
            {
                $product->where('total_quantity','<=', 10);
                $product->where('total_quantity', '>', 0);
            }
        }
        if( ! empty($filters['auto_update_price'])) {
            if($filters['auto_update_price'] == config('product.auto_update_price.automatic_price_updates_on')) {
                $product->where('auto_update_price', config('product.auto_update_price.automatic_price_updates_on'));
            } else {
                $product->where('auto_update_price', '<>', config('product.auto_update_price.automatic_price_updates_on'));
            }
        }
        if( ! empty($filters['source_product_link']))
        {
            if($filters['source_product_link'] == config('product.source_product_link.AliExpress')) {
                $product->where('source_product_link', '!=', null)
                    ->where('source_product_link', '!=', '');
            } else {
                $product->where(function ($query) {
                    $query->orWhere('source_product_link', '=', null);
                    $query->orWhere('source_product_link', '=', '');
                });
            }
        }
        $product->orderBy('created_at', 'desc');
        return $product->with(['productVariant', 'productImage'])->paginate(config('common.paginate_default'));
    }
    public function allForAlireview( array $ids = [])
    {
        $shop = ShopModel::find($this->_shopId);
        if( ! $shop)
            return false;
        $product = $shop->product()->select(['id', 'source_product_link', 'aliexpress_product_id']);
        $product->whereNotNull('source_product_link');
        if(!empty($ids)) {
            $product->whereIn('id', $ids);
        }

        $product->orderBy('created_at', 'desc');
        return $product->paginate(config('common.paginate_default'));
    }
    /**
     * @param array $filters
     * @param $paged_option
     * @param $currentPage
     * @return bool
     */
    public function allProductPlace(array $filters=[],$paged_option,$currentPage){
        $shop = ShopModel::find($this->_shopId);
        if( ! $shop)
            return false;
        $product = $shop->product();
        $product->join(DB::raw('(SELECT product_id, SUM(source_quantity) as product_in_stock FROM product_variant GROUP BY product_id) as product_variant'),
            'product_variant.product_id', '=', 'product.id');
        if( ! empty($filters['title']))
            $product->where('title','like', '%'.$filters['title'].'%');
        if( ! empty($filters['status']))
        {
            if($filters['status'] == 1)
            {
                $product->where('product_variant.product_in_stock', '>', 0)
                    ->where('product.source_product_link', '!=', null)
                    ->where('product.source_product_link', '!=', '');
            }
            elseif($filters['status'] == 2)
                $product->where('product_variant.product_in_stock', '<=', 0)
                    ->where('product.source_product_link', '!=', null)
                    ->where('product.source_product_link', '!=', '');
            elseif($filters['status'] == 3)
                $product->where('product.status', 3)
                    ->where('product.source_product_link', '!=', null)
                    ->where('product.source_product_link', '!=', '');
            elseif($filters['status'] ==  4)
            {
                $product->where('product_variant.product_in_stock','<=', 10);
                $product->where('product_variant.product_in_stock', '>', 0);
            }
        }
        if( ! empty($filters['auto_update_price']))
            $product->where('product.auto_update_price', $filters['auto_update_price']);
        if( ! empty($filters['source_product_link']))
        {
            if($filters['source_product_link'] == config('product.source_product_link.AliExpress'))
                $product->where('product.source_product_link', '!=', null)
                    ->where('product.source_product_link', '!=', '');
            else
                $product->where('product.source_product_link', '=', null)
                    ->orWhere('product.source_product_link', '=', '');
        }
        $product->orderBy('created_at', 'desc');
        if($paged_option == 2) {
            $pagination = config('common.paginate_default');
            $skip = $currentPage * $pagination -  $pagination;
            $take = $currentPage * $pagination - $skip;
            $product->skip($skip)->take($take);
        } //
        return $product->get();
    }
    /**
     * Get detail product
     *
     * @param $productId
     * @return bool
     */
    public function detail($productId)
    {
        if( ! $shop = ShopModel::find($this->_shopId))
            return false;
        if($product = $shop->product()->find($productId)){
            return $product->load(['productVariant' => function($query){
                $query->where('title','<>','Default Title');
            },'productImage', 'productVariant.productImage']);
        }
        return false;
    }
    public function detailEdit($productId)
    {
        if( ! $shop = ShopModel::find($this->_shopId))
            return false;
        if($product = $shop->product()->find($productId)){
            return $product->load(['productVariant' => function($query){
            },'productImage', 'productVariant.productImage']);
        }
        return false;
    }
    /**
     * @return mixed
     */
    public function productAutoUpdateAliexpress()
    {
//        $shop = ShopModel::find($this->_shopId);
//        if( ! $shop)
//            return false;
//        $products = $shop->product()->whereNotNull('source_product_link')->get();
//        return $products;
        $shop = ShopModel::find($this->_shopId);
        $products = $shop->product()->whereNotNull('product.source_product_link');
        $products->select('product.id','product.source_product_link');

        $products->with([
            'productVariant' =>function($query){
                $query->where('aliexpress_options','<>',null);
            },
            'productVariant:product_id,aliexpress_options,source_quantity,source_price,aliexpress_product_id,source_product_link',
        ]);
        $data = $products->get();
        return $data;
    }
    /**
     * @param      $productId
     *
     * @return bool
     */
    public function delete($productId)
    {
        if($product = ProductModel::find($productId))
        {
            if($product->delete())
                return true;
        }
        return false;
    }
    /**
     * @param string $productId
     * @param array  $args
     *
     * @return bool
     */
    public function update(string $productId, array $args = [])
    {
        $productModel = new ProductModel();
        $filterArgs = array_only($args, $productModel->getFillable());
        $shop = ShopModel::find($this->_shopId);
        //Check shop exist
        if( ! $shop)
            return false;
        if($product = $shop->product()->where('id', $productId))
        {
            if($product->update($filterArgs))
                return true;
        }
        return false;
    }
    /**
     * @param array $product
     *
     * @return bool
     */
    public function save(array $product) : bool
    {
        $shop = ShopModel::find($this->_shopId);
        if( ! $shop)
            return false;
        if($productObj = $shop->product()->withTrashed()->find($product['id']))
        {
            if($productObj->update($product))
                return true;
            return false;
        }
        if($shop->product()->create($product))
            return true;
        return false;
    }
    /**
     * @param array $products
     *
     * @return bool
     */
    public function saveMany(array $products): bool
    {
        $shop = ShopModel::find($this->_shopId);
        if( ! $shop)
            return false;
        if($shop->product()->createMany($products))
            return true;
        return false;
    }
    /**
     * Lấy tất cả variant đã có orders ra của products đó
     * @param int $productId
     * @return mixed
     */
    public function productHasOrder(Float $productId)
    {
        $shop = ShopModel::find($this->_shopId);
        if( ! $shop)
            return false;
        $product = $shop->product()->find($productId);
        if( ! $product)
            return false;
        $variants = $product->productVariant()->withTrashed()->get();
        $variantHasOrder = [];
        foreach ($variants as $variant)
        {
            if($variant->lineItem()->count() > 0)
                $variantHasOrder[] =  $variant->load('productImage');
        }
        return $variantHasOrder;
    }
//    public function updateOptionsFromSpf($shopDomain, $accessToken) {
//
//        $productApi = new ProductsApi($shopDomain, $accessToken);
//        $data = $productApi->detail(['options'], $productId);
//        if( ! $data['status'])
//            return false;
//        $options = array_values(array_map(function($option) {
//            return array(
//                'name' => $option->name,
//                'position' => $option->position
//            );
//        }, $data['data']->product->options));
//        $product->options = json_encode($options, JSON_UNESCAPED_UNICODE);
//        return $product->save();
//    }
    public function getAllProductNotify($page){
        return $this->getRequest(env('NOTIFY_DOMAIN').'api/product/all/group_date', $this->_shopId,['page'=>$page]);
    }
    public function getProductNotify($id){
        return $this->getRequest(env('NOTIFY_DOMAIN').'api/product/detail/'. $id, $this->_shopId);
    }
    public function deleteProductNotify($id){
        return $this->deleteRequest(env('NOTIFY_DOMAIN').'api/product/'. $id, $this->_shopId);
    }
    public function getProductNoLink() {
        $shop = ShopModel::find($this->_shopId);
        if( ! $shop)
            return false;
        $product = $shop->product()->select(['id', 'aliexpress_product_id']);
        $product->whereNull('source_product_link');
        return $product->get();
    }

    public function numberProductAfterPricing() {
        $shop = ShopModel::find($this->_shopId);
        if( ! $shop)
            return false;
            
        $product = $shop->product()->select(['id']);
        $product->whereNotNull('source_product_link');
        $product->where('created_at', '>', config('shopify.pricing_start_date'));
        return $product->count();
    }
}