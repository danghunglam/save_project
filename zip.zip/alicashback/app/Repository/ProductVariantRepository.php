<?php
declare(strict_types=1);
namespace App\Repository;
use App\Contracts\Repository\ProductVariantRepositoryInterface;
use App\Models\ProductModel;
use App\Models\ProductVariantModel;
use App\Models\ProductImageModel;
use Illuminate\Support\Facades\Log;

class ProductVariantRepository implements ProductVariantRepositoryInterface
{
    /**
     * @param string $productVariantId
     *
     * @return mixed
     */
    public function getDetail(string $productVariantId)
    {
        return ProductVariantModel::withTrashed()->find($productVariantId);
    }

    /**
     * @param string $productId
     *
     * @return bool
     */
    public function getVariantInProduct(string $productId)
    {
        return ProductVariantModel::where('product_id', $productId)->withTrashed()->get();
    }

    /**
     * @param string $productId
     *
     * @return bool
     */
    public function getVariantAliOptionNullInProduct(string  $productId)
    {
        $productVariant = ProductVariantModel::where('product_id', $productId)
            ->where('aliexpress_options', null)
            ->withTrashed()->get();
        if($productVariant->count() > 0)
        {
            $productVariant = $productVariant->each(function($variant) {
                $variant['image'] = isset($variant->productImage->src) ? $variant->productImage->src : config('common.default_image');
                return $variant;
            });
        }
        return $productVariant;
    }

    /**
     * Hành động cập nhập lại tất cả source quantity của variant trong sản phẩm bằng 0
     *
     * @param $productId
     * @return bool
     */
    public function updateAllVariantInProductQuantityZero($productId): bool
    {
        $product = ProductModel::find($productId);
        if( ! $productId)
            return false;

        $variants = $product->productVariant()->get();
        $variants->each(function ($variant) {
            $variant->update([
                'source_quantity' => 0
            ]);
        });
        return true;
    }

    /**
     * Delete variant
     * @param $variants
     * @return bool
     */
    public function deleteVariants($variants): bool
    {
        $variantModel = app(ProductVariantModel::class);
        foreach ($variants as $variant)
        {
            if($variantDel = $variantModel->where('id', $variant->id)){
                $variantDel->delete();
            }
        }
        return true;
    }


    /**
     * Update variants in product
     * args = [
     * 'variant_id' => [
     *      price: '',
     *      cost: ''
     * ]
     * ]
     * @param $productId
     * @param array $args
     * @return bool
     */
    public function updateAllVariantInProduct($productId, array $args): bool
    {
        $product = ProductModel::find($productId);
        if( ! $product)
            return false;

        $productVariant = $product->productVariant()->get();
        if($productVariant->count() > 0)
        {
            foreach ($args as $key => $arg) {
                $productVariant->each(function ($variant) use ($key, $arg) {
                    $variant->where('id', $key)->update($arg);
                });
            }
        }
        return true;
    }

    /**
     * @param string $productVariantId
     * @param array  $args
     *
     * @return bool
     */
    public function update(string $productVariantId, array $args): bool
    {
	    $productVariant = ProductVariantModel::withTrashed()->find($productVariantId);
	    if( ! $productVariant)
            return false;
            
        if(isset($args['image_id']) && !ProductImageModel::find($args['image_id']) ) {
            $args['image_id'] = null;
        } 

	    if( $productVariant->update($args) )
	    	return true;
    }

    /**
     * @param string $productId
     * @param array  $variant
     *
     * @return bool
     */
    public function save(string $productId, array $variant): bool
    {
        $product = ProductModel::find($productId);
        if( ! $product)
            return false;

        if($variantModel = $product->productVariant()->withTrashed()->find($variant['id']))
        {
            $variantModel->restore();
            if($variantModel->update($variant))
                return true;

            return false;
        }

        if($product->productVariant()->create($variant))
            return true;

        return false;
    }

    /**
     * @param string $productId
     * @param array  $args
     *
     * @return bool
     */
    public function saveMany(string $productId, array $args = []): bool
    {
        $product = ProductModel::find($productId);

        if( ! $product)
            return false;

        foreach ($args as $k => $arg)
        {
            if($productImageModel = $product->productVariant()->withTrashed()->find($arg['id']))
            {
                unset($args[$k]);
                $productImageModel->restore();
                $productImageModel->update($arg);
            }
        }

        if($product->productVariant()->createMany($args))
            return true;

        return false;
    }

    /**
     * @param $productId
     */
    public function deleteByProductId($productId)
    {
        ProductVariantModel::where(['product_id' => $productId ])->delete();
    }

    /**
     * Delete variant if not has order
     * @param $productId
     * @param $variantHasOrder
     * @return bool
     */
    public function deleteVariantNotHasOrder($productId, $variantHasOrder)
    {
        $product = ProductModel::find($productId);
        if( ! $product)
            return false;

        foreach ($variantHasOrder as $value)
        {
            if($variant = ProductVariantModel::withTrashed()->find($value->id))
            {
                $variant->forceDelete();
            }

        }
    }

    /**
     * Custom variant if not has order
     * @param array  $variantsData
     * @param array  $product
     * @return array
     */
    public function customVariantNotHasOrder($variantsData, $product)
    {
        $arrayVariant = array(); 
        $i = 0;
        foreach ($variantsData as $key => $value)
        {
            $arrayVariant[$i] = $value;
            $arrayVariant[$i]["source_product_link"] = $product['source_product_link'];
            $arrayVariant[$i]["aliexpress_product_id"] = $product['aliexpress_product_id'];
            $arrayVariant[$i]["supplier_id"] = $product['supplier_id'];
            $i++;
        }
        return $arrayVariant;
    }

    /**
     * Restore soft delete
     *
     * @param $variantId
     * @return mixed
     */
    public function restore($variantId)
    {
        if($productVariant = ProductVariantModel::withTrashed()->find($variantId))
            return $productVariant->restore();

        return false;
    }
}