<?php

namespace App\Repository;


use App\Models\ImportProductModel;
use App\Models\ImportProductVariantModel;
use App\Models\ProductModel;
use Illuminate\Support\Facades\Log;

class ImportProductVariantRepository
{

    private function convertData($variant)
    {
        $args = [];
        //bởi vì data truyền vào là kiểu float thì khi save sẽ tự động bỏ phần thập phân đi nên phải chuyển
        //tất cả kiểu tiền tệ về string
        foreach ($variant as $key => $value)
        {
            if(in_array($key, ['source_price', 'price', 'compare_at_price']))
                $args[$key] = (string) $value;
            else
                $args[$key] = $value;
        }

        return $args;
    }
    /**
     * @param $productId
     * @param $imageId
     * @param $variant
     *
     * @return bool
     */
    public function create($productId, $imageId, $variant)
    {
        $variant['image_id'] = $imageId;
        if( ! $productModel = ImportProductModel::find($productId))
            return false;

        $variant = $this->convertData($variant);

        if($productModel->productVariant()->create($variant))
            return true;

        return false;
    }

    /**
     * @param $productVariantId
     * @param array  $args
     *
     * @return bool
     */
    public function update($productVariantId, array $args): bool
    {
        $productVariant = ImportProductVariantModel::find($productVariantId);
        if( ! $productVariant)
            return false;

        $variant = $this->convertData($args);
        if( $productVariant->update($variant) )
            return true;
    }

    public function delete($productVariantId)
    {
        $productVariantModel = ImportProductVariantModel::find($productVariantId);
        if( ! $productVariantModel)
            return false;

        if( ! $productVariantModel->delete())
            return false;

        return true;
    }
}