<?php
declare(strict_types=1);
namespace App\Repository;

use App\Contracts\Repository\SettingRepositoryInterface;
use App\Helpers\SettingHelper;
use App\Jobs\AddRuleImportSettingsToProductImportListJob;
use App\Models\ImportProductModel;
use App\Models\SettingModel;
use App\Models\ShopModel;
use Illuminate\Support\Facades\DB;

class SettingRepository implements SettingRepositoryInterface
{
    /**
     * @var
     */
    private $_shopId;

    public function __construct($shopId)
    {
        $this->_shopId = $shopId;
    }

    /**
     * @return mixed
     */
    public function getAll()
    {
        if( ! $shop = ShopModel::find($this->_shopId))
            return false;

        return $shop->setting()->get();
    }

    public function getObjAll()
    {
        if( ! $shop = ShopModel::find($this->_shopId))
            return false;

        $settings = $shop->setting;
        $settings = SettingHelper::decodeSettings($settings);
        if(empty($settings['time_zone'])) {
            $shop = session('shop');
            $settings['time_zone'] = isset($shop['iana_timezone']) ? $shop['iana_timezone'] : null;
        }
        $settings['default_phone_code'] = isset($settings['default_phone_code']) ? $settings['default_phone_code']  : null;
        //Get primary email address
        $settings['primary_email_address'] = isset($settings['primary_email_address']) ? $settings['primary_email_address'] : (isset($shop->email) ? $shop->email : '');
        //
        $settings['assign_cent_compare_at_check'] = ! empty($settings['assign_cent_compare_at_check']) ? true : false;
        $settings['assign_cent_price_check'] = ! empty($settings['assign_cent_price_check']) ? true : false;

        if(isset($settings['automation_fulfillment'])) {
            $settings['automation_fulfillment'] = (int) $settings['automation_fulfillment'];
        }
        
        $setting_default = config('setting_default');
        $settings = array_merge($setting_default, $settings);
        

        return $settings;
    }

    /**
     * @param string $key
     * @return mixed
     */
    public function getKey(string $key)
    {
        if( ! $shop = ShopModel::find($this->_shopId))
            return false;

        return $shop->setting()->select('value')->where('key', $key)->first();
    }

    /**
     * @param array $args
     * @return bool
     */
    public function saveMany(array $args) : bool
    {
        $shop = ShopModel::find($this->_shopId);

        if( ! $shop)
            return false;

        DB::beginTransaction();

        $keys = array_map(function ($field) {
                    return $field['key'];
                }, $args);

        //Delete all setting old
        $this->deleteField($keys);

        //Add or update setting
        foreach ($args as $arg)
        {
            if( ! $this->save($shop, $arg))
            {
                DB::rollBack();
                return false;
            }
        }
        DB::commit();
        return true;
    }

    /**
     * @return mixed
     */
    public function deleteAll()
    {
        $shop = ShopModel::find($this->_shopId);
        return $shop->setting()->delete();
    }

    /**
     * @param array $arg
     * @return mixed
     */
    public function deleteField(array $keys)
    {
        if(empty($keys))
            return false;        
        $shop = ShopModel::find($this->_shopId);
        return $shop->setting()->whereIn('key', $keys)->delete();
    }

    /**
     * @param ShopModel $shop
     * @param array $arg
     * @return bool
     */
    public function save(ShopModel $shop, array $arg)
    {
        //If key exist update value
        if($shop->setting()->where('key', $arg['key'])->count())
        {
            return $shop->setting()->where('key', $arg['key'])->update($arg);
        }

        if($shop->setting()->save(new SettingModel($arg)))
            return true;

        return false;
    }

    /**
     * @param ShopModel $shop
     * @param string $key
     * @return bool|mixed
     */
    public function delete(ShopModel $shop, string $key)
    {
        if($shop->setting()->where('key', $key)->count())
        {
            return $shop->setting()->where('key', $key)->delete();
        }
        return true;
    }

    public function addRuleProduct()
    {
        if( ! $shop = ShopModel::find($this->_shopId))
            return false;

        AddRuleImportSettingsToProductImportListJob::dispatch($this->_shopId, $shop)->allOnQueue('add_rule_product');

        return true;
    }
}