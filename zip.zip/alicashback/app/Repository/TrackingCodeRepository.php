<?php
/**
 * Created by PhpStorm.
 * User: hunglam
 * Date: 20/07/2018
 * Time: 14:51
 */

namespace App\Repository;


use App\Contracts\Repository\TrackingCodeRepositoryInterface;
use App\Helpers\SettingHelper;
use App\Models\OrdersModel;
use App\Models\ShopModel;
use App\ShopifyApi\FulfillmentApi;
use function Couchbase\defaultDecoder;
use Illuminate\Support\Facades\Input;
use Maatwebsite\Excel\Excel;

class TrackingCodeRepository implements TrackingCodeRepositoryInterface
{

    public function getOrders($filters): array
    {
        $ordersData = [];

        $paged = isset($filters['paged']) ? $filters['paged'] : 1;

        $orderRepository = new OrderRepository();
        $shopId = session('shopId');
        $orders = $orderRepository->trackingCode($shopId, $filters, config( 'common.paginate_default'), $paged);

        $pagination = [
            'total' => $orders->total(),
            'last_page' => $orders->lastPage(),
            'perPage' => $orders->perPage(),
            'current_page' => $orders->currentPage()
        ];

        foreach ($orders as $order)
        {
            $ordersData[$order->id] = [
                'id' => $order->id,
                'order_number' => $order->order_number,
                'order_name' => $order->order_name,
                'note' => $order->note,
                'fullname' => $order->fullname,
                'city' => $order->city,
                'phone' => SettingHelper::splitPhoneNumberCode($order->phone)['phone'],
                'phone_code' => SettingHelper::splitPhoneNumberCode($order->phone)['phone_code'],
                'country' => $order->country,
                'country_code' => $order->country_code,
                'address1' => $order->address1,
                'address2' => $order->address2,
                'province' => $order->province,
                'province_code' => $order->province_code,
                'email' => $order->email,
                'zip' => $order->zip,
                'financial_status' => $order->financial_status,
                'fulfillment_status' => $order->fulfillment_status,
                'created_at' => $order->created_at,
                'total_price_order' => $order->total_price_order,
                'flag' => ($order->flag != '') ? $order->flag : 'none'
            ];

            foreach ($order->lineItem as $line_item)
            {
                $ordersData[$order->id]['line_items'][$line_item->id] = [
                    'id' => $line_item->id,
                    'status' => $line_item->status,
                    'aliexpress_order_no' => $line_item->aliexpress_order_no,
                    'product_title' => isset($line_item->productVariant->product->title) ? $line_item->productVariant->product->title : '',
                    'product_handle' => isset($line_item->productVariant->product->handle) ? $line_item->productVariant->product->handle : '',
                    'product_variant_image' => isset($line_item->productVariant->productImage->src) ? $line_item->productVariant->productImage->src : config('common.default_image'),
                    'variant_sku' => isset($line_item->productVariant->sku) ? $line_item->productVariant->sku : '',
                    'variant_title' => isset($line_item->productVariant->title) ? $line_item->productVariant->title : '',
                    'tracking_code' => $line_item->tracking_code,
                    'quality' => $line_item->quality,
                    'price' => number_format($line_item->price,2),
                    'total_price_item' => $line_item->quality * $line_item->price,
                    'orders_id' => $line_item->orders_id,
                    'source_product_link' => isset($line_item->productVariant->product->source_product_link) ? $line_item->productVariant->product->source_product_link : '',
                    'aliexpress_options' => isset($line_item->productVariant->aliexpress_options) ? $line_item->productVariant->aliexpress_options : '',
                    'product_variant_id' => isset($line_item->productVariant->id) ? $line_item->productVariant->id : '',
                    'product_id' => isset($line_item->productVariant->product->id) ? $line_item->productVariant->product->id : '',
                    'aliexpress_product_id' => isset($line_item->productVariant->product->aliexpress_product_id) ? $line_item->productVariant->product->aliexpress_product_id : '',
                    'supplier' => isset($line_item->productVariant->product->supplier) ? $line_item->productVariant->product->supplier : '',
                    'variant_deleted_at' => isset($line_item->productVariant->deleted_at) ? $line_item->productVariant->deleted_at : '',
                    'created_at'=>$line_item->created_at,
                    'updated_at'=>$line_item->update_at,
                ];
            }
        }
        return ['status' => true, 'ordersData' => $ordersData, 'pagination' => $pagination];
    }

    public function import(array $datas) :array
    {
        $shopId = session('shopId');
        $shop = ShopModel::find($shopId);
        if (!$shop)
            return ['status' => false];

        $settingRepo = new SettingRepository(session('shopId'));
        $default_fulfillment_tracking_url = $settingRepo->getKey('default_fulfillment_tracking_url');
        if(isset($default_fulfillment_tracking_url->value) and filter_var($default_fulfillment_tracking_url->value, FILTER_VALIDATE_URL))
            $fulfillment['tracking_url'] = $default_fulfillment_tracking_url->value;



        foreach ($datas as $orderId => $values)
        {
            foreach ($values as $item){

                $orders = $shop->order()->where(['order_name' => $orderId])->first();
                if(empty($orders)) continue;
                //LineItem in database
                $lineItems = $orders->lineItem()->get();
                if(empty($lineItems)) continue;
                foreach ($lineItems as $k => $lineItem) {

                    $supplier = $lineItem->productVariant()->where('supplier_id', $item[1])->first();
                    if(!empty($supplier)){
                        $lineItem->update(['tracking_code' => $item[2], 'status' => 3]);

                        $orderRepository = new OrderRepository();
                        $location_id = $orderRepository->getFulfillLocationId(session('shopDomain'), session('accessToken'), $lineItem->orders_id, $lineItem->id);
                        $isUseFulfillService = ($location_id != $shop->primary_location_id) ? true : false;
                        //Update trackingCode in shopify
                        $fulfillment = [
                            'location_id' => $location_id,
                            'tracking_number' => $item[2],
                            'line_items' => [
                                [
                                    'id' => $lineItem->id
                                ]
                            ],
                        ];

                        //Update Fulfillment api
                        $fulfillmentApi = new FulfillmentApi(session('shopDomain'), session('accessToken'));

                        $isUpdateFulfillment = $fulfillmentApi->create($lineItem->orders_id, $fulfillment);

                        // update status fulfillment if current status is pending and use fulfill service
                        if($isUseFulfillService) {
                            if(isset($isUpdateFulfillment['data']->fulfillment)) {
                                $fulfillmentFromSpf = $isUpdateFulfillment['data']->fulfillment;
                                if($fulfillmentFromSpf->status == 'pending') {
                                    $fulfillmentApi->complete($lineItem->orders_id, $fulfillmentFromSpf->id);
                                }
                            }
                        }
                        sleep(3);
                        //
                    }
                }
            }
        }
        return ['status' => false];

    }

}