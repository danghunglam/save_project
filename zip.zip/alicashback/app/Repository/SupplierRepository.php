<?php
/**
 * Created by PhpStorm.
 * User: buicongdang
 * Date: 11/28/17
 * Time: 3:59 PM
 */

namespace App\Repository;


use App\Contracts\Repository\SupplierRepositoryInterface;
use App\Models\SupplierModel;

class SupplierRepository implements SupplierRepositoryInterface
{
    /**
     * @param string $supplierId
     *
     * @return mixed
     */
    public function get(string $supplierId)
    {
        return SupplierModel::find($supplierId);
    }

    /**
     * @param array $supplier
     *
     * @return bool
     */
    public function save(array $supplier = []): bool
    {
        $supplier = new SupplierModel();
        if($supplier->create($supplier))
            return true;

        return false;
    }

    /**
     * @param string $supplierId
     * @param array  $supplier
     *
     * @return bool
     */
    public function update(string $supplierId, array $supplier = []): bool
    {
        if( ! $supplier = SupplierModel::find($supplierId))
            return false;

        if($supplier->update($supplier))
            return true;

        return false;
    }

    /**
     * @param string $supplierId
     * @param array  $args
     *
     * @return bool
     */
    public function createOrUpdate(string $supplierId, array $args = []): bool
    {
        if($supplier = SupplierModel::find($supplierId))
        {
            if($supplier->update($args))
                return true;

            return false;
        }

        if(SupplierModel::create($args))
            return true;

        return false;
    }
}