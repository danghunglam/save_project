<?php

namespace App\ShopifyApi;


use App\Services\SpfService;

class CollectsApi extends SpfService
{
    public function get($data = []) 
    {
        $collect = $this->getRequest('collects.json', $data);
        return $collect;
    }

    public function create($productId, $collectionId)
    {
        $collect = $this->postRequest('collects.json', 
        [
           'collect' => [
                'product_id' => $productId,
                'collection_id' => $collectionId
           ]
        ]);

        return $collect;
    }

    public function delete($collectionId)
    {
        $collect = $this->deleteRequest('collects/' . $collectionId . '.json');

        return $collect;
    }
}