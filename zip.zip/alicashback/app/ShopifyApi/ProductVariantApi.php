<?php

namespace App\ShopifyApi;


use App\Services\SpfService;

class ProductVariantApi extends SpfService
{
    /**
     * @param array $data
     * @param int $productId
     *
     * @return array
     */
    public function create( int $productId, array $data ): array
    {
        $variant = $this->postRequest( 'products/'.$productId.'/variants.json',
            [
                'variant' => $data
            ]
        );
        return $variant;
    }

    /**
     * @param array $data
     * @param int $variantId
     *
     * @return array
     */
    public function update( int $variantId, array $data ): array
    {
        $variant = $this->putRequest( '/variants/'.$variantId.'.json',
            [
                'variant' => $data
            ]
        );
        return $variant;
    }

    /**
     * @param int $productId
     * @param int $variantId
     * @return array
     */
    public function delete(Float $productId, Float $variantId)
    {
        return $this->deleteRequest('products/'.$productId.'/variants/'.$variantId.'.json');
    }

    /**
     * @param int $variantId
     * @return array
     */
    public function detail(int $variantId)
    {
        return $this->getRequest('/variants/'.$variantId.'.json');
    }
}