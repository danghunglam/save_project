<?php

namespace App\ShopifyApi;

use App\Contract\ShopifyAPI\OrdersApiInterface;
use App\Services\SpfService;

class OrdersApi extends SpfService implements OrdersApiInterface
{
    public function getAll(array $fields = [], array $filters = [], string $fulfillment, string $financial, string $status, int $limit, int $page, string $createdAtMin = '', string $createdAtMax = '')
    {
        $field = implode(',', $fields);
        $data  = [
            'limit'            => $limit,
            'page'             => $page,
            'fields'           => $field,
            'financial_status' => $financial,
            'fulfillment_status' => $fulfillment,
            'status' => $status
        ];
        if ($createdAtMin != '' && $createdAtMax != '') {
            $data['created_at_min'] = $createdAtMin.'T'.'00:00:00';
            $data['created_at_max'] = $createdAtMax.'T'.'23:59:00';
        }
        if ( ! empty($filters['title'])) {
            $data['title'] = $filters['title'];
        }
        return $this->getRequest('orders.json', $data);
    }

    public function countAll(array $filters = [], string $fulfillment, string $financial, string $status)
    {
        $data  = [
            'financial_status' => $financial,
            'fulfillment_status' => $fulfillment,
            'status' => $status
        ];
        if ( ! empty($filters['title'])) {
            $data['title'] = $filters['title'];
        }

        return $this->getRequest('orders/count.json', $data);
    }

    /**
     * @param array  $fields
     * @param array  $filters
     * @param int    $limit
     * @param int    $page
     * @param string $status
     *
     * @return mixed
     */
    public function all(array $fields = [], array $filters = [], int $limit, int $page, string $status = 'paid')
    {
        $field = implode(',', $fields);
        $data  = [
            'limit'            => $limit,
            'page'             => $page,
            'fields'           => $field,
            'financial_status' => $status
        ];

        if (!empty($filters['title'])) {
            $data['title'] = $filters['title'];
        }

        if (!empty($filters['collection_id'])) {
            $data['collection_id'] = $filters['collection_id'];
        }

        return $this->getRequest('orders.json', $data);
    }

    public function getOrder(float $orderId)
    {
        return $this->getRequest('orders/'.$orderId.'.json');
    }

    /**
     * @param array  $filters
     * @param string $status
     *
     * @return int
     */
    public function count(array $filters = [], string $status): int
    {
        $data['financial_status'] = $status;

        return $this->getRequest('orders/count.json', $data);
    }

    /**
     * @param string $orderId
     *
     * @return bool
     */
    public function delete(string $orderId): bool
    {
        // TODO: Implement delete() method.
    }

    /**
     * @param string $orderId
     * @param array  $data
     *
     * @return array
     */
    public function update(string $orderId, array $data): array
    {
        // TODO: Implement update() method.
    }

    /**
     * @param string $orderId
     * @param array  $fields
     *
     * @return array
     */
    public function detail(string $orderId, array $fields = []): array
    {
        $field   = implode( ',', $fields );
        $order = $this->getRequest( 'orders/' . $orderId . '.json', ['fields' => $field]);
        return $order;
    }

    /**
     * @param array $order
     *
     * @return bool
     */
    public function create(array $order): bool
    {

    }
}