<?php

namespace App\ShopifyApi;


use App\Contracts\ShopifyAPI\FulfillmentApiInterface;
use App\Services\SpfService;

class FulfillmentApi extends SpfService implements FulfillmentApiInterface
{
    public function all(string $orderId)
    {
        $fulfillments = $this->getRequest('orders/'.$orderId.'/fulfillments.json',
             []
        );
        return $fulfillments;
    }

    public function count(string $orderId): int
    {
        // TODO: Implement count() method.
    }

    /**
     * @param string $orderId
     * @param array  $fulfillment
     *
     * @return mixed
     */
    public function create(string $orderId, array $fulfillment = [])
    {
        $isCreate = $this->postRequest('orders/'.$orderId.'/fulfillments.json',
             ['fulfillment' => $fulfillment]
        );
        return $isCreate;
    }

    public function detail(string $orderId, string $fulfillmentId)
    {
        // TODO: Implement detail() method.
    }

    public function toCancel(string $orderId, string $fulfillmentId): bool
    {
        // TODO: Implement toCancel() method.
    }

    public function toComplete(string $orderId, string $fulfillmentId): bool
    {
        // TODO: Implement toComplete() method.
    }
    public function toOpen(string $orderId, string $fulfillmentId): bool
    {
        // TODO: Implement toOpen() method.
    }
    public function update(string $orderId, string $fulfillmentId, array $fulfillment = [], string $trackingCode = '')
    {
        $data  = [
            'fulfillment' => [
                "tracking_number"=> $trackingCode,
                "id"=> $fulfillmentId
            ]
        ];
        $this->putRequest('orders/'.$orderId.'/fulfillments/'.$fulfillmentId.'.json', $data);
    }

    public function complete($orderId, $fulfillmentId) {
        if(!$orderId || !$fulfillmentId)
            return false;
        $isComplete = $this->postRequest('orders/'.$orderId.'/fulfillments/'.$fulfillmentId.'/complete.json', []);
        return $isComplete;
    }
}