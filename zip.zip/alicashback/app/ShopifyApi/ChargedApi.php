<?php

namespace App\ShopifyApi;



use App\Services\SpfService;

class ChargedApi extends SpfService
{
	private $_shopTest = [

		];
	
	private $_shopOneCharge = [];
	
	public function addCharge()
	{
		try {
			$data = [
				'recurring_application_charge' => [
					'name'       => config( 'charged.name' ),
					'price'      => config( 'charged.price' ),
					'return_url' => route( 'apps.chargeHandle' ),
					'trial_days' => config( 'charged.trial_days' ),
					'test'       => config( 'charged.test' )
				]
			];
			
			if ( in_array( session( 'shopDomain' ), $this->_shopTest ) )
			{
				$data['recurring_application_charge']['test'] = true;
			}
			
			if ( in_array( session( 'shopDomain' ), $this->_shopOneCharge ) )
			{
				$data['recurring_application_charge']['price']      = 1;
				$data['recurring_application_charge']['trial_days'] = 0;
			}
			
			$addCharge = $this->postRequest( 'recurring_application_charges.json', $data );
			
			return [
				'status'    => true,
				'addCharge' => $addCharge->recurring_application_charge
			];
		} catch ( \Exception $exception ) {
			return [ 'status' => false, 'message' => $exception->getMessage() ];
		}
	}
	
	public function detailCharge( $id )
	{
		try {
			$detailCharge = $this->getRequest(
				'recurring_application_charges/' . $id . '.json'
			);
			
			return [
				'status'       => true,
				'detailCharge' => $detailCharge->recurring_application_charge
			];
			
		} catch ( \Exception $exception ) {
			return [ 'status' => false, 'message' => $exception->getMessage() ];
		}
	}
	
	public function activeCharge( $idCharge )
	{
		try {
			$activeCharge = $this->postRequest(
				'recurring_application_charges/' . $idCharge . '/activate.json'
			);
			
			return [
				'status'       => true,
				'activeCharge' => $activeCharge->recurring_application_charge
			];
		} catch ( \Exception $exception ) {
			return [ 'status' => false, 'message' => $exception->getMessage() ];
		}
	}
	
	public function allCharge()
	{
		try {
			$allCharge = $this->getRequest(
				'recurring_application_charges.json'
			);
			
			return [
				'status'    => true,
				'allCharge' => $allCharge->recurring_application_charges
			];
		} catch ( \Exception $exception ) {
			return [ 'status' => false, 'message' => $exception->getMessage() ];
		}
	}
}