<?php

namespace App\ShopifyApi;

use App\Services\SpfService;
use Exception;

class AssetsApi extends SpfService
{
	/**
	 * @param $currentTheme
	 * @param $fileAsset
	 *
	 * @return array
	 */
	public function getAssetValue( $currentTheme, $fileAsset )
	{
	    return $this->getRequest('/themes/'.$currentTheme. '/assets.json', ["asset[key]" => $fileAsset ]);
	}
	
	/**
	 * @param $currentTheme
	 * @param $fileAsset
	 * @param $newAssetValue
	 *
	 * @return array
	 */
	public function updateAssetValue( $currentTheme, $fileAsset, $newAssetValue )
	{
		try {
            $createOrUpdate  = $this->putRequest( 'themes/' . $currentTheme . '/assets.json', [
			    'asset' => [
                    'key'   => $fileAsset,
                    'value' => $newAssetValue
                ]
            ] );
			
			return $createOrUpdate;
			
		} catch ( Exception $exception ) {
			return [ 'status' => false, 'message' => $exception->getMessage() ];
		}
	}

	public function deleteAssetFile( $currentTheme, $assetKey)
    {
        try {
            $result = $this->deleteRequest('themes/'.$currentTheme.'/assets.json', [
                'asset' => [
                    'key'   => $assetKey
                ]
            ]);
            return $result;
        } catch ( Exception $exception ) {
            return [ 'status' => false, 'message' => $exception->getMessage() ];
        }
    }
}