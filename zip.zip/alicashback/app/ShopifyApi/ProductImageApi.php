<?php

namespace App\ShopifyApi;


use App\Services\SpfService;

class ProductImageApi extends SpfService
{
    public function create(string $productId, array $data)
    {
        $image = $this->postRequest( 'products/'.$productId.'/images.json',
            [
                'image' => $data
            ]
        );
        return $image;
    }

    public function delete(string $productId, string $imageId)
    {
        $image = $this->deleteRequest( 'products/'.$productId.'/images/'.$imageId.'.json');
        return $image;
    }
}