<?php

namespace App\ShopifyApi;


use App\Services\SpfService;

class CustomCollectionsApi extends SpfService
{
	public function custom( $limit = 250 )
	{
        return $this->getRequest( 'custom_collections.json', ['limit' => $limit]);
	}


	public function smart( $limit = 250 )
    {
        return $this->getRequest( 'smart_collections.json', ['limit' => $limit]);
    }
}