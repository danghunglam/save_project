<?php

namespace App\ShopifyApi;

use App\Contracts\ShopifyAPI\ProductsApiInterface;
use App\Services\SpfService;
use Illuminate\Support\Facades\Log;

/**
 * Class InventoryLevelApi
 *
 * @package App\ShopifyApi
 */
class InventoryLevelApi extends SpfService
{
    public function setAvailable($inventory_item_id, $location_id, $available) {
        $inventory_level = $this->postRequest( 'inventory_levels/set.json',
            [
                "location_id" => $location_id,
                "inventory_item_id" => $inventory_item_id,
                "available" => $available
            ]
        );
        return $inventory_level;
    }
}