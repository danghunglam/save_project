<?php

namespace App\ShopifyApi;


use App\Services\SpfService;

class ThemesApi extends SpfService
{
	/**
	 * @return array
	 */
	public function getAllTheme()
	{
		return $this->getRequest( 'themes.json' );
	}
}
