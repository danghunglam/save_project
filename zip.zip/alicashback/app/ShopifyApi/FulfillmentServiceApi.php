<?php
namespace App\ShopifyApi;
use App\Services\SpfService;

class FulfillmentServiceApi extends SpfService 
{
    public function getAll(array $fields = [])
    {
        return $this->getRequest('fulfillment_services.json', $fields);
    }
} 