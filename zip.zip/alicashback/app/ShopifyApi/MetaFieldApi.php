<?php

namespace App\ShopifyApi;


use App\Services\SpfService;

class MetaFieldApi extends SpfService
{
	/**
	 * @param $nameSpace
	 * @param $key
	 * @param $valueMetaField
	 *
	 * @return array
	 */
	public function addMetaField( $nameSpace, $key, $valueMetaField )
	{
        return  $this->postRequest( 'metafields.json', [
            'DATA' => [
                'metafield' => [
                    'namespace'  => $nameSpace,
                    'key'        => $key,
                    'value'      => $valueMetaField,
                    'value_type' => 'string'
                ]
            ]
        ] );
	}
	
	/**
	 * @return array
	 */
	public function allMetaField()
	{
		return $metaField = $this->getRequest( 'metafields.json' );
	}
}