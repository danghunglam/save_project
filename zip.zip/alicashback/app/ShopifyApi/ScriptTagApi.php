<?php

namespace App\ShopifyApi;


use App\Services\SpfService;

class ScriptTagApi extends SpfService
{
	/**
	 * @param $scriptUrl
	 *
	 * @return array
	 */
	public function addScriptTag( $scriptUrl )
	{
		try {
			$scriptTag = $this->postRequest( 'script_tags.json', [
				'DATA' => [
					'script_tag' => [
						'event' => 'onload',
						'src'   => $scriptUrl
					]
				]
			] );
			
			return [ 'status' => true, 'scriptTag' => $scriptTag->script_tag ];
		} catch ( \Exception $exception ) {
			return [ 'status' => false, 'message' => $exception->getMessage() ];
		}
	}
	
	/**
	 * @return array
	 */
	public function allScriptTag()
	{
		try {
			$scriptTag = $this->getRequest( 'script_tags.json' );
			
			return [ 'status' => true, 'scriptTag' => $scriptTag->script_tags ];
		} catch ( \Exception $exception ) {
			return [ 'status' => false, 'message' => $exception->getMessage() ];
		}
	}
	
	/**
	 * @param $scriptTagId
	 *
	 * @return array
	 */
	public function deleteScriptTag( $scriptTagId )
    {
	    return $this->deleteRequest( 'script_tags/' . $scriptTagId . '.json' );
	}
	
}