<?php

namespace App\Listeners;

use App\Events\AutoUpdatePrice;
use App\Events\AutoUpdatePriceEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendMailOwnerListeners
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  AutoUpdatePriceEvent  $event
     * @return void
     */
    public function handle(AutoUpdatePriceEvent $event)
    {
        //
    }
}
