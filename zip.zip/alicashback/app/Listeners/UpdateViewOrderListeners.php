<?php

namespace App\Listeners;

use App\Events\UpdateAliexpressEvent;
use App\Models\ShopModel;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Log;
use Pusher\Pusher;

class UpdateViewOrderListeners
{
    /**
     * UpdateViewOrderListeners constructor.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UpdateAliexpressEvent  $event
     * @return void
     */
    public function handle(UpdateAliexpressEvent $event)
    {
        $shopId = $event->_lineItemModel->order->shop->id;

        $status = $event->_status;

        $type = $event->_type;

        $options = array(
            'cluster' => env('PUSHER_APP_CLUSTER'),
            'encrypted' => true
        );
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            $options
        );

        $pusher->trigger(strval($shopId), 'update-view-order', ['lineItem' => $event->_lineItemModel, 'status' => $status, 'type' => $type]);
    }
}
