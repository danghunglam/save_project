<?php

namespace App\Listeners;

use App\Events\InitAppEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Pusher\Pusher;

class LoadingListeners
{
    /**
     * LoadingListeners constructor.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  InitAppEvent  $event
     * @return void
     */
    public function handle(InitAppEvent $event)
    {
        $type = $event->_type;
        $shopId = $event->_shopId;

        $options = array(
            'cluster' => env('PUSHER_APP_CLUSTER'),
            'encrypted' => true
        );
        $pusher = new Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            $options
        );

        $pusher->trigger(strval($shopId), 'update-loading', ['type' => $type]);
    }
}
