<?php

namespace App\Listeners;

use App\Events\UninstallAppEvent;
use http\Env\Response;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Cache;

class UninstallAppListeners
{
    /**
     * LoadingListeners constructor.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UninstallAppEvent $event
     * @return void
     */
    public function handle(UninstallAppEvent $event)
    {
        $shopId = $event->shopId;
        $uninstallDate = time();
        if(Cache::has('uninstall_ao_'.$shopId)) {
            Cache::forever('uninstall_ao_'.$shopId, $uninstallDate);
        }
    }
}
