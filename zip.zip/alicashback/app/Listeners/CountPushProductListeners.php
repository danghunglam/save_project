<?php

namespace App\Listeners;

use App\Events\PushProductEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Cache;

class CountPushProductListeners
{
    /**
     * LoadingListeners constructor.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  PushProductEvent $event
     * @return void
     */
    public function handle(PushProductEvent $event)
    {
        $totalProduct = $event->totalProduct;
        $shopId = $event->shopId;
        $count = Cache::get('push_product_'.$shopId, 0);
        $new_total = $totalProduct +  $count;
        Cache::forever('push_product_'.$shopId, $new_total);
    }
}
