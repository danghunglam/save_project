<?php

namespace App\Listeners;

use App\Events\AutoUpdatePrice;
use App\Events\AutoUpdatePriceEvent;
use App\Helpers\ProductHelper;
use App\ShopifyApi\ProductsApi;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class UpdateShopifyListeners
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  AutoUpdatePriceEvent  $event
     * @return void
     */
    public function handle(AutoUpdatePriceEvent $event)
    {
        $autoUpdate = $event->_autoUpdate;
        $primaryEmailAddress = $event->_primaryEmailAddress;
        $shop = $event->_shop;
        $data = $event->_data;
        $productId = $event->_productId;
        $productApi = new ProductsApi($shop->myshopify_domain, $shop->access_token);
        $checkVariants = ProductHelper::checkVariant($productId, $data);
        //When one of your products is no longer available at AliExpress, we will...
        if( ! $data['status'])
        {
            switch ($autoUpdate['product_no_longer_available_aliexpress']) {
                case config('setting.auto_update_when_product_no_longer_available_aliexpress.do_nothing'):
                    break;
                case config('setting.auto_update_when_product_no_longer_available_aliexpress.unpublish_product'):
                    //Unpublish product, soft delete
//                    $productApi->
                    break;
                case config('setting.auto_update_when_product_no_longer_available_aliexpress.set_quantity_to_zero'):
                    //Set all variant quantity in product to zero

                    break;
            }
        }

        //When one of your product's variants is no longer available at AliExpress, we will...
        if( ! empty($checkVariants['variantNotAvailable']))
        {
            switch ($autoUpdate['product_variant_no_longer_available_aliexpress']) {
                case config('setting.auto_update_when_product_variant_no_longer_available_aliexpress.do_nothing'):
                    break;
                case config('setting.auto_update_when_product_variant_no_longer_available_aliexpress.remove_variant'):

                    break;
                case config('setting.auto_update_when_product_variant_no_longer_available_aliexpress.set_quantity_to_zero'):
                    $argsUpdate = [];
                    foreach ($checkVariants['variantNotAvailable'] as $variant)
                    {
                        $argsUpdate[$variant->id] = [
                            'source_quantity' => 0
                        ];
                    }
                    //Set quantity to zero

                    break;
            }
        }

        //When the cost of one of your products at AliExpress changes, we will...
        if( ! empty($checkVariants['variantChangePrice']))
        {
            switch ($autoUpdate['product_cost_change_aliexpress']) {
                case config('setting.auto_update_when_product_cost_change_aliexpress.do_nothing'):
                    break;
                case config('setting.auto_update_when_product_cost_change_aliexpress.update_automatically'):
                    $argsUpdate = [];
                    $variantChangePrice = $checkVariants['variantChangePrice'];
                    foreach ($variantChangePrice as $variant)
                    {
                        $argsUpdate[$variant->id] = [
                            'source_price' => $variantChangePrice['new_price'],
                            'compare_at_price' => $variantChangePrice['new_price'] * $variantChangePrice['range_compare_at_price'],
                            'price' => $variantChangePrice['new_price'] * $variantChangePrice['range_price'],
                        ];
                    }
                    //Update price variants

                    break;
            }
        }

        //When one of your product is out of stock at AliExpress, we will....
        if( ! empty($checkVariants['variantOutOfStock']))
        {
            switch ($autoUpdate['when_one_product_is_out_of_stock_on_aliexpress']) {
                case config('setting.when_one_product_is_out_of_stock_on_aliexpress.do_nothing'):
                    break;
                case config('setting.when_one_product_is_out_of_stock_on_aliexpress.set_quantity_to_zero'):
                    $argsUpdate = [];
                    $variantOutOfStock = $checkVariants['variantOutOfStock'];
                    foreach ($variantOutOfStock as $variant)
                    {
                        $argsUpdate[$variant->id] = [
                            'quality' => 0
                        ];
                    }
                    //Update quality

                    break;
            }
        }

    }
}
