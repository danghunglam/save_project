<?php

namespace App\Listeners;

use App\Events\UninstallAppEvent;
use http\Env\Response;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Cache;
use App\Repository\ShopRepository;
use App\Jobs\RemoveThemesCodeJob;

class RemoveThemeCodeListeners
{
    /**
     * LoadingListeners constructor.
     */

    public function __construct()
    {

    }

    /**
     * Handle the event.
     *
     * @param  UninstallAppEvent $event
     * @return void
     */
    public function handle(UninstallAppEvent $event)
    {
        $shopId = $event->shopId;
        $shopRepo = new ShopRepository();
        $shopDetail = $shopRepo->detail($shopId);
        $shopDomain = $shopDetail->domain;
        $accessToken = $shopDetail->access_token;
        dispatch(new RemoveThemesCodeJob($shopDomain, $accessToken))->onQueue('init_app_before');
    }
}
