<?php

namespace App\Listeners;

use App\Events\OrderFulfillmentEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Cache;

class CountOrderFulfillmentListeners
{
    /**
     * LoadingListeners constructor.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  OrderFulfillmentEvent $event
     * @return void
     */
    public function handle(OrderFulfillmentEvent $event)
    {
        $shopId = $event->shopId;
        if(Cache::has('order_fulfillment_'.$shopId)) {
            Cache::increment('order_fulfillment_'.$shopId, 1);
        }
    }
}
