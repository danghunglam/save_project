<?php
return [
    'product_update_text' => 'Product Update'
];