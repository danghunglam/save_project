<?php
return [
	'site_title' => 'AliCashback',
	'sidebar_dashboard' => 'Dashboard',
	'sidebar_overview' => 'Overview',
	'sidebar_import_list' => 'Import List',
	'sidebar_import_settings' => 'Import Settings',
	'sidebar_my_products' => 'Product List',
	'sidebar_product_settings' => 'Product Settings',
    'sidebar_product_status' => 'Product Status',
	'sidebar_orders' => 'Order List',
	'sidebar_orders_settings' => 'Order Settings',
	'sidebar_manage_tracking' => 'Manage Tracking',
	'sidebar_customers' => 'Customers',
	'sidebar_chat_room' => 'Chat Room',
	'sidebar_calendar' => 'Calendar',
	'sidebar_support' => 'Support',
	'sidebar_help_center' => 'Help Center',
	'sidebar_settings' => 'Settings',
    'sidebar_statistics' => 'Statistics',
    'sidebar_manage_account'=> 'Manage Account',
    'sidebar_community' => 'Community'
];
