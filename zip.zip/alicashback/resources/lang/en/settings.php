<?php
return [
	//== Shop Settings
	'text_settings_title' => 'Settings',
	'text_save_settings' => 'Save Settings',
	'text_restore_settings' => 'Restore Default',

	'text_notification' => 'Notification',
	'text_general_checkbox_1' => 'Publish products after pushing them to your store',
	'text_general_checkbox_2' => 'Set products as taxable',
	'text_general_checkbox_3' => 'Send notification email to customers about the order fulfillment',
	'text_placeholder_general_1' => 'Fulfillment tracking URL (optional)',
	'text_tooltip_fulfillment_url' => 'This URL is used to track the fulfillment, it will be added to notification email to your customers',

	'text_auto_updates' => 'Auto Updates',

	'text_auto_updates_label_1' => 'When one of your products is no longer available from AliExpress, we will...',
	'text_auto_updates_radio_11' => 'Do nothing',
	'text_auto_updates_radio_12' => 'Unpublish product',
	'text_auto_updates_radio_13' => 'Set quantity to zero',

	'text_auto_updates_label_2' => 'When one of your product\'s variants is no longer available from AliExpress, we will...',
	'text_auto_updates_radio_21' => 'Do nothing',
	'text_auto_updates_radio_22' => 'Remove variant',
	'text_auto_updates_radio_23' => 'Set quantity to zero',

	'text_auto_updates_label_3' => 'When the cost of one of your products from AliExpress changes, we will...',
	'text_auto_updates_radio_31' => 'Do nothing',
	'text_auto_updates_radio_32' => 'Update automatically',
	'text_auto_updates_radio_33' => 'Set quantity to zero',

	'text_auto_updates_label_4' => 'When one of your product is out of stock from AliExpress, we will....',
	'text_auto_updates_radio_41' => 'Do nothing',
	'text_auto_updates_radio_42' => 'Update automatically',
    'text_auto_updates_radio_43' => 'Set quantity to zero',

	//== Pricing Rules
	'text_pricing_rules' => 'Pricing Rule',
	'text_title_cost_range' => 'Product Cost',
	'text_title_item_price' => 'Product Item',
	'text_title_compared_price' => 'Comparing Price',
	'text_add_cost_range' => 'Add Cost Range',

	//== Order setting
	'text_order_setting' => 'Order setting',
	'text_label_input_1' => 'Primary shipping method',
	'text_label_input_1_1' => 'Backup shipping method',
	'text_label_input_2' => 'Autofill phone number',
	'text_label_input_3' => 'Note to supplier on AliExpress checkout page',
	'text_auto_bypass_captcha' => 'Automated fulfillment',
	'text_auto_completed_order' => 'Auto completed order (automation payment)',
	'tooltip_shipping_method' => 'Automatically select this shipping method during the checkout on AliExpress',
	'tooltip_override_phone' => "Autofill phone number when Customer's phone number field is empty",
	'text_cheapest_shipping_method' => 'Cheapest method',
	'text_specific_method' => 'Specific method',

	//== Api setting
	'text_api_settings' => 'API Settings',
	'text_affiliate_programs' => 'Affiliate programs',
	'text_api_settings_radio_1' => 'Do not use any affiliate programs',
	'text_api_settings_radio_2' => 'Use AliExpress. com programs credentials ',

	//== Others
	'text_others' => 'Others',
	'text_others_checkbox_1' => 'Receive reports via email',
	'text_other_radio_1' => 'Daily email',
	'text_other_radio_2' => 'Weekly email',
	'text_other_radio_3' => 'Monthly email',

	'text_others_label_1' => 'Primary email address',
	'tooltip_primary_email' => 'This email address will be used in all of your messages to your customers',
	'text_others_label_2' => 'Your timezone',

	'text_notify_me' => 'Notify me',

	//Import Product Reviews
	'text_product_reviews' => 'Import Product Reviews',
	'text_auto_import_review' => 'Auto imported product reviews',

	//== Notification
	'update_setting_success' => 'Setting updated successfully'
];
