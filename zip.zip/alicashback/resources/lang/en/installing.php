<?php
return [
    'install_title_1' => 'Installing Ali Orders',
    'install_text_1' => 'Hold tight, we\'re setting up your Ali Orders and getting things ready for you. This could take up to a minute.',
    'install_step_1' => 'Importing <br/> Product list',
    'install_step_2' => 'Importing <br/> Order list',
    'install_step_3' => 'Creating charts',
    'install_step_4' => 'Finishing',
    'install_text_2' => '<span class="color-skin fw-600">Auto Fulfillment</span> & <span class="color-skin fw-600">Product Importing</span> features require <span class="color-skin fw-600">Chrome\'s extension</span> to run. Do you want to install it now?',
    'install_text_3' => 'Installation was successful. Happy selling with Ali Orders!.'
];