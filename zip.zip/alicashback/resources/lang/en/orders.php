<?php
return [
	'text_placeholder_keyword_filter' => 'Search order by keywords',
	'text_all_status_filter' => 'All Order Status',
	'text_pending_status_filter' => 'Pending',
	'text_complete_status_filter' => 'Complete',

	'text_sync_order' => 'Update Order',
	'text_export_csv' => 'Export CSV',
	'text_export_xls' => 'Export XLS',
	'text_place_all_order' => 'Place All Order',
	'text_mark_all_shipped' => 'Mark All Shipped',
    'text_import_tracking_code_csv' => 'Import Tracking Code CSV',
    'text_import_tracking_code_xls' => 'Import Tracking Code XLS',
];