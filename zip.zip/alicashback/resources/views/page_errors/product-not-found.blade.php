@extends('layout.backend', ['page_title' => 'Product not found'])
@section('styles')
    <link href="{{ URL::asset('css/backend/general-setting.css') }}" rel="stylesheet"/>
    <style>
        .content-container{
            padding-top: 30px;
        }
    </style>
@endsection

@section('header')
    @include('layout.header', ['page_title' => 'Product not found'])
@endsection


@section('container_content')
    <div class="general-setting-wrap">
        <div class="text-center">
            <h2>{{ $message }}</h2>
            <img src="{{ url('images/backend/404.jpg') }}" style="max-width: 100%;width: 400px">
        </div>
    </div>
@endSection