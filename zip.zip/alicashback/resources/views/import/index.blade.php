@extends('layout.backend')

@section('head_extend')
	{{--  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">  --}}
	<link href="{{ URL::asset(mix('css/import.css')) }}" rel="stylesheet">
	<link href="{{ URL::asset('bower_component/trumbowyg/dist/ui/trumbowyg.min.css') }}" rel="stylesheet">
	<link href="{{ URL::asset('bower_component/bootstrap-tagsinput/dist/bootstrap-tagsinput.css') }}" type="text/css" rel="stylesheet">
	<link href="{{ URL::asset('bower_component/magnific-popup/dist/magnific-popup.css') }}" type="text/css" rel="stylesheet">
@endsection

@section('content_container')
	<div id="import-product" class="import-list-content-wrap">
		<div class="box-import" >
			<div class="loading text-center" v-if="loading" style="padding-top: 90px;">
				<vue_loaders_circle loading="Loading..."></vue_loaders_circle>
			</div>
			<div v-else class="import-list-empty-box">
				<div class="import-filter-wrap" v-show="product_result === 'search' || products.length > 0">
					<div class="form-group">
						<input type="text" ref="keyword"
							   v-model="filters.keyword"
							   @keypress.enter="searchProduct"
							   placeholder="Search by keyword">
					</div>
				</div>
				<div class="import-list-wrapper" v-if="!products.length">
					<div class="content-not-found-wrap" v-if="product_result != 'search'">
						<div>
							<img src="{{ URL::asset('images/backend/import-list-empty.png') }}" />
						</div>
						<div style="padding-left: 20px;">
							<h2>Your Import List is Empty</h2>
							<p>You can add products to this list from the <a style="cursor: pointer;" onclick="redirectAliExpress()" >AliExpress product page</a></p>
						</div>
					</div>
					<div  v-else>
						<div class="content-not-found-wrap">
							<h2>
								No result product
							</h2>
						</div>
					</div>
				</div>

				<div v-else>
					<div class="import-action-wrap">
						<div class="pull-left">
							<label class="checkbox-style checkbox-text-o" for="select-all">
								<input id="select-all"  @click="checkAll" type="checkbox">
								<span class="checked-style"></span>
							</label>
							<span class="total-filter"><b v-text="products_select.length"></b> of <b v-text="total_product"></b> <span v-text="((total_product > 1 || total_product==0)) ? 'Products' : 'Product'"></span></span>

							<div class="dropdown box-dropdown" v-show="(products_select.length > 0)">
								<span class="box-dropdown-toggle" data-toggle="dropdown">Bulk Action</span>
								<div class="dropdown-menu box-dropdown-menu">
									<ul>
										<li @click="bulkActionProduct('push')">Push products to shop</li>
										<li v-show="products_select.length > 1" @click="bulkActionProduct('edit')">Mass apply edit</li>
										<li @click="bulkActionProduct('delete')">Remove from import list</li>
									</ul>
								</div>
							</div>

							{{--  <span class="pull-right import-action">
								<select class="bulkAction" v-model="bulkProduct" @change="bulkActionProduct" v-show="(products_select.length > 0)">
									<option value="" disabled selected>Bulk action</option>
									<option value="push">Push products to shop</option>
									<option value="delete">Remove from import list</option>
								</select>
							</span>  --}}
						</div>
						<div class="pull-right">
							<button class="button-style-sm-o button-style-sm push-to-shop-btn remove-all-btn remove-all-btn-import ars-btn-o"
									@click="removeAllProducts"
									:disabled="is_remove_all" v-html="(is_remove_all) ? '<span></span>Removing...' : 'Remove All Products'"></button>
							{{--<button class="push-all-shop-btn button-style-sm"--}}
									{{--@click="pushAllProducts"--}}
									{{--:disabled="is_push_all" v-html="(is_push_all) ? 'Pushing...' : '<span></span>Push All to Shop'"></button>--}}
						</div>
					</div>
					<modal_shipping_country v-on:freight="infoShipping" ref="modal_shipping_country" v-bind:props_product="current_product" ></modal_shipping_country>
					<modal_split_product v-bind:split_product="split_product" v-on:refesh_page="refeshPage"></modal_split_product>
					<div class="import-list-wrapper">
							<ul class="import-list-wrap">
								{{--List item--}}
								<import_item v-for="product in products"
											 :key="product.id"
											 v-on:check-product="checkProduct"
											 v-on:remove-product="removeItemProduct"
											 v-on:push-product="pushItemProduct"
											 v-on:show_shipping_method="showModalShipingCountry"
											 v-on:load_shipping = "loadShipping"
											 v-on:split_product="splitProduct"
											 v-on:check_edit_product="checkEditproduct"
											 v-bind:props_freight="freight"
											 v-bind:props_product="product"
											 v-bind:props_current_product="shipping_product"
											 v-bind:settings="settings"
											 v-bind:product_type="product_type"
											 v-bind:collections="custom_collection"
											 v-bind:bulk_edit_product="bulkEditProduct"></import_item>
							</ul>

							{{--Pagination--}}
							<div class="pagination-wrap" v-show="pagination.last_page > 1">
								<pagination
										:pagination="pagination"
										:offset="6"
										@paginate="clickPagination"></pagination>
							</div>

						</div>
					<modal_bulk_edit_product v-on:cancel_bulk_edit="cancelBulkEdit" v-bind:props_products_select = "product_select_bulk_edit" v-bind:product_type="product_type" v-bind:props_is_loading_bulk_edit="is_loading_bulk_edit" v-bind:props_bulk_edit_product = "bulkEditProduct" v-bind:collections="custom_collection" v-on:save_bulk_product="saveBulkProduct"></modal_bulk_edit_product>
				</div>
			</div>
		</div>

		<toast_process
				v-bind:process_title="'Pushing product'"
				v-bind:process_successful="'Pushing Successfully'"
				v-bind:process="import_process"
				v-bind:process_type="process_import_type"
				v-bind:process_tooltip="'Please wait a while after <b>Bulk push products</b> to continue using this function'"
				v-on:close_process="closeToastProcess"></toast_process>
		<modal_leave_page
				v-bind:href="leave_page_href"
				v-bind:title="'Leave page?'"
				v-bind:content="'You haven\'t finish import reviews. Do you want to leave without finishing?'"
				v-bind:cancel="'Stay on this page'"
				v-bind:submit="'Leave this page'"></modal_leave_page>
	@include('layout.modal_vote')
	</div>
@endsection

@section('footer_extend')
	<script>
		window.currency = "{{ $currency }}"
		window.exchange = "{{ $exchange }}"
	</script>
	{{--  <script type="text/javascript" charset="utf-8" src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js"></script>  --}}
	<script src="{{ URL::asset('bower_component/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js') }}"></script>
	<script src="{{ URL::asset('bower_component/trumbowyg/dist/trumbowyg.min.js') }}"></script>
	<script src="{{ URL::asset('bower_component/Sortable/Sortable.min.js') }}"></script>
	<script src="{{ URL::asset('bower_component/magnific-popup/dist/jquery.magnific-popup.min.js') }}"></script>
	<script src="{{ URL::asset(mix('js/modules/import_product.min.js')) }}"></script>
@endsection
