<!DOCTYPE html>
<html>
    <head>
        @include('layout.head')
        @yield('header_extend')
        @yield('GA_head')
    </head>
    <body style="background: #FFF">
        <div class="wrapper">
            @yield('content_container')
        </div>
        <script src="{{ URL::asset('bower_component/jquery/dist/jquery.min.js') }}"></script>
        <script src="{{ URL::asset('bower_component/bootstrap/dist/js/bootstrap.min.js') }}"></script>
        <script src="{{ URL::asset('bower_component/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
        <script src="{{ URL::asset('bower_component/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.js') }}"></script>
        <script src="{{ URL::asset('bower_component/chosen/chosen.jquery.min.js') }}"></script>
        <script src="{{ URL::asset('bower_component/vue/dist/vue.min.js') }}"></script>
        <script src="{{ URL::asset('bower_component/axios/dist/axios.min.js') }}"></script>
        <script src="{{ URL::asset('bower_component/jquery-validation/dist/jquery.validate.min.js') }}"></script>
        <script src="{{ URL::asset('bower_component/moment/min/moment.min.js') }}"></script>
        <script src="{{ URL::asset('bower_component/vue-select/dist/vue-select.js') }}"></script>
        <script src="https://js.pusher.com/4.1/pusher.min.js"></script>
        <script src="{{ URL::asset('js/main.min.js') }}"></script>

        @yield('footer_extend')
        <script type="text/javascript">
            //Extension install
            function successInstall() {
                window.location.href = appUrl
                // location.reload();
            }
            function failureInstall() {
                window.open('https://chrome.google.com/webstore/detail/'+chromeExtensionId, '_blank');
            }
            $(function(){
                console.log('extension install inline')
                $('.extension-install-btn').on('click', function () {
                    window.open('https://chrome.google.com/webstore/detail/'+chromeExtensionId, '_blank');
                });
            });
        </script>
    @yield('GA_body')
    </body>
</html>