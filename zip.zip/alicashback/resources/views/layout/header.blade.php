<header id="header">
    <div class="logo">
        <a class="nav-hamburger" href="{{ route('dashboard.index') }}">
            <img src="{{ URL::asset('images/backend/logo-bar-menu.png') }}" />
        </a>
        <a class="logo-a" href="{{ route('dashboard.index') }}"><img src="{{ URL::asset('images/backend/ali-order-logo.png') }}" alt="Ali Orders"></a>
    </div>
    <nav class="header-top">
        <div class="breadcrumb-wrap">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('dashboard.index') }}"><i class="mdi mdi-home-outline"></i>Ali Orders</a></li>
                <li><a>{{ config('header_meta.'.session('current_route_name').'.breadcrumb') }}</a></li>
            </ol>
        </div>
        @if(session('shopDomain'))
            <div class="shopify-name-wrap">
                <ul class="shopify-name">
                    <li class="oberlo-app-wrap">
                        <span id="ao__1_click_btn" class="oberlo-app-btn" target="_blank" title="Easy transfer from other apps like Oberlo to Ali Orders in just 1 - Click"
                              data-toggle="tooltip" data-placement="left"
                              data-container=".oberlo-app-wrap" onclick="redirectOberloProduct()">
                            <span id="ao__1_click_spin" class="{{--animate-spin--}}" >
                                <i class="mdi mdi-autorenew"></i>
                            </span>
                            1 - Click Sync Product
                        </span>
                        <div class="ao__circle_loading">
                            <div id="ao__sync_product_loading" class="ao__circle_active_border">
                                <div id="ao__circle_sync_product" class="ao__circle">
                                    <span id="ao__sync_product_prect" class="ao__circle_prec">0</span>
                                    <span class="ao__circle_start" data-deg="90"></span>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a class="more-app-btn">
                            <span class="mdi mdi-view-dashboard"></span>
                        </a>
                        <div class="more-app-wrap">
                            <ul class="more-app-list">
                                <li>
                                    <a href="https://apps.shopify.com/ali-reviews" target="_blank">
                                        <span class="more-app-icon"><img src="{{ URL::asset('images/backend/Reviews.png') }}" alt=""></span>
                                        <h3>Ali Reviews</h3>
                                        <p>1 Click import 1000+ AliExpress product reviews</p>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://apps.shopify.com/shipping-information-by-fireapps" target="_blank">
                                        <span class="more-app-icon"><img src="{{ URL::asset('images/backend/Sale.png') }}" alt=""></span>
                                        <h3>Sales Box</h3>
                                        <p>More conversions with sales promotions</p>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://chrome.google.com/webstore/detail/alihunter-aliexpress-prod/mpajidobdpdigheplhpfggmeldjcpgfh" target="_blank">
                                        <span class="more-app-icon"><img src="{{ URL::asset('images/backend/alihunter-icon.png') }}" alt=""></span>
                                        <h3>Ali Hunter</h3>
                                        <p>Find winning product in 1 click</p>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>

                    {{--<li>
                        <a class="icon-notify-app new-notify">
                            <span class="icon-ali icon-icon_chat-notification-1">
                            </span>
                        </a>
                    </li>--}}
                    <li>
                        <a class="icon-notify-app new-notify">
                            <span class="mdi mdi-bell"></span>
                            <span v-if="total_notification" class="icon-ali icon-ic-notifications-24px">
                                <span v-text="total_notification>9?'9+':total_notification"></span>
                            </span>
                        </a>
                        <div class="notifi-app-wrap menu-block-dropdown">
                            <div class="notifications">
                                <div class="notifications-title">
                                    <h3>Notifications</h3>
                                </div>
                                <notification v-on:number_notification="numberNotification"></notification>
                            </div>
                        </div>
                    </li>

                    <li class="shopify-profile">
                        <span>{{ session('shopDomain','') }}<i class="mdi mdi-chevron-down"></i></span>
                        <span id="shopAvatar" class="avatar"></span>
                        <div class="shopify-name-link shopify-name-dropdown">
                            <div class="modal-body multiaccount-body">
                                <div class="flex-box">
                                    <div class="avatar-account avatar-current-shop">
                                        <span id="shopAvatar-current-shop" class="avatar"></span>
                                    </div>
                                    <div class="">
                                        <ul class="">
                                            <li class="current-account">
                                                <h4>{{ session('shopDomain','') }}</h4>
                                            </li>
                                            <li><a class="go-store-link" href="https://{{ session('shopDomain', '') }}" target="_blank"><span class="mdi mdi-store"></span> Go to store</a></li>
                                            <li><a href="https://{{ session('shopDomain', '') }}/admin/" target="_blank"><span class="mdi mdi-open-in-new"></span> Back to Shopify</a></li>
                                            <li><a class="view-tutorial-onboard"><span class="mdi mdi-book-variant"></span> Quick Tutorial</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="list-account">
                                @foreach (session('user_shop', []) as $shop)
                                    @if(session('shopId') != $shop['shop']['id'])
                                        <div class="account-item" id="store_account_{{ $shop['shop']['id'] }}">
                                            <a href="{{ $shop['auth'] }}">
                                                <div class="account-info">
                                                    <div class="avatar">
                                                        <span id="shopAvatar-{{$shop['shop']['id']}}" data-owner="{{isset($shop['shop']['shop_owner'])?$shop['shop']['shop_owner']:'Ali Orders'}}" class="avatar"></span>
                                                        {{-- <span class="number-notify">25</span> --}}
                                                    </div>
                                                    <span>{{ $shop['shop']['myshopify_domain'] }}</span>
                                                </div>
                                            </a>
                                            <span @click="removeAccount('{{ $shop['shop']['id'] }}', '{{ $shop['shop']['myshopify_domain'] }}')" class="mdi mdi-delete-forever"></span>
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                            <div class="multiaccount-footer modal-footer">
                                <button class="modal__ok_button">Add Store</button>
                                <a href="{{ route('apps.logout') }}" class="modal__cancel_button">Logout</a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        @endif
    </nav>
</header>
<div id="popup-header">
    <add_account></add_account>
    <delete_account></delete_account>
</div>
