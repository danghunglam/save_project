<!-- Delete Reviews Modal-->
<div id="voteForUsModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">
        <!-- Modal content-->
        <div class="modal-content" style="width: 600px; text-align: center;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="icon-ali icon-ic-highlight-off-24px"></i></button>
                {{--<h4 class="modal-title">Vote for us</h4>--}}
            </div>
            <div class="modal-body" style="padding: 20px; padding-bottom: 25px; padding-top: 10px;">
                <form id="formVoteForUs">
                    <div class="vote-for-us-wrap">
                        <img src="{{ URL::asset('images/great-app.png') }}" style="margin-bottom: 15px;">

                        <div class="step-1">
                            <h4 style="font-size: 15px; font-weight: 600; margin-bottom: 10px;">Thank you for being our valued customer</h4>
                            <p style="font-size: 13px; line-height: 1.6; font-weight: 400;">If you don't mind, please take a moment to let us know how you feel about this
                                app.<br> We always want to improve to make sure every dollar you pay is well worth.</p>
                            <div class="vote-for-us-btn-wrap" style="font-size: 13px; line-height: 1.4; margin-top: 25px;">
                                <div class="row" style="display: flex; align-items: center;">
                                    <div class="col-xs-6 txt-right">
                                        <button type="button" class="btn-bad-review" style="font-weight: 400;">
                                            <div>
                                                <span class="icon-ali icon-ic-sentiment-dissatisfied-24px"></span>
                                            </div>
                                            Not good enough!<br/>
                                            I have some feedback
                                        </button>
                                    </div>

                                    <div class="col-xs-6 txt-left">
                                        <a  class="btn-good-review txt-center" href="https://apps.shopify.com/ali-orders-fulfillment-automation?reveal_new_review=true" target="_blank" style="font-weight: 400; font-size: 13px;">
                                            <div>
                                                <span class="icon-ali icon-ic-sentiment-satisfied-24px"></span>
                                            </div>
                                            Great App!<br/>
                                            I'll leave a good review
                                        </a>
                                    </div>
                                </div>
                                <div class="left-feedback-wrap">
                                    <a href="javascript:void(0)" data-dismiss="modal" style="font-size: 11px; font-weight: 400;">I've already left a feedback</a>
                                </div>
                            </div>
                        </div>
                        <div class="step-2" style="display: none">
                            <h4>Thank you for being our valued customer</h4>
                            <p>We're really sorry for any inconvenience that may cause to you. <br>Let us know more about your problem?</p>
                            <textarea id="feedback-vote" class="form-control" name="feedback" rows="5" placeholder="Not good enough, I have some feedback"></textarea>
                            <button class="button-style-dark-sm" type="submit" style="margin-top: 30px">
                                Submit
                            </button>
                        </div>
                    </div>
                    <input type="hidden" value="{{ csrf_token() }}" name="_token">
                    <input type="hidden" value="" name="plan">
                </form>
            </div>
        </div>
    </div>
</div>