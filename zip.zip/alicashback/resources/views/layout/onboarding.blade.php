<div class="tutorial-modal-wrapper">
    <div class="tutorial-modal-step tutorial-modal-step-1" data-tutorial-step="1">
        <span class="tutorial-modal-close"><i class="mdi mdi-close"></i></span>
        <div class="tutorial-modal-body">
            <p>View your business status in Dashboard</p>
        </div>
        <div class="tutorial-modal-step-btn">
            <span class="tutorial-step-next-btn tutorial-step-next-first">Next</span>
        </div>
    </div>
    <div class="tutorial-modal-step tutorial-modal-step-2" data-tutorial-step="2">
        <span class="tutorial-modal-close"><i class="mdi mdi-close"></i></span>
        <div class="tutorial-modal-body">
            <p>Manage all your imported products in Import List</p>
        </div>
        <div class="tutorial-modal-step-btn">
            <span class="tutorial-step-prev-btn">Previous</span>
            <span class="tutorial-step-next-btn">Next</span>
        </div>
    </div>

    <div class="tutorial-modal-step tutorial-modal-step-3" data-tutorial-step="3">
        <span class="tutorial-modal-close"><i class="mdi mdi-close"></i></span>
        <div class="tutorial-modal-body">
            <p>Manage your published products in Product List</p>
        </div>
        <div class="tutorial-modal-step-btn">
            <span class="tutorial-step-prev-btn">Previous</span>
            <span class="tutorial-step-next-btn">Next</span>
        </div>
    </div>

    <div class="tutorial-modal-step tutorial-modal-step-4" data-tutorial-step="4">
        <span class="tutorial-modal-close"><i class="mdi mdi-close"></i></span>
        <div class="tutorial-modal-body">
            <p>You can check all your orders here. Ali Orders will help you fulfill all orders in just 1 click</p>
        </div>
        <div class="tutorial-modal-step-btn">
            <span class="tutorial-step-prev-btn">Previous</span>
            <span class="tutorial-step-next-btn">Next</span>
        </div>
    </div>

    <div class="tutorial-modal-step tutorial-modal-step-5" data-tutorial-step="5">
        <span class="tutorial-modal-close"><i class="mdi mdi-close"></i></span>
        <div class="tutorial-modal-body">
            <p>Sync your old orders & products to Ali Orders by clicking <span class="highlight-update-button">Update link</span> button in Order List and Product List</p>
        </div>
        <div class="tutorial-modal-step-btn">
            <span class="tutorial-step-prev-btn">Previous</span>
            <span class="tutorial-step-next-btn">Next</span>
        </div>
    </div>
    <div class="tutorial-modal-step tutorial-modal-step-6" data-tutorial-step="6">
        <span class="tutorial-modal-close"><i class="mdi mdi-close"></i></span>
        <div class="tutorial-modal-body">
            <p>If you come from Oberlo, click this button to update all your product links</p>
        </div>
        <div class="tutorial-modal-step-btn">
            <span class="tutorial-step-prev-btn">Previous</span>
            <span class="tutorial-step-next-btn">Next</span>
        </div>
    </div>

    <div class="tutorial-modal-step tutorial-modal-step-7" data-tutorial-step="7">
        <span class="tutorial-modal-close"><i class="mdi mdi-close"></i></span>
        <div class="tutorial-modal-body">
            <p>Settings like Pricing Rules, Shipping Method...can be found under each menu section</p>
        </div>
        <div class="tutorial-modal-step-btn">
            <span class="tutorial-step-prev-btn">Previous</span>
            <span class="tutorial-step-finish">Finish</span>
        </div>
    </div>
</div>

