<div class="sidebar-wrap">
    <div class="sidebar-container">
        <nav class="nav-sidebar">
            <ul class="nav-sidebar-list">
                <li class="@if(session('current_route_name') == 'dashboard_index') active show-submenu @endif sidebar-dashboard">
                    <a class="nav-menu-a" href="{{ route('dashboard.index') }}">
                        <i class="mdi mdi-home-outline"></i>
                        <span class="menu-txt">{{ __('commons.sidebar_dashboard') }}</span>
                    </a>
                    <ul class="nav-subsidebar-list">
                        <li class="@if(session('current_route_name') == 'dashboard_index') active @endif nav-submenu-parent">
                            <a class="nav-menu-a" href="{{ route('dashboard.index') }}">
                                <span class="menu-txt">{{ __('commons.sidebar_dashboard') }}</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="@if(session('current_route_name') == 'import_index') active show-submenu @endif @if(session('current_route_name') == 'setting_pricing_rule') active-subnav  @endif sidebar-import">
                    <a class="nav-menu-a" href="{{ route('import.index') }}" data-menu-id="1">
                        <i class="mdi mdi-inbox-arrow-down"></i>
                        <span class="menu-txt">{{ __('commons.sidebar_import_list') }} <span class="badge total_import_product_number">{{ isset($total_import_product) ? $total_import_product : 0 }}</span></span>
                    </a>
                    <ul class="nav-subsidebar-list">
                        <li class="@if(session('current_route_name') == 'import_index') active @endif nav-submenu-parent">
                            <a class="nav-menu-a" href="{{ route('import.index') }}">
                                <i class="mdi mdi-inbox-arrow-down"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_import_list') }} <span class="badge total_import_product_number">{{ isset($total_import_product) ? $total_import_product : 0 }}</span></span>
                            </a>
                        </li>
                        <li class="@if(session('current_route_name') == 'setting_pricing_rule') active @endif">
                            <a class="nav-menu-a" href="{{ route('setting.pricing_rule') }}">
                                <i class="mdi mdi-dns"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_import_settings') }}</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="@if(session('current_route_name') == 'products_index') active show-submenu @endif @if(session('current_route_name') == 'products_settings' || session('current_route_name') == 'products_status') active-subnav @endif sidebar-product">
                    <a class="nav-menu-a" href="{{ route('products.index') }}">
                        <i class="mdi mdi-shopping"></i>
                        <span class="menu-txt">{{ __('commons.sidebar_my_products') }}</span>
                    </a>
                    <ul class="nav-subsidebar-list">
                        <li class="@if(session('current_route_name') == 'products_index') active @endif nav-submenu-parent">
                            <a class="nav-menu-a" href="{{ route('products.index') }}" data-menu-id="3">
                            <span class="menu-txt">{{ __('commons.sidebar_my_products') }}</span>
                        </a>
                        </li>
                        <li class="@if(session('current_route_name') == 'products_settings') active @endif">
                            <a class="nav-menu-a" href="{{ route('products.settings') }}" data-menu-id="4">
                                <i class="mdi mdi-clipboard-text"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_product_settings') }}</span>
                            </a>
                        </li>
                        <li class="@if(session('current_route_name') == 'products_status') active @endif">
                            <a class="nav-menu-a" href="{{ route('products.status') }}">
                                <i class="mdi mdi-message-alert"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_product_status') }}</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="@if(session('current_route_name') == 'orders_index') active show-submenu @endif @if(session('current_route_name') == 'orders_settings') active-subnav @endif sidebar-orders">
                    <a class="nav-menu-a" href="{{ route('orders.index') }}">
                        <i class="mdi mdi-cart"></i>
                        <span class="menu-txt">{{ __('commons.sidebar_orders') }}</span>
                    </a>
                    <ul class="nav-subsidebar-list">
                        <li class="@if(session('current_route_name') == 'orders_index') active @endif nav-submenu-parent">
                            <a class="nav-menu-a" href="{{ route('orders.index') }}">
                                <span class="menu-txt">{{ __('commons.sidebar_orders') }}</span>
                            </a>
                        </li>
                        <li class="@if(session('current_route_name') == 'orders_settings') active @endif">
                            <a class="nav-menu-a" href="{{ route('orders.settings') }}" data-menu-id="6">
                                <i class="mdi mdi-package-down"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_orders_settings') }}</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="@if(in_array(session('current_route_name'), ['setting_index', 'setting_supplier', 'setting_api'])) active show-submenu @endif @if(session('current_route_name') == 'setting_manage_account') active-subnav @endif sidebar-settings">
                    <a class="nav-menu-a" href="{{ route('setting.index') }}" data-menu-id="8">
                        <i class="mdi mdi-settings"></i>
                        <span class="menu-txt">{{ __('commons.sidebar_settings') }}</span>
                    </a>
                    <ul class="nav-subsidebar-list">
                        <li class="@if(session('current_route_name') == 'setting_index') active @endif nav-submenu-parent">
                            <a class="nav-menu-a" href="{{ route('setting.index') }}" data-menu-id="8">
                                <i class="mdi mdi-settings"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_settings') }}</span>
                            </a>
                        </li>
                        {{--<li class="@if(session('current_route_name') == 'setting_manage_account') active @endif">
                            <a class="nav-menu-a" href="{{ route('setting.manage_account') }}" data-menu-id="6">
                                <i class="mdi mdi-account-circle"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_manage_account') }}</span>
                            </a>
                        </li>--}}
                    </ul>
                </li>
                <li id="aliorders-help-center" class="@if(session('current_route_name') == 'help_center_index') active @endif sidebar-help-center">
                    <a class="nav-menu-a nav-menu-help" target="_blank" href="https://help.fireapps.io/ali-orders" data-menu-id="9">
                        <i class="mdi mdi-lifebuoy"></i>
                        <span class="menu-txt">{{ __('commons.sidebar_help_center') }}</span>
                    </a>
                    <ul class="nav-subsidebar-list">
                        <li class="nav-submenu-parent">
                            <a class="nav-menu-a" target="_blank" href="https://help.fireapps.io/ali-orders" data-menu-id="9">
                                <i class="mdi mdi-lifebuoy"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_help_center') }}</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li id="aliorders-toggle-intercom">
                    <a class="nav-menu-a" style="cursor: pointer" data-menu-id="10">
                        <i class="mdi mdi-headset"></i>
                        <span class="menu-txt">{{ __('commons.sidebar_support') }}</span>
                    </a>
                    <ul class="nav-subsidebar-list">
                        <li class="nav-submenu-parent">
                            <a class="nav-menu-a" href="javascript:void(0)" data-menu-id="10">
                                <i class="mdi mdi-headset"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_support') }}</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li id="aliorders-community">
                    <a href="https://www.facebook.com/groups/fireapps.io" target="_blank" class="nav-menu-a" style="cursor: pointer" data-menu-id="10">
                        <i class="mdi mdi-voice"></i>
                        <span class="menu-txt">{{ __('commons.sidebar_community') }}</span>
                        <span class="new-menu">New</span>
                    </a>
                    <ul class="nav-subsidebar-list">
                        <li class="nav-submenu-parent">
                            <a class="nav-menu-a" href="https://www.facebook.com/groups/fireapps.io" target="_blank" data-menu-id="11">
                                <i class="mdi mdi-voice"></i>
                                <span class="menu-txt">{{ __('commons.sidebar_community') }}</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>

    <div class="sidebar-tooltip">
        <ul class="nav-sidebar-tooltip-list">
            <li></li>
            <li></li>
            <li class="@if(session('current_route_name') == 'import_index') submenu-item-active @endif nav-submenu-item">
                <div class="menu-tooltip right">
                    <div class="tooltip-arrow"></div>
                    <div class="tooltip-inner">{{ __('commons.sidebar_import_settings') }}</div>
                </div>
            </li>
            <li></li>
            <li class="@if(session('current_route_name') == 'products_index') submenu-item-active @endif nav-submenu-item">
                <div class="menu-tooltip right">
                    <div class="tooltip-arrow"></div>
                    <div class="tooltip-inner">{{ __('commons.sidebar_product_settings') }}</div>
                </div>
            </li>
            <li></li>
            <li class="@if(session('current_route_name') == 'orders_index') submenu-item-active @endif nav-submenu-item">
                <div class="menu-tooltip right">
                    <div class="tooltip-arrow"></div>
                    <div class="tooltip-inner">{{ __('commons.sidebar_fulfillment_settings') }}</div>
                </div>
            </li>
            <li>
                <div class="menu-tooltip right">
                    <div class="tooltip-arrow"></div>
                    <div class="tooltip-inner">{{ __('commons.sidebar_settings') }}</div>
                </div>
            </li>
            <li>
                {{--  
                <div class="menu-help-center-box">
                    <div class="help-center-box-wrap">
                        <div class="help-center-link">
                            <ul>
                                <li>
                                    <span>Get Started</span>
                                </li>
                                <li>
                                    <a target="_blank" href="https://help.fireapps.io/ali-orders">Help FAQs</a>
                                </li>
                            </ul>
                        </div>
                        <div class="help-center-video">
                            <iframe width="100%" height="150" class="youtube-video" src="https://www.youtube.com/embed/jMKQUaKGTGw?enablejsapi=1" frameborder="0" allow="encrypted-media" allowfullscreen></iframe>
                            <p>How to use Ali Orders?</p>
                        </div>
                        <div class="help-center-video-list">
                            <h3>Frequently Asked Questions</h3>
                            <ul class="youtube-link-list">
                                <li class="active"><span>- How To Import Product To My Store?</span></li>
                                <li><span>- How To Find Product Have E-Packet Shipping Method?</span></li>
                                <li><span>- How To Fulfill Orders Automatically?</span></li>
                                {{--<li><span>- How To Update AliExpress Link For Products?</span></li>--}}
                                {{--<li><span>- How To Override Products?</span></li>--}}
                                {{--<li><span>Open Help Center</span></li>--}}
                            {{--</ul>
                            <p>
                                <a target="_blank" href="https://help.fireapps.io/ali-orders">Open Help Center</a>
                            </p>
                        </div>
                    </div>
                </div>
                --}}
            </li>
            <li id="aliorders-toggle-intercom">
                <div class="menu-tooltip right">
                    <div class="tooltip-arrow"></div>
                    <div class="tooltip-inner">{{ __('commons.sidebar_support') }}</div>
                </div>
            </li>
        </ul>
    </div>

    <div class="tooltip-dashboard tooltip fade right in" role="tooltip">
        <div class="tooltip-arrow"></div>
        <div class="tooltip-inner">
            <p>You can always go to Dashboard to watch how to use videos</p>
        </div>
    </div>

    <div class="tooltip-policy tooltip fade right in" role="tooltip">
        <div class="tooltip-arrow"></div>
        <div class="tooltip-inner">
            <p>We've just updated our Policy, please kindly check before using the app</p>
        </div>
    </div>
</div>

@section('scripts')
    <script>
        (function($) {
            $('.youtube-link-list li').on('click', function() {
                $('.youtube-link-list li span').removeClass('active');
                $(this).addClass('active');
                var index = $(this).index();
                var video_list = [
                    '<iframe width="100%" height="150" src="https://www.youtube.com/embed/jMKQUaKGTGw?autoplay=1&enablejsapi=1" class="youtube-video" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
                    '<iframe width="100%" height="150" src="https://www.youtube.com/embed/F9bSWejVTtA?autoplay=1&enablejsapi=1" class="youtube-video" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
                    '<iframe width="100%" height="150" src="https://www.youtube.com/embed/_kusm4Hc0xg?autoplay=1&enablejsapi=1" class="youtube-video" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
                    '<iframe width="100%" height="150" src="https://www.youtube.com/embed/0HAPXhWdVhE?autoplay=1&enablejsapi=1" class="youtube-video" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
                    '<iframe width="100%" height="150" src="https://www.youtube.com/embed/jsRwAfsxD2Y?autoplay=1&enablejsapi=1" class="youtube-video" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>'
                ];

                $('.help-center-video').html(video_list[index]);
            });

            {{--  $('#aliorders-help-center').on('click',function () {
                $('.nav-sidebar-list > li, .nav-subsidebar-list li').removeClass('active')
                $(this).toggleClass('active')
            });  --}}
        })(jQuery);
    </script>
@endsection
