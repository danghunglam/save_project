@php
    $is_chrome = 1;
    $browser = \App\Helpers\Helpers::getBrowser();
@endphp
@if($browser['code'] != 'Chrome')
    @php $is_chrome = 0; @endphp
@else
    @if($browser['code'] != 'Chrome')
        @php $is_chrome = 0; @endphp
    @endIf
@endIf

@if($is_chrome == 1)
    <div id="extension-install-timeout" class="extension-install" style="text-align: center; display: none;">
        <div class="extension-block-icon">
            <img style="width: 43px; heigh: auto;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAHj0lEQVRoge2ae4xUVx3HP+ee+5qd2V2BlfIuUJYNKBRKG5ai0TZVUpXWWoslmioNmpoQCZq1Kk1ra0wxJcYGSmgJRgUixoIai61FW9bVSsOrYqnEpVIpZR+wz9l53Ofxj9lldtl57XagkvSbTGb3/s459/s959zf73d+d0Rfj//C5obkjGONaWUYgBAIQABa/7cgA4EYdl2IAVvGns+mkR0XMXjMAbuW+VvL2rJ9s+MJIPTgupt17tlYgXj8a93Nx5vULKmH/Y2yNxryEVkBw69nBRSyDRBB5Bh/oO8gG8PulR3fdxVzb42gH210A9OUKBUM6pIPhWzF+4b5iOUSn7PdoN1hKP59wEfTjSKc/o8hjcz2uqrxvoD3Gu8LeK+hX7aRFSgFChDqEveYMw70u0ctE8xKxWUREPggJVTVCKSWCU6aENkgpWUDnSb6v8nYnaQi3h5i6JeE5CslwHMUk2sldz8YZepciSYHZl1cTC0uroAA0W9XKmNyEoqDv+7j5acdDFE8SJVVgJdWzLheZ/WPY4ybLEvq03PeRQhBVU2GrGELbnugirdPtNH8so9lFaZYNgFuWjGn3uT+J2JUf7D4Jm7/b5pnf9TOm6/6SE1jzkcifPbBsYyZkBEyaa7kX/u9KyPATSsW3GLylQ2VRKuLb9xkr8+2defoOGWw5HM1BC4c+k0Cp7eb1Vtq0C2BkwivzDPgphSLl1vc91gMq6KEOwIn/trHmddg1RM11N8dAaBqYsD+TWnOvuExfaFJsidAiOLjjV6AAtdRfOwLNisfimKYpZEH6G71MQyD6fPNi9cm1mn4gUc6nvk/1RsiRHF6owpkSoHnKpbdH+FLj8RGRB5gyhwbFSoad8aJd/pcOOvQuKObqnEGE2r1fgEKrYSAMOIVUApCX3HHmgruXFMx0u4AzL4pys33pvnLzgT/+FMcN+3hJwzuebiaD0zUCANFui9EaGXeQioEFKxoiLJsVWSIrfu8h5MKuWaaVXQcqQvufXgcs25I0vyKjxURLLjdpnZJZkt5boibVOV9BsIApFR8cX2Mj6+wh9n3PNnO4eddvvz9GuqXVxYXYQgW3xVl8V3DbV5a4SazZ+pCKElAGIBpw6rHKqn/dO4ZTvYo3F6bn383zrlTLnesGYNuCFpOO5w8mOCfBxIs+kQ1Sz9fXfR+birES1OeFQh8iFYKvrqhkoW3mPnbeQqpC3Rp8+IzDv851grS48zrPk6vJHQM6m4oLTqnEyG+C6YQmWRwtALCAKrGCr6+sZK59fnJAwQBgEAIhWWZnD4cABqGUUE0IrHHCRbdXtpDn+4LCP1i7DLI76cUaBJW/7A4+Z4OlwvveEiZnSvDlJiWiaZJfFdRu1inZlppXjsVDwn9wbWJ/MirMQhgWp1k3kcLkz/6Uje/2niBjrd0bDM3QaHBjZ8p7p0GkI4HqFCUkknkFyDI7OswUGg5/HHPBY89m9poejaJVBXYpt1fusoBBZ2tHlB4MgbQ/pYLqrTVyttK0+HcaZ+m3/XltB/Y08W+rSm0oArTiFBouTVd8PyWBOea3aKEWk6leHVPH6ZVWsFKzhvfsEYIrQZUjtKi4PW/pZgyWzBpxtDZmzTTZmqtjVKCeGeAk8gEqFylRU2A2ydoO+2wcJmNNHKLPXMiyfZvtJBotftXNNMuV2kRQAq9iAABga/xWmOSmfN1xk/JzooV0Zgxz6R+eYSFt5lYsZDmIw5Skxf7Bx4Ersp4FCVobQ4ZMxmunTd8K5063MdP17aSbIsQsSuGk88joKijklLgJky2fKuLdVsEs66PDGtzzXSDTz0Q4+/P9ZBo09Glhu8qFnzSZOYCHc9R+A54KTUkAx3AiaYednz7PEE8im3blHQQ6EdJkVjqgkSXyVPruvjmVo2ps4d7FMuWXPshneNnA5SvUXujwX2PxzAjhckceaGbXz50HuHEsMyRkYcRpNO6IehqMdi8tpO2M7kfxrqbbJy0R/V4jZWPRouSf2VvBzu/cwHhVmIaIycPIzwPGKZG+2mdzWs7+93iUMxdEmVynWDF+gomzCycNvx5x3l2P9KFrmIYusVoyAOIlR9uP6kJWYcKSn7B4aUDrlsUsnZzDZVjh+5CNxViRgrPy76tbfxhU5yIXokhzVG94ACFodmjO5GZtuTNIxpPN3SQ6guG2gqQV6Fiz8YW9j3ZR8SowpClBbZCGHVt1LIlbzTB9u914KbDou19L2TXD86xf1uKCqsSqRmo0d58EN5VcdeK6Bz7o+IXj3YQePnpOKmAn61/h6ZdDtFIhny58K6r01ZE5+DegN0bOlHhcBHJuM+2hrMc+q1PrKIKKfSyzPwAylJetyIGB3Z57P1J15DrPR0eW9a+zfEXQ2LRSjRR2oFmJChbadGyTPZv9+hoaWPBrTaJHp/G3T20nJTEolEE5ScP5SzuCoVhGBx9zufQ73tBhZiGTUXEzJ9mlwFlL6+blo5AH+LTLyeu+ldMV78Af3hKc9Ug8ECbv1THcxWZ13FXz8d3YOZSgUglwuanGtKzjrzkYZqlJXO5jo2DE7JLfx5z6Q81cr+lLD2Zy/zcRnDnBpP/AYEcszN4riIvAAAAAElFTkSuQmCC"
                    alt="">
            <i class="icon-ali icon-ic-trending-flat-24px"></i>
            <img src="{{ url('images/chrome-icon.png') }}" alt="">
        </div>
        <p class="fw-600 mar-t-30"><span class="color-skin fw-600">Auto Fulfillment</span> & <span class="color-skin fw-600">Product Importing</span> features require <span class="color-skin fw-600">Chrome's extension</span> to run.<br/> Do you want to install it now?</p>
        <div class="mar-t-30">
            <button onclick="installChrome()" class="extension-install-btn">Install Now</button>
        </div>
    </div>
    <script>
        const checkInterval = setInterval(function() {
            const { extensionAliOdersId = false } = window;
            if ( ! extensionAliOdersId || (extensionAliOdersId && (extensionAliOdersId != chromeExtensionId))) {
                    document.getElementById('extension-install-timeout').style.display = 'block'
            }
            clearInterval(checkInterval);
        }, 3000)

    </script>
@else
    <div class="extension-install">
        <h3 class="title-product">Opps, This function only works with <b
                    style="color: #f53663">Google Chrome</b> for Win/Mac<br>
            Please change your device/browser and try again</h3>
    </div>
    <div class="mar-t-30">
        <button class="extension-cancel-btn ars-btn-o close-modal">Cancel</button>
    </div>
@endIf