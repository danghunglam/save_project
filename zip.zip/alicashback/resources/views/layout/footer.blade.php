{{--
<div class="copyright-wrap">
    <p>Copyright 2017 <a href="http://help.fireapps.io" target="_blank">FireApps</a>. <span>All rights reserved.</span></p>
</div>
--}}
<script src="{{ URL::asset('bower_component/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ URL::asset(mix('js/app.min.js')) }}"></script>
<script src="{{ URL::asset('bower_component/moment/min/moment.min.js') }}"></script>
<script src="{{ URL::asset('bower_component/popper.js/dist/umd/popper.js') }}"></script>
<script src="{{ URL::asset('bower_component/bootstrap/dist/js/bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('bower_component/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js') }}"></script>
<script src="{{ URL::asset('bower_component/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.js') }}"></script>
<script src="{{ URL::asset('bower_component/vue/dist/vue.min.js') }}"></script>
<script src="{{ URL::asset('bower_component/jquery-validation/dist/jquery.validate.min.js') }}"></script>
<script src="{{ URL::asset('bower_component/moment/min/moment.min.js') }}"></script>
<script src="{{ URL::asset('bower_component/select2/dist/js/select2.min.js') }}"></script>
<script src="{{ URL::asset('bower_component/noty/lib/noty.min.js') }}"></script>
<script src="{{ URL::asset('bower_component/mojs/build/mo.min.js') }}"></script>
<script src="{{ URL::asset('bower_component/bootstrap-multiselect/dist/js/bootstrap-multiselect.js') }}"></script>

<script src="https://js.pusher.com/4.1/pusher.min.js"></script>

<script src="{{ URL::asset('js/main.min.js') }}"></script>
<script src="{{ URL::asset('js/common.min.js') }}"></script>


@yield('footer_extend')
