<meta charset="utf-8">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="robots" content="noindex, nofollow">
<title>{{ config('header_meta.'.session('current_route_name').'.title') }}</title>
<link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:400,700|Roboto:400,700" rel="stylesheet">
<link href="{{ URL::asset('bower_component/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('bower_component/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css') }}" rel="stylesheet">

<link href="{{ URL::asset('bower_component/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('bower_component/select2/dist/css/select2.min.css') }}" rel="stylesheet">
<link href="{{ URL::asset('bower_component/noty/lib/noty.css') }}" rel="stylesheet">
{{--  <link rel="stylesheet" href="{{ URL::asset('bower_component/select2-bootstrap-theme/dist/select2-bootstrap.min.css') }}">  --}}
 <link href="{{ URL::asset('bower_component/bootstrap-multiselect/dist/css/bootstrap-multiselect.css') }}" rel="stylesheet" >
<link href="{{ URL::asset(mix('css/main.css')) }}" rel="stylesheet">
<link rel="stylesheet" href="{{ URL::asset('css/animate.css') }}">
<link rel="chrome-webstore-item" href="https://chrome.google.com/webstore/detail/{{ env('EXTENSION_ID') }}">
{{--Header Extend--}}
@yield('head_extend')
{{--End Header Extend--}}



<script>
    window.appUrl = "{{ url('') }}";
    window.chromeExtensionId = "{{ session('aliorders_chrome_extension_id', null) != null ? session('aliorders_chrome_extension_id') : env('EXTENSION_ID') }}"
    window.chromeAlireviewsExtensionId = "{{ session('alireviews_chrome_extension_id', null) != null ? session('alireviews_chrome_extension_id') : env('EXTENSION_ALIREVIEWS_ID') }}"
    window.publicToken = "{{ session('publicToken') }}"
    window.shopId = "{{ session('shopId') }}"
    window.shopName = "{{ isset(session('shop')->shop_owner) ? session('shop')->shop_owner : ''  }}"
    window.pusherEnv = {
        app_id: "{{ env('PUSHER_APP_ID') }}",
        app_key: "{{ env('PUSHER_APP_KEY') }}",
        app_cluster: "{{ env('PUSHER_APP_CLUSTER') }}",
    }
    window.notify_domain = "{{ env('NOTIFY_DOMAIN') }}"
    window.alireviews_api = "{{ env('ALIREVIEW_API') }}"
    window.alireviews_url = "{{ env('ALIREVIEW_URL') }}"
    window.aliorders_es = "{{ env('ES_ALIORDERS_DOMAIN') }}"
    window.shopDomain = "{{ session('shopDomain') }}"
    window.shopMail = "{{ session('shopEmail', 'no-email-aliorder@fireapps.io') }}"
    window.alireviews = {!! json_encode(config('alireviews')) !!}
    window.last_time_update = {{ Cache::get('last_time_update_'.session('shopId'), 'null') }}
    window.last_time_update_tracking_code = {{ Cache::get('last_time_update_tracking_code_'.session('shopId'), 'null') }}
    window.fulfillmented_with_tracking_code = {{ Cache::get('fulfillmented_with_tracking_code_'.session('shopId'), 'false') }}
    window.order_type_sync = {{ session('order_type_sync') ? session('order_type_sync') : 0 }};
</script>

@if( session('shopDomain', false) )
    <script>
        window.intercomSettings = {
            app_id: "pqt7dlbm",
            ali_orders: true,
            shop_owner: "{{ session('shopOwner', 'Customer') }}",
            shop_email: "{{ session('shopEmail', 'no-email-aliorder@fireapps.io') }}",
            email: "{{ session('shopEmail', 'no-email-aliorder@fireapps.io') }}",
            shop_domain: "{{ session('shopDomain', 'no-shop.myshopify.com') }}",
            installed_ao: "{{ session('created_at', 1499385600) }}",
            imported_products: {{ isset($imported_product)? $imported_product: 0 }},
            fulfilled_orders: {{ Cache::get('order_fulfillment_'.session('shopId'), 0) }},
            uninstalled_ao: "{{ Cache::get('uninstall_ao_'.session('shopId'), false) }}"
        };
    </script>

    <script>
        (function(){var w=window;var ic=w.Intercom;if(typeof ic==="function"){ic('reattach_activator');ic('update',intercomSettings);}else{var d=document;var i=function(){i.c(arguments)};i.q=[];i.c=function(args){i.q.push(args)};w.Intercom=i;function l(){var s=d.createElement('script');s.type='text/javascript';s.async=true;s.src='https://widget.intercom.io/widget/pqt7dlbm';var x=d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);}if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})()
        document.addEventListener("DOMContentLoaded", function(event) {
            var aliorders_toggle_intercom = document.querySelector('#aliorders-toggle-intercom')
            if(aliorders_toggle_intercom) {
                aliorders_toggle_intercom.addEventListener('click', function () {
                    var intercom_on_messager = document.querySelector('.intercom-messenger-frame');
                    if( intercom_on_messager == null ) {
                        Intercom('show');
                    } else {
                        Intercom('hide');
                    }
                });
            }
        });
    </script>
@endif

{{--<!-- Global site tag (gtag.js) - Google Analytics -->--}}
{{--<script async src="https://www.googletagmanager.com/gtag/js?id=UA-105008699-4"></script>--}}
{{--<script>--}}
    {{--window.dataLayer = window.dataLayer || [];--}}
    {{--function gtag(){dataLayer.push(arguments);}--}}
    {{--gtag('js', new Date());--}}

    {{--gtag('config', 'UA-105008699-4');--}}
{{--</script>--}}

