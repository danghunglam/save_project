<script>
    let is_chrome = 1;
</script>
@php
    $is_chrome = 1;
    $browser = \App\Helpers\Helpers::getBrowser();
@endphp
@if($browser['code'] != 'Chrome')
    @php $is_chrome = 0; @endphp
    <script>
        is_chrome = 0;
    </script>
@else
    @if($browser['code'] != 'Chrome')
        @php $is_chrome = 0; @endphp
        <script>
            is_chrome = 0;
        </script>
    @endIf
@endIf
{{--  <div class="extension-chrome-wrap-aliorders d-none-aliorders">  --}}
<div id="modal-chrome-extension" class="modal fade" role="dialog">
    <div class="modal-dialog modal-xs">
        <div class="modal-content modal__content_icon">
            @if($is_chrome == 1)
                <div class="modal-header">
                    <button class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <div class="modal__header_icon">
                        <span><i class="mdi-emoticon-chrome"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 49.72 49.717">
                            <defs>
                                <style>
                                .cls-1 {
                                    fill: #f44336;
                                }

                                .cls-2 {
                                    fill: #2196f3;
                                }

                                .cls-3 {
                                    fill: #4caf50;
                                }

                                .cls-4 {
                                    fill: #ffc107;
                                }

                                .cls-5 {
                                    filter: url(#Path_948);
                                }

                                .cls-6 {
                                    filter: url(#Path_947);
                                }

                                .cls-7 {
                                    filter: url(#Path_946);
                                }

                                .cls-8 {
                                    filter: url(#Path_945);
                                }
                                </style>
                                <filter id="Path_945" x="4.916" y="0" width="42.574" height="27.285" filterUnits="userSpaceOnUse">
                                <feOffset dx="1" dy="1" input="SourceAlpha"/>
                                <feGaussianBlur stdDeviation="1.5" result="blur"/>
                                <feFlood flood-opacity="0.161"/>
                                <feComposite operator="in" in2="blur"/>
                                <feComposite in="SourceGraphic"/>
                                </filter>
                                <filter id="Path_946" x="13.587" y="13.591" width="22.535" height="22.539" filterUnits="userSpaceOnUse">
                                <feOffset dx="1" dy="1" input="SourceAlpha"/>
                                <feGaussianBlur stdDeviation="1.5" result="blur-2"/>
                                <feFlood flood-opacity="0.161"/>
                                <feComposite operator="in" in2="blur-2"/>
                                <feComposite in="SourceGraphic"/>
                                </filter>
                                <filter id="Path_947" x="0" y="9.243" width="31.978" height="40.095" filterUnits="userSpaceOnUse">
                                <feOffset dx="1" dy="1" input="SourceAlpha"/>
                                <feGaussianBlur stdDeviation="1.5" result="blur-3"/>
                                <feFlood flood-opacity="0.161"/>
                                <feComposite operator="in" in2="blur-3"/>
                                <feComposite in="SourceGraphic"/>
                                </filter>
                                <filter id="Path_948" x="19.084" y="13.585" width="30.636" height="36.132" filterUnits="userSpaceOnUse">
                                <feOffset dx="1" dy="1" input="SourceAlpha"/>
                                <feGaussianBlur stdDeviation="1.5" result="blur-4"/>
                                <feFlood flood-opacity="0.161"/>
                                <feComposite operator="in" in2="blur-4"/>
                                <feComposite in="SourceGraphic"/>
                                </filter>
                            </defs>
                            <g id="chrome" transform="translate(3.5 3.48)">
                                <g class="cls-8" transform="matrix(1, 0, 0, 1, -3.5, -3.48)">
                                <path id="Path_945-2" data-name="Path 945" class="cls-1" d="M61.818,7.112a20.353,20.353,0,0,1,33.574,4.026c-4.619,0-11.849,0-15.766,0-2.84,0-4.675-.064-6.66.982a9.389,9.389,0,0,0-4.711,6.184Z" transform="translate(-53.4 3.48)"/>
                                </g>
                                <g class="cls-7" transform="matrix(1, 0, 0, 1, -3.5, -3.48)">
                                <path id="Path_946-2" data-name="Path 946" class="cls-2" d="M170.842,177.67a6.767,6.767,0,1,0,6.767-6.77A6.776,6.776,0,0,0,170.842,177.67Z" transform="translate(-153.75 -153.81)"/>
                                </g>
                                <g class="cls-6" transform="matrix(1, 0, 0, 1, -3.5, -3.48)">
                                <path id="Path_947-2" data-name="Path 947" class="cls-3" d="M22.979,136.222A9.119,9.119,0,0,1,12.3,131.9c-1.858-3.207-6.77-11.76-9-15.652a20.386,20.386,0,0,0,13.109,31.095Z" transform="translate(3.5 -103.5)"/>
                                </g>
                                <g class="cls-5" transform="matrix(1, 0, 0, 1, -3.5, -3.48)">
                                <path id="Path_948-2" data-name="Path 948" class="cls-4" d="M247.516,170.839a9.269,9.269,0,0,1,1.71,11.4c-1.614,2.784-6.767,11.48-9.264,15.69a20.374,20.374,0,0,0,20.464-27.091Z" transform="translate(-217.38 -153.75)"/>
                                </g>
                            </g>
                            </svg></i></span>
                    </div>
                </div>
                <div class="modal-body">
                    <h2 class="modal__body_title">Extension Required!</h2>
                    <p>
                        Auto Fulfillment &
                        Product Importing features require
                        Chrome's extension</span> to run. Do you want to install it now?
                    </p>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" onclick="installChrome()" data-dismiss="modal">Install Now</button>
                </div>
            @else
                <div class="modal-header">
                    <button class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <div class="modal__header_icon">
                        <span><i class="mdi mdi-emoticon-sad"></i></span>
                    </div>
                </div>
                <div class="modal-body">
                    <h2 class="modal__body_title">Opps!</h2>
                    <p>Opps, This function only works with <b class="color-skin">Google Chrome</b> for Win/Mac<br>
                        Please change your device/browser and try again</p>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button_full" data-dismiss="modal">Cancel</button>
                </div>
            @endif
        </div>
    </div>
</div>
<script>
    function alertExtension(param) {
        notify('error', 'Please login or')
    }
    // alertExtension(param)
</script>