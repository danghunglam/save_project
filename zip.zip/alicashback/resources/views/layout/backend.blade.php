<!DOCTYPE html>
<html>
<head>
    @include('layout.head')
    @include('layout.expand')
    {{--extend style--}}
    @yield('styles')
    @include('layout.google_analytics')
    <!-- Google Tag Manager -->
    {{--<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':--}}
                {{--new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],--}}
            {{--j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=--}}
            {{--'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);--}}
        {{--})(window,document,'script','dataLayer','GTM-T96C735');</script>--}}
    {{--<!-- End Google Tag Manager -->--}}
    
</head>

<body class="{{ isset($no_search) ? 'page-fullheight' : '' }} {{ isset($dashboardPage) ? 'dashboard-page' : '' }} @yield('body-class') {{ (isset($shop->onboarding) && $shop->onboarding == 1) ? 'tutorial-onboarding tutorial-onboarding-step-1' : '' }}"  >
        <!-- Google Tag Manager (noscript) -->
        {{--<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T96C735"--}}
                  {{--height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>--}}
        <!-- End Google Tag Manager (noscript) -->

        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KZCPC4W" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->
        @yield('codeTracking')
        <div class="wrapper">
            <!--Logo - breadcrumb and shop_url-->
            @include('layout.header')

            <div class="body-wrap">

                @include('layout.sidebar')

                @yield('dashboard_statics')

                <div class="content-wrap">
                    <div class="content-container">
                        @include('sections.localizationjs')
                        @yield('content_container')
                    </div>
                    <div class="copyright-wrap">
                        <p>Copyright {{ date('Y') }} <a href="https://fireapps.io" target="_blank">FireApps</a>. <span>All rights reserved.</span>
                        </p>
                    </div>
                </div>
                {{--<div class="support-btn-wrap">
                    <a class="support-btn" href="javascript:void(0)" data-action="show"><img
                                src="{{ URL::asset('images/support-icon.png?v2') }}" alt="">Hi! do you need help?</a>

                    <div class="fb-page" style="display: none"
                         data-href="https://www.facebook.com/fireapps.io/"
                         data-tabs="messages"
                         data-width="400"
                         data-height="300"
                         data-small-header="true">
                        <div class="fb-xfbml-parse-ignore">
                            <blockquote></blockquote>
                        </div>
                    </div>
                </div>--}}
            </div>
        </div>
        <div class="nav-backdrop"></div>

        @include('layout.onboarding')

        @include('layout.footer')
        {{--Extend scripts--}}
        @yield('scripts')
        <script type="text/javascript" src="{{ URL::asset('js/modules/header.min.js') }}"></script>
</body>
</html>