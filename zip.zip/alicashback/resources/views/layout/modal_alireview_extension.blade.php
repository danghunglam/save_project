<div id="modal-alireview-extension" class="modal fade" role="dialog">
    <div class="modal-dialog modal-xs">
        <div class="modal-content modal__content_icon">
            <div class="modal-header">
                <div class="modal__header_icon">
                    <img src="images/chrome-icon.png" width="22px" height="22px" alt="">
                </div>
            </div>
            <div class="modal-body" style="padding:25px">
                <h2 class="modal__body_title">Extension Required!</h2>
                <p>
                    To immediately get reviews for your products, please use Google Chrome and install Ali Reviews Extension.
                </p>
            </div>
            <div class="modal-footer">
                <button class="modal__cancel_button" data-dismiss="modal">Cancel</button>
                <button class="modal__ok_button" onclick="installAlireviewExtension()" data-dismiss="modal">Install Now</button>
            </div>
        </div>
    </div>
</div>
<script>
    function alertExtension(param) {
        notify('error', 'Please login or')
    }
    // alertExtension(param)
</script>