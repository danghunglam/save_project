@extends('layout.backend')

@section('head_extend')
	{{-- <link href="{{ URL::asset('css/products.css') }}" rel="stylesheet"> --}}
	<link href="{{ URL::asset('bower_component/trumbowyg/dist/ui/trumbowyg.min.css') }}" rel="stylesheet">
	<link href="{{ URL::asset('bower_component/magnific-popup/dist/magnific-popup.css') }}" type="text/css" rel="stylesheet">
@endsection

@section('content_container')
	<div id="page-products" class="products-content-wrap">
		<input type="hidden" value="{{ session('shopDomain') }}" ref="shop_domain">
		<div class="product-list-container-wrapper">
			<div class="total-product-wrap">

				<form id="filter-product" method="GET" action="{{ route('products.index') }}">
					<ul class="product-list-filter-wrap">
						<li>
							<div class="product-filter-keyword">
								<div class="form-group m-b-0">
									<input name="title" @keyup.enter="filters" type="text" value="{{ isset($_GET['title']) ? $_GET['title'] : '' }}" placeholder="Search by keyword">
								</div>
							</div>
						</li>
						<li>
							<div class="row">
								<div class="col-xs-4">
									<div class="product-filter-status filter-source-link">
										<select class="filter-product-status" name="source_product_link">
											<option value="" {{((isset($_GET['source_product_link']) && $_GET['source_product_link'] ==''))?'selected' : ''}}>All source</option>
											@foreach(config('product.source_product_link') as $key => $source_product_link)
											<option {{ ((isset($_GET['source_product_link']) && $_GET['source_product_link'] == $source_product_link)) ? 'selected' : '' }} value="{{ $source_product_link }}">{{ \App\Helpers\Helpers::slugToString($key, '_', true) }}</option>
											@endforeach
										</select>
									</div>
								</div>
								<div class="col-xs-4">
									<div class="product-filter-status filter-price-update">
										<select class="filter-product-status" name="auto_update_price">
											<option value="" {{((isset($_GET['auto_update_price']) && $_GET['auto_update_price'] ==''))?'selected' : ''}}>All price update</option>
											@foreach(config('product.auto_update_price') as $key => $auto_update_price)
											<option {{ ((isset($_GET['auto_update_price']) && $_GET['auto_update_price'] == $auto_update_price)) ? 'selected' : '' }} value="{{ $auto_update_price }}">{{ \App\Helpers\Helpers::slugToString($key, '_', true) }}</option>
											@endforeach
										</select>
									</div>
								</div>
								<div class="col-xs-4">
									<div class="product-filter-status filter-all-stock">
										<select class="filter-product-status" name="status">
											<option value="" {{((isset($_GET['status']) && $_GET['status'] ==''))?'selected' : ''}}>All stock status</option>
											@foreach(config('product.status') as $key => $status)
												<option {{ ((isset($_GET['status']) && $_GET['status'] == $status)) ? 'selected' : '' }} value="{{ $status }}">{{ \App\Helpers\Helpers::slugToString($key, '_', true) }}</option>
											@endforeach
										</select>
									</div>
								</div>
							</div>
						</li>
					</ul>
				</form>
			</div>
			<div class="product-list-wrapper">
				<div v-if="loading" style="padding-top: 60px;">
					<vue_loaders_circle loading="Loading..."></vue_loaders_circle>
				</div>
				<div v-else v-show="! loading" style="display: none;">
					<template v-if="products">
						<template v-if="products.length != 0">
							<div class="import-all-reivew-wrap">
								<p class="total-products" v-html="getTotalItemHtml">Total:

								</p>
								<button id="importAllReviewProduct" class="import-all-review-btn" @click="importAllReviews"><img src="{{ URL::asset('images/backend/import-reviews-icon.png') }}"/>Import All Reviews</button>
							</div>
							<ul class="product-list-wrap" v-show="products.length > 0">
								<li v-for="product in products">
									<div class="product-list-item" v-bind:data-id="product.id" v-bind:id="'product-list-item'+product.id">
										<div class="product-list-item-filter">
											<div class="product-action-all-wrap">
												<div class="dropdown">
													<div class="box-dropdown-toggle" data-toggle="dropdown">
														<span>All Action</span>
													</div>
													<div class="dropdown-menu box-dropdown-menu">
														<ul>
															<li @click="editProduct(product.id)">
																<a>Edit product</a>
															</li>
															<li @click="addNewVariantProduct(product)">
																<a>Add variant</a>
															</li>
															<li @click.prevent="deleteProduct(product)">
																<a>Delete product</a>
															</li>

															{{--<li v-if="product.source_product_link" @click.prevent="importReviews(product)">--}}
																{{--<a>Import reviews</a>--}}
															{{--</li>--}}

															{{--<li v-if="product.source_product_link">--}}
																{{--<a @click="manageReview({{ json_encode(session('shopDomain')) }}, product)" target="_blank">Manage Review</a>--}}
															{{--</li>--}}
														</ul>
													</div>
												</div>
											</div>
											<a class="product-open-in-shopify" v-bind:href="'https://{{ session('shopDomain') }}/admin/products/' + product.id " target="_blank">Open in Shopify<i class="mdi mdi-open-in-new"></i></a>
										</div>
										<div class="product-image">
											<img v-bind:src="product.image ? product.image : '{{ config('common.default_image') }}'" alt="">
											<div class="product-price-range" v-html="showPriceRange(product)">
											</div>
										</div>
										<p class="product-source">
											Product source:
											<span v-if="product.source_product_link" class="icon-ali icon-ali-aliexpress" data-toggle="tooltip" title="AliExpress"></span>
											<span v-else>Unknown</span>
										</p>
										<h2 v-if="product.source_product_link" class="product-source-title">
											<a v-bind:href="product.source_product_link" target="_blank" v-text="product.title ? product.title : '' "></a>
										</h2>
										<h2 v-if="!product.source_product_link" v-text="product.title ? product.title : '' " class="product-source-title">
										</h2>
										<div class="product-in-stock-text" >
											<template v-if="product.source_product_link && product.total_quantity">
												<span v-if="product.total_quantity > 0"
													v-bind:class="{ 'product-in-stock': true, 'in-stock-warning': product.total_quantity <= 10 }"
													v-text="'In Stock:  ' + product.total_quantity">
												</span>
												<span v-else class="product-out-stock">Out of Stock</span>
											</template>
											<template v-else>
												<span class="product-no-aliexpress-link">No AliExpress link</span>
											</template>
										</div>
										<div class="product-in-stock-text" v-if="product.status == 3">
											<span class="product-out-stock">Gone from AliExpress</span>
										</div>
										<div>
											<button v-if="product.source_product_link" class="product-override-btn" @click.prevent="overrideProduct(product)">Override</button>
											<button v-else class="product-out-stock-update-link" @click.prevent="addVariantProduct(product)">Update Link</button>
											<div v-if="product.source_product_link" class="product-auto-update-price pull-right">
												<div class="fz-11">Auto Update Price</div>
												<label class="switch-style">
													<input type="checkbox" v-bind:checked="product.auto_update_price == 1 ? 'checked' : ''" @click="updatePrice($event, product)">
													<span class="switch-button">
													</span>
												</label>
											</div>
										</div>
									</div>
								</li>
							</ul>
							<div v-html="pagination_html">
							</div>
						</template>
						<template v-else-if="fetchProductComplete">
							<div class="content-not-found-wrap">
								<div>
									<img src="{{ URL::asset('images/backend/import-list-empty.png') }}" />
								</div>
								<div style="padding-left: 20px;">
									<h2>Cannot find products!</h2>
									<p>No product matching your search options</p>
								</div>
							</div>
						</template>
					</template>
					<template v-else>
						<div class="content-not-found-wrap">
							<div>
								<img src="{{ URL::asset('images/backend/import-list-empty.png') }}" />
							</div>
							<div style="padding-left: 20px;">
								<h2>Shop is not product</h2>
								<p>No product matching your search options</p>
							</div>
						</div>
					</template>
				</div>
			</div>
			<delete_product
					v-bind:current_product="product_current"></delete_product>

			{{--Modal action product--}}
			<add_variant_aliexpress
					v-on:input_aliexress="inputAliexpress"
					v-bind:current_product="product_current"></add_variant_aliexpress>

			<override_product
					v-on:page="product_current.step"
					v-on:input_aliexress="inputAliexpress"
					v-on:override_process="overrideProcess"
					v-bind:current_product="product_current"
					v-bind:settings="settings">
			</override_product>
			<add_variant
					v-bind:current_product="product_current"
					v-bind:add_variant_product="add_variant_product"
					v-bind:page="product_current.step"
					v-bind:settings="settings"
					v-on:add_variant_process="addVariantProcess">
			</add_variant>

			{{--<edit_product--}}
					{{--v-bind:current_product="product_current"></edit_product>--}}
			<import_all_reviews
					v-bind:filters_products="{{ json_encode($filters) }}"
					v-bind:current_page="{{ $current_page }}"
					v-bind:shop_id="{{ session('shopId') }}"
					v-bind:alireviews_default_setting="alireviews_default_setting"
					v-bind:shopify_domain="shopify_domain"
			></import_all_reviews>


			{{--<import_all_reviews v-bind:current_page="{{ $current_page }}"></import_all_reviews>--}}

			<import_reviews v-if="api_popup_review_return"
					v-bind:alireviews_default_setting="alireviews_default_setting"
					{{--v-bind:alireviews_countries="alireviews_countries"--}}
					v-bind:shopify_domain="shopify_domain"
					v-bind:product_reviews="product_current"
					{{--v-bind:productIsReview="productIsReview"--}}
					v-bind:alireviews_api_url="alireviews_api_url">
			</import_reviews>

			<modal_install_alireview></modal_install_alireview>

			<toast_process v-bind:process="override_process"
				:process_title="process_title"
							v-bind:process_type="override_process_type"
			v-on:close_process="closeToastProcess"></toast_process>
		</div>
	</div>
	@include('layout.modal_alireview_extension')
@endsection

@section('footer_extend')
	<script src="{{ URL::asset('bower_component/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js') }}"></script>
	<script src="{{ URL::asset('bower_component/trumbowyg/dist/trumbowyg.min.js') }}"></script>
	<script src="{{ URL::asset('bower_component/Sortable/Sortable.min.js') }}"></script>
	<script src="{{ URL::asset('bower_component/magnific-popup/dist/jquery.magnific-popup.min.js') }}"></script>
	<script>
		window.product_filter = {!! json_encode($filters) !!}
		window.currency = "{{ $currency }}"
		window.exchange = "{{ $exchange }}"
        const _extensionAlireviewID = window.extensionId;
		window.addEventListener('load', function() {
            if (_extensionAlireviewID !== 'undefined' && (_extensionAlireviewID === chromeAlireviewsExtensionId)) {
                const btnImportReview = document.getElementById('importAllReviewProduct');
                btnImportReview && btnImportReview.remove();
            }
        });
	</script>
	<script type="text/javascript" src="{{ URL::asset(mix('js/modules/product.min.js')) }}"></script>
@endsection
