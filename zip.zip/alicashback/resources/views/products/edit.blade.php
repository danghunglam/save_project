
@extends('layout.backend')

@section('head_extend')
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
	<link href="{{ URL::asset('css/products.css') }}" rel="stylesheet">
	<link href="{{ URL::asset('bower_component/trumbowyg/dist/ui/trumbowyg.min.css') }}" rel="stylesheet">
	<link href="{{ URL::asset('bower_component/jquery.tagsinput/src/jquery.tagsinput.css') }}" type="text/css" rel="stylesheet">
	<link href="{{ URL::asset('bower_component/magnific-popup/dist/magnific-popup.css') }}" type="text/css" rel="stylesheet">
@endsection

@section('content_container')
	<div id="page-edit-product" class="products-content-wrap">
		<input type="hidden" ref="product_id" value="{{$id}}">
		<div class="edit-product-wrap">
			<div class="product-import-wrap">
				<div class="vue__loaders_wrapper" v-show="Object.values(product).length === 0">
					<vue_loaders_circle loading="loading"></vue_loaders_circle>
				</div>
				<div v-show="Object.values(product).length > 0" style="display: none">
					<div class="header-import-wrap">
						<div class="import-product-action">
							<div class="pull-left">
								<a class="text-base" href="{{ route('products.index') }}"><i class="mdi mdi-chevron-left"></i>Back to product list</a>
							</div>
							<div class="header-import-action">
								<div class="auto-update-price"  v-if="product.source_product_link">
									<label class="switch-style" v-bind:for="'switch-style-'+ product.id">

										<input v-bind:id="'switch-style-'+ product.id" v-model="product.auto_update_price" type="checkbox">
										<span class="switch-button">
											<span>Auto Update Price</span>
											<span>Auto Update Price</span>
										</span>
									</label>
								</div>
								<button class="button-style-sm push-to-shop-btn" @click.prevent="saveEditProduct()">Save</button>
							</div>
						</div>
						<ul class="nav nav-tabs">
							<li class="active tab-p-id"><a data-toggle="tab" v-bind:href="'#product-'+product.id">Product</a></li>
							<li class="tab-p-description"><a data-toggle="tab" v-bind:href="'#description-'+product.id">Description</a></li>
							<li class="tab-p-variant"><a data-toggle="tab" v-bind:href="'#variants-'+product.id">Variants ( @{{ Object(product.product_variant).length }} )</a>@{{ Object(product.product_variant)}}</li>
							<li class="tab-p-image">
								<a data-toggle="tab" v-bind:href="'#images-'+product.id">
									Images
									<span class="tooltip-style-wrap color-skin" style="margin-left: 3px" data-toggle="tooltip" title="Drag and drop image to select your product thumbnail">
										<i class="mdi mdi-alert-circle"></i>
									</span>
								</a>
							</li>
						</ul>
					</div>
					<div class="tab-content">
						<div v-bind:id="'product-'+product.id" class="tab-pane fade in active">
							<div class="tab-product-wrap">
								<div class="tab-product-image">
									<img v-bind:src="product.image" v-bind:alt="product.title">
								</div>
								<div class="tab-product-info">
									<p class="product-info-from">Product from <img data-toggle="tooltip" title="AliExpress" v-bind:src="appUrl+'/images/icon-ali-aliexpress.png'" alt=""></p>
									<h2>
										{{--<a v-bind:href="'https://'+shopDomain+'/admin/products/'+product.id" target="_blank">--}}
										<a v-bind:href="product.source_product_link"  target="_blank">
											<span v-text="product.title_source != null ? product.title_source : product.title "></span>
										</a>
									</h2>
									<div class="form-group">
										<label class="fz-13">Name on Shopify</label>
										<input class="fz-13" type="text" v-model="product.title">
									</div>
									<div class="form-group m-b-0">
										<label class="fz-13">
											Collections
											<span class="tooltip-style-wrap color-skin" style="margin-left: 3px" data-toggle="tooltip" title="Maximum of 250 collections">
												<i class="mdi mdi-alert-circle"></i>
											</span>
										</label>
										{{--<select class="product-collection" id="collection-edit" multiple>
										</select>--}}
										<div class="dropdown box-dropdown dropdown-collection">
											<span data-toggle="dropdown" class="box-dropdown-toggle">
												<span class="result-multiselect">
													<ul>
														<li v-for="collection in current_collection" v-bind:key="collection.id">@{{ collection.title }}<span @click="removeCollection(collection)" class="mdi mdi-close"></span></li>
														<li><input type="text" @keyup="keyupCollection()"></li>
													</ul>
												</span>
											</span>
											<div class="dropdown-menu box-dropdown-menu">
												<ul v-if="obj_collections.length > 0">
													<li v-for="collection in obj_collections" :class="collection.selected?'selected':''" @click="addCollection(collection)" v-text="collection.title"></li>
												</ul>
												<span class="no-results" v-else>No results found</span>
											</div>
										</div>
									</div>
									<div class="row m-t-30">
										<div class="col-xs-6">
											<div class="form-group dropdown box-dropdown">
												<label class="fz-13">Type</label>
												<div class="dropdown box-dropdown dropdown-product-type">
													<span class="box-dropdown-toggle" data-toggle="dropdown">
														<span class="result-multiselect">
															<ul>
																<li v-if="this.product.product_type"><span v-text="this.product.product_type"></span><span @click="removeproductType()" class="mdi mdi-close"></span></li>
																<li><input class="product__type_input fz-13" type="text" @keyup="keyupProductType($event)" @keyup.enter="keyupEnterProductType()"></li>
															</ul>
															<span class="box-dropdown-menu-label">Add new type by pressing Enter key</span>
														</span>
													</span>
													<div class="dropdown-menu box-dropdown-menu" v-if="this.product_type.length!=0">
														<ul>
															<li v-for="type in this.product_type" @click="selectType(type)" v-text="type.name"></li>
														</ul>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xs-6">
											<div class="form-group form-group-tag m-b-0">
												<label class="fz-13">Tags</label>
												<div class="bootstrap-tagsinput-wrap">
													<input id="product-tag" ref="product_tag" />
													<span class="box-dropdown-menu">Add new tag by pressing Enter key</span>
												</div>
											</div>
										</div>
									</div>

								</div>
							</div>
						</div>
						<div v-bind:id="'description-'+product.id" class="tab-description tab-pane fade in">
							<div class="tab-description-wrap">
								<trumbowyg v-show="false" v-bind:content="body_html" v-on:change-content="changeBodyHtml"></trumbowyg>
							</div>
						</div>
						<div v-bind:id="'variants-'+product.id" class="tab-variants tab-pane fade in">
							<div class="tab-variants-wrap">
								<div class="ars-table">
									<div class="ars-table-head">
										<div class="ars-table-col col-variant-select">
											<label class="checkbox-style checkbox-text-o" v-bind:for="'select-variant-all'+product.id" title="You can selected a maximum of 100 variants">
												<input v-bind:id="'select-variant-all'+product.id" @click="selectAllVariants" value="1" type="checkbox" v-model="selectAll">
												<span class="checked-style"></span>
											</label>
										</div>
										<div class="ars-table-col col-variant-product">Product</div>
										<div class="ars-table-col col-variant-sku">SKU</div>
										{{--<div  class="ars-table-col" v-for="option in options">
											@{{ option.name }}
										</div>--}}
										<div class="ars-table-col col-variant-color" v-for="(option, label, key) in optionFilter" :key=key>
											<div class="dropdown box-dropdown dropdown-option-variant">
												<div class="parent-dropdown" data-toggle="dropdown">@{{label}}<i class="mdi mdi-menu-down"></i> </div>
												<div class="dropdown-menu box-dropdown-menu">
													<ul>
														<li v-for="(select, value, optionKey) in option" :key="optionKey">
															<label class="checkbox-style">
																<input type="checkbox" v-model="option[value]['selected']" v-on:change="selectOptionFilter(select)">
																<span class="checked-style"></span>
																@{{ value }}
															</label>
														</li>
													</ul>
												</div>
											</div>
										</div>
										<div class="ars-table-col col-variant-cost" v-if="product.source_product_link">Cost</div>
										<div class="ars-table-col col-variant-shipping" v-if="product.source_product_link">Shipping</div>
										<div class="ars-table-col col-variant-price">
											Price
											<span class="tooltip-style-wrap color-skin" data-toggle="tooltip" title="The Price value is calculated based on Cost value">
												<i class="mdi mdi-alert-circle"></i>
											</span>
										</div>
										<div class="ars-table-col col-variant-profit" v-if="product.source_product_link">Profit</div>
										<div class="ars-table-col col-variant-compared-at-price">
											Compare At Price
											<span class="tooltip-style-wrap color-skin" data-toggle="tooltip" title="The Compare At Price value is calculated based on Cost value">
												<i class="mdi mdi-alert-circle"></i>
											</span>
										</div>
										<div class="ars-table-col col-variant-inventory">Inventory</div>
									</div>
									<div class="num-variant-selected">
										<div class="count-select-variant">
											<span>@{{numVariantSelected}}</span> of <span v-text="totalVariant"></span> Variants
										</div>
										<div v-if="numVariantSelected > 1" class="change-price">
											<div class="dropdown box-dropdown">
												<span class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
													Action
												</span>
												<div class="dropdown-menu box-dropdown-menu">
													<ul>
														<li @click="showInputChangePrice"><a href="javascript:void(0)">Change Price</a></li>
														<li @click="showInputChangeComparePrice"><a href="javascript:void(0)">Change Compare Price</a></li>
													</ul>
												</div>
												<div class="box box-variant-price" style="z-index: 99;" v-show="showChangePrice">
													<div>
														<input type="text" class="form-control" placeholder="New value price" @keyup.enter="saveChangePrice" @keyup="isNumberKeyup($event, '', 'priceVariantSelect')" @keypress="isNumber($event)" v-model="priceVariantSelect">
													</div>
													<div>
														<button class="btn btn-warning" @click.prevent="saveChangePrice">Apply</button>
													</div>
												</div>
												<div class="box box-variant-price" style="z-index: 99;" v-show="showChangeComparePrice">
													<div>
														<input type="text" class="form-control" placeholder="New value compared price" @keyup.enter="saveChangeComparePrice" @keyup="isNumberKeyup($event, '', 'comparePriceVariantSelect')" v-model="comparePriceVariantSelect">
													</div>
													<div>
														<button class="btn btn-warning" @click.prevent="saveChangeComparePrice">Apply</button>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="ars-table-row ars-table-row-change-price">
										<div class="ars-table-col col-variant-select"></div>
										<div class="ars-table-col col-variant-product"></div>
										<div class="ars-table-col col-variant-sku"></div>
										<div  class="ars-table-col" v-for="option in options">

										</div>
										<div class="ars-table-col col-variant-cost" v-if="product.source_product_link"></div>
										<div class="ars-table-col col-variant-shipping" v-if="product.source_product_link">
											<div class="shipping-country">
												<a v-text="freight.shipTo ==null ? 'Shipping to' : freight.shipTo " href="javascript:;" @click="showModalShipingCountry(product)"></a>
												{{--<div class="dropdown box-dropdown">
													<span @click="showModalShipingCountry()" class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding-right: 20px">
														Country
													</span>
												</div>--}}
											</div>
										</div>
										<div class="ars-table-col col-variant-price">
											<div class="change-price">
												<div class="dropdown box-dropdown">
													<span class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														Change All
													</span>
													<div class="dropdown-menu box-dropdown-menu">
														<ul>
															<li @click.prevent="changeItemPrice('new_value')"><a href="#">Set New Value</a></li>
															<li @click.prevent="changeItemPrice('multiply_by')"><a href="#">Multiply by</a></li>
															<li @click.prevent="changeItemPrice('plus')"><a href="#">Plus by</a></li>
														</ul>
													</div>
												</div>
												<div class="box box-variant-price" style="z-index: 99;" v-show="itemPrice.showBox">
													<div>
														<input type="text" class="form-control" @keyup="isNumberKeyup($event, '', 'itemPrice')" @keypress="isNumber($event)" v-model="itemPrice.value" v-bind:placeholder="itemPrice.placeHolder">
													</div>
													<div>
														<button class="btn btn-warning" @click.prevent="saveItemPrice">Apply</button>
													</div>
													<div class="glyphicon">
														<span class="glyphicon glyphicon-remove" @click.prevent="closeChangeItemPrice"></span>
													</div>
													<div class="arrow-down"></div>
												</div>
											</div>
										</div>
										<div class="ars-table-col col-variant-profit" v-if="product.source_product_link"></div>
										<div class="ars-table-col col-variant-compared-at-price">
											<div class="change-price">
												<div class="dropdown box-dropdown">
													<span class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														Change All
													</span>
													<div class="dropdown-menu box-dropdown-menu">
														<ul>
															<li @click.prevent="changeComparedPrice('new_value')"><a href="#">Set New Value</a></li>
															<li @click.prevent="changeComparedPrice('multiply_by')"><a href="#">Multiply by</a></li>
															<li @click.prevent="changeComparedPrice('plus')"><a href="#">Plus by</a></li>
														</ul>
													</div>
												</div>

												<div class="box box-variant-price" style="z-index: 99" v-show="comparedPrice.showBox">
													<div>
														<input type="text" class="form-control" @keyup="isNumberKeyup($event, '', 'comparedPrice')" @keypress="isNumber($event)" v-model="comparedPrice.value" v-bind:placeholder="comparedPrice.placeHolder">
													</div>
													<div>
														<button class="btn btn-warning" @click.prevent="saveComparedPrice">Apply</button>
													</div>
													<div class="glyphicon">
														<span class="glyphicon glyphicon-remove" @click.prevent="closeComparedPrice"></span>
													</div>
													<div class="arrow-down"></div>
												</div>
											</div>
										</div>
										<div class="ars-table-col col-variant-inventory">
										</div>
									</div>
									<div class="ars-table-row ars-table-row-item" v-for="(variant, index) in product.product_variant" :key="index">
										<div class="ars-table-col col-variant-select">
											<label v-bind:for="'select-variant-'+variant.id" class="checkbox-style checkbox-text-o">
												<input v-bind:id="'select-variant-'+variant.id" v-model="variant.selected" value="1" v-bind:checked="variant.selected" @click="selectVariant(variant)" type="checkbox">
												<span class="checked-style"></span>
											</label>
										</div>
										<div class="ars-table-col col-variant-product">
											<div class="box-variant-content">
												<img v-bind:src="variant.product_image ? variant.product_image.src : ''" alt="">
												<span v-if="!variant.selected"></span>
												<div v-if="variant.selected" class="select-variant-image" @click="showModalImage(variant)"><i class="mdi mdi-plus"></i></div>
											</div>
										</div>
										<div class="ars-table-col col-variant-sku">
											<div class="box-variant-content">
												<input type="text" v-bind:value="variant.sku" readonly>
												<span v-if="!variant.selected"></span>
											</div>
										</div>
										<div class="ars-table-col col-variant-color" v-if="options.length > 0">
											<div class="box-variant-content">
												<input type="text" v-model="variant.option1">
												<span v-if="!variant.selected"></span>
											</div>
										</div>
										<div class="ars-table-col col-variant-size" v-if="options.length > 1">
											<div class="box-variant-content">
												<input type="text" v-model="variant.option2">
												<span v-if="!variant.selected"></span>
											</div>
										</div>
										<div class="ars-table-col col-variant-size" v-if="options.length > 2">
											<div class="box-variant-content">
												<input type="text" v-model="variant.option3">
												<span v-if="!variant.selected"></span>
											</div>
										</div>
										<div class="ars-table-col col-variant-cost" v-if="product.source_product_link">
											<div class="box-variant-content">
												<input type="text" readonly disabled v-bind:value="'$'+variant.source_price">
												<span v-if="!variant.selected"></span>
											</div>
										</div>
										<div class="ars-table-col col-variant-shipping" v-if="product.source_product_link">
											<div class="box-variant-content">
												<input type="text" readonly disabled v-bind:value="'$'+freight.price">
												<span v-if="!variant.selected"></span>
											</div>
										</div>
										<div class="ars-table-col col-variant-price">
											<div class="box-variant-content">
												<div class="input-group">
													<input type="text" @keyup="isNumberKeyup($event,index, 'price')" @keypress="isNumber($event)" @input="changePrice" @change="setNull" v-model="variant.price">
													<span class="input-group-addon">{{ $currency }}</span>
												</div>
												<span v-if="!variant.selected"></span>
											</div>
										</div>
										<div class="ars-table-col col-variant-profit" v-if="product.source_product_link">
											<div class="box-variant-content">
												<input type="text" v-bind:style=" variant.profit < 0 ? 'color: red;' : ''" readonly disabled v-bind:value="'$'+variant.profit">
												<span v-if="!variant.selected"></span>
											</div>
										</div>
										<div class="ars-table-col col-variant-compared-at-price">
											<div class="box-variant-content">
												<div class="input-group">
													<input type="text" @keyup="isNumberKeyup($event, index, 'compare_at_price')" @keypress="isNumber($event)" v-model="variant.compare_at_price==0?null:variant.compare_at_price">
													<span class="input-group-addon">{{ $currency }}</span>
												</div>
												<span v-if="!variant.selected"></span>
											</div>
										</div>
										<div class="ars-table-col col-variant-inventory">
											<div class="box-variant-content">
												<input type="text" disabled v-model="variant.source_quantity">
												<span v-if="!variant.selected"></span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div v-bind:id="'images-'+product.id" class="tab-images tab-pane fade in">
							<div class="tab-images-wrap">
								<div class="select-all-group">
									<label class="checkbox-style checkbox-text-o" for="select-all">
										<input v-on:change="checkAllImage($event)" id="select-all" type="checkbox">
										<span class="checked-style"></span>
									</label>
									<span class="select-all-text">
										 <b v-text="image_selected"></b> of
										<b v-text="imageSort.length"></b> <span v-text="((imageSort.length > 1 || imageSort.length==0)) ? 'images' : 'image'"></span>
									</span>
								</div>
								<div class="variant-image-wrap">
									<ul id="el-variant-image" class="variant-image-list">

										<li class="sortable-image" v-for="(image, index) in imageSort" :key="image.id" v-bind:data-variant-id="index">
											<div class="variant-images" v-bind:class="image.status ? 'active' : ''">
												<img v-on:click="selectImageContainer(image, index)" v-bind:src="image.src" :data-height="image.height" :data-width="image.height" :data-id="image.id" :data-status="image.status">

												{{-- <label v-show="index != 0" v-bind:for="'select-image-'+image.id" class="checkbox-style check-variant-image">
													<input type="checkbox" v-bind:id="'select-image-'+image.id" v-model="image.status" v-on:change="selectImage(image)">
													<span class="checked-style"></span>
												</label> --}}
												<a v-bind:href="image.src" class="view-original-image-size" @click="viewOriginSize" target="_blank"><i class="mdi mdi-magnify-plus-outline"></i></a>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="vue__loaders_wrapper" v-show="loading_page">
						<vue_loaders_circle></vue_loaders_circle>
					</div>
				</div>
			</div>
		</div>
		<modal_item_image v-bind:props_product_images="product.product_image" v-show="product.modal_images" v-on:close-modal-images="closeModalImages" v-on:add-variant-image="addVariantImage"></modal_item_image>

		<modal_shipping_country v-on:freight="infoShipping" ref="modal_shipping_country" v-bind:props_product="product" ></modal_shipping_country>
	</div>
@endsection

@section('footer_extend')
	<script>
        window.exchange = {{ $exchange }}
	</script>
	<script src="{{ URL::asset('bower_component/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js') }}"></script>
	<script src="{{ URL::asset('bower_component/trumbowyg/dist/trumbowyg.min.js') }}"></script>
	<script src="{{ URL::asset('bower_component/magnific-popup/dist/jquery.magnific-popup.min.js') }}"></script>
	<script src="{{ URL::asset('bower_component/Sortable/Sortable.min.js') }}"></script>
	<script type="text/javascript" src="{{ URL::asset(mix('js/modules/edit_product.min.js')) }}"></script>
@endsection
