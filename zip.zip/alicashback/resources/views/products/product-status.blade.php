@extends('layout.backend')

@section('head_extend')
    <link href="{{ URL::asset(mix('css/products.css')) }}" rel="stylesheet">
@endsection

@section('content_container')
    <div id="page-products" class="products-content-wrap">
        <div class="product-list-container-wrapper">
            <div class="product-status-item-wrap">
                <input type="hidden" value="{{ $shopId }}" id="data_shop_id">
                <div class="vue__loaders_wrapper" v-show="loading_page">
                    <vue_loaders_circle></vue_loaders_circle>
                </div>
                <div v-if="products_notify.length <= 0">
                    <div class="content-not-found-wrap">
                        <div>
                            <img src="https://aliorders.fireapps.io/images/backend/import-list-empty.png">
                        </div>
                        <div style="padding-left: 20px;">
                            <h2>Your Product Status is Empty</h2>
                        </div>
                    </div>
                </div>
                <div v-else>
                    <div v-for="(productNotify,key) in products_notify" :key="key" class="product-status-item">
                        <div class="product-status-item-head">
                            <h2><i class="mdi mdi-calendar"></i><span v-text="moment( key).format('ll')"></span></h2>
                        </div>

                        <div v-for="product in productNotify" :key="product._id">
                            <div class="product-status-item-line" :id="'product-status-item-line-'+product._id" >
                                {{--<div v-if="product.product">--}}
                                <div class="ars-table">
                                    <div class="ars-table-row">
                                        <div class="ars-table-col col-product-status-item-image">
                                            <div class="product-status-item-image">
                                                <img v-bind:src="product.product.image" alt="">
                                            </div>
                                        </div>
                                        <div class="ars-table-col product-status-item-content">
                                            {{--<a target="_blank" v-bind:href="product.object[0][0].aliexpess_link" v-text="product.product.title"></a>--}}
                                            <span v-text="product.product.title"></span>
                                            {{--<a href="" v-text="product.title"></a>--}}
                                            <p v-text="(type_config[product.type_notify]) ? type_config[product.type_notify].title : ''"></p>
                                        </div>
                                        <div class="ars-table-col col-product-status-item-action">
                                            <a href="" class="button-style-dark-sm" data-toggle="modal" @click="showDetail(product.type_notify,product.object, product._id)" data-target="#modal-type-product" >More Detail</a>
                                            <span class="mdi mdi-delete-forever" @click="setProductIdDelete(product._id)" data-toggle="modal" data-target="#modal-delete-product"></span>
                                        </div>
                                    </div>
                                </div>
                                {{--</div>--}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="pagination-wrap" v-show="pagination.last_page > 1">
            <pagination
                    :pagination="pagination"
                    :offset="6"
                    @paginate="clickPagination"></pagination>
        </div>
        <type_product
                    :type_config="type_config"
                    :notify_type="current_type"
                    :object="current_object">
        </type_product>

        <status_delete v-bind:product_notify_id="product_notify_id"
                       v-on:load_page="loadPage">

        </status_delete>


    </div>

@endsection

@section('footer_extend')
    <script type="text/javascript" src="{{ URL::asset(mix('js/modules/product_status.min.js')) }}"></script>
@endsection
