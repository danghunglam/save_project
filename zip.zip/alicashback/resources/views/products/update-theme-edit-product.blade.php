@extends('layout.backend')
@section('head_extend')
    <link href="{{ URL::asset('css/products.css') }}" type="text/css" rel="stylesheet">
@endsection
@section('content_container')
    <div class="row">
        <div class="col-lg-12">
            <div class="update-theme-content-wrap" id="update-theme-shopify">
                <h3>Update Ali Orders theme</h3>
                <div>Please click the button below to continue</div>
                <button @click="updateTheme()" class="button-style-dark-sm push-to-shop-btn update-theme-btn">Update theme</button>
            </div>
        </div>
    </div>
@endsection

@section('footer_extend')
    <script type="text/javascript" src="{{ URL::asset(mix('js/modules/update_theme.min.js')) }}"></script>
@endsection