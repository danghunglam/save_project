
<div id="product-status-missing-modal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="icon-ali icon-ic-highlight-off-24px"></i></button>
                <h4 class="modal-title">Shopify product variant is missing</h4>
            </div>
            <div class="modal-body">
                <div class="product-status-missing-wrap">
                    <p>Shopify product Cat Sofa Cushion/Pillow  variants have been removed or replaced. We will no longer be able to import orders with the missing variants. Please see the information below to make sure this action was intentional.</p>
                    <p>Note: This can be caused by third-party Shopify apps replacing or removing product variants.</p>
                    <div class="ars-table product-status-table">
                        <div class="ars-table-head">
                            <div class="ars-table-col col-product-miss-sku">SKU</div>
                            <div class="ars-table-col col-product-miss-color">Color</div>
                            <div class="ars-table-col col-product-miss-size">Size</div>
                            <div class="ars-table-col col-product-miss-specification">Specification</div>
                            <div class="ars-table-col col-product-miss-shipifyid">Shopify ID</div>
                        </div>
                        <div class="ars-table-row">
                            <div class="ars-table-col col-product-miss-sku">365352-black-4xl</div>
                            <div class="ars-table-col col-product-miss-color">Black</div>
                            <div class="ars-table-col col-product-miss-size">4XL</div>
                            <div class="ars-table-col col-product-miss-specification">No filling</div>
                            <div class="ars-table-col col-product-miss-shipifyid">234542482724</div>
                        </div>
                        <div class="ars-table-row">
                            <div class="ars-table-col col-product-miss-sku">365352-black-4xl</div>
                            <div class="ars-table-col col-product-miss-color">Black</div>
                            <div class="ars-table-col col-product-miss-size">4XL</div>
                            <div class="ars-table-col col-product-miss-specification">No filling</div>
                            <div class="ars-table-col col-product-miss-shipifyid">234542482724</div>
                        </div>
                    </div>
                    <div class="ars-form-submit-btn-wrap">
                        <button class="ars-btn-o" type="button">Dismiss</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
