@extends('layout.backend')
@section('content_container')
    <div class="content-container-wrap">
        <div class="error-page-wrap">
            <div class="error-page-image">
                <img src="{{ URL::asset('images/backend/error-page.png') }}" alt="ali orthers">
            </div>
            <div class="error-page-text">
                <h1>Please login your store</h1>
                <p>{{ $shopDomain }} to Ali Order to edit this product</p>
                <a href="{{ route('apps.installApp') }}" class="button-style-dark-sm button-back-home">Login Now</a>
            </div>
        </div>
    </div>
    <style>
        .button-back-home {
            margin-top: 30px;
            width: 150px;
            height: 35px;
            line-height: 35px;
        }
    </style>
@endsection
