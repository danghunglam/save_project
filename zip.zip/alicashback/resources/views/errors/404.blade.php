@extends('layout.backend')
@section('content_container')
    <div class="content-container-wrap">
        <div class="error-page-wrap">
            <div class="error-page-image">
                <img src="{{ URL::asset('images/backend/error-page.png') }}" alt="ali orthers">
            </div>
            <div class="error-page-text">
                <h1>We think you’re lost!</h1>
                <p>You can choose to stay, but we recommend to go back home</p>
                <a href="{{ route('dashboard.index') }}" class="button-style-dark-sm button-back-home">Back Home</a>
            </div>
        </div>
    </div>
    <style>
        .button-back-home {
            margin-top: 30px;
            width: 150px;
            height: 35px;
            line-height: 35px;
        }
    </style>
@endsection
