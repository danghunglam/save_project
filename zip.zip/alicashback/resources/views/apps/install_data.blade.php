@extends('layout.fullwidth')

@section('header_extend')
    <link href="{{ URL::asset('css/installing.css') }}" rel="stylesheet">
@endsection

@section('GA_head')
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-105008699-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-105008699-1');
    </script>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-KZCPC4W');</script>
    <!-- End Google Tag Manager -->
@endsection

<script>
    let is_chrome = 1;
</script>
@php
    $is_chrome = 1;
    $browser = \App\Helpers\Helpers::getBrowser();
@endphp
@if($browser['code'] != 'Chrome')
    @php $is_chrome = 0; @endphp
    <script>
        is_chrome = 0;
    </script>
@else
    @if($browser['code'] != 'Chrome')
        @php $is_chrome = 0; @endphp
        <script>
            is_chrome = 0;
        </script>
    @endIf
@endIf

@section('GA_body')
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KZCPC4W" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <!-- body_element - Google Analytics -->
    <script type="text/javascript">
        adroll_adv_id = "JS5D42XOJFFQZOOI4GXMBF";
        adroll_pix_id = "4MDCUR47YVAYND3IKCCD26";

        (function () {
            var _onload = function(){
                if (document.readyState && !/loaded|complete/.test(document.readyState)){setTimeout(_onload, 10);return}
                if (!window.__adroll_loaded){__adroll_loaded=true;setTimeout(_onload, 50);return}
                var scr = document.createElement("script");
                var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com");
                scr.setAttribute('async', 'true');
                scr.type = "text/javascript";
                scr.src = host + "/j/roundtrip.js";
                ((document.getElementsByTagName('head') || [null])[0] ||
                    document.getElementsByTagName('script')[0].parentNode).appendChild(scr);
            };
            if (window.addEventListener) {window.addEventListener('load', _onload, false);}
            else {window.attachEvent('onload', _onload)}
        }());
    </script>
@endsection
@section('content_container')
    <style>
        .installing .content-right .progress-block-text span, .installing .content-right .progress-block-text p{
            font-family: Poppins,sans-serif;
            font-size: 13px;
            font-weight: 600;
            line-height: 20px;
            opacity: 0.5;
            transition: 0.5s;
        }
        .installing .content-right .progress-block-text.done-install p, .installing .content-right .progress-block-text.done-install span {
            opacity: 1;
        }
        .meter {
            height: 10px;  /* Can be anything */
            position: relative;
            margin: 0px 0 0; /* Just for demo spacing */
            background: #f0f2f8;
            -moz-border-radius: 10px;
            -webkit-border-radius: 10px;
            border-radius: 10px;
            -webkit-box-shadow: inset 0 -1px 1px rgba(255,255,255,0.3);
            -moz-box-shadow   : inset 0 -1px 1px rgba(255,255,255,0.3);
            box-shadow        : inset 0 -1px 1px rgba(255,255,255,0.3);
        }
        .meter > span {
            display: block;
            height: 100%;
            width: 0;
            border-radius: 10px;
            /* -webkit-border-top-right-radius: 8px;
            -webkit-border-bottom-right-radius: 8px;
                -moz-border-radius-topright: 8px;
                -moz-border-radius-bottomright: 8px;
                    border-top-right-radius: 8px;
                    border-bottom-right-radius: 8px; */
                /* -webkit-border-top-left-radius: 20px;
            -webkit-border-bottom-left-radius: 20px;
                    -moz-border-radius-topleft: 20px;
                -moz-border-radius-bottomleft: 20px;
                        border-top-left-radius: 20px;
                    border-bottom-left-radius: 20px; */
            /*background-color: #242538;
            background-image: -webkit-gradient( linear, left bottom, left top, color-stop(0, #242538), color-stop(1, #242538) );
            background-image: -moz-linear-gradient(center bottom, #242538 37%, #242538 69%);
            */
            -webkit-box-shadow:
            inset 0 2px 9px  rgba(255,255,255,0.3),
            inset 0 -2px 6px rgba(0,0,0,0.4);
            -moz-box-shadow:
            inset 0 2px 9px  rgba(255,255,255,0.3),
            inset 0 -2px 6px rgba(0,0,0,0.4);
            box-shadow:
            inset 0 2px 9px  rgba(255,255,255,0.3),
            inset 0 -2px 6px rgba(0,0,0,0.4);
            position: relative;
            overflow: hidden;
            background-color: #7009ff;
        }
        .meter > span:after, .animate > span > span {
            content: "";
            position: absolute;
            top: 0; left: 0; bottom: 0; right: 0;
            /*background-image:
            -webkit-gradient(linear, 0 0, 100% 100%,
                color-stop(.25, rgba(255, 255, 255, .2)),
                color-stop(.25, transparent), color-stop(.5, transparent),
                color-stop(.5, rgba(255, 255, 255, .2)),
                color-stop(.75, rgba(255, 255, 255, .2)),
                color-stop(.75, transparent), to(transparent)
            );
            background-image:
                -moz-linear-gradient(
                -45deg,
                rgba(255, 255, 255, .2) 25%,
                transparent 25%,
                transparent 50%,
                rgba(255, 255, 255, .2) 50%,
                rgba(255, 255, 255, .2) 75%,
                transparent 75%,
                transparent
            );*/
            z-index: 1;
            -webkit-background-size: 50px 50px;
            -moz-background-size: 50px 50px;
            -webkit-animation: move 2s linear infinite;
            -webkit-border-top-right-radius: 8px;
            -webkit-border-bottom-right-radius: 8px;
                -moz-border-radius-topright: 8px;
                -moz-border-radius-bottomright: 8px;
                    border-top-right-radius: 8px;
                    border-bottom-right-radius: 8px;
                -webkit-border-top-left-radius: 20px;
            -webkit-border-bottom-left-radius: 20px;
                    -moz-border-radius-topleft: 20px;
                -moz-border-radius-bottomleft: 20px;
                        border-top-left-radius: 20px;
                    border-bottom-left-radius: 20px;
            overflow: hidden;
        }

        .animate > span:after {
            display: none;
        }

        @-webkit-keyframes move {
            0% {
            background-position: 0 0;
            }
            100% {
            background-position: 50px 50px;
            }
        }

        .orange > span {
            background-color: #f1a165;
            background-image: -moz-linear-gradient(top, #f1a165, #f36d0a);
            background-image: -webkit-gradient(linear,left top,left bottom,color-stop(0, #f1a165),color-stop(1, #f36d0a));
            background-image: -webkit-linear-gradient(#f1a165, #f36d0a);
        }

        .red > span {
            background-color: #f0a3a3;
            background-image: -moz-linear-gradient(top, #f0a3a3, #f42323);
            background-image: -webkit-gradient(linear,left top,left bottom,color-stop(0, #f0a3a3),color-stop(1, #f42323));
            background-image: -webkit-linear-gradient(#f0a3a3, #f42323);
        }

        .nostripes > span > span, .nostripes > span:after {
            -webkit-animation: none;
            background-image: none;
        }
    </style>

    <div class="sign-in installing">
        <div class="content-left text-center">
            <div class="max-width-450">
                <div class="logo">
                    <img src="{{ URL::asset('images/logo-aliorder-white.svg') }}" alt="logo ali orders">
                </div>
                <div class="title-logo">
                    <h1>Ali Orders</h1>
                    <h4>A Product Of FireApps</h4>
                </div>
            </div>
            <div class="bottom-text">
                <a class="text-link fz-11" href="https://fireapps.io/terms-of-service" target="_blank">Term of use.</a> &nbsp;&nbsp;&nbsp;<a class="text-link fz-11" href="https://fireapps.io/privacy-policy" target="_blank">Privacy policy</a>
            </div>
        </div>
        <div class="content-right text-center">
            <div class="content-installing">
                <div class="installing-wrapper">
                    <div id="installing-page">
                        <div class="installing-step-1 installing-step text-center">
                            <h2>INSTALLING</h2>
                            <p>Hold tight, we’re setup your Ali Orders and getting things ready for you. This could take up to a minute.</p>
                            <div class="progress-loading-wrap">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="meter">
                                            <span style="width: 100%"></span>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="progress-block-text">
                                            <span class="fw-600">1</span>
                                            <p class="fw-600">{!! __('installing.install_step_1') !!}</p>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="progress-block-text">
                                            <span class="fw-600">2</span>
                                            <p class="fw-600">{!! __('installing.install_step_2') !!}</p>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="progress-block-text">
                                            <span class="fw-600">3</span>
                                            <p class="fw-600">{!! __('installing.install_step_3') !!}</p>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="progress-block-text">
                                            <span class="fw-600">4</span>
                                            <p class="fw-600">{!! __('installing.install_step_4') !!}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="progress-loading-btn-wrap text-center">
                                <span id="progress-loading-btn-1" class="ars-btn" style="display: none">Next</span>
                            </div>
                        </div>

                        <div class="installing-step-2 installing-step text-center">
                            <div class="content-success">
                                <img style="width: 70px; height: 70px;" src="{{ URL::asset('images/backend/transfer-oberlo-icon.png') }}">
                                <h2>EASY TRANSFER FROM OBERLO</h2>
                                <p>If you are using Oberlo and worry about missing<br/> 
                                    information when moving to Ali Orders,<br/>
                                    just click <span class="color-skin fw-600">Transfer Now</span>, everything will be automatically updated.</p>
                                <div class="progress-loading-btn-wrap text-center">
                                <span id="ao__transfer_later" class="button-style button-style-o ao__transfer_btn">Later</span>
                                <span id="ao__transfer_now" class="button-style ao__transfer_btn">Transfer Now</span>
                            </div>
                            </div>
                        </div>

                        <div class="installing-step-3 installing-step text-center">
                            <div class="content-success">
                                <img style="width: 70px; height: 70px;" src="{{ URL::asset('images/backend/chrome-logo.png') }}">
                                <h2>EXTENSION REQUIRED</h2>
                                <p>{!! __('installing.install_text_2') !!}</p>
                                <div class="progress-loading-btn-wrap text-center">
                                    <span id="progress-loading-btn-3" class="button-style button-style-o ao__transfer_btn">Skip Next</span>
                                    <span id="progress-loading-btn-3-1" onclick="installChrome()" class="button-style extension-install-btn ao__transfer_btn">Install Now</span>
                                </div>
                            </div>
                        </div>

                        <div class="installing-step-4 installing-step text-center">
                            <div class="content-success">
                                <img src="{{URL::asset('images/icon-success.png')}}" alt="icon success ali orders">
                                <h2>INSTALLED SUCCESSFUL</h2>
                                <p>Congratulation, you have updated all necessary information for your product and order list.</p>
                                <a href="{{ route('dashboard.index') }}" class="button-style">Discover Now</a>
                            </div>
                        </div>

                        <div class="installing-step-5 installing-step">
                            <div class="content-success">
                                <img style="width: 70px; height: 70px;" src="{{ URL::asset('images/backend/chrome-logo.png') }}">
                                <h2>EXTENSION REQUIRED</h2>
                                <p><span class="color-skin fw-600">Easy Transfer from Oberlo</span> requires <span class="color-skin fw-600">Chrome's extension</span> to start process.<br/>Do you want to install it now?</p>
                                <div class="progress-loading-btn-wrap text-center">
                                    <span id="progress-loading-btn-5" class="button-style button-style-o ao__transfer_btn">Skip Next</span>
                                    <span id="progress-loading-btn-5-1" onclick="installChrome()" class="button-style ao__transfer_btn">Install Now</span>
                                </div>
                            </div>
                        </div>

                        <div class="installing-step-51 installing-step">
                            <div class="content-success">
                                <img style="width: 70px; height: 70px;" src="{{ URL::asset('images/backend/chrome-logo.png') }}">
                                <h2>EXTENSION REQUIRED</h2>
                                <p><span class="color-skin fw-600">Easy Transfer from Oberlo</span> requires <span class="color-skin fw-600">Chrome's extension</span> to start process.<br/>Do you want to install it now?</p>
                                <div class="progress-loading-btn-wrap text-center">
                                    <span id="progress-loading-btn-51" class="button-style button-style-o ao__transfer_btn">I'll install later</span>
                                    <span id="progress-loading-btn-51-1" class="button-style ao__transfer_btn">I have installed</span>
                                </div>
                            </div>
                        </div>

                        <div class="installing-step-6 installing-step">
                            <div class="vue__loaders_wrapper" v-show="step_loading">
                                <vue_loaders_circle loading="Connecting..."></vue_loaders_circle>
                            </div>
                            <div class="content-success" v-show="! step_loading" style="display: none;">
                                <img style="width: 70px; height: 70px;" src="{{ URL::asset('images/backend/connect-oberlo-icon.png') }}">
                                <h2>CONNECT OBERLO ACCOUNT</h2>
                                <p class="m-b-15">Please click on below link to connect your Oberlo account. Make sure 
                                        you log in the same account on both Oberlo and Ali Orders then press <span class="color-skin fw-600">Retry</span> button</p>
                                <p><a class="text-link" href="https://{{ session('shopDomain') }}/admin/apps" target="_blank">Click here to login Oberlo</a></p>
                                <div class="progress-loading-btn-wrap text-center">
                                    <span id="progress-loading-btn-6" class="button-style button-style-o ao__transfer_btn">Later</span>
                                    <span id="progress-loading-btn-6-1" class="button-style ao__transfer_btn">Retry</span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            {{--<div class="bottom-text">
                <a class="text-link fz-11" href="https://fireapps.io/terms-of-service" target="_blank">Term of use.</a> &nbsp;&nbsp;&nbsp;<a class="text-link fz-11" href="https://fireapps.io/privacy-policy" target="_blank">Privacy policy</a>
            </div>--}}
        </div>
    </div>


@endsection

@section('footer_extend')
    <script>
        window.chromeExtensionId = "{{ session('aliorders_chrome_extension_id', null) != null ? session('aliorders_chrome_extension_id') : env('EXTENSION_ID') }}"
		$(function() {
			$(".meter > span").each(function() {
                $(this)
                    .data("origWidth", $(this).width())
                    .width(0)
                    .animate({
                        width: $(this).data("origWidth")
                    }, 10000);

                var run_installing=setInterval(function () {
                    var percent_install=parseInt($('.meter span').width()/$('.meter').width()*100);
                    if(percent_install==25){
                        $('.progress-loading-wrap .col-sm-3:nth-child(2) .progress-block-text').addClass('done-install');
                    }
                    if(percent_install==50){
                        $('.progress-loading-wrap .col-sm-3:nth-child(3) .progress-block-text').addClass('done-install');
                    }
                    if(percent_install==75){
                        $('.progress-loading-wrap .col-sm-3:nth-child(4) .progress-block-text').addClass('done-install');
                    }
                    if(percent_install==99){
                        $('.progress-loading-wrap .col-sm-3:nth-child(5) .progress-block-text').addClass('done-install');
                    }
                    if(isNaN(percent_install)){
                        clearInterval(run_installing);
                    }
                },10);
			});
		});
    </script>
    <script type="text/javascript" src="{{ URL::asset('js/modules/loading.min.js') }}"></script>
@endsection
