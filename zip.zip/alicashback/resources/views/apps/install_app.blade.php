@include('layout.head')
@include('layout.google_analytics')
<div id="install-app-wrap" class="sign-in welcome-page">
    <div class="content-left text-center">
        <div class="max-width-450">
            <div class="logo">
                <img src="{{ URL::asset('images/logo-aliorder-white.svg') }}" alt="logo ali orders">
            </div>
            <div class="title-logo">
                <h1>Ali Orders</h1>
                <h4>A Product Of FireApps</h4>
            </div>
        </div>
        <div class="bottom-text">
            <a class="text-link fz-11" href="https://fireapps.io/terms-of-service" target="_blank">Term of use.</a> &nbsp;&nbsp;&nbsp;<a class="text-link fz-11" href="https://fireapps.io/privacy-policy" target="_blank">Privacy policy</a>
        </div>
    </div>
    <div class="content-right text-center">
        <div class="form-sign-in">
            <div class="title-form">
                <h2>WELCOME</h2>
                <p>Please enter your Shopify URL</p>
            </div>
            <form id="installation-shop-form" method="post" action="{{ route('apps.installHandle') }}" name="installShopify">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <div class="form-group">
                    <label class="hidden" for="url-shopify">Shopify URL:</label>
                    <input class="fz-15" type="text" placeholder="Example: aliorder.myshopify.com" v-model="shop_url" name="shop" id="basic-url" value="" aria-describedby="basic-addon3">
                    <p v-text="shop_url_error ? ' Please input your Shopify store\'s link (store_name.myshopify.com)' : ''" class="m-t-10 text-error fz-13" style="font-style: italic;"></p>
                </div>
                <div class="form-submit" style="margin-top: 50px">
                    <input class="login button-style buttn__submit" type="submit" value="Login">
                </div>

                @include('sections.alert_success')
            </form>
        </div>
        <div class="text-bottom-right">
            <div class="">
                <a href="https://www.shopify.com/pricing?ref=developer-4d9a2b35fefa4208&amp;utm_campaign=webappdata" target="_blank" class="bg-text-bottom-right">
                    Click here to create your own store if you haven’t used Shopify yet
                    <img src="{{ URL::asset('images/backend/shopify-white.png') }}">
                </a>
            </div>
        </div>
    </div>
</div>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KZCPC4W" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
@section('footer_extend')
    <script type="text/javascript" src="{{ URL::asset(mix('js/modules/install_app.min.js')) }}"></script>
@endsection
@include('layout.footer')
