@extends('layout.backend')

@section('head_extend')
	<link href="{{ URL::asset('css/order.css') }}" rel="stylesheet">
@endsection

@section('content_container')
	<div class="orders-content-wrap" id="order-fulfillment">
		<div class="orders__notify-wrap" style="display: none">
			Ali Orders will only sync orders from Shopify with <b>Payment status = Paid/Partially refunded/Refunded</b> & the product is still available in <b>Ali Orders Product List</b>
			<span class="orders__notify-close button__notify-close"><i class="mdi mdi-close"></i></span>
		</div>
		<filter-order v-on:get_order="getOrders" v-bind:filters="filters"></filter-order>
		<div v-if="loading_filter" style="height: 64px;"></div>
		<div v-else v-show="! loading_filter" style="display: none" class="total-orders-wrap">
			<p class="fw-400 fz-15 width_orders">Total: <span class="color-skin fw-600" v-text="pagination.total"></span> Order<span v-if="pagination.total > 1 || pagination.total==0">s</span></p>
				<button @click="runJobOrders($event)" class="job-orders-btn button-style-sm-o" data-toggle="tooltip" title="Use this button to update your Order List if missing orders. The process may take a while to finish."><?php echo e(__('orders.text_sync_order')); ?></button>
                <button @click="exportFile('csv')" class="export-csv-btn button-style-export" :disabled="is_export.csv" v-text="( ! is_export.csv) ? 'Export CSV' : 'Exporting...'"><?php echo e(__('orders.text_export_csv')); ?></button>
			<div v-if="(filters.status.length === 1 && filters.status[0] == 1)" class="action-order-wrap pull-right" id="place-all-order">
				<span class="button-place-all-orders button-style-sm" @click="placePageOrder"><i class="mdi mdi-cart-plus"></i>Place All Orders</span>
			</div>

			<div v-if="(filters.status.length === 1 && filters.status[0] == 2 && Object.keys(orders).length > 0)" class="action-order-wrap pull-right">
				<span class="button-import-tracking-code button-style-sm m-l-30" :disabled="is_get_tracking_code" @click="getAllTrackingCode(orders)">
					<i class="mdi mdi-exit-to-app"></i> <span>Get Tracking AliExpress</span></span>
			</div>

			<div v-if="filters.status.length > 1" class="action-order-wrap pull-right">
				{{--  <span @click="syncAliOrderNo" :disabled="is_sync_ali_order_no" class="button-sync-ali-number button-style-sm-o"><i class="mdi mdi-autorenew"></i>
					<span>Sync Ali Order No</span>
				</span>  --}}
				<span @click="importFromFile()" class="button-import-tracking-code button-style-sm m-l-30"><i class="mdi mdi-download"></i>Import Tracking Code</span>
			</div>
		</div>

		<div v-if="loading_filter">
			<vue_loaders_circle loading="Loading..."></vue_loaders_circle>
		</div>
		<div v-else class="orders-list-wrapper" v-show="! loading_filter" style="display: none">
			<input type="hidden" value="{{ $shopId }}" id="data_shop_id">
			<input type="hidden" value="{{ $shopDomain }}" id="data_shop_domain">
			<input type="hidden" value="{{ $accessToken }}" id="data_access_token">
			<input type="hidden" value="{{ json_encode($filters) }}" ref="data_json_filters">


			<div class="orders-list-container">
				<div class="sidebar-orders-list">
					<div class="sidebar-orders-status">
						<div class="box-orders-status">
							<h2 data-toggle="collapse" data-target="#fulfillment-status">Fulfillment Status</h2>
							<ul id="fulfillment-status" class="collapse in">
								@foreach(config('order.fulfillment_status_filter') as $k => $v)
									<li>
										<label class="checkbox-style" for="fulfillment_status-{{$k}}">
											<input id="fulfillment_status-{{$k}}" type="checkbox"  value="{{ $k }}" v-model="filters.fulfillment_status" @change="filterOrders"  />
											<span class="checked-style"></span>
											<span class="fulfillment-icon-status-{{ strtolower(str_slug($v,'-')) }}">{{ $v }}</span>
										</label>
									</li>
								@endforeach
							</ul>
						</div>
						<div class="box-orders-status">
							<h2 data-toggle="collapse" data-target="#financial-status">Financial Status</h2>
							<ul id="financial-status" class="collapse in">
								@foreach(config('order.financial_status_filter') as $k => $v)
									<li>
										<label class="checkbox-style" for="finacial-status-{{$k}}">
											<input id="finacial-status-{{$k}}" type="checkbox" value="{{ $k }}" v-model="filters.financial_status" @change="filterOrders"/>
											<span class="checked-style"></span>
											<span class="financial-icon-status-{{ strtolower(str_slug($v,'-')) }}">{{ $v }}</span>
										</label>
									</li>
								@endforeach
							</ul>
						</div>
						<div class="box-orders-status">
							<h2 data-toggle="collapse" data-target="#flags-status">Flags Status</h2>
							<ul id="flags-status" class="collapse in">
								@foreach(config('order.flags') as $k => $flag)
									<li>
										<label class="checkbox-style" for="filter-flag-{{ $k }}">
											<input id="filter-flag-{{ $k }}" type="checkbox" value="{{ $k }}" v-model="filters.flag" @change="filterOrders" />
											<span class="checked-style"></span>
											<span class="{{ $flag['class'] }}">{{ $flag['title'] }}</span>
										</label>
									</li>
								@endforeach
							</ul>
						</div>
					</div>
				</div>
				<div class="content-orders-list">
					<div class="head-tabs-orders-list">
						<div class="tabs-orders-list-wrap">
							<ul class="tabs-orders-list">
								<li @click="filterOrdersStatus($event, 0)" v-bind:class="filters.status.length > 1 ? 'active' : ''">All Orders (@{{ statusCount.total }})</li>
								<li @click="filterOrdersStatus($event, 1)" v-bind:class="(filters.status.length === 1 && filters.status[0] == 1 ) ? 'active' : ''">To Order (@{{ statusCount.to_order }})</li>
								<li @click="filterOrdersStatus($event, 2)" v-bind:class="(filters.status.length === 1 && filters.status[0] == 2 ) ? 'active' : ''">Order Placed (@{{ statusCount.order_placed }})</li>
								<li @click="filterOrdersStatus($event, 3)" v-bind:class="(filters.status.length === 1 && filters.status[0] == 3 ) ? 'active' : ''">Shipped (@{{ statusCount.shipped }})</li>
							</ul>
						</div>
					</div>

					<div class="vue__loaders_wrapper" v-show="loading_page">
						<vue_loaders_circle></vue_loaders_circle>
					</div>
					<div v-show="! loading_page">
						<div class="tabs-orders-content">
							<div v-if="Object.keys(orders).length === 0">
								<div class="content-not-found-wrap">
									<div>
										<img src="{{ URL::asset('images/backend/import-list-empty.png') }}" />
									</div>
									<div style="padding-left: 20px;">
                                        <h2 v-if="this.filter_search===false">Your Order List is Empty</h2>
                                        <h2 v-if="this.filter_search===true">Cannot Find Orders!</h2>
										<p>No orders matching your search options</p>
									</div>
								</div>
							</div>
							<div class="content-all-orders active">
								<div class="orders-list-wrap_item" v-for="(order, index) in orders" v-bind:id="'order-id-'+ index">
									<div class="orders-list-wrap" >
										<div class="orders-list-header">
											<div class="order__flag">
												<div class="dropdown order__flag-dropdown">
													<span class="order__flag-toggle" data-toggle="dropdown">
														<span v-bind:class="(flags[order.flag]) ? flags[order.flag].class : 'flags-icon-class-white'"></span>
													</span>
													<div class="dropdown-menu box-dropdown-menu">
														<ul class="flags-order-list">
															<li v-for="(flag, key) in flags" @click="choiceFlag(key, order.id)"><span v-bind:class="flag.class"></span>@{{ flag.title }}</li>
														</ul>
													</div>
												</div>
											</div>
											<div class="order__id">
												<a class="fw-600" v-bind:href="'https://'+shopDomain+'/admin/orders/'+order.id" target="_blank" v-text="order.order_name"></a>
											</div>
											<div class="order__date">
												<p><i class="mdi mdi-calendar"></i>@{{ moment(order.created_at).format('MMM D, YYYY - H:mm') }}</p>
											</div>
											<div class="order__status">
												<div class="order__status_line">
													<span v-bind:class="classFulfillmentStatus(order)" v-text="jsUcfirst(fulfillmentStatus[fulfillment_status(order)])"></span>
												</div>
												<div class="order__status_line">
													<span v-bind:class="classFinancialStatus(order)" v-text="jsUcfirst(financialStatus[financial_status(order)])"></span>
												</div>
											</div>
											<div class="order__action">
												<button v-show="orderHasSourceProductLink(Object.values(order.line_items)).length > 1 && orderCanPlace(order)" class="place-this-order-btn" @click="placeAllOrder(event, order, order.line_items)">Place This Order</button>
											</div>
										</div>
										{{--@{{ Object.values(order.line_items) }}--}}
										{{--<line_item--}}
												{{--v-on:add_variant_product="addVariantProduct"--}}
												{{--v-on:open_shipping_modal="openShippingModal"--}}
												{{--v-on:tracking_code="trackingCode"--}}
												{{--v-bind:index="indexGroup"--}}
												{{--v-bind:line_item_ids="group.line_item_ids"--}}
												{{--v-bind:settings="settings"--}}
												{{--v-bind:order="order"--}}
												{{--v-bind:shop_id="shopId"--}}
												{{--v-bind:order_status="orderStatus"--}}
												{{--v-bind:fulfillment_status="fulfillmentStatus"--}}
												{{--v-bind:financial_status="financialStatus"--}}
												{{--v-bind:line_item="line_item"--}}
												{{--v-bind:current_product="currentProduct"--}}
												{{--v-bind:class_status="classStatus"--}}
												{{--v-bind:shop_domain="shopDomain"--}}
												{{--v-bind:access_token="accessToken"--}}
										{{--></line_item>--}}
										<template v-for="(group, key_group) in order.lineItemGroup">

											<line_item
													v-on:add_variant_product="addVariantProduct"
													v-on:open_shipping_modal="openShippingModal"
													v-on:tracking_code="trackingCode"
													v-bind:index="0"
													v-bind:line_item_number="orderHasSourceProductLink(Object.values(order.line_items)).length > 1 && orderCanPlace(order)"
													v-bind:line_items="group.lineItem"
													v-bind:line_item_ids="group.line_item_ids"
													v-bind:settings="settings"
													v-bind:order="order"
													v-bind:key_group="key_group"
													v-bind:shop_id="shopId"
													v-bind:order_status="orderStatus"
													v-bind:fulfillment_status="fulfillmentStatus"
													v-bind:financial_status="financialStatus"
													v-bind:line_item_first="group.first_line_item"
													v-bind:current_product="currentProduct"
													v-bind:class_status="classStatus"
													v-bind:shop_domain="shopDomain"
													v-bind:access_token="accessToken"></line_item>

										</template>
										<add_variant_aliexpress
											v-on:input_aliexress="inputAliexpress"
											v-bind:current_product="currentProduct"></add_variant_aliexpress>
									</div>
									<div class="orders-list-info">
										<div class="box-orders-list-info">
											<h2 class="collapsed" v-bind:data-toggle="'collapse'" v-bind:data-target="'#show-order-cutomer-info-'+order.id">Customer</h2>
											<div class="order-customer-name">
												<p class="order-customer-name-text" v-if="(order.first_name && order.last_name)">
													<span v-bind:data-target="'#show-order-cutomer-info-'+order.id" data-toggle="collapse" class="text-link collapsed" @click="showOrderCustomer($event)">@{{ order.first_name }} @{{ order.last_name }}</span>
													<span class="order-customer-country"><img v-bind:src="appUrl+'/images/flag/'+(order.country_code ? order.country_code.toLowerCase() : 'default')+'.png'" alt=""></span>
													<span class="order-customer-email" @click="sendMessageTo(order)"><i class="mdi mdi-email"></i></span>
												</p>
												<p v-else>
													<span class="order-customer-country"><img v-bind:src="appUrl+'/images/flag/'+(order.country_code ? order.country_code.toLowerCase() : 'default')+'.png'" alt=""></span>
													<span class="order-customer-email" @click="sendMessageTo(order)"><i class="mdi mdi-email"></i></span>
												</p>
											</div>
											<div class="order-product-total" v-if="Object.keys(order.line_items).length > 1">
												Total <span class="fw-600">@{{ Object.keys(order.line_items).length }} Products</span>
											</div>
											<ul class="order-customer-info-list collapse" v-bind:id="'show-order-cutomer-info-'+order.id">
												<li><p>Name:</p>@{{ order.first_name }} @{{ order.last_name }}</li>
												<li><p>Country:</p>@{{ order.country }}</li>
												<li><p>Address:</p>@{{ order.address1 }}</li>
												<li v-if="order.address2 !== null"><p>Apartment, suite, etc:</p>@{{ order.address2 }}</li>
												<li><p>Province:</p>@{{ order.province }}</li>
												<li><p>City:</p>@{{ order.city }}</li>
												<li><p>Zip:</p>@{{ order.zip }}</li>
												<li><p>Phone:</p>@{{ order.phone }}</li>
												<li class="order-customer-info-email"><p>Email:</p><a v-bind:title="order.email" v-bind:href="'mailto:' + order.email">@{{ order.email }}</a></li>
											</ul>
										</div>
										<div class="box-orders-list-info orders-list-notes" v-bind:class="! order.note ? 'orders-list-note-empty' : ''">
											<div class="orders-notes-text" v-text="order.note" @click="showOrderNotes($event)" title="Click here to edit"></div>
											<div class="form-group m-b-0 orders-notes-input">
												<textarea class="order_note-textarea" v-on:blur="blurHandle($event)" title="Click here to edit" placeholder="Enter your notes" @keyup="autoUpdateHeight($event, order)">@{{ order.note }}</textarea>
												<span class="order_note-textarea-border"></span>
												<button v-show="order.save_order_note_button" class="save-ali-order-note-btn" @click="saveNote($event, order.id)">Save</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

						{{--Pagination--}}
						<div class="pagination-wrap" v-show="pagination.last_page > 1">
							<pagination
								:pagination="pagination"
								:offset="6"
								@paginate="clickPagination"></pagination>
						</div>
					</div>
				</div>
			</div>

			{{--Send email customer--}}
			<send_message_customer
					v-bind:customer="customer"
					v-bind:settings="settings"
			></send_message_customer>
			{{--Add tracking code--}}

			{{--<modal_shipping v-bind:items_detail="itemsDetail"--}}
							{{--v-bind:settings="settings"--}}
							{{--v-on:save_tracking_code="saveTrackingCode"--}}
			{{--></modal_shipping>--}}
			<modal_shippings  v-bind:items_detail="itemsDetail"
							  v-bind:settings="settings"
							  v-on:save_tracking_code="saveMultipleTrackingCode"
			></modal_shippings>
			<modal_trackingcode v-bind:tracking_code_id="trackingCodeId"></modal_trackingcode>

			<modal_place_page_orders
					v-bind:current_page="pagination.current_page"
					v-bind:filters="filters"
					v-bind:shop_domain="shopDomain"></modal_place_page_orders>

			<div class="toast-parent">
				<toast_process v-bind:process="tracking_code_process"
							   v-bind:process_type="tracking_code_process_type"
							   v-on:close_process="closeToastProcess"></toast_process>

				<toast_process_percent @close_process="closeProcessPercent" v-bind:process_percent="process_percent" v-bind:process_title="'Processing'" v-bind:process_successful="'Successfully'"></toast_process_percent>
			</div>

			<popup_import_tracking_code v-on:call-popup="callPopup"></popup_import_tracking_code>
		</div>
	</div>

@endsection


@section('footer_extend')
	@include('orders.components.filters')
	<script>
		window.configOrder = {!! json_encode(config('order')) !!} // Add property configOrder for window to bind it in line_item component
		window.accessToken = "{{ session('accessToken') }}"
	</script>
	<script type="text/javascript" src="/bower_component/jquery-csv/src/jquery.csv.js"></script>
	<script type="text/javascript" src="{{ URL::asset('js/modules/order.min.js') }}"></script>
@endsection
