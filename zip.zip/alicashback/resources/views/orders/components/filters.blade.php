<script type="text/x-template"  id="filterOrder">
    {{--<form id="filterOrder" action="{{ route('orders.index') }}" method="GET">--}}
        <div class="order-filter-wrap">

                <div class="order-filter-keyword">
                    <div class="form-group m-b-0">
                        <input type="text" name="keyword" v-model="filters.keyword" @keypress.enter="searchKeyword" placeholder="Search by keyword">
                    </div>
                </div>

                <div class="filter-order-date">
                    <div class="order-date-form">
                        <input id="filter_date_from" v-model="filters.filter_date_from" name="filter_date_from"  class="datepicker" type="button">
                    </div>
                    <span class="order-date-dash">-</span>
                    <div class="order-date-to">
                        <input id="filter_date_to" v-model="filters.filter_date_to" name="filter_date_to"  class="datepicker" type="button">
                    </div>
                    <div class="filter-order-date-dropdown" @click="showFilterDatePicker">
                        <span><i class="mdi mdi-chevron-down"></i></span>
                    </div>
                    <div id="filter-date-time-picker" v-show="show_filter_date_picker">
                        <div id="filter-date-time-picker-from"></div>
                        <div id="filter-date-time-picker-to"></div>
                        <div id="filter-date-time-apply">
                            <button type="button" @click="filterOrderDateApply">Apply</button>
                        </div>
                    </div>
                </div>
                <div class="order-filter-range-date button">
                        <select id="choice-date_range" v-model="filters.date_range">
                            @foreach(config('order.date_range') as $k => $v)
                               <option value="{{ $k }}">{{ $v }}</option>
                            @endforeach
                        </select>
                </div>

                 <!--
                 <div class="export-order-wrap dropdown box-dropdown">
                     <div class="box-dropdown-toggle" data-toggle="dropdown">
                         <span>Export List</span>
                     </div>
                     <div class="dropdown-menu box-dropdown-menu">
                         <ul class="export-order-list">
                             <li @click="exportFile('csv')"><a  class="export-csv-btn" :disabled="is_export.csv" v-text="( ! is_export.csv) ? 'Export CSV' : 'Exporting...'"><?php echo e(__('orders.text_export_csv')); ?></a></li>
                         </ul>
                     </div>
                 </div> -->

            </div>

            {{--  <div class="filter-order-status-wrap">
                <div class="order-filter-status-wrap">
                    <div class="row">
                        <div class="col-sm-3">
                            <select name="fulfillment_status[]" v-model="filters.fulfillment_status" id="filter-fulfillment_status" multiple>
                                @foreach(config('order.fulfillment_status_filter') as $k => $v)
                                    <option value="{{ $k }}"
                                        data-icon-class="fulfillment-icon-status-{{ strtolower(str_slug($v,'-')) }}">{{ $v}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-sm-3">
                            <select name="financial_status[]" v-model="filters.financial_status" id="filter-financial_status" multiple>
                                @foreach(config('order.financial_status_filter') as $k => $v)
                                    <option value="{{ $k }}"
                                        data-icon-class="financial-icon-status-{{ strtolower(str_slug($v,'-')) }}">{{ $v }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-sm-3 flags-status">
                            <select name="flag[]" v-model="filters.flag" id="filter-flags_status" multiple>
                                @foreach(config('order.flags') as $key => $flag)
                                <option value="{{ $key }}"
                                data-icon-class="{{ $flag['class'] }}">{{ $flag['title'] }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-sm-3 order-filter-status">
                            <select name="status[]" id="filter-order_status" multiple>
                                @foreach(config('order.status_filter') as $k => $v)
                                    <option value="{{ $k }}"  data-icon-class="orders-icon-status-{{ strtolower(str_replace(' ', '-', $v)) }}">{{ $v }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                </div>
            </div>  --}}

        </div>
    {{--</form>--}}

</script>

<script type="text/javascript">
    Vue.component('filter-order', {
        template: '#filterOrder',
        props: ['filters'],
        data() {
            return {
                show_filter_date_picker: false,
                is_export: {
                    csv: false,
                    xls: false
                }
            }
        },
        mounted: function () {
            let _this = this

            $('#filter_date_from').datetimepicker({
                widgetParent: '#filter-date-time-picker-from',
                format: 'MMM DD, YYYY',
                keepOpen: true,
                debug: true,
                inline: true,
                sideBySide: true
            });
            $('#filter_date_to').datetimepicker({
                widgetParent: '#filter-date-time-picker-to',
                format: 'MMM DD, YYYY',
                keepOpen: true,
                debug: true,
                inline: true,
                sideBySide: true
            });

            $("#filter_date_from").on("dp.change", function (e) {
                _this.filters.paged = 1
                _this.filters.filter_date_from = e.date.format('MMM DD, YYYY')
                //_this.getOrders(_this.filters)
                $('#filter_date_to').data("DateTimePicker").minDate(e.date);
            });

            $("#filter_date_to").on("dp.change", function (e) {
                _this.filters.filter_date_to = e.date.format('MMM DD, YYYY')
               // _this.getOrders()
            });

            $('#choice-date_range').multiselect({
                enableHTML: true,
                nonSelectedText: 'Select date range',
                buttonContainer: '<div class="selected-parents-container select-no-checked"></div>',
            }).change(function (event) {
                let current = $(event.currentTarget);
                _this.date_range = current.val();
                _this.date_now = moment().format();
                _this.date_to = moment().format('MMM DD, YYYY');

                switch (_this.date_range) {
                    case 'today' :
                        _this.date_to = _this.date_from = moment().format('MMM DD, YYYY');
                        break;
                    case 'yesterday' :
                        _this.date_from = _this.date_to = moment().add(-1, 'day').format('MMM DD, YYYY');
                        break;
                    case 'last_7days' :
                        _this.date_from = moment(_this.date_now).add(-7, 'days').format('MMM DD, YYYY');
                        break;
                    case 'last_30days' :
                        _this.date_from = moment(_this.date_now).add(-30, 'days').format('MMM DD, YYYY');
                        break;
                    case 'last_90days' :
                        _this.date_from = moment(_this.date_now).add(-90, 'days').format('MMM DD, YYYY');
                        break;
                    case 'week_to_date':
                        _this.date_from = moment(_this.date_now).add(-1, 'week').format('MMM DD, YYYY');
                        break;
                    case 'month_to_date' :
                        _this.date_from = moment(_this.date_now).add(-1, 'month').format('MMM DD, YYYY');
                        break;
                    case 'year_to_date' :
                        _this.date_from = moment(_this.date_now).add(-1, 'year').format('MMM DD, YYYY');
                        break;
                    default :
                        _this.date_from = moment(_this.date_now).add(-30, 'days').format('MMM DD, YYYY');
                        break;
                }
                _this.filters.paged = 1
                _this.filters.filter_date_from = _this.date_from
                _this.filters.filter_date_to = _this.date_to
                _this.filters.date_range = _this.date_range
                _this.getOrders()

            });


            $('#filter-order_status').multiselect({
                enableHTML: true,
                nonSelectedText: 'Order Status',
                buttonContainer: '<div class="selected-parents-container"></div>',
                optionLabel: function (element) {
                    return '<span class="' + $(element).data('icon-class') + '"></span>' + $(element).text();
                }
            })
                .change(function (event) {
                _this.filters.paged = 1
                _this.filters.status = $(event.currentTarget).val()
                _this.getOrders()
            });

            $('#filter-flags_status').multiselect({
                enableHTML: true,
                enableFiltering: false,
                nonSelectedText: 'Flags Status',
                buttonContainer: '<div class="selected-parents-container"></div>',
                optionLabel: function (element) {
                    return '<span class="' + $(element).data('icon-class') + '"></span>' + $(element).text();
                }
            }).change(function (event) {
                _this.filters.paged = 1
                _this.filters.flag = $(event.currentTarget).val()
                _this.getOrders()
            });

            $('#filter-fulfillment_status').multiselect({
                enableHTML: true,
                nonSelectedText: 'Fulfillment Status',
                buttonContainer: '<div class="selected-parents-container"></div>',
                optionLabel: function (element) {
                    return '<span class="' + $(element).data('icon-class') + '"></span>' + $(element).text();
                }
            }).change(function (event) {
                _this.filters.paged = 1
                _this.filters.fulfillment_status = $(event.currentTarget).val()
                _this.getOrders()
            });

            $('#filter-financial_status').multiselect({
                enableHTML: true,
                nonSelectedText: 'Financial Status',
                buttonContainer: '<div class="selected-parents-container"></div>',
                optionLabel: function (element) {
                    return '<span class="' + $(element).data('icon-class') + '"></span>' + $(element).text();
                }
            }).change(function (event) {
                _this.filters.paged = 1
                _this.filters.financial_status = $(event.currentTarget).val()
                _this.getOrders()
            });

            $(document.body).on('click', function(event) {
                if ($(event.target).closest('.filter-order-date').length === 0) {
                    _this.show_filter_date_picker = false
                }
            });

        },
        methods: {
            searchKeyword: function () {
                console.log('vao day')
                this.getOrders()
            },
            getOrders: function () {
                this.$emit('get_order', this.filters)
                console.log('vao get order')
            },
            /**
            * Handle click button export csv or xls order
            * @param type
            */
            exportFile: function () {
                let _this = this
                const urlParams = new URL(appUrl+'/orders/export');
                $.each(this.filters, function(index, value) {
                    urlParams.searchParams.set(index, value);
                });

                window.open(urlParams.href, '_blank');
                // this.is_export[type] = true
                // axios.post(appUrl+'/orders/export', {filters: this.filters, shop_id: window.shopId, type: type})
                //     .then(function (response) {
                //         console.log(response)
                //         // _this.$nextTick(function () {
                //         //     _this.is_export[type] = false
                //         // })
                //         // let { partSource, fileName, type } = response.data
                //         // let url = appUrl+'/storage/exports/'+fileName+'.'+type
                //         // _this.downloadURI(url, 'csv')
                //     })
                //     .catch(function (error) {
                //         _this.is_export[type] = false
                //         console.log(error)
                //         notify('error', error)
                //     })
            },
            downloadURI(uri, name) {
                var link = document.createElement("a");
                link.download;
                link.href = uri;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                delete link;
            },
            showFilterDatePicker: function() {
                if(this.show_filter_date_picker == true)
                    this.show_filter_date_picker = false
                else
                    this.show_filter_date_picker = true
            },
            filterOrderDateApply: function() {
                this.getOrders()
                this.show_filter_date_picker = false
            }
        },
        watch:{
            // filters_prop:{
            //     handler: function (value) {
            //         console.log(value)
            //         this.filters = value
            //     },
            //     deep: true
            //}
            filters: {
                handler: function (value) {
                    $("input[name='keyword']").val(value.keyword)
                    $('#choice-date_range').multiselect('select', value.date_range)
                    $('#filter-fulfillment_status').multiselect('select', value.fulfillment_status)
                    $('#filter-financial_status').multiselect('select', value.financial_status)
                    $('#filter-flags_status').multiselect('select', value.flag)
                    $('#filter-order_status').multiselect('select', value.status)
                    $('#filter_date_to').data("DateTimePicker").date(value.filter_date_to);
                    $('#filter_date_from').data("DateTimePicker").date(value.filter_date_from);
                },
                deep: true
            }
        }
    })
</script>
