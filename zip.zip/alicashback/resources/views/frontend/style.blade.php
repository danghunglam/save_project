<div id="aliorders-bukl-action" class="aliorders-bukl-action-edit">
    <span onclick="window.open('https://aliorders.fireapps.io/products/edit/{{ product.id }}/{{ shop.domain }}','mywindow');" style="cursor: pointer;">
        <img src="https://aliorders-dev.fireapps.io/images/backend/ailorder-shortcut.png" />
    </span>
</div>
<style type="text/css">
    .aliorders-bukl-action-edit {
        position: fixed;
        right: 20px;
        bottom: 70px;
        width: 60px;
        height: 60px;
        cursor: pointer;
        display: none;
        z-index: 9999;
    }
    .aliorders-bukl-action-edit > span {
        display: inline-block;
        overflow: hidden;
        width: 60px;
        height: 60px;
        border-radius: 50%;
    }
</style>
<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
        let adminBarIframe = document.getElementById('admin-bar-iframe');
        if(adminBarIframe != null) {
            $(".aliorders-bukl-action-edit").css("display", "block");
        } else {
            $(".aliorders-bukl-action-edit").css("display", "none");
        }
    });
</script>