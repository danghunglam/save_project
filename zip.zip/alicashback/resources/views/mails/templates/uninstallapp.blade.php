<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">

    <style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=Poppins');
        /* reset  color: #fff;*/
        .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {
            line-height: 100%;
        }

        /* Forces Hotmail to display normal line spacing.  More on that: http://www.emailonacid.com/forum/viewthread/43/ */
        p {
            margin: 0;
            padding: 0;
            font-size: 16px;
            line-height: 1.5px;
        }

        /* squash Exact Target injected paragraphs */
        table td {
            border-collapse: collapse;
        }

        /* Outlook 07, 10 padding issue fix */
        table {
            border-collapse: collapse;
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }

        /* remove spacing around Outlook 07, 10 tables */
        /* bring inline */
        img {
            display: block;
            outline: none;
            text-decoration: none;
            -ms-interpolation-mode: bicubic;
        }

        a img {
            border: none;
        }

        a {
            text-decoration: none;
            color: #000001;
        }

        /* text link */
        a.phone {
            text-decoration: none;
            color: #000001 !important;
            pointer-events: auto;
            cursor: default;
        }

        /* phone link, use as wrapper on phone numbers */
        /*span {font-size: 13px; line-height: 17px; color: #000001;}*/
    </style>
    <!--[if gte mso 9]>
    <style>
        /* Target Outlook 2007 and 2010 */
    </style>
    <![endif]-->
</head>
<body style="width:100%; margin:0; padding:0; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; font-family: 'Poppins', sans-serif;">

<!-- body wrapper -->
<table cellpadding="10px" cellspacing="0" border="0"
       style="margin: 0;padding: 0;width: 100%;line-height: 100% !important;font-family: 'Poppins', sans-serif;border-collapse: collapse;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
    <tr style="background-color:rgb(38, 194, 121); color: #fff; height: 50px;">
        <td colspan="1" style="border-collapse: collapse; font-family: 'Poppins', sans-serif;">
            New Message from <a href="https://shopboostify.com" target="_blank" title="ShopBoostify"
                                style="color: #ffffff;text-decoration: none;"><u>ShopBoostify.com</u></a>
        </td>
        <td colspan="1" style="border-collapse: collapse; font-family: 'Poppins', sans-serif; text-align: right;">{{ date('M, d, Y') }}</td>
    </tr>
    <tr align="center">
        <td colspan="2">
            <table cellpadding="10px" cellspacing="0" border="0"
                   style="font-family: 'Poppins', sans-serif;border-collapse: collapse;mso-table-lspace: 0pt;mso-table-rspace: 0pt;">
                <tr>
                    <td colspan="1" align="center" style="height: 100px;border-collapse: collapse;">
                        <img src="https://alireview.shopboostify.com/images/mail/ShopBOOSTify.png" alt="ShopBoostify"
                             style="display: block;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;">
                    </td>
                </tr>
                <tr>
                    <td colspan="1" align="center" style="border-collapse: collapse;">
                        <img src="https://alireview.shopboostify.com/images/mail/we-sorry.png"
                             alt="We're sorry to see you go!" title="We're sorry to see you go!"
                             style="display: block;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;">
                    </td>
                </tr>
                <tr style="height: 25px;"></tr>
                <tr>
                    <td colspan="1" align="center"
                        style="font-size: 30px;line-height: 1.5;font-weight: 700;border-collapse: collapse;font-family: 'Poppins', sans-serif;">
                        Thank {{ $data['name'] }} for
                        choosing Shop<span style="font-size: 30px; color:#26c179;">BOOST</span>ify and we’re sorry to
                        see
                        you go!
                    </td>
                </tr>
                <tr style="height: 25px;"></tr>
                <tr>
                    <td colspan="1"
                        style="font-size: 16px;line-height: 1.6;border-collapse: collapse;font-family: 'Poppins', sans-serif;"
                        align="center">
                        Because we want every Shopify ownerto be thrilled with our service. We’d like to know how make
                        things better for you and what we did wrong. Could you tell us why you uninstalled? Your answers
                        are
                        valuable
                        to our developers.
                    </td>
                </tr>
                <tr style="height: 25px;"></tr>
                <tr>
                    <td colspan="1" align="center"
                        style="border-collapse: collapse;font-family: 'Poppins', sans-serif;">
                        <a href="mailto:support@shopboostify.com" style="padding: 20px 30px; color: #ffffff; text-transform:uppercase; border-radius: 2px; background-color: rgb(38, 193, 121); border:none;">
                            Leave Feedback
                        </a>
                    </td>
                </tr>
                <tr style="height: 25px;"></tr>
                <tr>
                    <td colspan="1" align="center"
                        style="font-size: 16px;line-height: 1.6;border-collapse: collapse;font-family: 'Poppins', sans-serif;">
                        Thanks for helping make Shop<span style="color:#26c179;">BOOST</span>ify even better!
                    </td>
                </tr>
                <tr>
                    <td colspan="1" align="center"
                        style="font-size: 16px;line-height: 1.6;border-collapse: collapse;font-family: 'Poppins', sans-serif;">
                        Regards,
                    </td>
                </tr>
                <tr>
                    <td colspan="1" align="center"
                        style="font-size: 16px;line-height: 1.6;border-collapse: collapse;font-family: 'Poppins', sans-serif;">
                        <b>Shop<span style="color:#26c179;">BOOST</span>ify Team</b>
                    </td>
                </tr>
                <tr style="height: 25px;"></tr>
                <tr style="height: 25px;">
                    <td style="border-collapse: collapse;">
                        <hr>
                    </td>
                </tr>
                <tr style="height: 25px;"></tr>
                <tr>
                    <td colspan="1" align="center"
                        style="border-collapse: collapse;font-family: 'Poppins', sans-serif;">
                        <a href="#" target="_blank" style="text-decoration: none;color:#26c179;">How it works</a> <span
                                style="color:#cecece;">|</span> <a href="#" target="_blank"
                                                                   style="text-decoration: none;color:#26c179;">Contact
                            US</a> <span style="color:#cecece;">|</span> <a href="#" target="_blank"
                                                                            style="text-decoration: none;color:#26c179;">Unsubscribe</a>
                        <span style="color:#cecece;">|</span> <a href="#" target="_blank"
                                                                 style="text-decoration: none;color:#26c179;">View In
                            Browser</a>
                    </td>
                </tr>
                <tr>
                    <td colspan="1" align="center"
                        style="border-collapse: collapse;font-family: 'Poppins', sans-serif; line-height: 1.5;">
                        © 2017 All rights reserved to Shop<span style="color:#26c179;">BOOST</span>ify. If any questions
                        mail us at <a
                                href="mailto:support@shopboostify.com" target="_top"
                                style="text-decoration: none;color:#26c179;">support@shopboostify.com</a>
                    </td>
                </tr>
                <tr style="height: 35px;"></tr>
                <tr>
                    <td colspan="1" align="center"
                        style="border-collapse: collapse;font-family: 'Poppins', sans-serif;">
                        <img src="https://alireview.shopboostify.com/images/mail/stay-in-touch.png" alt="Stay in touch"
                             title="Stay in touch"
                             style="display: block;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;">
                    </td>
                </tr>
                <tr style="height: 25px;"></tr>
                <tr>
                    <td colspan="1" align="center"
                        style="border-collapse: collapse;font-family: 'Poppins', sans-serif;">
                        <a href="#" style="display: inline-block; color: #26c179;"><img
                                    src="https://alireview.shopboostify.com/images/mail/facebook_icon.png"
                                    style="margin: 0 10px;display: inline-block;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;border: none;"></a>
                        <a href="#" style="display: inline-block;color: #26c179;"><img
                                    src="https://alireview.shopboostify.com/images/mail/twitter_icon.png"
                                    style="margin: 0 10px;display: inline-block;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;border: none;"></a>
                        <a href="#" style="display: inline-block;color: #26c179;"><img
                                    src="https://alireview.shopboostify.com/images/mail/email_icon.png"
                                    style="margin: 0 10px;display: inline-block;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;border: none;"></a>
                    </td>
                </tr>
                <tr style="height: 30px;"></tr>
            </table>
        </td>
    </tr>
</table>


<!-- / page wrapper -->
</body>
</html>
