<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <!-- NAME: TELL A STORY -->
    <!--[if gte mso 15]>
    <xml>
        <o:OfficeDocumentSettings>
            <o:AllowPNG/>
            <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
    </xml>
    <![endif]-->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>

    <style type="text/css">
        p{
            margin:10px 0;
            padding:0;
        }
        table{
            border-collapse:collapse;
        }
        h1,h2,h3,h4,h5,h6{
            display:block;
            margin:0;
            padding:0;
        }
        img,a img{
            border:0;
            height:auto;
            outline:none;
            text-decoration:none;
        }
        body,#bodyTable,#bodyCell{
            height:100%;
            margin:0;
            padding:0;
            width:100%;
        }
        .mcnPreviewText{
            display:none !important;
        }
        #outlook a{
            padding:0;
        }
        img{
            -ms-interpolation-mode:bicubic;
        }
        table{
            mso-table-lspace:0pt;
            mso-table-rspace:0pt;
        }
        .ReadMsgBody{
            width:100%;
        }
        .ExternalClass{
            width:100%;
        }
        p,a,li,td,blockquote{
            mso-line-height-rule:exactly;
        }
        a[href^=tel],a[href^=sms]{
            color:inherit;
            cursor:default;
            text-decoration:none;
        }
        p,a,li,td,body,table,blockquote{
            -ms-text-size-adjust:100%;
            -webkit-text-size-adjust:100%;
        }
        .ExternalClass,.ExternalClass p,.ExternalClass td,.ExternalClass div,.ExternalClass span,.ExternalClass font{
            line-height:100%;
        }
        a[x-apple-data-detectors]{
            color:inherit !important;
            text-decoration:none !important;
            font-size:inherit !important;
            font-family:inherit !important;
            font-weight:inherit !important;
            line-height:inherit !important;
        }
        .templateContainer{
            max-width:600px !important;
        }
        a.mcnButton{
            display:block;
        }
        .mcnImage,.mcnRetinaImage{
            vertical-align:bottom;
        }
        .mcnTextContent{
            word-break:break-word;
        }
        .mcnTextContent img{
            height:auto !important;
        }
        .mcnDividerBlock{
            table-layout:fixed !important;
        }
        /*
        @tab Page
 Heading 1
	@style heading 1
	*/
        h1{
            /*@editable*/color:#222222;
            /*@editable*/font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;
            /*@editable*/font-size:40px;
            /*@editable*/font-style:normal;
            /*@editable*/font-weight:normal;
            /*@editable*/line-height:150%;
            /*@editable*/letter-spacing:normal;
            /*@editable*/text-align:left;
        }
        /*
        @tab Page
 Heading 2
	@style heading 2
	*/
        h2{
            /*@editable*/color:#222222;
            /*@editable*/font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;
            /*@editable*/font-size:34px;
            /*@editable*/font-style:normal;
            /*@editable*/font-weight:normal;
            /*@editable*/line-height:150%;
            /*@editable*/letter-spacing:normal;
            /*@editable*/text-align:left;
        }
        /*
        @tab Page
 Heading 3
	@style heading 3
	*/
        h3{
            /*@editable*/color:#444444;
            /*@editable*/font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;
            /*@editable*/font-size:22px;
            /*@editable*/font-style:normal;
            /*@editable*/font-weight:normal;
            /*@editable*/line-height:150%;
            /*@editable*/letter-spacing:normal;
            /*@editable*/text-align:left;
        }
        /*
        @tab Page
 Heading 4
	@style heading 4
	*/
        h4{
            /*@editable*/color:#999999;
            /*@editable*/font-family:Georgia, Times, 'Times New Roman', serif;
            /*@editable*/font-size:20px;
            /*@editable*/font-style:italic;
            /*@editable*/font-weight:normal;
            /*@editable*/line-height:125%;
            /*@editable*/letter-spacing:normal;
            /*@editable*/text-align:left;
        }
        /*
        @tab Header
 Header Container Style
	*/
        #templateHeader{
            /*@editable*/background-color:#ededed;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:1px none ;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:40px;
            /*@editable*/padding-bottom:0px;
        }
        /*
        @tab Header
 Header Interior Style
	*/
        .headerContainer{
            /*@editable*/background-color:#ffffff;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:5px solid #dadada;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:px;
            /*@editable*/padding-bottom:px;
        }
        /*
        @tab Header
 Header Text
	*/
        .headerContainer .mcnTextContent,.headerContainer .mcnTextContent p{
            /*@editable*/color:#222121;
            /*@editable*/font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;
            /*@editable*/font-size:16px;
            /*@editable*/line-height:150%;
            /*@editable*/text-align:right;
        }
        /*
        @tab Header
 Header Link
	*/
        .headerContainer .mcnTextContent a,.headerContainer .mcnTextContent p a{
            /*@editable*/color:#00ADD8;
            /*@editable*/font-weight:normal;
            /*@editable*/text-decoration:underline;
        }
        /*
        @tab Body
 Body Container Style
	*/
        #templateBody{
            /*@editable*/background-color:#ededed;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:1px none ;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:0px;
            /*@editable*/padding-bottom:0px;
        }
        /*
        @tab Body
 Body Interior Style
	*/
        .bodyContainer{
            /*@editable*/background-color:#ffffff;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:1px none ;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:27px;
            /*@editable*/padding-bottom:27px;
        }
        /*
        @tab Body
 Body Text
	*/
        .bodyContainer .mcnTextContent,.bodyContainer .mcnTextContent p{
            /*@editable*/color:#222121;
            /*@editable*/font-family:Helvetica;
            /*@editable*/font-size:16px;
            /*@editable*/line-height:150%;
            /*@editable*/text-align:left;
        }
        /*
        @tab Body
 Body Link
	*/
        .bodyContainer .mcnTextContent a,.bodyContainer .mcnTextContent p a{
            /*@editable*/color:#222121;
            /*@editable*/font-weight:normal;
            /*@editable*/text-decoration:underline;
        }
        /*
        @tab Footer
 Footer Style
	*/
        #templateFooter{
            /*@editable*/background-color:#ededed;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:0;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:0px;
            /*@editable*/padding-bottom:40px;
        }
        /*
        @tab Footer
 Footer Interior Style
	*/
        .footerContainer{
            /*@editable*/background-color:#transparent;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:0;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:17px;
            /*@editable*/padding-bottom:0;
        }
        /*
        @tab Footer
 Footer Text
	*/
        .footerContainer .mcnTextContent,.footerContainer .mcnTextContent p{
            /*@editable*/color:#808080;
            /*@editable*/font-family:Helvetica;
            /*@editable*/font-size:12px;
            /*@editable*/line-height:150%;
            /*@editable*/text-align:center;
        }
        /*
        @tab Footer
 Footer Link
	*/
        .footerContainer .mcnTextContent a,.footerContainer .mcnTextContent p a{
            /*@editable*/color:#222121;
            /*@editable*/font-weight:normal;
            /*@editable*/text-decoration:underline;
        }
        @media only screen and (min-width:768px){
            .templateContainer{
                width:600px !important;
            }

        }	@media only screen and (max-width: 480px){
            body,table,td,p,a,li,blockquote{
                -webkit-text-size-adjust:none !important;
            }

        }	@media only screen and (max-width: 480px){
            body{
                width:100% !important;
                min-width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnRetinaImage{
                max-width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImage{
                width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnCartContainer,.mcnCaptionTopContent,.mcnRecContentContainer,.mcnCaptionBottomContent,.mcnTextContentContainer,.mcnBoxedTextContentContainer,.mcnImageGroupContentContainer,.mcnCaptionLeftTextContentContainer,.mcnCaptionRightTextContentContainer,.mcnCaptionLeftImageContentContainer,.mcnCaptionRightImageContentContainer,.mcnImageCardLeftTextContentContainer,.mcnImageCardRightTextContentContainer,.mcnImageCardLeftImageContentContainer,.mcnImageCardRightImageContentContainer{
                max-width:100% !important;
                width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnBoxedTextContentContainer{
                min-width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageGroupContent{
                padding:9px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnCaptionLeftContentOuter .mcnTextContent,.mcnCaptionRightContentOuter .mcnTextContent{
                padding-top:9px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageCardTopImageContent,.mcnCaptionBottomContent:last-child .mcnCaptionBottomImageContent,.mcnCaptionBlockInner .mcnCaptionTopContent:last-child .mcnTextContent{
                padding-top:18px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageCardBottomImageContent{
                padding-bottom:9px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageGroupBlockInner{
                padding-top:0 !important;
                padding-bottom:0 !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageGroupBlockOuter{
                padding-top:9px !important;
                padding-bottom:9px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnTextContent,.mcnBoxedTextContentColumn{
                padding-right:18px !important;
                padding-left:18px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageCardLeftImageContent,.mcnImageCardRightImageContent{
                padding-right:18px !important;
                padding-bottom:0 !important;
                padding-left:18px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcpreview-image-uploader{
                display:none !important;
                width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Heading 1
	@tip Make the first-level headings larger in size for better readability on small screens.
	*/
            h1{
                /*@editable*/font-size:30px !important;
                /*@editable*/line-height:125% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Heading 2
	@tip Make the second-level headings larger in size for better readability on small screens.
	*/
            h2{
                /*@editable*/font-size:26px !important;
                /*@editable*/line-height:125% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Heading 3
	@tip Make the third-level headings larger in size for better readability on small screens.
	*/
            h3{
                /*@editable*/font-size:20px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Heading 4
	@tip Make the fourth-level headings larger in size for better readability on small screens.
	*/
            h4{
                /*@editable*/font-size:18px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Boxed Text
	@tip Make the boxed text larger in size for better readability on small screens. We recommend a font size of at least 16px.
	*/
            .mcnBoxedTextContentContainer .mcnTextContent,.mcnBoxedTextContentContainer .mcnTextContent p{
                /*@editable*/font-size:14px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Header Text
	@tip Make the header text larger in size for better readability on small screens.
	*/
            .headerContainer .mcnTextContent,.headerContainer .mcnTextContent p{
                /*@editable*/font-size:16px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Body Text
	@tip Make the body text larger in size for better readability on small screens. We recommend a font size of at least 16px.
	*/
            .bodyContainer .mcnTextContent,.bodyContainer .mcnTextContent p{
                /*@editable*/font-size:16px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Footer Text
	@tip Make the footer content text larger in size for better readability on small screens.
	*/
            .footerContainer .mcnTextContent,.footerContainer .mcnTextContent p{
                /*@editable*/font-size:14px !important;
                /*@editable*/line-height:150% !important;
            }

        }</style></head>
<body>
<!--*|IF:MC_PREVIEW_TEXT|*-->
<!--[if !gte mso 9]><!----><span class="mcnPreviewText" style="display:none; font-size:0px; line-height:0px; max-height:0px; max-width:0px; opacity:0; overflow:hidden; visibility:hidden; mso-hide:all;">*|MC_PREVIEW_TEXT|*</span><!--<![endif]-->
<!--*|END:IF|*-->
<center>
    <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="yiv3459935963bodyTable" style="border-collapse:collapse;min-height:100%;margin:0;padding:0;width:100%;">
                <tbody id="yui_3_16_0_1_1530082595951_2752"><tr id="yui_3_16_0_1_1530082595951_2751">
                    <td align="center" valign="top" id="yiv3459935963bodyCell" style="min-height:100%;margin:0;padding:0;width:100%;">
                        
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_2750">
							<tbody id="yui_3_16_0_1_1530082595951_2749"><tr id="yui_3_16_0_1_1530082595951_2748">
								<td align="center" valign="top" id="yiv3459935963templateHeader" style="background:#ededed none no-repeat;background-color:#ededed;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:1px none;border-bottom:0;padding-top:40px;padding-bottom:0px;">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963templateContainer" style="border-collapse:collapse;overflow-x:auto;max-width:600px !important;" id="yui_3_16_0_1_1530082595951_2747">
										<tbody id="yui_3_16_0_1_1530082595951_2746">
                                        <tr id="yui_3_16_0_1_1530082595951_2745">
                                			<td valign="top" class="yiv3459935963headerContainer" style="background:#ffffff none no-repeat;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:5px solid #dadada;border-bottom:0;padding-top:px;padding-bottom:px;" id="yui_3_16_0_1_1530082595951_2744">
                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnCaptionBlock" style="border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_2763">
                                                <tbody class="yiv3459935963mcnCaptionBlockOuter" id="yui_3_16_0_1_1530082595951_2762">
                                                    <tr id="yui_3_16_0_1_1530082595951_2761">
                                                        <td class="yiv3459935963mcnCaptionBlockInner" valign="top" style="padding:9px;" id="yui_3_16_0_1_1530082595951_2760">
                                                            <table border="0" cellpadding="0" cellspacing="0" class="yiv3459935963mcnCaptionRightContentOuter" width="100%" style="border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_2759">
                                                                <tbody id="yui_3_16_0_1_1530082595951_2758">
                                                                    <tr id="yui_3_16_0_1_1530082595951_2757">
                                                                        <td valign="top" class="yiv3459935963mcnCaptionRightContentInner" style="padding:0 9px;" id="yui_3_16_0_1_1530082595951_2756">
                                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" class="yiv3459935963mcnCaptionRightImageContentContainer" width="132" style="border-collapse:collapse;">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td class="yiv3459935963mcnCaptionRightImageContent" align="left" valign="top" style="">
                                                                                            <img alt="" src="https://gallery.mailchimp.com/485095222da43f30e5bfab9f3/images/606b717b-fc88-4db9-82c0-f086ebccd4e8.png" width="107" style="overflow-x:auto;max-width:107px;border:0;min-height:auto;outline:none;text-decoration:none;vertical-align:bottom;" class="yiv3459935963mcnImage">
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                            <table class="yiv3459935963mcnCaptionRightTextContentContainer" align="right" border="0" cellpadding="0" cellspacing="0" width="396" style="border-collapse:collapse;">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td valign="top" class="yiv3459935963mcnTextContent" style="color:#222121;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size:16px;line-height:150%;text-align:right;">

                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                    </table>
</td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
							<tr id="yui_3_16_0_1_1530082595951_2768">
								<td align="center" valign="top" id="yiv3459935963templateBody" style="background:#ededed none no-repeat;background-color:#ededed;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:1px none;border-bottom:0;padding-top:0px;padding-bottom:0px;">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963templateContainer" style="border-collapse:collapse;overflow-x:auto;max-width:600px !important;" id="yui_3_16_0_1_1530082595951_2767">
										<tbody id="yui_3_16_0_1_1530082595951_2766"><tr id="yui_3_16_0_1_1530082595951_2765">
                                			<td valign="top" class="yiv3459935963bodyContainer" style="background:#ffffff none no-repeat;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:1px none;border-bottom:0;padding-top:27px;padding-bottom:27px;" id="yui_3_16_0_1_1530082595951_2764"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnImageBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_2777">
    <tbody class="yiv3459935963mcnImageBlockOuter" id="yui_3_16_0_1_1530082595951_2776">
            <tr id="yui_3_16_0_1_1530082595951_2775">
                <td valign="top" style="padding:0px;" class="yiv3459935963mcnImageBlockInner" id="yui_3_16_0_1_1530082595951_2774">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="yiv3459935963mcnImageContentContainer" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_2773">
                        <tbody id="yui_3_16_0_1_1530082595951_2772"><tr id="yui_3_16_0_1_1530082595951_2771">
                            <td class="yiv3459935963mcnImageContent" valign="top" style="padding-right:0px;padding-left:0px;padding-top:0;padding-bottom:0;text-align:center;" id="yui_3_16_0_1_1530082595951_2770">
                                <img align="center" src="https://gallery.mailchimp.com/485095222da43f30e5bfab9f3/images/ce921f4a-43db-4e0d-8421-9066bf3d0b6f.png" width="600" style="overflow-x:auto;max-width:600px;padding-bottom:0;display:inline;vertical-align:bottom;border:0;min-height:auto;outline:none;text-decoration:none;" class="yiv3459935963mcnImage" id="yui_3_16_0_1_1530082595951_2769">
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnTextBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_3021">
    <tbody class="yiv3459935963mcnTextBlockOuter" id="yui_3_16_0_1_1530082595951_3020">
        <tr id="yui_3_16_0_1_1530082595951_3019">
            <td valign="top" class="yiv3459935963mcnTextBlockInner" style="padding-top:9px;" id="yui_3_16_0_1_1530082595951_3018">
              	
			
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="overflow-x:auto;max-width:100%;min-width:100%;border-collapse:collapse;" width="100%" class="yiv3459935963mcnTextContentContainer" id="yui_3_16_0_1_1530082595951_3017">
                    <tbody id="yui_3_16_0_1_1530082595951_3016"><tr id="yui_3_16_0_1_1530082595951_3015">

                        <td valign="top" class="yiv3459935963mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530082595951_3014">

                            <p style="margin:10px 0;padding:0;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530082595951_3022">Hi there,</p>

<p style="margin:10px 0;padding:0;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530082595951_3023">I'm Hailey,&nbsp;your point of contact here at FireApps.</p>

<p style="margin:10px 0;padding:0;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530082595951_3046">I'm really delighted that you installed Ali Orders app. I want to say hi and share a few things to help you get started quickly.</p>

                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed;" id="yui_3_16_0_1_1530082595951_3050">
    <tbody class="yiv3459935963mcnDividerBlockOuter" id="yui_3_16_0_1_1530082595951_3049">
        <tr id="yui_3_16_0_1_1530082595951_3048">
            <td class="yiv3459935963mcnDividerBlockInner" style="min-width:100%;padding:7px 18px;" id="yui_3_16_0_1_1530082595951_3047">
                <table class="yiv3459935963mcnDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-top:2px none #EAEAEA;border-collapse:collapse;">
                    <tbody><tr>
                        <td style="">
                            <span></span>
                        </td>
                    </tr>
                </tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnCaptionBlock" style="border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_3058">
    <tbody class="yiv3459935963mcnCaptionBlockOuter" id="yui_3_16_0_1_1530082595951_3057">
        <tr id="yui_3_16_0_1_1530082595951_3056">
            <td class="yiv3459935963mcnCaptionBlockInner" valign="top" style="padding:9px;" id="yui_3_16_0_1_1530082595951_3055">


<table align="left" border="0" cellpadding="0" cellspacing="0" class="yiv3459935963mcnCaptionBottomContent" width="282" style="border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_3066">
    <tbody id="yui_3_16_0_1_1530082595951_3065"><tr id="yui_3_16_0_1_1530082595951_3072">
        <td class="yiv3459935963mcnCaptionBottomImageContent" align="center" valign="top" style="padding:0 9px 9px 9px;" id="yui_3_16_0_1_1530082595951_3071">

            <img alt="" src="https://gallery.mailchimp.com/485095222da43f30e5bfab9f3/images/7e496125-25f4-49ff-b9ac-97f227c2e34e.png" width="64" style="overflow-x:auto;max-width:64px;border:0;min-height:auto;outline:none;text-decoration:none;vertical-align:bottom;" class="yiv3459935963mcnImage">

        </td>
    </tr>
    <tr id="yui_3_16_0_1_1530082595951_3064">
        <td class="yiv3459935963mcnTextContent" valign="top" style="padding:0 9px 0 9px;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" width="282" id="yui_3_16_0_1_1530082595951_3063">
            <div style="text-align:center;" id="yui_3_16_0_1_1530082595951_3062"><strong>Explore</strong><br>
<a rel="nofollow" target="_blank" href="https://help.fireapps.io" style="color:#222121;font-weight:normal;text-decoration:underline;" id="yui_3_16_0_1_1530082595951_3067">Our Getting Started Guides</a></div>

        </td>
    </tr>
</tbody></table>

<table align="right" border="0" cellpadding="0" cellspacing="0" class="yiv3459935963mcnCaptionBottomContent" width="282" style="border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_3054">
    <tbody id="yui_3_16_0_1_1530082595951_3053"><tr id="yui_3_16_0_1_1530082595951_3052">
        <td class="yiv3459935963mcnCaptionBottomImageContent" align="center" valign="top" style="padding:0 9px 9px 9px;" id="yui_3_16_0_1_1530082595951_3051">



            <img alt="" src="https://gallery.mailchimp.com/485095222da43f30e5bfab9f3/images/e696a6bd-d124-4b80-a5e0-9b520bd16778.png" width="64" style="overflow-x:auto;max-width:64px;border:0;min-height:auto;outline:none;text-decoration:none;vertical-align:bottom;" class="yiv3459935963mcnImage" id="yui_3_16_0_1_1530082595951_3073">


        </td>
    </tr>
    <tr id="yui_3_16_0_1_1530082595951_3061">
        <td class="yiv3459935963mcnTextContent" valign="top" style="padding:0 9px 0 9px;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" width="282" id="yui_3_16_0_1_1530082595951_3060">
            <div style="text-align:center;" id="yui_3_16_0_1_1530082595951_3059"><strong>Watch</strong><br>
<a rel="nofollow" target="_blank" href="https://www.youtube.com/watch?v=liOwHXL3zlw&amp;list=PLZEeiZUVAjqXAD2ybmwBL0Jqjc0uG4lmX" style="color:#222121;font-weight:normal;text-decoration:underline;" id="yui_3_16_0_1_1530082595951_3068">Our Video to Import Your Products</a></div>

        </td>
    </tr>
</tbody></table>





            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnTextBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_2798">
    <tbody class="yiv3459935963mcnTextBlockOuter" id="yui_3_16_0_1_1530082595951_2797">
        <tr id="yui_3_16_0_1_1530082595951_2796">
            <td valign="top" class="yiv3459935963mcnTextBlockInner" style="padding-top:9px;" id="yui_3_16_0_1_1530082595951_2795">
              	
			
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="overflow-x:auto;max-width:100%;min-width:100%;border-collapse:collapse;" width="100%" class="yiv3459935963mcnTextContentContainer" id="yui_3_16_0_1_1530082595951_2794">
                    <tbody id="yui_3_16_0_1_1530082595951_2793"><tr id="yui_3_16_0_1_1530082595951_2792">

                        <td valign="top" class="yiv3459935963mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530082595951_2791">

                            <p style="margin:10px 0;padding:0;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530082595951_3070">As you start using our app, just email me with questions. I'm happy to help!</p>

                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed;">
    <tbody class="yiv3459935963mcnDividerBlockOuter">
        <tr>
            <td class="yiv3459935963mcnDividerBlockInner" style="min-width:100%;padding:7px 18px;">
                <table class="yiv3459935963mcnDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-top:2px none #EAEAEA;border-collapse:collapse;">
                    <tbody><tr>
                        <td style="">
                            <span></span>
                        </td>
                    </tr>
                </tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnButtonBlock" style="min-width:100%;border-collapse:collapse;">
    <tbody class="yiv3459935963mcnButtonBlockOuter">
        <tr>
            <td style="padding-top:0;padding-right:18px;padding-bottom:18px;padding-left:18px;" valign="top" align="center" class="yiv3459935963mcnButtonBlockInner">
                <table border="0" cellpadding="0" cellspacing="0" class="yiv3459935963mcnButtonContentContainer" style="border-collapse:separate;border-radius:7px;background-color:#3E3E3E;">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle" class="yiv3459935963mcnButtonContent" style="font-family:Arial;font-size:16px;padding:15px;">
                                <a rel="nofollow" class="yiv3459935963mcnButton " title="Import your AliExpress product" target="_blank" href="https://aliorders.fireapps.io/install?utm_source=email&amp;utm_medium=new_user&amp;utm_campaign=aof_in" style="font-weight:normal;letter-spacing:normal;line-height:100%;text-align:center;text-decoration:none;color:#FFFFFF;display:block;">Import your AliExpress product</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed;">
    <tbody class="yiv3459935963mcnDividerBlockOuter">
        <tr>
            <td class="yiv3459935963mcnDividerBlockInner" style="min-width:100%;padding:7px 18px;">
                <table class="yiv3459935963mcnDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-top:2px none #EAEAEA;border-collapse:collapse;">
                    <tbody><tr>
                        <td style="">
                            <span></span>
                        </td>
                    </tr>
                </tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnCodeBlock" style="border-collapse:collapse;" id="yui_3_16_0_1_1530082595951_2802">
    <tbody class="yiv3459935963mcnTextBlockOuter" id="yui_3_16_0_1_1530082595951_2801">
        <tr id="yui_3_16_0_1_1530082595951_2800">
            <td valign="top" class="yiv3459935963mcnTextBlockInner" style="" id="yui_3_16_0_1_1530082595951_2799">
                <table cellpadding="0" cellspacing="0" border="0" style="background:none;border-width:0px;border:0px;margin:0;padding:0;border-collapse:collapse;">
<tbody><tr><td valign="top" style="padding-top:0;padding-bottom:0;padding-left:0;padding-right:7px;border-top:0;border-bottom:0;border-right:solid 3px #BCC5CE;">
<img id="yiv3459935963preview-image-url" src="https://gallery.mailchimp.com/485095222da43f30e5bfab9f3/images/fac44faa-8528-44db-92b1-447c06feb973.png" style="border:0;min-height:auto;outline:none;text-decoration:none;"></td>
<td style="padding-top:0;padding-bottom:0;padding-left:12px;padding-right:0;">
<table cellpadding="0" cellspacing="0" border="0" style="background:none;border-width:0px;border:0px;margin:0;padding:0;border-collapse:collapse;">
<tbody><tr><td colspan="2" style="padding-bottom:5px;color:#344b67;font-size:77%;font-family:Tahoma, Helvetica, sans-serif;"><strong>Hailey Ho</strong></td></tr>
<tr><td colspan="2" style="color:#808080;font-size:77%;font-family:Tahoma, Helvetica, sans-serif;">Customer Guru</td></tr>
<tr><td colspan="2" style="color:#808080;font-size:77%;font-family:Tahoma, Helvetica, sans-serif;"><strong>FireApps Team</strong></td></tr>
<tr><td valign="top" style="vertical-align:top;color:#808080;font-size:14px;font-family:Tahoma, Helvetica, sans-serif;"><a rel="nofollow" ymailto="mailto:support@fireapps.io" target="_blank" href="mailto:support@fireapps.io" style="color:#808080;text-decoration:underline;font-weight:normal;font-size:77%;">hailey.ho@fireapps.io</a></td></tr>
</tbody></table>
</td></tr></tbody></table>
            </td>
        </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
                            <tr id="yui_3_16_0_1_1530082595951_3069">
								<td align="center" valign="top" id="yiv3459935963templateFooter" style="background:#ededed none no-repeat;background-color:#ededed;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:40px;">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963templateContainer" style="border-collapse:collapse;overflow-x:auto;max-width:600px !important;">
										<tbody><tr>
                                			<td valign="top" class="yiv3459935963footerContainer" style="background:none no-repeat;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:17px;padding-bottom:0;"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnTextBlock" style="min-width:100%;border-collapse:collapse;">
    <tbody class="yiv3459935963mcnTextBlockOuter">
        <tr>
            <td valign="top" class="yiv3459935963mcnTextBlockInner" style="padding-top:9px;">
              	
			
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="overflow-x:auto;max-width:100%;min-width:100%;border-collapse:collapse;" width="100%" class="yiv3459935963mcnTextContentContainer">
                    <tbody><tr>

                        <td valign="top" class="yiv3459935963mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;color:#808080;font-family:Helvetica;font-size:12px;line-height:150%;text-align:center;">

                            <a rel="nofollow" target="_blank" href="https://fireapps.io/blog" style="text-decoration:none;color:#222121;font-weight:normal;">Blog</a> • <a rel="nofollow" target="_blank" href="https://help.fireapps.io" style="text-decoration:none;color:#222121;font-weight:normal;">Help &amp; Support</a> • <a rel="nofollow" target="_blank" href="https://facebook.com/fireapps.io" style="text-decoration:none;color:#222121;font-weight:normal;">Facebook</a> • <a rel="nofollow" target="_blank" href="https://twitter.com/fireapps_io" style="text-decoration:none;color:#222121;font-weight:normal;">Twitter</a><br>
FireApps, Ltd. 182 Le Dai Hanh Street, 22nd Floor, HCMC 700000.<br>
<a rel="nofollow" style="text-decoration:none;color:#222121;font-weight:normal;">Unsubscribe</a> | <a rel="nofollow" target="_blank" href="https://fireapps.io/privacy" style="text-decoration:none;color:#222121;font-weight:normal;">Privacy Policy</a>
                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv3459935963mcnImageBlock" style="min-width:100%;border-collapse:collapse;">
    <tbody class="yiv3459935963mcnImageBlockOuter">
            <tr>
                <td valign="top" style="padding:9px;" class="yiv3459935963mcnImageBlockInner">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="yiv3459935963mcnImageContentContainer" style="min-width:100%;border-collapse:collapse;">
                        <tbody><tr>
                            <td class="yiv3459935963mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center;">


                                        <img align="center" alt="" src="https://ecp.yusercontent.com/mail?url=https%3A%2F%2Fgallery.mailchimp.com%2F485095222da43f30e5bfab9f3%2Fimages%2Fd3f976b0-518e-464b-b159-c4af48aa9e5d.png&amp;t=1530083093&amp;ymreqid=7e2ea64b-fbaf-2e85-01d0-e3001f010000&amp;sig=dqemGdIGlx8jihQEXgDEeA--~C" width="17" style="overflow-x:auto;max-width:17px;padding-bottom:0;display:inline;vertical-align:bottom;border:0;min-height:auto;outline:none;text-decoration:none;" class="yiv3459935963mcnImage">


                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
                        </tbody></table>
                        
                    </td>
                </tr>
            </tbody></table>
</center>
</body>
</html>
