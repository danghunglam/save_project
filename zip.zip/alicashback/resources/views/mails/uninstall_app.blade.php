<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <!-- NAME: TELL A STORY -->
    <!--[if gte mso 15]>
    <xml>
        <o:OfficeDocumentSettings>
            <o:AllowPNG/>
            <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
    </xml>
    <![endif]-->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>

    <style type="text/css">
        p{
            margin:10px 0;
            padding:0;
        }
        table{
            border-collapse:collapse;
        }
        h1,h2,h3,h4,h5,h6{
            display:block;
            margin:0;
            padding:0;
        }
        img,a img{
            border:0;
            height:auto;
            outline:none;
            text-decoration:none;
        }
        body,#bodyTable,#bodyCell{
            height:100%;
            margin:0;
            padding:0;
            width:100%;
        }
        .mcnPreviewText{
            display:none !important;
        }
        #outlook a{
            padding:0;
        }
        img{
            -ms-interpolation-mode:bicubic;
        }
        table{
            mso-table-lspace:0pt;
            mso-table-rspace:0pt;
        }
        .ReadMsgBody{
            width:100%;
        }
        .ExternalClass{
            width:100%;
        }
        p,a,li,td,blockquote{
            mso-line-height-rule:exactly;
        }
        a[href^=tel],a[href^=sms]{
            color:inherit;
            cursor:default;
            text-decoration:none;
        }
        p,a,li,td,body,table,blockquote{
            -ms-text-size-adjust:100%;
            -webkit-text-size-adjust:100%;
        }
        .ExternalClass,.ExternalClass p,.ExternalClass td,.ExternalClass div,.ExternalClass span,.ExternalClass font{
            line-height:100%;
        }
        a[x-apple-data-detectors]{
            color:inherit !important;
            text-decoration:none !important;
            font-size:inherit !important;
            font-family:inherit !important;
            font-weight:inherit !important;
            line-height:inherit !important;
        }
        .templateContainer{
            max-width:600px !important;
        }
        a.mcnButton{
            display:block;
        }
        .mcnImage,.mcnRetinaImage{
            vertical-align:bottom;
        }
        .mcnTextContent{
            word-break:break-word;
        }
        .mcnTextContent img{
            height:auto !important;
        }
        .mcnDividerBlock{
            table-layout:fixed !important;
        }
        /*
        @tab Page
 Heading 1
	@style heading 1
	*/
        h1{
            /*@editable*/color:#222222;
            /*@editable*/font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;
            /*@editable*/font-size:40px;
            /*@editable*/font-style:normal;
            /*@editable*/font-weight:normal;
            /*@editable*/line-height:150%;
            /*@editable*/letter-spacing:normal;
            /*@editable*/text-align:left;
        }
        /*
        @tab Page
 Heading 2
	@style heading 2
	*/
        h2{
            /*@editable*/color:#222222;
            /*@editable*/font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;
            /*@editable*/font-size:34px;
            /*@editable*/font-style:normal;
            /*@editable*/font-weight:normal;
            /*@editable*/line-height:150%;
            /*@editable*/letter-spacing:normal;
            /*@editable*/text-align:left;
        }
        /*
        @tab Page
 Heading 3
	@style heading 3
	*/
        h3{
            /*@editable*/color:#444444;
            /*@editable*/font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;
            /*@editable*/font-size:22px;
            /*@editable*/font-style:normal;
            /*@editable*/font-weight:normal;
            /*@editable*/line-height:150%;
            /*@editable*/letter-spacing:normal;
            /*@editable*/text-align:left;
        }
        /*
        @tab Page
 Heading 4
	@style heading 4
	*/
        h4{
            /*@editable*/color:#999999;
            /*@editable*/font-family:Georgia, Times, 'Times New Roman', serif;
            /*@editable*/font-size:20px;
            /*@editable*/font-style:italic;
            /*@editable*/font-weight:normal;
            /*@editable*/line-height:125%;
            /*@editable*/letter-spacing:normal;
            /*@editable*/text-align:left;
        }
        /*
        @tab Header
 Header Container Style
	*/
        #templateHeader{
            /*@editable*/background-color:#ededed;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:1px none ;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:40px;
            /*@editable*/padding-bottom:0px;
        }
        /*
        @tab Header
 Header Interior Style
	*/
        .headerContainer{
            /*@editable*/background-color:#861de8;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:5px solid #dadada;
            /*@editable*/border-bottom:1px none ;
            /*@editable*/padding-top:0px;
            /*@editable*/padding-bottom:0px;
        }
        /*
        @tab Header
 Header Text
	*/
        .headerContainer .mcnTextContent,.headerContainer .mcnTextContent p{
            /*@editable*/color:#222121;
            /*@editable*/font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;
            /*@editable*/font-size:16px;
            /*@editable*/line-height:150%;
            /*@editable*/text-align:right;
        }
        /*
        @tab Header
 Header Link
	*/
        .headerContainer .mcnTextContent a,.headerContainer .mcnTextContent p a{
            /*@editable*/color:#00ADD8;
            /*@editable*/font-weight:normal;
            /*@editable*/text-decoration:underline;
        }
        /*
        @tab Body
 Body Container Style
	*/
        #templateBody{
            /*@editable*/background-color:#ededed;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:1px none ;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:0px;
            /*@editable*/padding-bottom:0px;
        }
        /*
        @tab Body
 Body Interior Style
	*/
        .bodyContainer{
            /*@editable*/background-color:#ffffff;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:1px none ;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:27px;
            /*@editable*/padding-bottom:27px;
        }
        /*
        @tab Body
 Body Text
	*/
        .bodyContainer .mcnTextContent,.bodyContainer .mcnTextContent p{
            /*@editable*/color:#222121;
            /*@editable*/font-family:Helvetica;
            /*@editable*/font-size:16px;
            /*@editable*/line-height:150%;
            /*@editable*/text-align:left;
        }
        /*
        @tab Body
 Body Link
	*/
        .bodyContainer .mcnTextContent a,.bodyContainer .mcnTextContent p a{
            /*@editable*/color:#222121;
            /*@editable*/font-weight:normal;
            /*@editable*/text-decoration:underline;
        }
        /*
        @tab Footer
 Footer Style
	*/
        #templateFooter{
            /*@editable*/background-color:#ededed;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:0;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:0px;
            /*@editable*/padding-bottom:40px;
        }
        /*
        @tab Footer
 Footer Interior Style
	*/
        .footerContainer{
            /*@editable*/background-color:#transparent;
            /*@editable*/background-image:none;
            /*@editable*/background-repeat:no-repeat;
            /*@editable*/background-position:center;
            /*@editable*/background-size:cover;
            /*@editable*/border-top:0;
            /*@editable*/border-bottom:0;
            /*@editable*/padding-top:17px;
            /*@editable*/padding-bottom:0;
        }
        /*
        @tab Footer
 Footer Text
	*/
        .footerContainer .mcnTextContent,.footerContainer .mcnTextContent p{
            /*@editable*/color:#808080;
            /*@editable*/font-family:Helvetica;
            /*@editable*/font-size:12px;
            /*@editable*/line-height:150%;
            /*@editable*/text-align:center;
        }
        /*
        @tab Footer
 Footer Link
	*/
        .footerContainer .mcnTextContent a,.footerContainer .mcnTextContent p a{
            /*@editable*/color:#222121;
            /*@editable*/font-weight:normal;
            /*@editable*/text-decoration:underline;
        }
        @media only screen and (min-width:768px){
            .templateContainer{
                width:600px !important;
            }

        }	@media only screen and (max-width: 480px){
            body,table,td,p,a,li,blockquote{
                -webkit-text-size-adjust:none !important;
            }

        }	@media only screen and (max-width: 480px){
            body{
                width:100% !important;
                min-width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnRetinaImage{
                max-width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImage{
                width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnCartContainer,.mcnCaptionTopContent,.mcnRecContentContainer,.mcnCaptionBottomContent,.mcnTextContentContainer,.mcnBoxedTextContentContainer,.mcnImageGroupContentContainer,.mcnCaptionLeftTextContentContainer,.mcnCaptionRightTextContentContainer,.mcnCaptionLeftImageContentContainer,.mcnCaptionRightImageContentContainer,.mcnImageCardLeftTextContentContainer,.mcnImageCardRightTextContentContainer,.mcnImageCardLeftImageContentContainer,.mcnImageCardRightImageContentContainer{
                max-width:100% !important;
                width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnBoxedTextContentContainer{
                min-width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageGroupContent{
                padding:9px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnCaptionLeftContentOuter .mcnTextContent,.mcnCaptionRightContentOuter .mcnTextContent{
                padding-top:9px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageCardTopImageContent,.mcnCaptionBottomContent:last-child .mcnCaptionBottomImageContent,.mcnCaptionBlockInner .mcnCaptionTopContent:last-child .mcnTextContent{
                padding-top:18px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageCardBottomImageContent{
                padding-bottom:9px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageGroupBlockInner{
                padding-top:0 !important;
                padding-bottom:0 !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageGroupBlockOuter{
                padding-top:9px !important;
                padding-bottom:9px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnTextContent,.mcnBoxedTextContentColumn{
                padding-right:18px !important;
                padding-left:18px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcnImageCardLeftImageContent,.mcnImageCardRightImageContent{
                padding-right:18px !important;
                padding-bottom:0 !important;
                padding-left:18px !important;
            }

        }	@media only screen and (max-width: 480px){
            .mcpreview-image-uploader{
                display:none !important;
                width:100% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Heading 1
	@tip Make the first-level headings larger in size for better readability on small screens.
	*/
            h1{
                /*@editable*/font-size:30px !important;
                /*@editable*/line-height:125% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Heading 2
	@tip Make the second-level headings larger in size for better readability on small screens.
	*/
            h2{
                /*@editable*/font-size:26px !important;
                /*@editable*/line-height:125% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Heading 3
	@tip Make the third-level headings larger in size for better readability on small screens.
	*/
            h3{
                /*@editable*/font-size:20px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Heading 4
	@tip Make the fourth-level headings larger in size for better readability on small screens.
	*/
            h4{
                /*@editable*/font-size:18px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Boxed Text
	@tip Make the boxed text larger in size for better readability on small screens. We recommend a font size of at least 16px.
	*/
            .mcnBoxedTextContentContainer .mcnTextContent,.mcnBoxedTextContentContainer .mcnTextContent p{
                /*@editable*/font-size:14px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Header Text
	@tip Make the header text larger in size for better readability on small screens.
	*/
            .headerContainer .mcnTextContent,.headerContainer .mcnTextContent p{
                /*@editable*/font-size:16px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Body Text
	@tip Make the body text larger in size for better readability on small screens. We recommend a font size of at least 16px.
	*/
            .bodyContainer .mcnTextContent,.bodyContainer .mcnTextContent p{
                /*@editable*/font-size:16px !important;
                /*@editable*/line-height:150% !important;
            }

        }	@media only screen and (max-width: 480px){
            /*
            @tab Mobile Styles
 Footer Text
	@tip Make the footer content text larger in size for better readability on small screens.
	*/
            .footerContainer .mcnTextContent,.footerContainer .mcnTextContent p{
                /*@editable*/font-size:14px !important;
                /*@editable*/line-height:150% !important;
            }

        }</style></head>
<body>
<!--*|IF:MC_PREVIEW_TEXT|*-->
<!--[if !gte mso 9]><!----><span class="mcnPreviewText" style="display:none; font-size:0px; line-height:0px; max-height:0px; max-width:0px; opacity:0; overflow:hidden; visibility:hidden; mso-hide:all;">*|MC_PREVIEW_TEXT|*</span><!--<![endif]-->
<!--*|END:IF|*-->
<center>
    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8169">
							<tbody id="yui_3_16_0_1_1530081848663_8168"><tr id="yui_3_16_0_1_1530081848663_8167">
								<td align="center" valign="top" id="yiv0327446023templateHeader" style="background:#ededed none no-repeat;background-color:#ededed;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:1px none;border-bottom:0;padding-top:40px;padding-bottom:0px;">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023templateContainer" style="border-collapse:collapse;overflow-x:auto;max-width:600px !important;" id="yui_3_16_0_1_1530081848663_8178">
										<tbody id="yui_3_16_0_1_1530081848663_8177"><tr id="yui_3_16_0_1_1530081848663_8176">
                                			<td valign="top" class="yiv0327446023headerContainer" style="background:#861de8 none no-repeat;background-color:#861de8;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:5px solid #dadada;border-bottom:1px none;padding-top:0px;padding-bottom:0px;" id="yui_3_16_0_1_1530081848663_8175"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnImageBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8182">
    <tbody class="yiv0327446023mcnImageBlockOuter" id="yui_3_16_0_1_1530081848663_8181">
            <tr id="yui_3_16_0_1_1530081848663_8180">
                <td valign="top" style="padding:9px;" class="yiv0327446023mcnImageBlockInner" id="yui_3_16_0_1_1530081848663_8179">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="yiv0327446023mcnImageContentContainer" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8186">
                        <tbody id="yui_3_16_0_1_1530081848663_8185"><tr id="yui_3_16_0_1_1530081848663_8184">
                            <td class="yiv0327446023mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;" id="yui_3_16_0_1_1530081848663_8183">
                                <img align="left" alt="" src="https://gallery.mailchimp.com/485095222da43f30e5bfab9f3/images/e7ad628c-8385-4349-b18e-01cbed1d7c34.png" width="107" style="overflow-x:auto;max-width:107px;padding-bottom:0;display:inline;vertical-align:bottom;border:0;min-height:auto;outline:none;text-decoration:none;" class="yiv0327446023mcnImage">
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed;" id="yui_3_16_0_1_1530081848663_8190">
    <tbody class="yiv0327446023mcnDividerBlockOuter" id="yui_3_16_0_1_1530081848663_8189">
        <tr id="yui_3_16_0_1_1530081848663_8188">
            <td class="yiv0327446023mcnDividerBlockInner" style="min-width:100%;padding:20px 18px 18px;" id="yui_3_16_0_1_1530081848663_8187">
                <table class="yiv0327446023mcnDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-top:2px none #EAEAEA;border-collapse:collapse;">
                    <tbody><tr>
                        <td style="">
                            <span></span>
                        </td>
                    </tr>
                </tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnImageBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8194">
    <tbody class="yiv0327446023mcnImageBlockOuter" id="yui_3_16_0_1_1530081848663_8193">
            <tr id="yui_3_16_0_1_1530081848663_8192">
                <td valign="top" style="padding:9px;" class="yiv0327446023mcnImageBlockInner" id="yui_3_16_0_1_1530081848663_8191">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="yiv0327446023mcnImageContentContainer" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8199">
                        <tbody id="yui_3_16_0_1_1530081848663_8198"><tr id="yui_3_16_0_1_1530081848663_8197">
                            <td class="yiv0327446023mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center;" id="yui_3_16_0_1_1530081848663_8196">
                                <img align="center" alt="" src="https://gallery.mailchimp.com/485095222da43f30e5bfab9f3/images/e1359fc7-2afd-488d-b3b7-edbb4bc23bda.png" width="111" style="overflow-x:auto;max-width:111px;padding-bottom:0;display:inline;vertical-align:bottom;border:0;min-height:auto;outline:none;text-decoration:none;" class="yiv0327446023mcnImage" id="yui_3_16_0_1_1530081848663_8195">
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed;">
    <tbody class="yiv0327446023mcnDividerBlockOuter">
        <tr>
            <td class="yiv0327446023mcnDividerBlockInner" style="min-width:100%;padding:18px 18px 5px;">
                <table class="yiv0327446023mcnDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-top:2px none #EAEAEA;border-collapse:collapse;">
                    <tbody><tr>
                        <td style="">
                            <span></span>
                        </td>
                    </tr>
                </tbody></table>

            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnTextBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8216">
    <tbody class="yiv0327446023mcnTextBlockOuter" id="yui_3_16_0_1_1530081848663_8215">
        <tr id="yui_3_16_0_1_1530081848663_8214">
            <td valign="top" class="yiv0327446023mcnTextBlockInner" style="padding-top:9px;" id="yui_3_16_0_1_1530081848663_8213">
              	
			
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="overflow-x:auto;max-width:100%;min-width:100%;border-collapse:collapse;" width="100%" class="yiv0327446023mcnTextContentContainer" id="yui_3_16_0_1_1530081848663_8212">
                    <tbody id="yui_3_16_0_1_1530081848663_8211"><tr id="yui_3_16_0_1_1530081848663_8210">

                        <td valign="top" class="yiv0327446023mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;color:#222121;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size:16px;line-height:150%;text-align:right;" id="yui_3_16_0_1_1530081848663_8209">

                            <h2 style="text-align:center;font-weight:700;color:#fff;display:block;margin:0;padding:0;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size:34px;font-style:normal;line-height:150%;letter-spacing:normal;" id="yui_3_16_0_1_1530081848663_8499">We're sorry to see you go</h2>

                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed;" id="yui_3_16_0_1_1530081848663_8208">
    <tbody class="yiv0327446023mcnDividerBlockOuter" id="yui_3_16_0_1_1530081848663_8207">
        <tr id="yui_3_16_0_1_1530081848663_8206">
            <td class="yiv0327446023mcnDividerBlockInner" style="min-width:100%;padding:18px 18px 10px;" id="yui_3_16_0_1_1530081848663_8205">
                <table class="yiv0327446023mcnDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-top:2px none #EAEAEA;border-collapse:collapse;">
                    <tbody><tr>
                        <td style="">
                            <span></span>
                        </td>
                    </tr>
                </tbody></table>

            </td>
        </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
							<tr id="yui_3_16_0_1_1530081848663_8204">
								<td align="center" valign="top" id="yiv0327446023templateBody" style="background:#ededed none no-repeat;background-color:#ededed;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:1px none;border-bottom:0;padding-top:0px;padding-bottom:0px;">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023templateContainer" style="border-collapse:collapse;overflow-x:auto;max-width:600px !important;" id="yui_3_16_0_1_1530081848663_8203">
										<tbody id="yui_3_16_0_1_1530081848663_8202"><tr id="yui_3_16_0_1_1530081848663_8201">
                                			<td valign="top" class="yiv0327446023bodyContainer" style="background:#ffffff none no-repeat;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:1px none;border-bottom:0;padding-top:27px;padding-bottom:27px;" id="yui_3_16_0_1_1530081848663_8200"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnTextBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8233">
    <tbody class="yiv0327446023mcnTextBlockOuter" id="yui_3_16_0_1_1530081848663_8232">
        <tr id="yui_3_16_0_1_1530081848663_8231">
            <td valign="top" class="yiv0327446023mcnTextBlockInner" style="padding-top:9px;" id="yui_3_16_0_1_1530081848663_8230">
              	
			
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="overflow-x:auto;max-width:100%;min-width:100%;border-collapse:collapse;" width="100%" class="yiv0327446023mcnTextContentContainer" id="yui_3_16_0_1_1530081848663_8229">
                    <tbody id="yui_3_16_0_1_1530081848663_8228"><tr id="yui_3_16_0_1_1530081848663_8227">

                        <td valign="top" class="yiv0327446023mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530081848663_8226">

                            <p style="margin:10px 0;padding:0;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530081848663_8234">Hi there,</p>

<p style="margin:10px 0;padding:0;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530081848663_8235">We're disappointed to see you go, but we thank you for giving Ali Orders a fair try. I would like to better understand what made you uninstall our app?</p>

<p style="margin:10px 0;padding:0;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530081848663_8239">We constantly improving our product to make it the best it can be. Please help us with any feedback you may have.</p>

<p style="margin:10px 0;padding:0;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;" id="yui_3_16_0_1_1530081848663_8281">If you want to come back, Ali Orders is just a click away.</p>

                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnButtonBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8243">
    <tbody class="yiv0327446023mcnButtonBlockOuter" id="yui_3_16_0_1_1530081848663_8242">
        <tr id="yui_3_16_0_1_1530081848663_8241">
            <td style="padding-top:0;padding-right:18px;padding-bottom:18px;padding-left:18px;" valign="top" align="center" class="yiv0327446023mcnButtonBlockInner" id="yui_3_16_0_1_1530081848663_8240">
                <table border="0" cellpadding="0" cellspacing="0" class="yiv0327446023mcnButtonContentContainer" style="border-collapse:separate;border-radius:3px;background-color:#222222;">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle" class="yiv0327446023mcnButtonContent" style="font-family:Arial;font-size:16px;padding:15px;">
                                <a rel="nofollow" class="yiv0327446023mcnButton " title="GET ALI ORDERS" target="_blank" href="https://aliorders.fireapps.io/install?utm_source=email&amp;utm_medium=new_user&amp;utm_campaign=swf_un" style="font-weight:normal;letter-spacing:normal;line-height:100%;text-align:center;text-decoration:none;color:#FFFFFF;display:block;">GET ALI ORDERS</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnTextBlock" style="min-width:100%;border-collapse:collapse;">
    <tbody class="yiv0327446023mcnTextBlockOuter">
        <tr>
            <td valign="top" class="yiv0327446023mcnTextBlockInner" style="padding-top:9px;">
              	
			
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="overflow-x:auto;max-width:100%;min-width:100%;border-collapse:collapse;" width="100%" class="yiv0327446023mcnTextContentContainer">
                    <tbody><tr>

                        <td valign="top" class="yiv0327446023mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;color:#222121;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left;">

                            <div style="text-align:center;">We hope to welcome you back soon!</div>
                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnCodeBlock" style="border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8277">
    <tbody class="yiv0327446023mcnTextBlockOuter" id="yui_3_16_0_1_1530081848663_8276">
        <tr id="yui_3_16_0_1_1530081848663_8275">
            <td valign="top" class="yiv0327446023mcnTextBlockInner" style="" id="yui_3_16_0_1_1530081848663_8274">
                <table cellpadding="0" cellspacing="0" border="0" style="background:none;border-width:0px;border:0px;margin:0;padding:0;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8273">
<tbody id="yui_3_16_0_1_1530081848663_8272"><tr id="yui_3_16_0_1_1530081848663_8271"><td valign="top" style="padding-top:0;padding-bottom:0;padding-left:0;padding-right:7px;border-top:0;border-bottom:0;border-right:solid 3px #BCC5CE;" id="yui_3_16_0_1_1530081848663_8280">
<img id="yiv0327446023preview-image-url" src="https://gallery.mailchimp.com/485095222da43f30e5bfab9f3/images/fac44faa-8528-44db-92b1-447c06feb973.png" style="border:0;min-height:auto;outline:none;text-decoration:none;"></td>
<td style="padding-top:0;padding-bottom:0;padding-left:12px;padding-right:0;" id="yui_3_16_0_1_1530081848663_8270">
<table cellpadding="0" cellspacing="0" border="0" style="background:none;border-width:0px;border:0px;margin:0;padding:0;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8269">
<tbody id="yui_3_16_0_1_1530081848663_8268"><tr><td colspan="2" style="padding-bottom:5px;color:#344b67;font-size:77%;font-family:Tahoma, Helvetica, sans-serif;"><strong>Hailey Ho</strong></td></tr>
<tr id="yui_3_16_0_1_1530081848663_8279"><td colspan="2" style="color:#808080;font-size:77%;font-family:Tahoma, Helvetica, sans-serif;" id="yui_3_16_0_1_1530081848663_8278">Customer Success Guru</td></tr>
<tr><td colspan="2" style="color:#808080;font-size:77%;font-family:Tahoma, Helvetica, sans-serif;"><strong>FireApps Team</strong></td></tr>
<tr id="yui_3_16_0_1_1530081848663_8267"><td valign="top" style="vertical-align:top;color:#808080;font-size:14px;font-family:Tahoma, Helvetica, sans-serif;" id="yui_3_16_0_1_1530081848663_8266"><a rel="nofollow" ymailto="mailto:support@fireapps.io" target="_blank" href="mailto:support@fireapps.io" style="color:#808080;text-decoration:underline;font-weight:normal;font-size:77%;" id="yui_3_16_0_1_1530081848663_8265">hailey.ho@fireapps.io</a></td></tr>
</tbody></table>
</td></tr></tbody></table>
            </td>
        </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
                            <tr id="yui_3_16_0_1_1530081848663_8252">
								<td align="center" valign="top" id="yiv0327446023templateFooter" style="background:#ededed none no-repeat;background-color:#ededed;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:40px;">
									
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023templateContainer" style="border-collapse:collapse;overflow-x:auto;max-width:600px !important;" id="yui_3_16_0_1_1530081848663_8251">
										<tbody id="yui_3_16_0_1_1530081848663_8250"><tr id="yui_3_16_0_1_1530081848663_8249">
                                			<td valign="top" class="yiv0327446023footerContainer" style="background:none no-repeat;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:17px;padding-bottom:0;" id="yui_3_16_0_1_1530081848663_8248"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnTextBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8264">
    <tbody class="yiv0327446023mcnTextBlockOuter" id="yui_3_16_0_1_1530081848663_8263">
        <tr id="yui_3_16_0_1_1530081848663_8262">
            <td valign="top" class="yiv0327446023mcnTextBlockInner" style="padding-top:9px;" id="yui_3_16_0_1_1530081848663_8261">
              	
			
				
                <table align="left" border="0" cellpadding="0" cellspacing="0" style="overflow-x:auto;max-width:100%;min-width:100%;border-collapse:collapse;" width="100%" class="yiv0327446023mcnTextContentContainer" id="yui_3_16_0_1_1530081848663_8260">
                    <tbody id="yui_3_16_0_1_1530081848663_8259"><tr id="yui_3_16_0_1_1530081848663_8258">

                        <td valign="top" class="yiv0327446023mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;color:#808080;font-family:Helvetica;font-size:12px;line-height:150%;text-align:center;" id="yui_3_16_0_1_1530081848663_8257">

                            <a rel="nofollow" target="_blank" href="https://fireapps.io/blog" style="text-decoration:none;color:#222121;font-weight:normal;">Blog</a> • <a rel="nofollow" target="_blank" href="https://help.fireapps.io" style="text-decoration:none;color:#222121;font-weight:normal;">Help &amp; Support</a> • <a rel="nofollow" target="_blank" href="https://facebook.com/fireapps.io" style="text-decoration:none;color:#222121;font-weight:normal;">Facebook</a> • <a rel="nofollow" target="_blank" href="https://twitter.com/fireapps_io" style="text-decoration:none;color:#222121;font-weight:normal;">Twitter</a><br>
FireApps, Ltd. 182 Le Dai Hanh Street, 22nd Floor, HCMC 700000.<br>
<a rel="nofollow" style="text-decoration:none;color:#222121;font-weight:normal;">Unsubscribe</a> | <a rel="nofollow" target="_blank" href="https://fireapps.io/privacy" style="text-decoration:none;color:#222121;font-weight:normal;">Privacy Policy</a>
                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table><table border="0" cellpadding="0" cellspacing="0" width="100%" class="yiv0327446023mcnImageBlock" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8247">
    <tbody class="yiv0327446023mcnImageBlockOuter" id="yui_3_16_0_1_1530081848663_8246">
            <tr id="yui_3_16_0_1_1530081848663_8245">
                <td valign="top" style="padding:9px;" class="yiv0327446023mcnImageBlockInner" id="yui_3_16_0_1_1530081848663_8244">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="yiv0327446023mcnImageContentContainer" style="min-width:100%;border-collapse:collapse;" id="yui_3_16_0_1_1530081848663_8256">
                        <tbody id="yui_3_16_0_1_1530081848663_8255"><tr id="yui_3_16_0_1_1530081848663_8254">
                            <td class="yiv0327446023mcnImageContent" valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center;" id="yui_3_16_0_1_1530081848663_8253">


                                        <img align="center" alt="" src="https://ecp.yusercontent.com/mail?url=https%3A%2F%2Fgallery.mailchimp.com%2F485095222da43f30e5bfab9f3%2Fimages%2Fd3f976b0-518e-464b-b159-c4af48aa9e5d.png&amp;t=1530083364&amp;ymreqid=7e2ea64b-fbaf-2e85-011d-f3004e010000&amp;sig=yOfAeqZRqPxNhiClt9bS9g--~C" width="17" style="overflow-x:auto;max-width:17px;padding-bottom:0;display:inline;vertical-align:bottom;border:0;min-height:auto;outline:none;text-decoration:none;" class="yiv0327446023mcnImage">


                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table></td>
										</tr>
									</tbody></table>
									
								</td>
                            </tr>
                        </tbody></table>
</center>
</body>
</html>
