@extends('layout.backend')

@section('head_extend')
    <link rel="stylesheet" href="{{ URL::asset(mix('css/statistic.css')) }}">
@endsection

@section('content_container')
    <div id="page-statistic" class="statistic-content-wrap">
        {{-- <div class="row flex-equal" style="background: #fff; padding:10px; border: 1px solid orange; margin-bottom: 25px; margin-left: 0px; margin-right: 0px;">
            <div class="col-md-1">
                    <img src="{{ URL::asset('images/Cup.svg') }}">
            </div>
            <div class="col-md-11" style="margin: auto; padding-top: 10px; padding-right: 80px;">
                <p>We are currently out of the office from <b>26 Apr 2019</b> until <b>02 May 2019</b> for our long weekend holiday. <br>
                During this times, if you would like to get some helps, kindly help us to wait for a bit longer than normal, we are surely getting back to you asap. <br>
                Really appreciate for your patience in advance! </p>
            </div>
        </div> --}}
        <modal_reference></modal_reference>
        <div class="statistic-total-block-wrap">
            <div class="row">
                <div class="col-md-4">
                    <div class="statistic-total-block">
                        <div class="statistic-total-icon-chart">
                            <img src="{{URL::asset('/images/backend/icon-chart-orders.png')}}" alt="icon chart orders">
                        </div>
                        <div class="statistic-total-description-chart dashboard-total-price">
                            <p class="statistic-total-number" v-text="this_total_summary.total_order"></p>
                            <p class="statistic-total-title">This Month Orders</p>
                        </div>
                    </div>
                </div>
                <notifications></notifications>
                <div class="col-md-4">
                    <div class="statistic-total-block">
                        <div class="statistic-total-icon-chart">
                            <img src="{{URL::asset('/images/backend/icon-chart-revenue.png')}}" alt="icon chart revenue">
                        </div>
                        <div class="statistic-total-description-chart statistic-total-price">
                            <p class="statistic-total-number" v-text="'$'+this_total_summary.total_revenue"></p>
                            <p class="statistic-total-title">This Month Revenue</p>
                        </div>
                        <div class="statistic-total-right">
                            <span data-toggle="tooltip" data-html="true" data-template='<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner max-width-300"></div></div>' title="Over the same period last month">
                                <span v-if="growRevenue.grow !== null">
                                    <img src="{{URL::asset('images/icon/icon-arrow-up.svg')}}" alt="icon chart cost" v-if="growRevenue.grow">
                                    <img src="{{URL::asset('images/icon/icon-arrow-down.svg')}}" alt="icondown" v-else="growRevenue.grow">
                                </span>
                                <span v-text="growRevenue.percent+'%'"></span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="statistic-total-block">
                        <div class="statistic-total-icon-chart">
                            <img src="{{URL::asset('/images/backend/icon-chart-cost.png')}}" alt="icon chart cost">
                        </div>
                        <div class="statistic-total-description-chart statistic-total-price">
                            <p class="statistic-total-number" v-text="'$'+this_total_summary.total_cost"></p>
                            <p class="statistic-total-title">This Month Cost</p>
                        </div>
                        <div class="statistic-total-right">
                            <span data-toggle="tooltip" data-html="true" data-template='<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner max-width-300"></div></div>' title="Over the same period last month">
                                <span v-if="growCost.grow !== null">
                                    <img src="{{URL::asset('images/icon/icon-arrow-up.svg')}}" alt="icon chart cost" v-if="growCost.grow">
                                    <img src="{{URL::asset('images/icon/icon-arrow-down.svg')}}" alt="icondown" v-else="growCost.grow">
                                </span>

                                <span v-text="growCost.percent+'%'"></span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{--using vue component statistic_chart--}}
        <statistic_chart v-on:chart_statistic="chartStatistic" v-bind:chart_loading="chart_loading"></statistic_chart>
        <div class="row" style="margin-top: 30px">
            <div class="col-md-8">
                <div class="statistic-reference-summary">
                    <div class="statistic-reference-wrap">
                        <h2>Reference
                            <span class="tooltip-style-wrap color-skin" style="margin-left: 3px" data-toggle="tooltip" title="Revenue/Total Orders are calculated based on products that have been synced to Ali Orders">
                                <i class="mdi mdi-alert-circle"></i>
                            </span>
                        </h2>
                        <div class="statistic-reference-table">
                            <div class="ars-table">
                                <div class="ars-table-head">
                                    <div class="ars-table-col">Date</div>
                                    <div class="ars-table-col">Total Orders</div>
                                    <div class="ars-table-col">Revenue</div>
                                    <div class="ars-table-col">Cost</div>
                                    {{-- <div class="ars-table-col">Earning</div> --}}
                                </div>
                                <div class="ars-table-body">
                                    <div class="ars-table-row" v-for="history in historys">
                                        <div class="ars-table-col" v-text="history.time"></div>
                                        <div class="ars-table-col" v-text="history.order"></div>
                                        <div class="ars-table-col" v-text="'$'+history.sale"></div>
                                        <div class="ars-table-col" v-text="'$'+history.cost"></div>
                                        {{-- <div class="ars-table-col" v-text="'$'+history.earning"></div> --}}
                                    </div>
                                </div>
                            </div>
                            <div class="statistic-reference-show-more">
                                <span @click="showMoreReference()">Show More</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="statistic-summary-wrap">
                    <h2>Quick Summary</h2>
                    <ul class="statistic-summary-list">
                        <li>
                            <a href="{{ url('orders/?status[]=1&filter_date_from=' . $minDate . '&filter_date_to=' . $maxDate) }}">
                                <span class="statistic-summary-icon statistic-summary-on-hold">
                                    <img src="{{ URL::asset('images/backend/statistic-on-hold-icon.png') }}" />
                                </span>
                                <span class="statistic-summary-to-order"><span v-text="quick_summary.on_hold"></span> <span v-text="quick_summary.on_hold==1?'Order':'Orders'"></span></span>
                                <span class="statistic-summary-status">Waiting to place order</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('orders/?status[]=2&filter_date_from=' . $minDate . '&filter_date_to=' . $maxDate) }}">
                                <span class="statistic-summary-icon statistic-summary-processing">
                                    <img src="{{ URL::asset('images/backend/statistic-processing-icon.png') }}" />
                                </span>
                                <span class="statistic-summary-to-order"><span v-text="quick_summary.processing"></span> <span v-text="quick_summary.processing==1?'Order':'Orders'"></span></span>
                                <span class="statistic-summary-status">Waiting for tracking code</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('products?status=4') }}">
                                <span class="statistic-summary-icon statistic-summary-low-in-stock">
                                    <img src="{{ URL::asset('images/backend/statistic-low-in-stock-icon.png') }}" />
                                </span>
                                <span class="statistic-summary-to-order"><span v-text="quick_summary.low_in_stock"></span> <span v-text="quick_summary.low_in_stock==1?'Product':'Products'"></span></span>
                                <span class="statistic-summary-status">Low stock</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('products?status=2') }}">
                                <span class="statistic-summary-icon statistic-summary-out-of-stock">
                                    <img src="{{ URL::asset('images/backend/statistic-out-of-stock-icon.png') }}" />
                                </span>
                                <span class="statistic-summary-to-order"><span v-text="quick_summary.out_of_stock"></span> <span v-text="quick_summary.out_of_stock==1?'Product':'Products'"></span></span>
                                <span class="statistic-summary-status">Out of stock</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('products?status=3') }}">
                                <span class="statistic-summary-icon statistic-summary-out-of-stock">
                                    <img src="{{ URL::asset('images/backend/statistic-gone-from-aliExpress.png') }}" />
                                </span>
                                <span class="statistic-summary-to-order"><span v-text="quick_summary.gone_from_aliExpress"></span> <span v-text="quick_summary.gone_from_aliExpress==1?'Product':'Products'"></span></span>
                                <span class="statistic-summary-status">Gone from AliExpress</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    @if(session('success'))
        <script>
            setTimeout(() => {
                notify('success', '{{ session('success') }}')
            }, 2000);
        </script>
    @endif
    @if(session('error'))
        <script>
            setTimeout(() => {
                notify('error', '{{ session('error') }}')
            }, 2000);
        </script>
    @endif
@endsection

@section('footer_extend')
    <script type="text/javascript" src="{{ URL::asset('bower_component/chart.js/dist/Chart.bundle.min.js') }}"></script>
    <script type="text/javascript" src="{{ URL::asset(mix('js/modules/dashboard.min.js')) }}"></script>
@endsection
