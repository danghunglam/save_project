@extends('layout.backend')
@section('content_container')
    <div class="dashhboard-page-wrap">
        <h2>Overview</h2>
        <div class="row">
            <div class="col-sm-6">
                <div class="dashboard-link-block">
                    <a>
                        <span class="dashboard-link-icon"><img src="{{ URL::asset('images/backend/annoucement-icon.png') }}" alt=""></span>
                        <h2>New annoucement</h2>
                        <p>Release: Ali Orders {{ config('common.app_version')  }}</p>
                    </a>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="dashboard-link-block">
                    <a class="shopify-vote" style="cursor: pointer;">
                        <span class="dashboard-link-icon"><img src="{{ URL::asset('images/backend/vote-us-icon.png') }}" alt=""></span>
                        <h2>Vote for us</h2>
                        <p>Evaluate your experience</p>
                    </a>
                </div>
            </div>
            {{-- <div class="col-sm-4">
                <div class="dashboard-link-block">
                    <a>
                        <span class="dashboard-link-icon"><img src="{{ URL::asset('images/backend/invite-friend-icon.png') }}" alt=""></span>
                        <h2>Invite your friend</h2>
                        <p>Coming Soon</p>
                    </a>
                </div>
            </div> --}}
        </div>

        <div class="quick-overview-wrap">
            <div class="row">
                <div class="col-sm-6">
                    <div class="youtube-embed-wrap">
                        <ul class="youtube-embed-list">
                            <li class="active">
                                <iframe width="100%" height="100%" src="https://www.youtube.com/embed/jMKQUaKGTGw" frameborder="0" allow="encrypted-media" allowfullscreen></iframe>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="youtube-link-wrap">
                        <h2>A Quick Overview</h2>
                        <div class="youtube-link-list-wrap">
                            <ul class="youtube-link-list">
                                <li class="active"><i class="youtube-play-icon"></i>How To Import Product To My Store?</li>
                                <li><i class="youtube-play-icon"></i>How To Find Product Have E-Packet Shipping Method?</li>
                                <li><i class="youtube-play-icon"></i>How To Fulfill Orders Automatically?</li>
                                <li><i class="youtube-play-icon"></i>How To Update AliExpress Link For Products?</li>
                                <li><i class="youtube-play-icon"></i>How To Override Products?</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    @include('layout.modal_vote')
@endsection

@section('scripts')
    <script>
        (function($) {
            $('.youtube-link-list li').on('click', function() {
                $('.youtube-link-list li').removeClass('active');
                $(this).addClass('active');
                var index = $(this).index();
                var video_list = [
                    '<iframe width="100%" height="100%" src="https://www.youtube.com/embed/jMKQUaKGTGw?autoplay=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
                    '<iframe width="100%" height="100%" src="https://www.youtube.com/embed/F9bSWejVTtA?autoplay=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
                    '<iframe width="100%" height="100%" src="https://www.youtube.com/embed/_kusm4Hc0xg?autoplay=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
                    '<iframe width="100%" height="100%" src="https://www.youtube.com/embed/0HAPXhWdVhE?autoplay=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
                    '<iframe width="100%" height="100%" src="https://www.youtube.com/embed/jsRwAfsxD2Y?autoplay=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>'
                ];
                $('.youtube-embed-list li').html(video_list[index]);
            });
        })(jQuery);
    </script>
@endsection


//bk dashboad

@extends('layout.backend')

@section('head_extend')
    <link rel="stylesheet" href="{{ URL::asset(mix('css/statistic.css')) }}">
@endsection

@section('content_container')



    <div id="page-dashboard" class="statistic-content-wrap">
        <modal_chart_cost v-bind:chart_modal_loading="chart_modal_loading"></modal_chart_cost>
        <modal_chart_order v-bind:chart_modal_loading="chart_modal_loading"></modal_chart_order>
        <modal_chart_revenue v-bind:chart_modal_loading="chart_modal_loading"></modal_chart_revenue>
        <modal_sale_report></modal_sale_report>
        <h2>Overview</h2>
        <div class="statistic-total-block-wrap">
            <div class="row">
                <div class="col-xs-4">
                    <div class="statistic-total-block" @click="barChartTotalOrders">
                        <p class="statistic-total-title">Total Revenue</p>
                        <div class="statistic-total-price">
                            <p class="statistic-total-number">246K</p>
                            <span class="decrease"><img src="{{URL::asset('images/icon/icon-arrow-down.svg')}}" alt="icondown"></i>13.8%</span>
                        </div>
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="statistic-total-block" @click="barChartTotalRevenue()">
                        <p class="statistic-total-title">Revenue</p>
                        <div class="statistic-total-price">
                            <p class="statistic-total-number">2453</p>
                            <span class="increase"><img src="{{URL::asset('images/icon/icon-arrow-up.svg')}}" alt="icon up"></i>13.8%</span>
                        </div>
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="statistic-total-block" @click="barChartTotalCost()">
                        <p class="statistic-total-title">Growth</p>
                        <div class="statistic-total-price">
                            <p class="statistic-total-number">$39K</p>
                            <span class="decrease"><img src="{{URL::asset('images/icon/icon-arrow-down.svg')}}" alt="icondown"></i>13.8%</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <statistic_chart v-on:chart_statistic="chartStatistic" v-bind:chart_loading="chart_loading"></statistic_chart>
                <div class="statistic-sale-report">
                    <h2>Sale Report</h2>
                    <div class="table-product">
                        <div class="ars-table">
                            <div class="ars-table-head">
                                <div class="ars-table-col">PRODUCT</div>
                                <div class="ars-table-col">AVAILABILITY</div>
                                <div class="ars-table-col">TOTAL</div>
                            </div>
                            <div class="ars-table-body">
                                <div class="ars-table-row">
                                    <div class="ars-table-col">
                                        <a href="">
                                            <img src="{{URL::asset('images/statistic/sale-report-product.png')}}" alt="sale report product">
                                            <span>Women’s Vintage Peacoat</span>
                                        </a>
                                    </div>
                                    <div class="ars-table-col"><span class="availability instock">320 In Stock</span></div>
                                    <div class="ars-table-col">$29,192</div>
                                </div>
                                <div class="ars-table-row">
                                    <div class="ars-table-col">
                                        <a href="">
                                            <img src="{{URL::asset('images/statistic/sale-report-product.png')}}" alt="sale report product">
                                            <span>Women’s Vintage Peacoat</span>
                                        </a>
                                    </div>
                                    <div class="ars-table-col"><span class="availability outstock">Out Stock</span></div>
                                    <div class="ars-table-col">$29,192</div>
                                </div>
                                <div class="ars-table-row">
                                    <div class="ars-table-col">
                                        <a href="">
                                            <img src="{{URL::asset('images/statistic/sale-report-product.png')}}" alt="sale report product">
                                            <span>Women’s Vintage Peacoat</span>
                                        </a>
                                    </div>
                                    <div class="ars-table-col"><span class="availability instock">320 In Stock</span></div>
                                    <div class="ars-table-col">$29,192</div>
                                </div>
                                <div class="ars-table-row">
                                    <div class="ars-table-col">
                                        <a href="">
                                            <img src="{{URL::asset('images/statistic/sale-report-product.png')}}" alt="sale report product">
                                            <span>Women’s Vintage Peacoat</span>
                                        </a>
                                    </div>
                                    <div class="ars-table-col"><span class="availability instock">320 In Stock</span></div>
                                    <div class="ars-table-col">$29,192</div>
                                </div>
                            </div>
                        </div>
                        <div class="statistic-reference-show-more">
                            <span @click="showSaleReport()">Show More</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="statistic-summary-wrap statistic-timeline">
                    <h2>Timeline</h2>
                    <ul class="statistic-summary-list">
                        <li>
                            <a href="{{ url('orders/?status[]=1&reject_filter[]=filter_date_from&reject_filter[]=filter_date_to') }}">
                                <span class="statistic-summary-icon statistic-summary-on-hold">
                                    <img src="{{ URL::asset('images/backend/icon-timeline-1.png') }}" />
                                </span>
                                <div class="content-statistic-summary-icon">
                                    <p><b>John Doe,</b> started following you on Instagram</p>
                                    <p class="statistic-time">4 hours ago</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('orders/?status[]=1&reject_filter[]=filter_date_from&reject_filter[]=filter_date_to') }}">
                                <span class="statistic-summary-icon statistic-summary-on-hold">
                                    <img src="{{ URL::asset('images/backend/icon-timeline-2.png') }}" />
                                </span>
                                <div class="content-statistic-summary-icon">
                                    <p>Invoice for 30 hours of calls has paid</p>
                                    <p class="statistic-time">8 hours ago</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('orders/?status[]=1&reject_filter[]=filter_date_from&reject_filter[]=filter_date_to') }}">
                                <span class="statistic-summary-icon statistic-summary-on-hold">
                                    <img src="{{ URL::asset('images/backend/icon-timeline-3.png') }}" />
                                </span>
                                <div class="content-statistic-summary-icon">
                                    <p>You’ve logged in on a new device</p>
                                    <p class="statistic-time">2 days ago</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('orders/?status[]=1&reject_filter[]=filter_date_from&reject_filter[]=filter_date_to') }}">
                                <span class="statistic-summary-icon statistic-summary-on-hold">
                                    <img src="{{ URL::asset('images/backend/icon-timeline-4.png') }}" />
                                </span>
                                <div class="content-statistic-summary-icon">
                                    <p>You’ve a new message on Facebook </p>
                                    <p class="statistic-time">3 days ago</p>
                                </div>
                            </a>
                        </li>

                    </ul>
                </div>

                <div class="statistic-summary-wrap">
                    <h2>Quick Details</h2>
                    <ul class="statistic-summary-list">
                        <li>
                            <a href="{{ url('orders/?status[]=1&reject_filter[]=filter_date_from&reject_filter[]=filter_date_to') }}">
                                <span class="statistic-summary-icon statistic-summary-on-hold">
                                    <img src="{{ URL::asset('images/backend/statistic-on-hold-icon.png') }}" />
                                </span>
                                <span class="statistic-summary-to-order"><span v-text="quick_summary.on_hold"></span> Orders</span>
                                <span class="statistic-summary-status">On Hold</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('orders/?status[]=2&reject_filter[]=filter_date_from&reject_filter[]=filter_date_to') }}">
                                <span class="statistic-summary-icon statistic-summary-processing">
                                    <img src="{{ URL::asset('images/backend/statistic-processing-icon.png') }}" />
                                </span>
                                <span class="statistic-summary-to-order"><span v-text="quick_summary.processing"></span> Orders</span>
                                <span class="statistic-summary-status">Processing</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('products?status=4') }}">
                                <span class="statistic-summary-icon statistic-summary-low-in-stock">
                                    <img src="{{ URL::asset('images/backend/statistic-low-in-stock-icon.png') }}" />
                                </span>
                                <span class="statistic-summary-to-order"><span v-text="quick_summary.low_in_stock"></span> Products</span>
                                <span class="statistic-summary-status">Low in Stock</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ url('products?status=2') }}">
                                <span class="statistic-summary-icon statistic-summary-out-of-stock">
                                    <img src="{{ URL::asset('images/backend/statistic-out-of-stock-icon.png') }}" />
                                </span>
                                <span class="statistic-summary-to-order"><span v-text="quick_summary.out_of_stock"></span> Products</span>
                                <span class="statistic-summary-status">Out of Stock</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    {{--<canvas id="chartbar" style="width: 700px"></canvas>--}}
@endsection

@section('footer_extend')
    <script type="text/javascript" src="{{ URL::asset('bower_component/chart.js/dist/Chart.js') }}"></script>
    <script type="text/javascript" src="{{ URL::asset(mix('js/modules/dashboard.min.js')) }}"></script>
    <script>
        //draw border radius bar in chart js

        /* var ctx = document.getElementById("chart").getContext("2d");*/
        // draws a rectangle with a rounded top
        Chart.helpers.drawRoundedTopRectangle = function(ctx, x, y, width, height, radius) {
            ctx.beginPath();
            ctx.moveTo(x + radius, y);
            // top right corner
            ctx.lineTo(x + width - radius, y);
            ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
            // bottom right	corner
            ctx.lineTo(x + width, y + height);
            // bottom left corner
            ctx.lineTo(x, y + height);
            // top left
            ctx.lineTo(x, y + radius);
            ctx.quadraticCurveTo(x, y, x + radius, y);
            ctx.closePath();
        };

        Chart.helpers.drawRoundedBottomRectangle = function(ctx,x,y,width,height,radius){
            ctx.beginPath();
            ctx.moveTo(x - radius, y);
            // bottom right corner
            ctx.lineTo(x + width - radius, y);
            ctx.quadraticCurveTo(x + width, y, x + width, y - radius);
            // bottom right	corner
            ctx.lineTo(x + width,(y + height));
            // bottom left corner
            ctx.lineTo(x, (y + height));
            // top left
            ctx.lineTo(x, y - radius);
            ctx.quadraticCurveTo(x, y, x + radius, y);
            ctx.closePath();
        }

        Chart.elements.RoundedTopRectangle = Chart.elements.Rectangle.extend({
            draw: function() {
                var ctx = this._chart.ctx;
                var vm = this._view;
                var left, right, top, bottom, signX, signY, borderSkipped;
                var borderWidth = vm.borderWidth;

                if (!vm.horizontal) {
                    // bar
                    left = vm.x - vm.width / 2;
                    right = vm.x + vm.width / 2;
                    top = vm.y;
                    bottom = vm.base;
                    signX = 1;
                    signY = bottom > top? 1: -1;
                    borderSkipped = vm.borderSkipped || 'bottom';
                } else {
                    // horizontal bar
                    left = vm.base;
                    right = vm.x;
                    top = vm.y - vm.height / 2;
                    bottom = vm.y + vm.height / 2;
                    signX = right > left? 1: -1;
                    signY = 1;
                    borderSkipped = vm.borderSkipped || 'left';
                }

                if (borderWidth) {
                    // borderWidth shold be less than bar width and bar height.
                    var barSize = Math.min(Math.abs(left - right), Math.abs(top - bottom));
                    borderWidth = borderWidth > barSize? barSize: borderWidth;
                    var halfStroke = borderWidth / 2;
                    // Adjust borderWidth when bar top position is near vm.base(zero).
                    var borderLeft = left + (borderSkipped !== 'left'? halfStroke * signX: 0);
                    var borderRight = right + (borderSkipped !== 'right'? -halfStroke * signX: 0);
                    var borderTop = top + (borderSkipped !== 'top'? halfStroke * signY: 0);
                    var borderBottom = bottom + (borderSkipped !== 'bottom'? -halfStroke * signY: 0);
                    // not become a vertical line?
                    if (borderLeft !== borderRight) {
                        top = borderTop;
                        bottom = borderBottom;
                    }
                    // not become a horizontal line?
                    if (borderTop !== borderBottom) {
                        left = borderLeft;
                        right = borderRight;
                    }
                }
                // calculate the bar width and roundess
                var barWidth = Math.abs(left - right);
                var roundness = this._chart.config.options.barRoundness || 0.5;
                var radius = barWidth * roundness * 0.5;

                // keep track of the original top of the bar
                var prevTop = top;

                // move the top down so there is room to draw the rounded top
                top = prevTop + radius;
                var barRadius = 6;

                ctx.beginPath();
                ctx.fillStyle = vm.backgroundColor;
                ctx.strokeStyle = vm.borderColor;
                ctx.lineWidth = borderWidth;


                if(signY > 0) {
                    // draw the rounded top rectangle
                    Chart.helpers.drawRoundedTopRectangle(ctx, left, (top - barRadius + 1), barWidth, bottom - prevTop, barRadius);
                }
                else if(signY < 0){
                    Chart.helpers.drawRoundedBottomRectangle(ctx, left, (top - barRadius + 1), barWidth, bottom - prevTop, barRadius);
                }
                ctx.fill();
                if (borderWidth) {
                    ctx.stroke();
                }

                // restore the original top value so tooltips and scales still work
                top = prevTop;
            },
        });

        Chart.defaults.roundedBar = Chart.helpers.clone(Chart.defaults.bar);

        Chart.controllers.roundedBar = Chart.controllers.bar.extend({
            dataElementType: Chart.elements.RoundedTopRectangle
        });

        /*new Chart(ctx, {
            type: 'roundedBar',
            data: {
                labels: [
                    "Jan",
                    "Fer",
                    "Mar",
                    "Apr",
                    "May",
                    "Jun",
                    "Jul"
                ],
                datasets: [
                    {
                        data: [7, 4.5, 1.7, 3.5, 5.5, 3, 5.5],
                        label: 'Total Revenue',
                        backgroundColor: '#a3a1fb',
                        hoverBackgroundColor: '#a3a1fb',
                        borderWidth: 0
                    },
                    {
                        data: [0,-2.2,-4.8,-3,-1,0,-2.5],
                        label: 'Total Cost',
                        backgroundColor: '#edecfe',
                        hoverBackgroundColor: '#edecfe',
                        borderWidth: 0
                    }
                ]
            },
            options: {
                responsive: true,
                defaultFontFamily: "'Roboto', sans-serif",
                title:{
                    display: true,
                },
                legend: {
                    display: false,
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            fontColor: "#91919B",
                        },
                        stacked: true,
                        gridLines: {
                            color: "rgba(0, 0, 0, 0)",
                        },
                        barPercentage: 0.6,
                    }],
                    yAxes: [{
                        ticks: {
                            fontColor: "#91919B",
                            beginAtZero:true
                        },
                        stacked: true,
                        gridLines: {
                            color: "#EAF0F4",
                            lineWidth: 1,
                            zeroLineColor: "#EAF0F4",
                            zeroLineWidth: 1
                        },
                    }]
                },
                tooltips: {
                    enabled: false,
                    mode: 'index',
                    intersect: false,
                    position: 'nearest',
                    backgroundColor: "#FFF",
                    borderColor: "#242539",
                    borderWidth: 1,
                    bodyFontSize: 14,
                    bodyFontColor: "#333c48",
                    titleFontSize: 14,
                    titleFontColor: "#333c48",
                    bodySpacing: 2,
                    titleMarginBottom: 10,
                    xPadding: 20,
                    yPadding: 12,
                    caretSize: 2,
                    yAlign: 'right',
                    callbacks: {
                        label: function(tooltipItem, data) {
                            var label = data.datasets[tooltipItem.datasetIndex].label || '';

                            if (label) {
                                label += ': ';
                            }
                            label += '$' + tooltipItem.yLabel
                            return label;
                        }
                    },
                    custom: function(tooltipModel) {
                        // Tooltip Element
                        var tooltipEl = document.getElementById('chartjs-tooltip');

                        // Create element on first render
                        if (!tooltipEl) {
                            tooltipEl = document.createElement('div');
                            tooltipEl.id = 'chartjs-tooltip-cost';
                            tooltipEl.innerHTML = "<table></table>"
                            document.body.appendChild(tooltipEl);
                        }

                        // Hide if no tooltip
                        if (tooltipModel.opacity === 0) {
                            tooltipEl.style.opacity = 0;
                            return;
                        }

                        // Set caret Position
                        tooltipEl.classList.remove('above', 'below', 'no-transform');
                        if (tooltipModel.yAlign) {
                            tooltipEl.classList.add(tooltipModel.yAlign);
                        } else {
                            tooltipEl.classList.add('no-transform');
                        }

                        function getBody(bodyItem) {
                            return bodyItem.lines;
                        }

                        // Set Text
                        if (tooltipModel.body) {
                            var titleLines = tooltipModel.title || [];
                            var bodyLines = tooltipModel.body.map(getBody);

                            var innerHtml = '<thead>';

                            titleLines.forEach(function(title) {
                                innerHtml += '<tr><th>' + title + '</th></tr>';
                            });
                            innerHtml += '</thead><tbody>';

                            bodyLines.forEach(function(body, i) {
                                var colors = tooltipModel.labelColors[i];
                                var style = 'background:' + colors.backgroundColor;
                                style += '; border-color:' + colors.borderColor;
                                style += '; border-width: 2px';
                                var span = '<span class="chartjs-tooltip-key" style="' + style + '"></span>';
                                innerHtml += '<tr><td>' + span + body + '</td></tr>';
                            });
                            innerHtml += '</tbody>';

                            var tableRoot = tooltipEl.querySelector('table');
                            tableRoot.innerHTML = innerHtml;
                        }

                        // `this` will be the overall tooltip
                        var position = this._chart.canvas.getBoundingClientRect();
                        // Display, position, and set styles for font
                        tooltipEl.style.position = 'absolute';
                        tooltipEl.style.opacity = 1;
                        tooltipEl.style.left = tooltipModel.caretX + 50+'px';
                        tooltipEl.style.top = tooltipModel.caretY + 100 + 'px';
                        // tooltipEl.style.fontFamily = tooltipModel._fontFamily;
                        tooltipEl.style.fontSize = tooltipModel.fontSize;
                        tooltipEl.style.fontStyle = tooltipModel._fontStyle;
                        tooltipEl.style.padding = '10px 15px';
                    }
                },
                hover: {
                    mode: 'index',
                    intersect: true
                },
            }
        });*/

    </script>
@endsection

<script>
    import Modal_sale_report from "../../assets/js/components/statistic/modal_sale_report";
    export default {
        components: {Modal_sale_report}
    }
</script>
