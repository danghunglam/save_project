@include('layout.head')
<div class="maintenance">
    <div class="content-left text-center">
        <div class="max-width-450">
            <div class="image-maintenance">
                <img src="{{ URL::asset('images/maintenance/image-maintenance.png') }}" alt="image maintence Ali Orders">
            </div>
            <div class="logo">
                <div class="logo">
                    <img src="{{ URL::asset('images/maintenance/logo-ali-order.png') }}" alt="logo ali orders">
                </div>
            </div>
        </div>
    </div>
    <div class="content-right">
        <div class="maintenance-content">
            <h1>Maintenance Notice</h1>
            <p>
                <span>Time: 10AM Sep 25,2018 - 10PM Sep 26,2018 (GMT +7)</span>
                We will be moving our database to a new server to cope with the growing amount of users, this will affect existing users trying to access to our app.</p>
            <p>During the maintain period, you can't access to the Dashboard, as well as adding new reviews. However, storefront reviews will still be shown as normal.</p>
            <p>Please prepare your reviews & products beforehand. Thank you for your patience and apologize for any inconvenience caused.</p>
            <p>Best,<br>Hailey</p>
        </div>
    </div>
</div>
<style>
    .maintenance {
        display: flex;
        height: 100%;
        min-width: 1170px;
    }
    .content-left.text-center, .content-right {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .content-left {
        background-image: linear-gradient(to left bottom ,#2B18AF, #802FE8);
    }
    .content-right {
        background: #ffffff;
        padding: 30px;
    }

    .maintenance h1{
        font-size: 25px;
        font-weight: 600;
        margin-top: 0;
        margin-bottom: 40px;
    }
    .maintenance p{
        font-weight: 400;
        font-size: 15px;
        margin-top: 0;
        margin-bottom: 20px;
        line-height: normal;
    }
    .maintenance span{
        font-weight: 600;
        display: block;
    }

    .maintenance-content {
        max-width: 485px;
        margin: auto;
        color: #242539;
    }

    .maintenance .logo {
        margin-top: 50px;
    }
</style>
@include('layout.footer')
