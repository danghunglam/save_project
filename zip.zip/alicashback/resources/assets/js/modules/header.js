import notification from '../components/common/notifications'
import add_account from '../components/multiAccount/add_account'
import delete_account from '../components/multiAccount/delete_account'
import swal from 'sweetalert2'

new  Vue({
    el : '#header',
    data: {
        hello: '1234',
        total_notification: ''
    },
    mounted: function () {
        $('.shopify-profile .shopify-name-dropdown ul li').click(function () {
            $(this).parents('.shopify-profile').removeClass('open-shopify-name')
        });
        $('.list-account .account-item div.avatar span').each(function () {
            let owner=$(this).attr('data-owner')
            let objShopName = owner.split(' ');
            let avatarName = ((objShopName[0]) ? objShopName[0].slice(0,1) : '')+ ((objShopName[1]) ? objShopName[1].slice(0,1) : '')
            $(this).text(avatarName.toUpperCase());
        })
    },
    methods: {
        numberNotification: function(obj_number) {
            this.total_notification = obj_number
        },
        /*remove account in multi_account*/
        removeAccount: function (shopId, shopDomain) {
            $('#popup_remove_shop_domain').text(shopDomain).attr('href','https://'+shopDomain+'/admin')
            $('#popup_remove_shop_id').val(shopId)
            $('#removeAccount').modal();
        }
    },
    components: {
        notification: notification
    }
});
new  Vue({
    el : '#popup-header',
    data: {

    },
    mounted: function () {
        //show popup add account
        $('.multiaccount-footer .modal__ok_button').click(function () {
            $('#addAccount').modal();
        });
    },
    methods: {

    },
    components: {
        add_account: add_account,
        delete_account: delete_account
    }
})
