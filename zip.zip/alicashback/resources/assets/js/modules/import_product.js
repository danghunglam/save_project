import import_item from '../components/import/import_item.vue'
import pagination from '../components/common/pagination'
import toast_process from '../components/common/toast_process'
import swal from 'sweetalert2'
import modal_leave_page from '../components/common/modal_leave_page'
import vue_loaders_circle from '../components/common/vue_loaders_circle'
import modal_shipping_country from '../components/import/modal-shipping-country'
import modal_split_product from '../components/import/modal_split_product'
import modal_bulk_edit_product from '../components/import/modal_bulk_edit_product'
import Rx from 'rxjs/Rx';

new Vue({
    el: '#import-product',
    data: {
        all_products: null,
        products : null,
        custom_collection : {},
        product_type: [],
        loading: true,
        total_checked: 0,
        bulkProduct: '',
        products_select: [],
        is_push_all: false,
        is_remove_all: false,
        product_result: null,
        pagination: [],
        total_product: 0,
        import_process: [],
        filters: {
            'keyword' : '',
            'paged' : 1
        },
        settings,
        keywordType: '',
        process_import_type: ['import_product'],
        leave_page_href: '',
        pageUrl: '/import',
        product_images_modal: [],
        current_product: {},
        shipping_product:{price_shipping:0, shipTo :''},
        freight:{price:0, shipTo :null},
        split_product: null,
        bulkEditProduct:{
            name:{
                active:false,
                text:''
            },
            collection:{
                active:false,
                text:''
            },
            type:{
                active:false,
                text:''
            },
            tag:{
                active:false,
                text:''
            },
            description:{
                active:false,
                text:''
            }
        },
        check_bulk_edit_product: null,
        is_loading_bulk_edit:false,
        change_bulk_edit:{
            title: false,
            edited: false
        },
        product_select_bulk_edit:{}

    },
    components: {
        import_item,
        pagination,
        toast_process,
        modal_leave_page,
        vue_loaders_circle,
        modal_shipping_country,
        modal_split_product,
        modal_bulk_edit_product
    },
    created: function () {
        let _this = this
        axios.get(appUrl+'/import/collection')
            .then(function (response) {
                const { data } = response
                if(data.status)
                    _this.custom_collection = Object.assign({}, _this.custom_collection, data.custom_collection)
            })
            .catch(function (error) {
                notify('error', error)
            });

        axios.get(appUrl+'/import/product_type')
                .then(function (response) {
                    const x = response.data.product_type;
                    _this.product_type = x
                })
                .catch(function (error) {

                })
        //Init all product in import product
        axios.get(appUrl+'/setting/all')
            .then(function (response) {
                let {status, settings} = response.data
                if( ! status)
                    console.log('Get settings error')
                else
                    _this.settings = settings
            })
            .catch(function (error) {
                console.log(error)
            })
        _this.initFilters()
        _this.getProductImport()

        _this.check_bulk_edit_product = new Rx.BehaviorSubject();
        _this.check_bulk_edit_product
            .debounceTime(1000)
            .subscribe(
                function() {
                    _this.is_loading_bulk_edit=false
                    _this.change_bulk_edit.edited = false
                    $('#bulkEditProduct').modal('hide')
                }
            );
    },
    mounted: function () {
        $('#voteForUsModal').on('hidden.bs.modal', function () {
            axios.post(appUrl+'/import/vote').then(function (res) {

            });
        })
        this.pusherSubscribe()
        this.getToastProcess()
    },
    methods: {
        showModalShipingCountry:function (current_product) {
            let _this = this
            this.current_product = current_product
            this.$nextTick(function () {
                _this.$refs.modal_shipping_country.initDataShip()
            })
            // console.log(Object.keys(obj_product.variants).length)
            if($('.modal-shipping-country').length){
                $('.modal-shipping-country').addClass('show-modal-shipping')
                $('body').append('<div class="bg-modal-shipping"></div>')
            }
            /*$('#modal-shipping-country-'+this.product.aliexpress_product_id).modal('show');*/
        },
        infoShipping: function(freight, product){
            this.shipping_product = product
            this.shipping_product.price_shipping = freight.price
            this.shipping_product.shipTo = freight.shipTo
            this.shipping_product.types = freight.types
            // this.freight = freight
        },
        setToastProcess: function (products) {
            let _this = this
            axios.post(appUrl+'/toast_process', {products: products, type: _this.process_import_type})
        },
        pushToastProcess: function (product, type) {
            let _this = this
            axios.post(appUrl+'/push_process', {product: product, type: type})
        },
        getToastProcess: function () {
            let _this = this

            axios.get(appUrl+'/toast_process', {
                    params: {
                        type: _this.process_import_type
                    }
                })
                .then(function (response) {
                    _this.import_process = response.data
                })
                .catch(function (error) {
                    console.log(error)
                })
        },
        //Push queue show process override
        importProcess: function (product) {
            $('#overrideProductModal').modal('hide')
            product = Object.assign({}, product, {
                product_link: '',
                status: 'pending'
            })

            this.import_process.forEach(function (item) {
                if(item.type === 'import_product') {
                    if(!Array.isArray(item.data)) {
                        item.data = []
                    }
                    item.data.unshift(product)
                }
            })

        },
        pusherSubscribe: function () {
            let _this = this;
            let pusher = new Pusher(pusherEnv.app_key, {
                cluster: pusherEnv.app_cluster,
                encrypted: true
            });
            let channel = pusher.subscribe(shopId);
            channel.bind('import_product', function(product) {
                _this.import_process = _this.import_process.map(function (process_with_type) {
                    if(process_with_type.type !== 'import_product')
                        return process_with_type
                    else {
                        return {
                            type: process_with_type.type,
                            data: process_with_type.data.map(function (product_process) {
                                if(product.product.id === product_process.id) {
                                    if(product.product.status == 'success') {
                                        return Object.assign({}, product_process, {
                                            status: 'success',
                                            tooltip_message: product.product.tooltip_message,
                                            product_link: product.product.product_link
                                        })
                                    } else if(product.product.status == 'error' && product_process.status != 'success') {
                                        return Object.assign({}, product_process, {
                                            tooltip_message: product.product.tooltip_message,
                                            status: 'error'
                                        })
                                    }
                                } else {
                                    return product_process
                                }
                            })
                        }
                    }
                })

                // _this.setToastProcess(_this.import_process)
            });
        },
        getProductImport: function () {
            let _this = this
            let url = appUrl + '/import/products' + _this.getSearchUrl()
            let products_select_id = [];
            // show empty box - fix bug #20
            $('.import-list-empty-box').css('display','block');
            axios.get(url)
                .then(function(response) {
                    const {status, productObj, pagination, totalProduct } = response.data
                    if(status) {
                        if(_this.filters.keyword != '') {
                            _this.product_result = 'search'
                        }
                        _this.products = productObj

                        _this.pagination = pagination
                        _this.total_product = totalProduct
                        // cap nhat trang thai selected
                        _this.products_select.forEach(function (productSelectedId) {
                            products_select_id.push(productSelectedId.id);
                        });
                        _this.products.map(function (productItem) {
                                let index = products_select_id.indexOf(productItem.id);
                                if(index >= 0) {
                                    productItem.selected = true;
                                }
                        });
                        console.log('_this.products', _this.products)
                        $('.total_import_product_number').text(totalProduct)
                        _this.updatePageUrl()
                        $(window).scrollTop(0);
                        if(totalProduct > 0 && _this.products.length == 0) {
                            _this.loading = true;
                        } else {
                            _this.loading = false;
                        }
                    }
                    else
                        notify('error', 'error')
                })
                .catch(function(error) {
                    notify('error', error)
                });
        },

        sliceTwoArray: function(arg_source, arg2_slice, key)
        {
            let arg_index = arg2_slice.map(function (index) {
                return index[key]
            })
            return arg_source.filter(function (source) {
                return  (arg_index.indexOf(source[key]) < 0)
            });
        },

        checkProduct: function (product) {
            let _this = this
            this.total_checked = 0
            // console.log(product.id)
            this.$nextTick(function () {
                _this.products = _this.products.map(function (product_item) {
                    if(product_item.id === product.id)
                    {
                        product_item = Object.assign(product_item, product)
                        // product_item.title = product.title
                        // product_item.selected = product.selected
                    }
                    return product_item
                });
                _this.products_select = _this.products.filter(function (product_item) {
                    return product_item.selected
                });
            })
            setTimeout(function(){
            },100)

        },
        checkEditproduct:function(status){
            if(this.change_bulk_edit.edited){
                this.is_loading_bulk_edit = true
                this.check_bulk_edit_product.next()
            }
        },
        checkAll: function (event) {
            let _this = this
            const selected = $(event.currentTarget).prop('checked')
            this.$nextTick(function () {
                _this.products = _this.products.map(function (product) {
                    product = Object.assign(product, {selected : selected});
                    return product
                });

                _this.products_select = _this.products.filter(function (product_item) {
                    return product_item.selected
                });

                console.log('_this.products_select', _this.products_select)
            });
        },
        removeItemProduct: function (product) {
            this.handleRemove([product])
            // this.getProductImport()
        },
        pushItemProduct: function (product) {
            // this.setOptions();
            this.handlePush([product])

        },
        pushAllProducts: function () {
            let _this = this

            swal({
                title:'<span class="sweetalert-icon"><i class="mdi mdi-package-up"></i></span>',
                html: '<h4 class="text-left sweetalert-title-delete">Push All Products</h4><span class="text-left" style="display: block">Are you sure you want to push all products?</span>',
                showCloseButton: true,
                showCancelButton: true,
                focusConfirm: false,
                position: 'top',
                confirmButtonText: 'Push Now',
                cancelButtonText: 'Cancel'
            })
            .then(function (action) {
                if (action.value) {
                    _this.is_push_all = true
                    _this.handlePushAll()
                }
            })

        },
        removeAllProducts: function () {
            let _this = this
            swal({
                title:'<span class="sweetalert-icon icon-delete"><i class="mdi mdi-delete-forever"></i></span>',
                html: '<h4 class="text-left sweetalert-title-delete">Remove Product</h4><div class="text-left">Are you sure you want to remove all products from Import List?</div>',
                showCloseButton: true,
                showCancelButton: true,
                focusConfirm: false,
                position: 'top',
                confirmButtonText: '<span class="text-button-remove">Remove</span>',
                cancelButtonText: '<span class="text-button-remove">Cancel</span>'
            })
                .then(function (action) {
                    if (action.value) {
                        _this.handleRemoveAll();
                    }
                })
        },
        setOptions: function (products) {
            return products.map(product => {
                let product_options = new Array([])
                if(product.variants) {
                    product.variants.map((variant) => {
                        let { options } = variant
                        let key = Object.keys(options)
                        let value = Object.values(options)

                        if(key[0]) {
                            variant.option1 = value[0]
                            product_options[0] =  {'name' : key[0],  'position' : 1}
                        }

                        if(key[1]) {
                            variant.option2 = value[1]
                            product_options[1] = {'name' : key[1],  'position' : 2}
                        }

                        if(key[2]) {
                            variant.option3 = value[2]
                            product_options[2] = {'name' : key[2], 'position' : 3}
                        }
                    })
                }
                product.options = product_options
                return product
            })
        },

        bulkActionProduct: function (bulk_name) {
            let _this = this
            //Set options
            // _this.setOptions();

            if(bulk_name === 'push')
            {
                // swal({ text: 'Are you sure you want push products?', buttons: ["Cancel", true]})
                //     .then(function (action) {
                //         if(action)
                //         {
                //             _this.products = _this.products.map(function(product) {
                //                 if(product.selected)
                //                     return Object.assign({}, product, {
                //                         is_push: true
                //                     })
                //                 else
                //                     return product
                //             })
                //             _this.handlePush(_this.products_select)
                //         }
                //     });

                swal({
                    title:'<span class="sweetalert-icon"><i class="mdi mdi-package-up"></i></span>',
                    html: '<h4 class="text-left sweetalert-title-delete">Push Products</h4><div class="text-left">Push selected products to shop?</div>',
                    showCloseButton: true,
                    showCancelButton: true,
                    focusConfirm: false,
                    position: 'top',
                    confirmButtonText: 'Push Now',
                    cancelButtonText: 'Cancel'
                })
                .then(function (action) {
                    if (action.value) {
                        _this.products = _this.products.map(function(product) {
                            if(product.selected)
                                return Object.assign({}, product, {
                                    is_push: true
                                })
                            else
                                return product
                        })
                        _this.handlePush(_this.products_select)
                    }
                })


            } else if(bulk_name === 'delete')
            {
                let _this = this
                swal({
                    title:'<span class="sweetalert-icon icon-delete"><i class="mdi mdi-delete-forever"></i></span>',
                    html: '<h4 class="text-left sweetalert-title-delete">Remove Product</h4><div class="text-left">Remove selected product from Import List?</div>',
                    showCloseButton: true,
                    showCancelButton: true,
                    focusConfirm: false,
                    position: 'top',
                    confirmButtonText: '<span class="text-button-remove">Remove</span>',
                    cancelButtonText: '<span class="text-button-remove">Cancel</span>'
                })
                .then(function (action) {
                    if (action.value) {
                        _this.handleRemove(_this.products_select);
                    }
                })
            }else if(bulk_name === 'edit')
            {
                _this.product_select_bulk_edit = _this.products_select
                $('#bulkEditProduct').data('bs.modal',null);
                $('#bulkEditProduct').modal({backdrop: 'static', keyboard: false})
            }
        },

        handlePush: function (product_select, message = {}) {
            let _this = this
            _this.setOptions(product_select)

            //ajax
            axios.post(appUrl+'/import/push', product_select)
                .then(function (response) {
                    let { data } = response
                    _this.is_push_all = false
                    if(data.status)
                    {
                        let hasSuccess = false;
                        product_select.forEach(function (product) {
                            if(data.fails.indexOf(product.id) > -1) {
                                // notify('error', 'Product had been removed')
                            } else {
                                _this.importProcess(product)
                                hasSuccess = true
                            }
                        })
                        // _this.pushToastProcess(product_select, 'import_product')

                        _this.products = _this.sliceTwoArray(_this.products, product_select, 'id')
                        _this.products_select = _this.products.filter(function (product_item) {
                            return product_item.selected
                        });
                        if(_this.products.length == 0) {
                            _this.loading = true;
                        }
                        //$('.bulkAction').select2('destroy')
                        _this.getProductImport();
                        if(hasSuccess) {
                            _this.total_product--;
                            // notify('success', 'Import product success')
                        }
                        if(data.count_import_product >= 5 && ! data.isVote) {
                            $('#voteForUsModal').modal('show')
                        }

                    } else {
                        notify('error', 'Import product error')
                    }
                })
                .catch(function (error) {
                    _this.is_push_all = false
                    if(!error.response)
                        console.log(error);
                    let {status, data } = error.response
                    if(status === 422)
                    {
                        let {errors} = data
                        errors = Object.values(errors)
                        for (let i = 0; i < errors.length; i++) {
                            notify('warning', errors[i])
                        }
                    } else {
                        console.log(error.response);
                        notify('error', 'Import error, please try again')
                    }

                })
        },
        refeshPage: function() {
            let _this = this
            this.filters.paged = 1
            let url = appUrl + '/import/products' + _this.getSearchUrl()
            let products_select_id = [];
            axios.get(url)
                .then(function(response) {
                    const {status, productObj, pagination, totalProduct } = response.data
                    if(status) {
                        if(_this.filters.keyword != '') {
                            _this.product_result = 'search'
                        }
                        _this.products = productObj

                        _this.pagination = pagination
                        _this.total_product = totalProduct
                        // cap nhat trang thai selected
                        _this.products_select = []
                        $('.total_import_product_number').text(totalProduct)
                        _this.updatePageUrl()
                        $(window).scrollTop(0);
                        if(totalProduct > 0 && _this.products.length == 0) {
                            _this.loading = true;
                        } else {
                            _this.loading = false;
                        }
                    }
                    else
                        notify('error', 'error')
                })
                .catch(function(error) {
                    notify('error', error)
                });
        },
        handlePushAll: function () {
            let _this = this
            //ajax
            axios.post(appUrl+'/import/push_all')
                .then(function (response) {
                    let { data } = response
                    _this.is_push_all = false
                    if(data.status)
                    {
                        _this.products = []
                        _this.products_select = []
                        _this.total_product = 0
                        $('.total_import_product_number').text(0)
                        notify('success', 'Import product success')

                        if(data.count_import_product >= 5 && ! data.isVote){
                            $('#voteForUsModal').modal('show')
                        }
                    } else {
                        notify('error', 'Import product error')
                    }
                })
                .catch(function (error) {
                    _this.is_push_all = false
                    let {status, data } = error.response
                    if(status === 422)
                    {
                        let {errors} = data
                        errors = Object.values(errors)
                        for (let i = 0; i < errors.length; i++) {
                            notify('warning', errors[i])
                        }
                    } else {
                        console.log(error.response);
                        notify('error', 'Import error, please try again')
                    }

                })
        },
        closeToastProcess: function (process) {
            this.import_process.forEach(element => {
                $(`#product-list-item-${element.product_id}`).removeClass('product_process_override')
            });
            this.import_process = process
        },
        handleRemove: function (product_select, message = {}) {
            let _this = this
            axios.post(appUrl+'/import/delete', product_select)
                .then(function (response) {
                    _this.is_remove_all = false
                    let { data } = response
                    if(data.status)
                    {
                        _this.products = _this.sliceTwoArray(_this.products, product_select, 'id')
                        _this.products_select = _this.products.filter(function (product_item) {
                            return product_item.selected
                        });
                        _this.total_product--;
                       // $('.bulkAction').select2('destroy')
                        if(_this.products.length == 0) {
                            _this.loading = true;
                        }
                        _this.getProductImport()
                        notify('success', 'Removing product')
                    } else {
                        notify('error', 'Delete product error')
                    }
                })
                .catch(function (error) {
                    _this.is_remove_all = false
                    notify('error', error)
                })
        },

        handleRemoveAll: function () {
            let _this = this
            axios.post(appUrl+'/import/delete_all')
                .then(function (response) {
                    _this.is_remove_all = false
                    let { data } = response
                    if(data.status)
                    {
                        _this.products = []
                        _this.products_select = []
                        _this.total_product = 0
                        $('.total_import_product_number').text(0)
                        notify('success', 'Removing product')
                    } else {
                        notify('error', 'Delete product error')
                    }
                })
                .catch(function (error) {
                    _this.is_remove_all = false
                    notify('error', error)
                })
        },

        searchProduct: function () {
            let _this = this
            // this.filters.keyword = this.keywordType
            this.$nextTick(function () {
                // this.products = []
            })
            _this.filters.paged = 1
            _this.getProductImport()
            // axios.get(appUrl+'/import/products?keyword='+this.filters.keyword)
            //     .then(function(response) {
            //         const {productObj, status, pagination, totalProduct} = response.data
            //         if(status) {
            //             _this.product_result = 'search'
            //             _this.products = productObj
            //             _this.pagination = pagination
            //             _this.total_product = totalProduct
            //         }
            //         else
            //             notify('error', 'error')
            //     })
            //     .catch(function(error) {
            //         notify('error', error)
            //     });
        },
        clickPagination: function (paged) {
            let _this = this
            this.$nextTick(function () {
                this.products = null
            })
            this.filters.paged = paged
            this.products_select = []
            $('#select-all').prop('checked', false)
            // axios.get(appUrl+'/import/products?keyword='+this.filters.keyword+'&paged='+this.filters.paged)
            //     .then(function (response) {
            //         const {productObj, status, pagination, totalProduct} = response.data
            //         if(status) {
            //             _this.product_result = 'search'
            //             _this.products = productObj,
            //             _this.pagination = pagination
            //             _this.total_product = totalProduct
            //         }
            //         else
            //             notify('error', 'error')
            //     })
            //     .catch(function (error) {
            //         notify('error', error)
            //     })
            _this.getProductImport();
        },
        getSearchUrl() {
            let searchClause = [];
            if(this.filters.keyword != '') {
                searchClause.push('keyword=' + this.filters.keyword)
            }
            if(this.filters.paged != 1) {
                searchClause.push('paged=' + this.filters.paged)
            }
            return (searchClause.length > 0 ? '?' : '') + searchClause.join('&');
        },
        updatePageUrl() {
            let subDir = ''

            if(process.env.MIX_SUBDIR) {
                subDir = '/' + process.env.MIX_SUBDIR
            }
            window.history.pushState(null, null, subDir + this.pageUrl + this.getSearchUrl())
        },
        initFilters() {
            var url = new URL(window.location.href);
            if(url.searchParams.get("paged")) {
                this.filters.paged = url.searchParams.get("paged")
            }
            if(url.searchParams.get("keyword")) {
                this.filters.keyword = url.searchParams.get("keyword")
                this.keywordType = this.filters.keyword
            }
        },
        loadShipping:function (product) {
            let _this = this
            let priceMinMax = product.price_range ? typeof (product.price_range)== "object" ? product.price_range : JSON.parse(product.price_range) : 0
            let shipping = {}
            shipping.price = 0
            shipping.shipTo = 'United States'
            shipping.types = {
                city:null,
                country:'us',
                key: 0,
                province:null
            }

            let url = 'https://freight.aliexpress.com/ajaxFreightCalculateService.htm?' +
                'callback=jQuery18309588254488714415_1539076163637&f=d&productid='+product.aliexpress_product_id+'&' +
                'count=1&minPrice='+priceMinMax.minPrice+'&maxPrice='+priceMinMax.maxPrice+'&currencyCode=USD&transactionCurrencyCode=USD&sendGoodsCountry=&' +
                'country='+shipping.types.country.toUpperCase()+'&' +
                'province='+shipping.types.province+'&' +
                'city='+shipping.types.city+'&' +
                'abVersion=1&_=1539076181301'

            window.postMessage({action: 'ACTION_GET_FREIGHT_FROM_ALIEXPRESS', payload: {url: url}}, '*')
            _this.setfreights(shipping,product)
        },
        setfreights:function(shipping,productItem){
            let _this = this

            this.$nextTick(function () {
                window.getFreightAliExpress = function(args)
                {
                    _this.freights = args.freight.map(function (object) {
                        return {
                            companyDisplayName : object.companyDisplayName,
                            time : object.time,
                            price : object.price,
                            priceFormatStr: object.priceFormatStr,
                            isTracked: object.isTracked,
                        }
                    })
                    _this.$nextTick(function () {
                        _this.showDefaultShipping(shipping,productItem,_this.freights)
                    })

                }
            })
        },
        showDefaultShipping:function (shipping,productItem,freights) {
            let _this = this
            let companyShipping={}
            Object.values(freights).map(function (item,key) {

                if(item.companyDisplayName==='ePacket'){

                    item.key = key
                    companyShipping = item
                }
            })
            companyShipping = $.isEmptyObject(companyShipping)  ? freights[0] : companyShipping

            shipping.price = companyShipping.price
            shipping.types.key = companyShipping.key ? companyShipping.key : 0
            _this.infoShipping(shipping,productItem)
        },
        splitProduct(product) {
            this.split_product = product
            $('#modal_split_product').modal('show')
        },
        saveBulkProduct:function (bulk_edit_product,collections) {
            let _this = this

            let newCollections =  collections.map(function (collection) {
                return collection.id
            })

            _this.change_bulk_edit.edited = true

            _this.products = _this.products.map(function (product) {

                let index_name = 0

                bulk_edit_product.productsId.forEach(function (element) {

                    ++index_name

                    if(element == product.id ){
                        if(bulk_edit_product.collection.active)
                            product.custom_collection = newCollections

                        if(bulk_edit_product.name.active && product.title != bulk_edit_product.name.text)
                            product.title = [bulk_edit_product.name.text,' ('+ index_name +')'].join(' ')
                        else if(bulk_edit_product.name.active && product.title == bulk_edit_product.name.text)
                            _this.change_bulk_edit.title  = true


                        if(bulk_edit_product.type.active)
                            product.product_type = bulk_edit_product.type.text

                        if(bulk_edit_product.tag.active)
                            product.tag = bulk_edit_product.tag.text

                        if(bulk_edit_product.description.active)
                            product.body_html = bulk_edit_product.description.text
                    }
                })

                return product
            })

            if(_this.change_bulk_edit.title) {
                _this.is_loading_bulk_edit = true
                _this.change_bulk_edit.title = false
                $('#bulkEditProduct').modal('hide')
            }
        },
        cancelBulkEdit: function () {
            this.product_select_bulk_edit={}
        }
    },
    watch: {
        pagination: function(newpagination, oldpagination) {
            if(this.products.length == 0 && newpagination.last_page != this.filters.paged) {
                this.filters.paged = newpagination.last_page
                this.products_select = []
                $('#select-all').prop('checked', false)
                this.getProductImport()
            }
        }
    }
});
