new Vue({
    el: '#update-theme-shopify',
    data: {},
    created: function () {

    },
    methods: {
        updateTheme: function () {
            axios.get(appUrl+'/cs/update-themes/handle').then(function (res) {
                let {status, message} = res.data;
                if(status) {
                    notify('success', message);
                } else {
                    notify('error', message);
                }
            });
        }
    }
});