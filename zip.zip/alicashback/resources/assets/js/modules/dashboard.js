import modal_chart_cost from '../components/statistic/modal_chart_total_cost.vue'
import modal_chart_order from '../components/statistic/modal_chart_total_order'
import modal_chart_revenue from '../components/statistic/modal_chart_total_revenue'
import statistic_chart from '../components/statistic/statistic_chart'
import modal_reference from '../components/statistic/modal_reference'
import vue_loaders_circle from '../components/common/vue_loaders_circle'
import { chart_line_modal, chart_line } from "../option_chart";

//Load the 'corecharts'. You do not need to provide that as a type.

var vm = new Vue({
    el: '#page-statistic',
    data: {
        this_total_summary: {
            total_order: 0,
            total_revenue: 0,
            total_cost: 0
        },
        last_total_summary: {
            total_order: 0,
            total_revenue: 0,
            total_cost: 0
        },
        historys: [],
        chart: {
            dateList: [],
            order: [],
            revenue: [],
            cost: []
        },
        quick_summary: {
            on_hold: 0,
            processing: 0,
            low_in_stock: 0,
            out_of_stock: 0,
            gone_from_aliExpress: 0
        },
        date_from : moment(this.date_to).add(-30, 'day').format('YYYY/MM/DD'),
        date_from_reference: moment(this.date_to).add(-7, 'day').format('YYYY/MM/DD'),
        date_to   : moment().format('YYYY/MM/DD'),
        chart_loading: true,
        options_order: [],
        options_revenue: [],
        options_cost: [],
        new_chart_order: null,
        new_chart_revenue: null,
        new_chart_cost: null,
        chart_modal_loading: true,
        watch_chart_order: false,
        watch_chart_revenvue: false,
        watch_chart_cost: false,
    },
    created: function () {
        let _this = this

        //reindex es
        let arr_domain =  window.shopDomain.split('.');
        axios.get(aliorders_es+'/add/order/'+ arr_domain[0])

        //Get total summary
        axios.get(aliorders_es+'/api/order/summary_the_month/'+window.shopId)
            .then(function (response) {
                let { status = true,
                    this_total_order = 0, this_total_revenue = 0, this_total_cost = 0,
                    last_total_order = 0, last_total_revenue = 0, last_total_cost = 0
                } = response.data
                if( ! status)
                    console.log('Cannot load data total summary')

                _this.$nextTick(function () {
                    _this.this_total_summary.total_order = this_total_order
                    _this.this_total_summary.total_revenue = this_total_revenue
                    _this.this_total_summary.total_cost = this_total_cost
                    _this.last_total_summary.total_order = last_total_order
                    _this.last_total_summary.total_revenue = last_total_revenue
                    _this.last_total_summary.total_cost = last_total_cost
                })

            })
            .catch(function (error) {
                console.log(error)
                _this.this_total_summary.total_order = 0
                _this.this_total_summary.total_revenue = 0
                _this.this_total_summary.total_cost = 0
                _this.last_total_summary.total_order = 0
                _this.last_total_summary.total_revenue = 0
                _this.last_total_summary.total_cost = 0
            })

        //Get quick summary
        axios.get(appUrl+'/statistic/quick_summary')
            .then(function (response) {
                let {status = true, to_order = 0, order_place = 0, product_low_stock = 0, product_out_stock = 0, product_gone_from_aliexpress = 0} = response.data
                _this.quick_summary.on_hold = to_order
                _this.quick_summary.processing = order_place
                _this.quick_summary.low_in_stock = product_low_stock
                _this.quick_summary.out_of_stock = product_out_stock
                _this.quick_summary.gone_from_aliExpress = product_gone_from_aliexpress
            })
            .catch(function (error) {
                console.log(error)
            })
    },
    computed: {
        growRevenue: function () {
            const this_revenue = parseFloat(this.this_total_summary.total_revenue.toString().replace(',', ''))
            const last_revenue = parseFloat(this.last_total_summary.total_revenue.toString().replace(',', ''))
            if(last_revenue === 0 && this_revenue === 0)
                return {
                    percent: 0,
                    grow: null
                }
            if(last_revenue === 0 && this_revenue > 0)
                return {
                    percent: 100,
                    grow: true
                }

            return {
                percent: (Math.abs((this_revenue - last_revenue)/last_revenue)*100).toFixed(2),
                grow: this_revenue === last_revenue ? null : (this_revenue > last_revenue)
            }
        },
        growCost: function () {
            const this_cost = parseFloat(this.this_total_summary.total_cost.toString().replace(',', ''))
            const last_cost = parseFloat(this.last_total_summary.total_cost.toString().replace(',', ''))
            if(last_cost === 0 && this_cost === 0)
                return {
                    percent: 0,
                    grow: null
                }
            if(last_cost === 0 && this_cost > 0)
                return {
                    percent: 100,
                    grow: true
                }
            return {
                percent: (Math.abs((this_cost - last_cost)/last_cost)*100).toFixed(2),
                grow: this_cost === last_cost ? null : (this_cost > last_cost)
            }
        }
    },
    mounted: function() {
        let _this = this
        this.getReference()

        axios.post(aliorders_es+'/api/order/aggregations_date_histogram', {shop: window.shopId ,from: this.date_from, to: this.date_to})
            .then(function (response) {
                let { status = true, dateList = [], orders = [], revenue = [], cost = [], earning = [] } = response.data;

                if( ! status)
                    console.log('Cannot load data')
                //Build chart statistic

                let chart_statistic = Object.assign({}, chart_line, {
                    data: {
                        labels: dateList,
                        datasets: [
                            {
                                label: "Total Revenue",
                                borderColor: '#7B1FA2',
                                pointBorderColor: '#A4A1FB',
                                pointBackgroundColor: '#fff',
                                pointBorderWidth: 0,
                                pointRadius: 0,
                                fill: false,
                                backgroundColor: '#7B1FA2',
                                borderWidth: 0,
                                data: revenue,
                            },
                            {
                                label: "Total Costs",
                                borderColor: '#54D8FF',
                                pointBorderColor: '#54D8FF',
                                pointBackgroundColor: '#fff',
                                pointBorderWidth: 0,
                                pointRadius: 0,
                                fill: false,
                                backgroundColor: '#54D8FF',
                                borderWidth: 0,
                                data: cost,
                            }
                            // {
                            //     label: "Total Earning",
                            //     borderColor: '#F63665',
                            //     pointBorderColor: '#F63665',
                            //     pointBackgroundColor: '#fff',
                            //     pointBorderWidth: 0,
                            //     pointRadius: 0,
                            //     fill: false,
                            //     backgroundColor: '#F63665',
                            //     borderWidth: 0,
                            //     data: earning,
                            // }
                        ]
                    }
                })

                _this.$nextTick(function() {
                    let canvas = document.getElementById("canvas-line-chart");
                    let ctx = canvas.getContext("2d");
                    const gradientStroke = ctx.createLinearGradient(500, 0, 100, 0);
                    gradientStroke.addColorStop(0, '#18ce0f');
                    gradientStroke.addColorStop(0, '#18ce0f');
                    gradientStroke.addColorStop(1, '#FFFFFF');

                    const gradientFill = ctx.createLinearGradient(0, 170, 0, 50);
                    gradientFill.addColorStop(0, "rgba(128, 182, 244, 0)");
                    gradientFill.addColorStop(1, hexToRGB('#18ce0f',0.4));
                    _this.chartline = new Chart(ctx, chart_statistic);
                    document.getElementById('legend-line-chart').innerHTML = _this.chartline.generateLegend();
                })

                _this.chart_loading = false;
            })
            .catch(function (error) {
                console.log(error)
            })

    },
    components: {
        modal_chart_cost,
        modal_chart_order,
        modal_chart_revenue,
        statistic_chart,
        modal_reference,
        vue_loaders_circle
    },
    methods: {
        barChartTotalOrders: function() {
            let _this = this;
            $('#modal-chart-order').modal('show');
            $('#modal-chart-order').on('shown.bs.modal', function() {
                _this.watch_chart_order = true;
                if( _this.new_chart_order == null && _this.chart_modal_loading == false ) {
                    const chart_order = document.getElementById('canvas-chart-order').getContext('2d');
                    _this.new_chart_order = new Chart(chart_order, _this.options_order);
                    document.getElementById('legend-line-chart-order').innerHTML = _this.new_chart_order.generateLegend();
                }
            });
        },
        barChartTotalRevenue: function() {
            let _this = this;
            $('#modal-chart-revenue').modal('show');
            $('#modal-chart-revenue').on('shown.bs.modal', function() {
                _this.watch_chart_revenvue = true;
                if( _this.new_chart_revenue == null && _this.chart_modal_loading == false) {
                    const chart_revenue = document.getElementById('canvas-chart-revenue').getContext('2d');
                    _this.new_chart_revenue = new Chart(chart_revenue, _this.options_revenue);
                    document.getElementById('legend-line-chart-revenue').innerHTML = _this.new_chart_revenue.generateLegend();
                }
            });
        },
        barChartTotalCost: function() {
            let _this = this;
            $('#modal-chart-cost').modal('show');
            $('#modal-chart-cost').on('shown.bs.modal', function() {
                _this.watch_chart_cost = true;
                if( _this.new_chart_cost  == null && _this.chart_modal_loading == false) {
                    const chart_cost = document.getElementById('canvas-chart-cost').getContext('2d');
                    _this.new_chart_cost = new Chart(chart_cost, _this.options_cost);
                    document.getElementById('legend-line-chart-cost').innerHTML = _this.new_chart_cost.generateLegend();
                }
            });
        },
        showMoreReference: function() {
            $('#modal-show-more-reference').modal('show');
        },
        showSaleReport: function() {
            $('#modal-show-more-sale-report').modal('show');
        },
        chartStatistic: function(value) {
            this.chartline.data.labels = value.data.labels;
            this.chartline.data.dateListNew = value.data.labels;
            let keys = this.chartline.data.datasets.keys();
            for( let key of keys) {
                this.chartline.data.datasets[key].data = value.data.datasets[key].data;
            }
            var number=this.chartline.data.labels.length;
            var lengthDataset=this.chartline.data.datasets.length
            this.chartline.update();
        },
        getReference: function () {
            let _this = this

            axios.post(aliorders_es+'/api/order/reference_history', {shop: window.shopId ,from: this.date_from_reference, to: this.date_to})
                    .then(function (response) {
                        let {status = true, dateList = [], orders = [], revenue = [], cost = [], earning = []} = response.data;

                        if ( ! status)
                            console.log('Cannot load data')

                        dateList = dateList.reverse()
                        orders = orders.reverse()
                        revenue = revenue.reverse()
                        cost = cost.reverse()
                        earning = earning.reverse()

                        dateList.forEach(function(date, key) {
                            _this.historys.push({
                                time: date,
                                order: orders[key],
                                sale: revenue[key],
                                cost: cost[key],
                                earning: earning[key],
                            })
                        })
                    })
                    .catch(function(error) {

                    })
        }
    },
    watch: {
        chart_modal_loading: function(val) {
            let _this = this;
            if(_this.watch_chart_order) {
                const chart_order = document.getElementById('canvas-chart-order').getContext('2d');
                _this.new_chart_order = new Chart(chart_order, _this.options_order);
                document.getElementById('legend-line-chart-order').innerHTML = _this.new_chart_order.generateLegend();
            }

            if(_this.watch_chart_revenvue) {
                const chart_revenue = document.getElementById('canvas-chart-revenue').getContext('2d');
                _this.new_chart_revenue = new Chart(chart_revenue, _this.options_revenue);
                document.getElementById('legend-line-chart-revenue').innerHTML = _this.new_chart_revenue.generateLegend();
            }
            if(_this.watch_chart_cost) {
                const chart_cost = document.getElementById('canvas-chart-cost').getContext('2d');
                _this.new_chart_cost = new Chart(chart_cost, _this.options_cost);
                document.getElementById('legend-line-chart-cost').innerHTML = _this.new_chart_cost.generateLegend();
            }
        }
    }
});

window.hexToRGB = function(a , c) {
    var d = parseInt(a.slice(1,3),16);
    var e=parseInt(a.slice(3,5),16);
    var f=parseInt(a.slice(5,7),16);
    return c ? 'rgba('+d+', '+e+', '+f+', '+c+')' : 'rgb('+d+', '+e+', '+f+')';
}
