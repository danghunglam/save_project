import price_rule from '../components/setting/price_rule.vue'
window.vueSetting = new Vue({
    el: "#settings-form",
    data: {
        settings: [],
        settings_errors: {
            price_rule: [],
            rest_of_the_price_ranges: [],
            message_validate_price_rule: [],
            default_fulfillment_tracking_url: '',
            default_phone_number_aliexpress_checkout:'',
            default_phone_code: '',
            note_supplier_aliexpress_checkout: '',
            shipping_max_price_alert: '',
            primary_email_address: ''
        },
        settings_group_field: {
            general: [
                'notification_email_customer_fulfillment',
                'default_fulfillment_tracking_url',
                'auto_update_when_product_no_longer_available_aliexpress',
                'auto_update_when_product_no_longer_available_aliexpress_notify',
                'auto_update_when_product_variant_no_longer_available_aliexpress',
                'auto_update_when_product_variant_no_longer_available_aliexpress_notify',
                'auto_update_when_product_cost_change_aliexpress',
                'auto_update_when_product_cost_change_aliexpress_notify',
                'when_one_product_is_out_of_stock_on_aliexpress',
                'when_one_product_is_out_of_stock_on_aliexpress_notify',
                'time_zone',
                'primary_email_address'
            ],
            pricing_rule: [
                'is_compared_price',
                'rest_of_the_price_ranges',
                'price_rule'
            ],
            supplier: [
                'default_shipping_method',
                'default_phone_number_aliexpress_checkout',
                'note_supplier_aliexpress_checkout',
                'shipping_max_price_alert',
                'is_shipping_max_price_alert',
                'default_phone_code'

            ],
            api: [

            ]
        },
        is_save: false,
        settings_old: [],
        current_tab: 'general'
    },
    mounted: function () {
        let _this = this;
        $('#setting_timezone').select2().on('select2:select', function (e) {
            _this.settings.time_zone = $(e.currentTarget).val()
        });

        $('#default_shipping_method').multiselect({
            enableFiltering: false,
            nonSelectedText: 'None',
            buttonContainer: '<div class="selected-parents-container select-no-checked"></div>',
        }).change(function(event) {
            _this.settings.default_shipping_method = $(event.currentTarget).val();
        });

    },
    created: function () {
        let _this = this
        axios.get(appUrl+'/setting/all')
            .then(function (response) {
                let { status, settings } = response.data
                _this.$nextTick(function () {
                    _this.settings = settings
                    _this.filterSettings()
                    _this.settings_old = settings
                    $('#setting_timezone').select2({
                        theme: 'bootstrap',
                        width: '100%',
                    }).val(_this.settings.time_zone)
                        .trigger('change')

                    $('#default_shipping_method').multiselect('select', _this.settings.default_shipping_method);
                })
            })
            .catch(function (error) {
                notify('error', error)
            })
    },
    components: {
        price_rule
    },
    methods: {
        filterSettings: function () {
            this.settings.price_rule =  this.settings.price_rule.map(function (price) {
                return {
                    min : price.min,
                    max : price.max,
                    item_price : price.item_price,
                    compared_price : price.compared_price,
                    item_price_type: price.item_price_type ? price.item_price_type : 'multiply',
                    compared_price_type: price.compared_price_type ? price.compared_price_type : 'multiply'
                }
            })
            this.settings.rest_of_the_price_ranges = {
                min : this.settings.rest_of_the_price_ranges.min,
                max : this.settings.rest_of_the_price_ranges.max,
                item_price : this.settings.rest_of_the_price_ranges.item_price,
                compared_price : this.settings.rest_of_the_price_ranges.compared_price,
                item_price_type : (this.settings.rest_of_the_price_ranges.item_price_type) ? this.settings.rest_of_the_price_ranges.item_price_type : 'multiply',
                compared_price_type : (this.settings.rest_of_the_price_ranges.compared_price_type) ? this.settings.rest_of_the_price_ranges.compared_price_type : 'multiply',
            }
        },
        validSetting: function (settings) {
            let _this = this
            _this.settings_errors = {
                price_rule: [],
                rest_of_the_price_ranges: [],
                message_validate_price_rule: _this.settings_errors.message_validate_price_rule,
                default_fulfillment_tracking_url: '',
                default_phone_number_aliexpress_checkout: '',
                default_phone_code: '',
                note_supplier_aliexpress_checkout: '',
                shipping_max_price_alert: '',
                primary_email_address: ''
            }
            let default_fulfillment_tracking_url = settings['default_fulfillment_tracking_url']
            let rest_of_the_price_ranges = settings['rest_of_the_price_ranges']
            let price_rule = settings['price_rule']
            let default_phone_number_aliexpress_checkout = settings['default_phone_number_aliexpress_checkout']
            let note_supplier_aliexpress_checkout = settings['note_supplier_aliexpress_checkout']
            let shipping_max_price_alert = settings['shipping_max_price_alert']
            let is_shipping_max_price_alert = settings['is_shipping_max_price_alert']
            let primary_email_address = settings['primary_email_address']
            let default_phone_code = settings['default_phone_code']

            if(primary_email_address) {
                const regex_email = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                if( ! regex_email.test(String(primary_email_address).toLowerCase()))
                    _this.settings_errors.primary_email_address = 'Valid'
            }

            if(default_fulfillment_tracking_url)
            {
                const regex_tracking = new RegExp('^((https|http):\\/\\/)?(www.)?[a-z0-9-_]+\\.[a-z]+(\\/[a-zA-Z0-9#-_]+\\/?)*$')
                if( ! regex_tracking.test(default_fulfillment_tracking_url))
                    _this.settings_errors.default_fulfillment_tracking_url = 'Valid'
            }

            if(default_phone_number_aliexpress_checkout || default_phone_code)
            {
                const regex_phone_code = new RegExp('^\\+\[0-9]{1,7}$')
                if( ! regex_phone_code.test(default_phone_code))
                    _this.settings_errors.default_phone_code = 'Valid'
            }

            if(default_phone_number_aliexpress_checkout || default_phone_code)
            {
                const regex_phone_number = new RegExp('^([0-9]|\-|\/){5,16}$')
                if( ! regex_phone_number.test(default_phone_number_aliexpress_checkout))
                    _this.settings_errors.default_phone_number_aliexpress_checkout = 'Valid'
            }

            if(rest_of_the_price_ranges) {
                //Valid rest of the price ranges
                if(rest_of_the_price_ranges.item_price && rest_of_the_price_ranges.item_price <= 0)
                    _this.settings_errors['rest_of_the_price_ranges']['item_price'] = 'Valid'

                if(rest_of_the_price_ranges.compared_price && rest_of_the_price_ranges.compared_price <= 0 && _this.settings.is_compared_price)
                    _this.settings_errors['rest_of_the_price_ranges']['compared_price'] = 'Valid'
            }

            if(price_rule) {
                //Valid price rules
                price_rule.map(function (price, k) {
                    let tmp_obj = {}
                    if(price['item_price'] <= 0)
                        tmp_obj['item_price'] = 'Valid'

                    if(price['compared_price'] <= 0 && _this.settings.is_compared_price)
                        tmp_obj['compared_price'] = 'Valid'

                    if(price['min'] < 0)
                        tmp_obj['min'] = 'Valid'

                    if(price['max'] <= 0)
                        tmp_obj['max'] = 'Valid'

                    if(Object.keys(tmp_obj).length > 0)
                        _this.settings_errors['price_rule'][k] = tmp_obj
                })
            }

            if(note_supplier_aliexpress_checkout && note_supplier_aliexpress_checkout.length > 1000)
                _this.settings_errors.note_supplier_aliexpress_checkout = 'Max. 1,000 English characters or Arabic numerals only'

            if(is_shipping_max_price_alert && ! validNumber(shipping_max_price_alert))
                _this.settings_errors.shipping_max_price_alert = 'Only input number'

            let isValidPriceRule = Object.values(_this.settings_errors['price_rule']).length
            let isValidRestPriceRule = Object.values(_this.settings_errors['rest_of_the_price_ranges']).length

            return ! (isValidPriceRule > 0 ||
                isValidRestPriceRule > 0 ||
                _this.settings_errors.message_validate_price_rule.length > 0 ||
                _this.settings_errors.default_fulfillment_tracking_url !== '' ||
                _this.settings_errors.default_phone_number_aliexpress_checkout !== '' ||
                _this.settings_errors.note_supplier_aliexpress_checkout !== '' ||
                _this.settings_errors.shipping_max_price_alert !== '' ||
                _this.settings_errors.primary_email_address !== '' ||
                _this.settings_errors.default_phone_code !== ''
            )
        },
        priceRuleChange: function (price_rule) {
            this.$nextTick(function () {
                this.settings = Object.assign({},this.settings, {price_rule: price_rule})
            })
        },
        restPriceRuleChange: function (rest_price_rule) {
            this.$nextTick(function () {
                this.settings = Object.assign({}, this.settings, {rest_of_the_price_ranges: rest_price_rule})
            })
        },
        validPriceRule: function (valid_message) {
            this.message_validate_price_rule = valid_message
            this.settings_errors.message_validate_price_rule = valid_message
        },
        checkIsComparedPrice: function (is_compared_price) {
            this.settings = Object.assign({}, this.settings, {is_compared_price: is_compared_price})
        },
        saveSettings: function () {
            //validate price rule
            let _this = this
            this.is_save = true

            if( ! this.validSetting(_this.settings))
            {
                this.is_save = false
                notify('warning', 'Please check valid form')
                return false
            }
            settings = _.pickBy(_this.settings, function (value, key) {
                return _this.settings_group_field[_this.current_tab].indexOf(key) > -1
            });
            axios.post(appUrl+'/setting/handle', settings)
                .then(function (response) {
                    _this.is_save = false
                    let { status, message } = response.data
                    if(status)
                        notify('success', message)
                    else
                        notify('error', message)
                })
                .catch(function (error) {
                    _this.is_save = false
                    notify('error', error)
                })
        },
        restoreSettings: function () {
            this.settings = Object.assign({}, this.settings, this.settings_old)
        },
        changeSettingTab: function(tab_name) {
            this.current_tab = tab_name
        },
        changeSettingRoute: function(route_link) {
            window.location = route_link;
        },
        showNotify: function(notifySetting) {
            notify(notifySetting.type, notifySetting.content)
        },
        autoUpdatePrice: function () {
            let port = chrome.runtime.connect(chromeExtensionId);
            //Send public token

            //Send auto update price
            const payloadMessageAutoUpdate = {
                data: {
                    action: 'AUTO_UPDATE_PRICE',
                    payload: {
                        shopId: '16331587',
                    }
                }
            }
            port.postMessage(payloadMessageAutoUpdate);
            port.disconnect()

        }
    }
});
