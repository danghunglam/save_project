window.checkLoginOberlo = 'please_login_oberlo'
window.retryLoginOberlo = 0

import vue_loaders_circle from '../components/common/vue_loaders_circle';
new Vue({
    el: '#installing-page',
    data: {
      shop_id : 'null',
      step_loading: true
    },
    mounted: function () {
        let _this = this
        let checkInstallExtension = window.localStorage.getItem('CHECK_INSTALL_EXTENSION')
        let port
        let payloadMessage

        if( localStorage.getItem('CHECK_INSTALL_EXTENSION') && checkInstallExtension == window.shopDomain ) {
            localStorage.removeItem('CHECK_INSTALL_EXTENSION')

            port = chrome.runtime.connect(chromeExtensionId)
            payloadMessage = {
                data: {
                    action: 'CHECK_LOGIN_OBERLO',
                    payload: {
                        public_token: publicToken,
                        shop_domain: window.shopDomain
                    }
                }
            }
            port.postMessage(payloadMessage);
            port.disconnect()

            if( checkLoginOberlo && (checkLoginOberlo == 'please_login_oberlo') ) {
                $('.installing-step').removeClass('active');
                $('.installing-step-6').addClass('active');
                setTimeout(function() {
                    _this.step_loading = false
                }, 5000)
            } else {
                $('.installing-step').removeClass('active');
                $('.installing-step-4').addClass('active');
            }
            
        } else {
            $('.installing-step-1').addClass('active');
            setTimeout(function () {
                $('.installing-step').removeClass('active');
                $('.installing-step-2').addClass('active');
            }, 10000);
        }
        
        $('#ao__transfer_later').on('click', function() {
            if( ! checkExtension() ) {
                $('.installing-step').removeClass('active');
                $('.installing-step-3').addClass('active');
            } else {
                $('.installing-step').removeClass('active');
                $('.installing-step-4').addClass('active');
            }
        })

        $('#ao__transfer_now').on('click', function() {
            if( ! checkExtension() ) {
                $('.installing-step').removeClass('active');
                $('.installing-step-5').addClass('active');
            } else {

                port = chrome.runtime.connect(chromeExtensionId)
                payloadMessage = {
                    data: {
                        action: 'CHECK_LOGIN_OBERLO',
                        payload: {
                            public_token: publicToken,
                            shop_domain: window.shopDomain
                        }
                    }
                }
                port.postMessage(payloadMessage);
                port.disconnect()
                
                if( window.checkLoginOberlo == 'please_login_oberlo' ) {
                    $('.installing-step').removeClass('active');
                    $('.installing-step-6').addClass('active');
                    setTimeout(function() {
                        _this.step_loading = false
                    }, 5000)
                } else {
                    $('.installing-step').removeClass('active');
                    $('.installing-step-4').addClass('active');
                }
            }
        })

        $('#progress-loading-btn-3').on('click', function() {
            $('.installing-step').removeClass('active');
            $('.installing-step-4').addClass('active');
        });

        $('#progress-loading-btn-3-1').on('click', function() {
            $('.installing-step').removeClass('active');
            $('.installing-step-4').addClass('active');
        });

        

        $('#progress-loading-btn-6').on('click', function() {
            $('.installing-step').removeClass('active');
            $('.installing-step-4').addClass('active');
        })

        $('#progress-loading-btn-5').on('click', function() {
            $('.installing-step').removeClass('active');
            $('.installing-step-4').addClass('active');
        })
        $('#progress-loading-btn-5-1').on('click', function() {
            $('.installing-step').removeClass('active');
            $('.installing-step-51').addClass('active');
        })

        $('#progress-loading-btn-51').on('click', function() {
            $('.installing-step').removeClass('active');
            $('.installing-step-4').addClass('active');
        })
        $('#progress-loading-btn-51-1').on('click', function() {
            localStorage.setItem("CHECK_INSTALL_EXTENSION", window.shopDomain);
            location.reload()
        })  

        $('#progress-loading-btn-6-1').on('click', function() {

            port = chrome.runtime.connect(chromeExtensionId)
            payloadMessage = {
                data: {
                    action: 'CHECK_LOGIN_OBERLO',
                    payload: {
                        public_token: publicToken,
                        shop_domain: window.shopDomain
                    }
                }
            }
            port.postMessage(payloadMessage);
            port.disconnect()

        })
        
    },
    components: {
        vue_loaders_circle
    },
});

window.notifyCheckLoginOberlo = function({ type, key, message }) {
    console.log('type', type)
    if(type == 'warning' && (key == 'please_login_oberlo' || key == 'aliorders_shop_different_oberlo' )) {
        checkLoginOberlo = 'please_login_oberlo'
    } 

    if( type == 'success' && key == 'login_oberlo_success') {
        checkLoginOberlo = 'login_oberlo_success'
        $('.installing-step').removeClass('active');
        $('.installing-step-4').addClass('active');
    }
}

window.checkExtension = function() {
    if ( ! is_chrome){
        if($('#modal-chrome-extension').length > 0)
            $('#modal-chrome-extension').modal('show')
        return false;
    } else{
        const { extensionAliOdersId = false } = window;
        if ( ! extensionAliOdersId || (extensionAliOdersId && (extensionAliOdersId != chromeExtensionId))) {
            if($('#modal-chrome-extension').length > 0)
                $('#modal-chrome-extension').modal('show')
            // if($('.inline-install-chrome-extension').length > 0)
            //     $('.inline-install-chrome-extension').show();
            // show pop up extension
            return false;
        }
    }

    return true
}

window.installChrome = function() {
    window.open('https://chrome.google.com/webstore/detail/'+chromeExtensionId, '_blank');
}