import modal_chart_cost from '../components/statistic/modal_chart_total_cost.vue'
import modal_chart_order from '../components/statistic/modal_chart_total_order'
import modal_chart_revenue from '../components/statistic/modal_chart_total_revenue'
import statistic_chart from '../components/statistic/statistic_chart'
import modal_sale_report from '../components/statistic/modal_sale_report'
import modal_reference from '../components/statistic/modal_reference'
import { chart_line_modal, chart_line } from "../option_chart";

//Load the 'corecharts'. You do not need to provide that as a type.

var vm = new Vue({
    el: '#page-statistic',
    data: {
        total_summary: {
            total_order: 0,
            total_revenue: 0,
            total_cost: 0
        },
        historys: [],
        chart: {
            dateList: [],
            order: [],
            revenue: [],
            cost: []
        },
        quick_summary: {
            on_hold: 0,
            processing: 0,
            low_in_stock: 0,
            out_of_stock: 0
        },
        date_from : moment(this.date_to).add(-1, 'month').format('YYYY/MM/D'),
        date_to   : moment().format('YYYY/MM/D'),
        chart_loading: true,
        options_order: [],
        options_revenue: [],
        options_cost: [],
        new_chart_order: null,
        new_chart_revenue: null,
        new_chart_cost: null,
        chart_modal_loading: true,
        watch_chart_order: false,
        watch_chart_revenvue: false,
        watch_chart_cost: false,
    },
    created: function () {
        let _this = this
        //Get total summary
        axios.get(appUrl+'/statistic/total_summary')
            .then(function (response) {
                let { status = true, totalOrder = 0, totalRevenue = 0, totalCost = 0 } = response.data
                if( ! status)
                    console.log('Cannot load data total summary')

                _this.$nextTick(function () {
                    _this.total_summary.total_order = totalOrder
                    _this.total_summary.total_revenue = totalRevenue
                    _this.total_summary.total_cost = totalCost
                })

            })
            .catch(function (error) {
                console.log(error)
            })

        //Get stock
        axios.get(appUrl+'/statistic/quick_summary')
            .then(function (response) {
                let {status = true, to_order = 0, order_place = 0, product_low_stock = 0, product_out_stock = 0} = response.data
                _this.quick_summary.on_hold = to_order
                _this.quick_summary.processing = order_place
                _this.quick_summary.low_in_stock = product_low_stock
                _this.quick_summary.out_of_stock = product_out_stock
            })
            .catch(function (error) {
                console.log(error)
            })
    },
    mounted: function() {
        let _this = this
        //Summary history
        axios.get(appUrl+'/statistic/list_total_summary_last_30_day')
            .then(function (response) {
                let { status = true, dateList = [], orders = [], revenue = [], cost = [], fee = [] } = response.data
                if( ! status)
                    console.log('Cannot load chart data');

                _this.options_cost = Object.assign({}, chart_line_modal, {
                    data: {
                        labels: dateList,
                        datasets:[
                            {
                                data: cost,
                                label: 'Product Cost',
                                backgroundColor: "transparent",
                                borderColor: "#3d88ff",
                                pointRadius: 0,
                                pointHoverRadius: 4,
                                pointHitRadius: 4,
                                pointBorderWidth: 2,
                                pointStyle: "circle",
                                pointBorderColor: "#3d88ff",
                                pointBackgroundColor: "#3d88ff",
                                fill: true,
                                lineWidth: 4
                            },
                            {
                                data: fee,
                                label: 'Shipping Cost',
                                backgroundColor: "transparent",
                                borderColor: "#ff0000",
                                pointRadius: 0,
                                pointHoverRadius: 4,
                                pointHitRadius: 4,
                                pointBorderWidth: 2,
                                pointStyle: "circle",
                                pointBorderColor: "#ff0000",
                                pointBackgroundColor: "#ff0000",
                                fill: true,
                                lineWidth: 4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        defaultFontFamily: "'Roboto', sans-serif",
                        title:{
                            display: true,
                        },
                        legend: {
                            display: false,
                        },
                        tooltips: {
                            enabled: false,
                            mode: 'index',
                            intersect: false,
                            position: 'nearest',
                            backgroundColor: "#FFF",
                            borderColor: "#242539",
                            borderWidth: 1,
                            bodyFontSize: 14,
                            bodyFontColor: "#333c48",
                            titleFontSize: 14,
                            titleFontColor: "#333c48",
                            bodySpacing: 2,
                            titleMarginBottom: 10,
                            xPadding: 20,
                            yPadding: 12,
                            caretSize: 2,
                            yAlign: 'right',
                            callbacks: {
                                label: function(tooltipItem, data) {
                                    var label = data.datasets[tooltipItem.datasetIndex].label || '';

                                    if (label) {
                                        label += ': ';
                                    }
                                    label += '$' + tooltipItem.yLabel;
                                    return label;
                                }
                            },
                            custom: function(tooltipModel) {
                                // Tooltip Element
                                var tooltipEl = document.getElementById('chartjs-tooltip-cost');

                                // Create element on first render
                                if (!tooltipEl) {
                                    tooltipEl = document.createElement('div');
                                    tooltipEl.id = 'chartjs-tooltip-cost';
                                    tooltipEl.innerHTML = "<table></table>"
                                    document.body.appendChild(tooltipEl);
                                }

                                // Hide if no tooltip
                                if (tooltipModel.opacity === 0) {
                                    tooltipEl.style.opacity = 0;
                                    return;
                                }

                                // Set caret Position
                                tooltipEl.classList.remove('above', 'below', 'no-transform');
                                if (tooltipModel.yAlign) {
                                    tooltipEl.classList.add(tooltipModel.yAlign);
                                } else {
                                    tooltipEl.classList.add('no-transform');
                                }

                                function getBody(bodyItem) {
                                    return bodyItem.lines;
                                }

                                // Set Text
                                if (tooltipModel.body) {
                                    var titleLines = tooltipModel.title || [];
                                    var bodyLines = tooltipModel.body.map(getBody);

                                    var innerHtml = '<thead>';

                                    titleLines.forEach(function(title) {
                                        innerHtml += '<tr><th>' + title + '</th></tr>';
                                    });
                                    innerHtml += '</thead><tbody>';

                                    bodyLines.forEach(function(body, i) {
                                        var colors = tooltipModel.labelColors[i];
                                        var style = 'background:' + colors.backgroundColor;
                                        style += '; border-color:' + colors.borderColor;
                                        style += '; border-width: 2px';
                                        var span = '<span class="chartjs-tooltip-key" style="' + style + '"></span>';
                                        innerHtml += '<tr><td>' + span + body + '</td></tr>';
                                    });
                                    innerHtml += '</tbody>';

                                    var tableRoot = tooltipEl.querySelector('table');
                                    tableRoot.innerHTML = innerHtml;
                                }

                                // `this` will be the overall tooltip
                                var position = this._chart.canvas.getBoundingClientRect();
                                // Display, position, and set styles for font
                                tooltipEl.style.position = 'absolute';
                                tooltipEl.style.opacity = 1;
                                tooltipEl.style.left = tooltipModel.caretX + 15 +'px';
                                tooltipEl.style.top = tooltipModel.caretY - 20 + 'px';
                                // tooltipEl.style.fontFamily = tooltipModel._fontFamily;
                                tooltipEl.style.fontSize = tooltipModel.fontSize;
                                tooltipEl.style.fontStyle = tooltipModel._fontStyle;
                                tooltipEl.style.padding = '10px 15px';
                            }
                        },
                        hover: {
                            mode: 'index',
                            intersect: true
                        },
                        scales: {
                            xAxes: [{
                                gridLines: {
                                    display: false,
                                }
                            }],
                            yAxes: [{
                                gridLines: {
                                    borderDash: [5, 10],
                                },
                                ticks: {
                                    min: 0, // it is for ignoring negative step.
                                    beginAtZero: true,
                                }
                            }]
                        }
                    }
                });

                _this.options_revenue = Object.assign({}, chart_line_modal, {
                    data: {
                        labels: dateList,
                        datasets:[
                            {
                                data: revenue,
                                label: 'Revenue',
                                backgroundColor: "transparent",
                                borderColor: "#5e30eb",
                                pointRadius: 0,
                                pointHoverRadius: 4,
                                pointHitRadius: 4,
                                pointBorderWidth: 2,
                                pointStyle: "circle",
                                pointBorderColor: "#5e30eb",
                                pointBackgroundColor: "#5e30eb",
                                fill: true,
                                lineWidth: 4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        defaultFontFamily: "'Roboto', sans-serif",
                        title:{
                            display: true,
                        },
                        legend: {
                            display: false,
                        },
                        tooltips: {
                            enabled: false,
                            mode: 'index',
                            intersect: false,
                            position: 'nearest',
                            backgroundColor: "#FFF",
                            borderColor: "#242539",
                            borderWidth: 1,
                            bodyFontSize: 14,
                            bodyFontColor: "#333c48",
                            titleFontSize: 14,
                            titleFontColor: "#333c48",
                            bodySpacing: 2,
                            titleMarginBottom: 10,
                            xPadding: 20,
                            yPadding: 12,
                            caretSize: 2,
                            yAlign: 'right',
                            callbacks: {
                                label: function(tooltipItem, data) {
                                    var label = data.datasets[tooltipItem.datasetIndex].label || '';

                                    if (label) {
                                        label += ': ';
                                    }
                                    label += '$' + tooltipItem.yLabel
                                    return label;
                                }
                            },
                            custom: function(tooltipModel) {
                                // Tooltip Element
                                var tooltipEl = document.getElementById('chartjs-tooltip-revenue');

                                // Create element on first render
                                if (!tooltipEl) {
                                    tooltipEl = document.createElement('div');
                                    tooltipEl.id = 'chartjs-tooltip-revenue';
                                    tooltipEl.innerHTML = "<table></table>"
                                    document.body.appendChild(tooltipEl);
                                }

                                // Hide if no tooltip
                                if (tooltipModel.opacity === 0) {
                                    tooltipEl.style.opacity = 0;
                                    return;
                                }

                                // Set caret Position
                                tooltipEl.classList.remove('above', 'below', 'no-transform');
                                if (tooltipModel.yAlign) {
                                    tooltipEl.classList.add(tooltipModel.yAlign);
                                } else {
                                    tooltipEl.classList.add('no-transform');
                                }

                                function getBody(bodyItem) {
                                    return bodyItem.lines;
                                }

                                // Set Text
                                if (tooltipModel.body) {
                                    var titleLines = tooltipModel.title || [];
                                    var bodyLines = tooltipModel.body.map(getBody);

                                    var innerHtml = '<thead>';

                                    titleLines.forEach(function(title) {
                                        innerHtml += '<tr><th>' + title + '</th></tr>';
                                    });
                                    innerHtml += '</thead><tbody>';

                                    bodyLines.forEach(function(body, i) {
                                        var colors = tooltipModel.labelColors[i];
                                        var style = 'background:' + colors.backgroundColor;
                                        style += '; border-color:' + colors.borderColor;
                                        style += '; border-width: 2px';
                                        var span = '<span class="chartjs-tooltip-key" style="' + style + '"></span>';
                                        innerHtml += '<tr><td>' + span + body + '</td></tr>';
                                    });
                                    innerHtml += '</tbody>';

                                    var tableRoot = tooltipEl.querySelector('table');
                                    tableRoot.innerHTML = innerHtml;
                                }

                                // `this` will be the overall tooltip
                                var position = this._chart.canvas.getBoundingClientRect();
                                // Display, position, and set styles for font
                                tooltipEl.style.position = 'absolute';
                                tooltipEl.style.opacity = 1;
                                tooltipEl.style.left = tooltipModel.caretX + 15 +'px';
                                tooltipEl.style.top = tooltipModel.caretY - 20 + 'px';
                                // tooltipEl.style.fontFamily = tooltipModel._fontFamily;
                                tooltipEl.style.fontSize = tooltipModel.fontSize;
                                tooltipEl.style.fontStyle = tooltipModel._fontStyle;
                                tooltipEl.style.padding = '10px 15px';
                            }
                        },
                        hover: {
                            mode: 'index',
                            intersect: true
                        },
                        scales: {
                            xAxes: [{
                                gridLines: {
                                    display: false,
                                }
                            }],
                            yAxes: [{
                                gridLines: {
                                    borderDash: [5, 10],
                                },
                                ticks: {
                                    min: 0, // it is for ignoring negative step.
                                    beginAtZero: true,
                                }
                            }]
                        }
                    }
                });

                _this.options_order = Object.assign({}, chart_line_modal, {
                    data: {
                        labels: dateList,
                        datasets:[
                            {
                                data: orders,
                                label: 'Orders',
                                backgroundColor: "transparent",
                                borderColor: "#4c56f3",
                                pointRadius: 0,
                                pointHoverRadius: 4,
                                pointHitRadius: 4,
                                pointBorderWidth: 2,
                                pointStyle: "circle",
                                pointBorderColor: "#4c56f3",
                                pointBackgroundColor: "#4c56f3",
                                fill: true,
                                lineWidth: 4
                            }
                        ]
                    },
                    options: {
                        responsive: false,
                        defaultFontFamily: "'Roboto', sans-serif",
                        title:{
                            display: true,
                        },
                        legend: {
                            display: false,
                        },
                        tooltips: {
                            enabled: false,
                            mode: 'index',
                            intersect: false,
                            position: 'nearest',
                            backgroundColor: "#FFF",
                            borderColor: "#242539",
                            borderWidth: 1,
                            bodyFontSize: 14,
                            bodyFontColor: "#333c48",
                            titleFontSize: 14,
                            titleFontColor: "#333c48",
                            bodySpacing: 2,
                            titleMarginBottom: 10,
                            xPadding: 20,
                            yPadding: 12,
                            caretSize: 2,
                            yAlign: 'right',
                            callbacks: {
                                // _eventPosition
                            },
                            custom: function(tooltipModel) {
                                // Tooltip Element
                                var tooltipEl = document.getElementById('chartjs-tooltip-order');

                                // Create element on first render
                                if (!tooltipEl) {
                                    tooltipEl = document.createElement('div');
                                    tooltipEl.id = 'chartjs-tooltip-order';
                                    tooltipEl.innerHTML = "<table></table>"
                                    document.body.appendChild(tooltipEl);
                                }

                                // Hide if no tooltip
                                if (tooltipModel.opacity === 0) {
                                    tooltipEl.style.opacity = 0;
                                    return;
                                }

                                // Set caret Position
                                tooltipEl.classList.remove('above', 'below', 'no-transform');
                                if (tooltipModel.yAlign) {
                                    tooltipEl.classList.add(tooltipModel.yAlign);
                                } else {
                                    tooltipEl.classList.add('no-transform');
                                }

                                function getBody(bodyItem) {
                                    return bodyItem.lines;
                                }

                                // Set Text
                                if (tooltipModel.body) {
                                    var titleLines = tooltipModel.title || [];
                                    var bodyLines = tooltipModel.body.map(getBody);

                                    var innerHtml = '<thead>';

                                    titleLines.forEach(function(title) {
                                        innerHtml += '<tr><th>' + title + '</th></tr>';
                                    });
                                    innerHtml += '</thead><tbody>';

                                    bodyLines.forEach(function(body, i) {
                                        var colors = tooltipModel.labelColors[i];
                                        var style = 'background:' + colors.backgroundColor;
                                        style += '; border-color:' + colors.borderColor;
                                        style += '; border-width: 2px';
                                        var span = '<span class="chartjs-tooltip-key" style="' + style + '"></span>';
                                        innerHtml += '<tr><td>' + span + body + '</td></tr>';
                                    });
                                    innerHtml += '</tbody>';

                                    var tableRoot = tooltipEl.querySelector('table');
                                    tableRoot.innerHTML = innerHtml;
                                }

                                // `this` will be the overall tooltip
                                var position = this._chart.canvas.getBoundingClientRect();
                                // Display, position, and set styles for font
                                tooltipEl.style.position = 'absolute';
                                tooltipEl.style.opacity = 1;
                                tooltipEl.style.left = tooltipModel.caretX + 15 +'px';
                                tooltipEl.style.top = tooltipModel.caretY - 20 + 'px';
                                // tooltipEl.style.fontFamily = tooltipModel._fontFamily;
                                tooltipEl.style.fontSize = tooltipModel.fontSize;
                                tooltipEl.style.fontStyle = tooltipModel._fontStyle;
                                tooltipEl.style.padding = '10px 15px';
                            }
                        },
                        hover: {
                            mode: 'index',
                            intersect: true
                        },
                        scales: {
                            xAxes: [{
                                gridLines: {
                                    display: false,
                                }
                            }],
                            yAxes: [{
                                gridLines: {
                                    borderDash: [5, 10],
                                },
                                ticks: {
                                    min: 0,
                                    beginAtZero: true,
                                    stepSize: 1
                                }
                            }]
                        }
                    }
                })
                orders.forEach(function(element) {
                    if(element > 10) {
                        delete _this.options_order.options.scales.yAxes[0].ticks.stepSize;
                    }
                })
                // _this.$nextTick(function() {

                // })
                _this.chart_modal_loading = false

            })
            .catch(function (error) {
                console.log(error)
            })

        //Chart statistic
        axios.post(appUrl+'/statistic/list_statistic', {from: this.date_from, to: this.date_to})
            .then(function (response) {
                let { status = true, dateList = [], orders = [], revenue = [], cost = [], earning = [] } = response.data;
                if( ! status)
                    console.log('Cannot load data')

                dateList.reverse();
                orders.reverse();
                revenue.reverse();
                cost.reverse();
                earning.reverse();
                //Build chart statistic
                let chart_statistic = Object.assign({}, chart_line, {
                    data: {
                        labels: dateList,
                        datasets: [
                            {
                                label: "Total Revenue",
                                backgroundColor: "transparent",
                                borderColor: "#A3A1FB",
                                pointRadius: 0,
                                pointHoverRadius: 4,
                                pointHitRadius: 4,
                                pointBorderWidth: 2,
                                pointStyle: "circle",
                                pointBorderColor: "#A3A1FB",
                                pointBackgroundColor: "#A3A1FB",
                                data: revenue,
                                fill: true,
                                lineWidth: 4
                            },
                            {
                                label: "Total Costs",
                                backgroundColor: "transparent",
                                borderColor: "#54D8FF",
                                pointRadius: 0,
                                pointHoverRadius: 4,
                                pointHitRadius: 4,
                                pointBorderWidth: 2,
                                pointStyle: "circle",
                                pointBorderColor: "#54D8FF",
                                pointBackgroundColor: "#54D8FF",
                                data: cost,
                                fill: true,
                            },
                            {
                                label: "Total Earning",
                                backgroundColor: "transparent",
                                borderColor: "#F63665",
                                pointRadius: 0,
                                pointHoverRadius: 4,
                                pointHitRadius: 4,
                                pointBorderWidth: 2,
                                pointStyle: "circle",
                                pointBorderColor: "#F63665",
                                pointBackgroundColor: "#F63665",
                                data: earning,
                                fill: true,
                            }
                        ]
                    }
                })
                _this.chart_loading = false;
                _this.$nextTick(function() {
                    let canvas = document.getElementById("canvas-line-chart");
                    let ctx = canvas.getContext("2d");
                    const gradientStroke = ctx.createLinearGradient(500, 0, 100, 0);
                    gradientStroke.addColorStop(0, '#18ce0f');
                    gradientStroke.addColorStop(1, '#FFFFFF');

                    const gradientFill = ctx.createLinearGradient(0, 170, 0, 50);
                    gradientFill.addColorStop(0, "rgba(128, 182, 244, 0)");
                    gradientFill.addColorStop(1, hexToRGB('#18ce0f',0.4));
                    _this.chartline = new Chart(ctx, chart_statistic);
                    document.getElementById('legend-line-chart').innerHTML = _this.chartline.generateLegend();
                })


                for(var i = dateList.length - 1; i > dateList.length - 8; i--){
                    _this.historys.push({
                        time:dateList[i],
                        order: orders[i],
                        sale: revenue[i],
                        cost: cost[i],
                        earning: earning[i]

                    })
                }
            })
            .catch(function (error) {
                console.log(error)
            })

    },
    components: {
        modal_chart_cost,
        modal_chart_order,
        modal_chart_revenue,
        statistic_chart,
        modal_reference,
        modal_sale_report
    },
    methods: {
        barChartTotalOrders: function() {
            let _this = this;
            $('#modal-chart-order').modal('show');
            $('#modal-chart-order').on('shown.bs.modal', function() {
                _this.watch_chart_order = true;
                if( _this.new_chart_order == null && _this.chart_modal_loading == false ) {
                    const chart_order = document.getElementById('canvas-chart-order').getContext('2d');
                    _this.new_chart_order = new Chart(chart_order, _this.options_order);
                    document.getElementById('legend-line-chart-order').innerHTML = _this.new_chart_order.generateLegend();
                }
            });
        },
        barChartTotalRevenue: function() {
            let _this = this;
            $('#modal-chart-revenue').modal('show');
            $('#modal-chart-revenue').on('shown.bs.modal', function() {
                _this.watch_chart_revenvue = true;
                if( _this.new_chart_revenue == null && _this.chart_modal_loading == false) {
                    const chart_revenue = document.getElementById('canvas-chart-revenue').getContext('2d');
                    _this.new_chart_revenue = new Chart(chart_revenue, _this.options_revenue);
                    document.getElementById('legend-line-chart-revenue').innerHTML = _this.new_chart_revenue.generateLegend();
                }
            });
        },
        barChartTotalCost: function() {
            let _this = this;
            $('#modal-chart-cost').modal('show');
            $('#modal-chart-cost').on('shown.bs.modal', function() {
                _this.watch_chart_cost = true;
                if( _this.new_chart_cost  == null && _this.chart_modal_loading == false) {
                    const chart_cost = document.getElementById('canvas-chart-cost').getContext('2d');
                    _this.new_chart_cost = new Chart(chart_cost, _this.options_cost);
                    document.getElementById('legend-line-chart-cost').innerHTML = _this.new_chart_cost.generateLegend();
                }
            });
        },
        showMoreReference: function() {
            $('#modal-show-more-reference').modal('show');
        },
        showSaleReport: function() {
            $('#modal-show-more-sale-report').modal('show');
        },
        chartStatistic: function(value) {
            this.chartline.data.labels = value.data.labels;
            let keys = this.chartline.data.datasets.keys();
            for( let key of keys) {
                this.chartline.data.datasets[key].data = value.data.datasets[key].data;
            }
            this.chartline.update();
        }
    },
    watch: {
        chart_modal_loading: function(val) {
            let _this = this;
            if(_this.watch_chart_order) {
                const chart_order = document.getElementById('canvas-chart-order').getContext('2d');
                _this.new_chart_order = new Chart(chart_order, _this.options_order);
                document.getElementById('legend-line-chart-order').innerHTML = _this.new_chart_order.generateLegend();
            }

            if(_this.watch_chart_revenvue) {
                const chart_revenue = document.getElementById('canvas-chart-revenue').getContext('2d');
                _this.new_chart_revenue = new Chart(chart_revenue, _this.options_revenue);
                document.getElementById('legend-line-chart-revenue').innerHTML = _this.new_chart_revenue.generateLegend();
            }
            if(_this.watch_chart_cost) {
                const chart_cost = document.getElementById('canvas-chart-cost').getContext('2d');
                _this.new_chart_cost = new Chart(chart_cost, _this.options_cost);
                document.getElementById('legend-line-chart-cost').innerHTML = _this.new_chart_cost.generateLegend();
            }
        }
    }
});

window.hexToRGB = function(a , c) {
    var d = parseInt(a.slice(1,3),16);
    var e=parseInt(a.slice(3,5),16);
    var f=parseInt(a.slice(5,7),16);
    return c ? 'rgba('+d+', '+e+', '+f+', '+c+')' : 'rgb('+d+', '+e+', '+f+')';
}
