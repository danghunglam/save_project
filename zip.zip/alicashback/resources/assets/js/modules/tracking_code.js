import pagination from '../components/common/pagination';
import modal_trackingcode from '../components/tracking_code/modal_trackingCode'
import popup_import_tracking_code from '../components/tracking_code/popup_import_tracking_code'
import toast_process from '../components/common/toast_process'
import toast_process_percent from '../components/common/toast_process_percent'
import download from 'downloadjs'
import queryString from "query-string";
import 'vue-loaders/dist/vue-loaders.css';
import { LineScalePulseOutRapidLoader } from 'vue-loaders';
import Pusher from "pusher-js";
import _ from 'lodash'
import { LineScaleLoader } from 'vue-loaders';

new Vue({
    el: '#manage-tracking-code',
    data: {
        filters: {
            keyword: '',
            ali_order_no: '',
            tracking_code: '',
            flag: [],
            sort_by: '',
            date_range : 'last_30days',
            filter_date_from : moment(this.date_to).add(-1, 'month').format('YYYY/MM/D'),
            filter_date_to   : moment().format('YYYY/MM/D'),
            paged: 1,
        },
        orders:{},
        pagination:[],
        loading_page:true,
        shopId : '',
        shopDomain : '',
        accessToken : '',
        lineItems:[],
        is_export: {
            csv: false,
            xls: false
        },
        is_load: false,
        trackingCodeId:'',
        tracking_code_process: [],
        tracking_code_process_type: ['tracking_code_from_file'],
        process_percent: [],
    },
    created: function() {

    },

    mounted: function() {
        let _this = this
        //add paged to filters
        axios.get(appUrl+'/tracking-code/all', { params: this.filters })
            .then(function (response) {
                let {status = false,
                    ordersData = {},
                    pagination = {}
                } = response.data
                _this.orders = ordersData
                _this.pagination = pagination
                _this.loading_page = false
            })
            .catch(function (error) {
                console.log(error)
            });

        if(jQuery('#data_shop_id').length > 0) {
            this.shopId = $('#data_shop_id').val();
        }
        if(jQuery('#data_shop_domain').length > 0) {
            this.shopDomain = $('#data_shop_domain').val();
        }

        if(jQuery('#data_access_token').length > 0)
        {
            this.accessToken = $('#data_access_token').val();
        }

        _this.pusherSubscribe()

        window.setPercentProcess = function(obj) {
            let index = _.findIndex(_this.process_percent, {type: obj.type})
            if(index >= 0)
            {
                console.log(_this.process_percent[index])
                _this.process_percent[index].percent = obj.percent
            } else {
                _this.process_percent.push(obj)
            }

        }

        //init build query string
        if(Object.keys(this.getQueryString()).length) {
            //Get query string
            // _this.filters = {}
            _this.filters = Object.assign({}, this.getQueryString())
        }
    },
    methods: {
        getOrders: function (filters, refresh = true) {
            let _this = this
            _this.filters = Object.assign({}, filters)
            _this.setQueryString()
            _this.loading_page = true
            axios.get(appUrl+'/tracking-code/all', {params: filters})
                .then(function (response) {
                    let {status = false,
                        ordersData = {},
                        pagination = {}
                    } = response.data
                    _this.loading_page = false
                    _this.orders = ordersData
                    _this.pagination = pagination
                })
                .catch(function (error) {
                    console.log(error)
                });
        },

        clickPagination: function (paged) {
            this.filters.paged = paged
            this.pagination.current_page = paged
            this.getOrders(this.filters, false)
        },
        setQueryString: function () {
            let _this = this
            let queryString = $.param(this.filters)
            history.pushState(this.filters, '', appUrl+'/tracking-code/?'+queryString)
        },
        getQueryString: function () {
            return queryString.parse(location.search, {arrayFormat: 'bracket'})
        },

        syncAliOrderNo:function () {
            let _this = this

            if( ! checkExtension())
                return false

            _this.is_load = true
            let port = chrome.runtime.connect(chromeExtensionId);
            const payloadMessage = {
                data: {
                    action: 'ACTION_SYNC_ORDERS_FROM_OBERLO',
                    payload: {
                        from_date: '2009-01-01',
                        to_date: moment().format('YYYY-MM-D')
                    }
                }
            }
            port.postMessage(payloadMessage);
            port.disconnect()
            setTimeout(function () {
                _this.is_load = false
            },3000)
        },
        getTrackingCode:function (lineItemId,aliexpressOrderNo,event) {

            if( aliexpressOrderNo === null || aliexpressOrderNo === ''){
                alert('Ali Order No is not null');
            }
            if( ! checkExtension())
                return false

            const port = chrome.runtime.connect(chromeExtensionId);
            $(event.currentTarget).loading_id();

            const payloadMsg = {
                data: {
                    action: 'ACTION_GET_TRACKING_CODE',
                    payload: {
                        data: [
                            {
                                line_item_id: [lineItemId],
                                ali_order_no: aliexpressOrderNo,
                            }
                        ],
                        shop_domain: this.shopDomain,
                        access_token: this.accessToken,
                        shop_id: this.shopId
                    }
                }
            }
            port.postMessage(payloadMsg)
            port.disconnect()
        },
        trackingCode:function (trackingCode) {
            let _this = this
            $('#trackingCodeModal').modal()
            _this.trackingCodeId = trackingCode
        },
        getAllTrackingCode:function (orders) {
            let _this = this
            if( ! checkExtension())
                return false

            _this.lineItems = _this.addArrayLineItem(orders)
            const port = chrome.runtime.connect(chromeExtensionId);
            // $(event.currentTarget).loading_id();
            const payloadMsg = {
                data: {
                    action: 'ACTION_GET_TRACKING_CODE',
                    payload: {
                        data: _this.lineItems,
                        shop_domain: _this.shopDomain,
                        access_token: _this.accessToken,
                        shop_id: _this.shopId
                    }
                }
            }

            port.postMessage(payloadMsg)
            port.disconnect()
        },
        addArrayLineItem: function (orders) {

            let items = []

            Object.values(orders).forEach(order=>{

                let line_items = order.line_items

                Object.values(line_items).forEach(line_item=>{

                    const { id = "", aliexpress_order_no = 0, tracking_code = ""} = line_item;

                    if (aliexpress_order_no && !tracking_code)
                    {
                        items.push({
                            line_item_id:[id],
                            ali_order_no: aliexpress_order_no
                        })
                    }
                })
            })
            return items
        },

        closeToastProcess: function () {
            this.tracking_code_process.forEach(element => {
                $(`#product-list-item-${element.product_id}`).removeClass('product_process_override')
            });
            this.tracking_code_process=[]
        },

        pusherSubscribe: function () {
            let _this = this;
            let pusher = new Pusher(pusherEnv.app_key, {
                cluster: pusherEnv.app_cluster,
                encrypted: true
            });
            let channel = pusher.subscribe(shopId);
                channel.bind('tracking_code_from_file', function(product) {
                    _this.tracking_code_process = _this.tracking_code_process.map(function (process_with_type) {
                        if(process_with_type.type !== 'tracking_code_from_file')
                            return process_with_type
                        else {
                            return {
                                type: process_with_type.type,
                                data: process_with_type.data.map(function (product_process) {

                                    if(product.product.id == product_process.id)
                                    {

                                        return Object.assign({}, product_process, {
                                            status: 'success'
                                        })
                                    }

                                    else
                                        return product_process
                                })
                            }
                        }
                    })
                    _this.setToastProcess(_this.tracking_code_process)
                });

            channel.bind('update-view-order', function(data) {
                // self.processOrder = false;
                const line_item_id = data.lineItem.id;
                const type = data.type
                let success_noti = '';
                let error_noti = '';
                switch (type) {
                    case 'tracking_code':
                        $('body').loading_id_finish('tracking_code-'+line_item_id);
                        success_noti = 'Get tracking code success'
                        error_noti = 'Tracking code not found'
                        break
                    default :
                        success_noti = 'Success'
                        error_noti = 'Error'
                        break
                }

                if( ! data.status)
                {
                    notify('error', error_noti);
                    $('body').find('.loading-blur-o').remove();
                    return false;
                }  const { orders_id, id } = data.lineItem;

                const {line_items} = _this.orders[orders_id];
                let firstObj = line_items[id];
                firstObj.tracking_code = data.lineItem.tracking_code;
                notify('success', success_noti)
            });
        },

        setToastProcess: function (products) {
            let _this = this
            axios.post(appUrl+'/toast_process', {products: products, type: _this.tracking_code_process_type})
        },

        importFromFile: function() {
            $('#tracking-code-modal').modal('show')
        },
        exportFile: function (type) {
            let _this = this
            _this.is_export[type] = true
            axios.post(appUrl+'/tracking-code/export', {filters: this.filters, shop_id: this.shopId, type: type})
                .then(function (response) {
                    _this.$nextTick(function () {
                        _this.is_export[type] = false
                    })
                    let { partSource, fileName, type } = response.data
                    let url = appUrl+'/storage/exports/'+fileName+'.'+type
                    download(url);
                })
                .catch(function (error) {
                    _this.is_export[type] = false
                    notify('error', error)
                })
        },

        callPopup:function (e) {
            let _this = this
            _this.tracking_code_process=[{
                type : 'tracking_code_from_file',
                data : [{
                    id:e[0],
                    title : 'Get tracking code from file' + e[1],
                    status : 'pending',
                }]
            }]
        },

    },
    watch: {

    },
    components: {
        pagination,
        modal_trackingcode,
        popup_import_tracking_code,
        toast_process,
        'line-scale-loader': LineScaleLoader,
        toast_process_percent,
        'line-scale-pulse-loader': LineScalePulseOutRapidLoader,
    }
});