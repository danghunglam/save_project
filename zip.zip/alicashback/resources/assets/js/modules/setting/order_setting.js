import vue_loaders_circle from '../../components/common/vue_loaders_circle';

new Vue({
    el: "#settings-form",
    data: {
        settings: {},
        setting_default: {},
        settings_errors: {
            default_phone_number_aliexpress_checkout:'',
            default_phone_code: '',
            note_supplier_aliexpress_checkout: '',
            shipping_max_price_alert: '',
            stop_total_cost_option: '',
            stop_total_order_processed_option: '',
            skip_shipping_fee_option: '',
            skip_product_price_option: '',
            skip_earning_lower_option: ''
        },
        fillable: [
            'default_shipping_method',
            'default_phone_number_aliexpress_checkout',
            'note_supplier_aliexpress_checkout',
            'shipping_max_price_alert',
            'is_shipping_max_price_alert',
            'default_phone_code',
            'default_fulfillment_tracking_url',
            'notification_email_customer_fulfillment',
            'automation_fulfillment'
        ],
        is_save: false,
        settings_old: [],
        current_tab: 'supplier',
        loading: true,
        stop_options: {
            is_stop_total_cost_option: false,
            is_stop_total_order_processed_option: false
        },
        skip_options: {
            is_skip_shipping_fee_option: false,
            is_skip_product_price_option: false,
            is_skip_earning_lower_option: false
        },
        shippingMethodBackup: [],
        shippingMethodName: []
    },
    mounted: function () {
        let _this = this;

        $('#default_shipping_method').multiselect({
            enableFiltering: false,
            nonSelectedText: 'None',
            buttonContainer: '<div class="selected-parents-container select-no-checked"></div>',
        }).change(function(event) {
            _this.settings.default_shipping_method = $(event.currentTarget).val()
            let shippingMethodBackup = _this.shippingMethodBackup.filter(function(method) {
                return method.value != _this.settings.default_shipping_method
            })
            $('#backup_shipping_method').multiselect('dataprovider', shippingMethodBackup)
            _this.settings.backup_shipping_method = $('#backup_shipping_method').val()
            
        });

        $('#backup_shipping_method').multiselect({
            enableFiltering: false,
            nonSelectedText: 'None',
            buttonContainer: '<div class="selected-parents-container select-no-checked"></div>',
            includeSelectAllOption: true
        }).change(function(event) {
            _this.settings.backup_shipping_method = $(event.currentTarget).val()
        });
    },
    created: function () {
        let _this = this
        axios.get(appUrl+'/setting/all')
            .then(function (response) {
                let { status, settings, setting_default } = response.data
                _this.$nextTick(function () {
                    _this.settings = settings
                    if(_this.settings.stop_total_cost_option != '') {
                        _this.stop_options = Object.assign({}, _this.stop_options, {
                            is_stop_total_cost_option: true
                        })
                    }
                    if(_this.settings.stop_total_order_processed_option != '') {
                        _this.stop_options = Object.assign({}, _this.stop_options, {
                            is_stop_total_order_processed_option: true
                        })
                    }
                    if(_this.settings.skip_shipping_fee_option != '') {
                        _this.skip_options = Object.assign({}, _this.skip_options, {
                            is_skip_shipping_fee_option: true
                        })
                    }
                    if(_this.settings.skip_product_price_option != '') {
                        _this.skip_options = Object.assign({}, _this.skip_options, {
                            is_skip_product_price_option: true
                        })
                    }
                    if(_this.settings.skip_earning_lower_option != '') {
                        _this.skip_options = Object.assign({}, _this.skip_options, {
                            is_skip_earning_lower_option: true
                        })
                    }

                    if(typeof _this.settings.automation_fulfillment == 'undefined') {
                        _this.settings.automation_fulfillment = 1
                    }

                    _this.setting_default = setting_default
                    $('#default_shipping_method').multiselect('select', _this.settings.default_shipping_method);

                    let shipping_method = document.querySelectorAll('#default_shipping_method option')
                    shipping_method.forEach((element, index) => {
                        let str = element.textContent || element.innerText
                        let _selected = false
                        if(element.getAttribute('value').trim() == _this.settings.backup_shipping_method) {
                            _selected = true
                        }
                        _this.shippingMethodBackup.push({ value: element.getAttribute('value'), label: str, selected: _selected })
                    })

                    $('#backup_shipping_method').multiselect('dataprovider', _this.shippingMethodBackup)

                    _this.loading=false
                })
            })
            .catch(function (error) {
                notify('error', error)
            })
    },
    components:{
        vue_loaders_circle
    },
    methods: {
        validSetting: function (settings) {
            let _this = this
            _this.settings_errors = {
                default_phone_number_aliexpress_checkout: '',
                default_phone_code: '',
                note_supplier_aliexpress_checkout: '',
                shipping_max_price_alert: '',
                default_fulfillment_tracking_url: '',
                stop_total_cost_option: '',
                stop_total_order_processed_option: '',
                skip_shipping_fee_option: '',
                skip_product_price_option: '',
                skip_earning_lower_option: ''

            }

            let default_phone_number_aliexpress_checkout = settings['default_phone_number_aliexpress_checkout']
            let note_supplier_aliexpress_checkout = settings['note_supplier_aliexpress_checkout']
            let shipping_max_price_alert = settings['shipping_max_price_alert']
            let is_shipping_max_price_alert = settings['is_shipping_max_price_alert']
            let default_phone_code = settings['default_phone_code']
            let default_fulfillment_tracking_url = settings['default_fulfillment_tracking_url']

            if(default_phone_number_aliexpress_checkout || default_phone_code)
            {
                const regex_phone_code = new RegExp('^\\+\[0-9]{1,7}$')
                if( ! regex_phone_code.test(default_phone_code))
                    _this.settings_errors.default_phone_code = 'Valid'
            }

            if(default_phone_number_aliexpress_checkout || default_phone_code)
            {
                const regex_phone_number = new RegExp('^([0-9]|\-|\/){5,16}$')
                if( ! regex_phone_number.test(default_phone_number_aliexpress_checkout))
                    _this.settings_errors.default_phone_number_aliexpress_checkout = 'Valid'
            }

            if(default_fulfillment_tracking_url)
            {
                const regex_tracking = new RegExp(/(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/)
                if( ! regex_tracking.test(default_fulfillment_tracking_url))
                    _this.settings_errors.default_fulfillment_tracking_url = 'Invalid format. Please try another URL'
            }

            if(note_supplier_aliexpress_checkout && note_supplier_aliexpress_checkout.length > 1000)
                _this.settings_errors.note_supplier_aliexpress_checkout = 'Max. 1,000 English characters or Arabic numerals only'

            if(is_shipping_max_price_alert && (! validNumber(shipping_max_price_alert) || (shipping_max_price_alert) < 0))
                _this.settings_errors.shipping_max_price_alert = 'Invalid shipping price'

            let stop_total_cost_option = settings['stop_total_cost_option']
            let stop_total_order_processed_option = settings['stop_total_order_processed_option']
            let skip_shipping_fee_option = settings['skip_shipping_fee_option']
            let skip_product_price_option = settings['skip_product_price_option']
            let skip_earning_lower_option = settings['skip_earning_lower_option']

            if(_this.stop_options.is_stop_total_cost_option && stop_total_cost_option == '')
                _this.settings_errors.stop_total_cost_option = 'Invalid'
            
            if(_this.stop_options.is_stop_total_order_processed_option && stop_total_order_processed_option == '')
                _this.settings_errors.stop_total_order_processed_option = 'Invalid'

            if(_this.skip_options.is_skip_shipping_fee_option && skip_shipping_fee_option == '')
                _this.settings_errors.skip_shipping_fee_option = 'Invalid'
            
            if(_this.skip_options.is_skip_product_price_option && skip_product_price_option == '')
                _this.settings_errors.skip_product_price_option = 'Invalid'
            
            if(_this.skip_options.is_skip_earning_lower_option && skip_earning_lower_option == '')
                _this.settings_errors.skip_earning_lower_option = 'Invalid'


            return ! (
                _this.settings_errors.default_phone_number_aliexpress_checkout !== '' ||
                _this.settings_errors.note_supplier_aliexpress_checkout !== '' ||
                _this.settings_errors.shipping_max_price_alert !== '' ||
                _this.settings_errors.default_phone_code !== '' ||
                _this.settings_errors.default_fulfillment_tracking_url !== '' ||
                ( _this.stop_options.is_stop_total_cost_option && stop_total_cost_option == '') ||
                ( _this.stop_options.is_stop_total_order_processed_option && stop_total_order_processed_option == '' ) ||
                ( _this.skip_options.is_skip_shipping_fee_option && skip_shipping_fee_option == '') ||
                ( _this.skip_options.is_skip_product_price_option && skip_product_price_option == '') ||
                ( _this.skip_options.is_skip_earning_lower_option && skip_earning_lower_option == '')
            )
        },
        saveSettings: function () {
            //validate price rule
            let _this = this
            this.is_save = true
            if( ! this.validSetting(_this.settings))
            {
                this.is_save = false
                notify('warning', 'Please check valid form')
                return false
            }
            settings = _.pickBy(_this.settings, function (value, key) {
                return _this.fillable.indexOf(key) > -1
            });
            axios.post(appUrl+'/setting/handle', settings)
                .then(function (response) {
                    _this.is_save = false
                    let { status, message } = response.data
                    if(status)
                        notify('success', message)
                    else
                        notify('error', message)
                })
                .catch(function (error) {
                    _this.is_save = false
                    notify('error', error)
                })
        },
        changeSettingRoute: function(route_link) {
            window.location = route_link;
        },
        restoreSettings: function () {
            let _this = this
            this.settings = Object.assign({}, this.setting_default)
            setTimeout(function () {
                $('#default_shipping_method').multiselect('select', _this.settings.default_shipping_method);
            }, 0)
        },
        isNumberKeyup: function(event) {
            let _this = this
            let val = $(event.currentTarget).val()
            let str_split = val.split('.');
            if( str_split[1] != undefined &&  str_split[1].length >= 3 || str_split.length >= 3) {
                let last = str_split[1].slice(0, 2)
                let first = str_split[0] + '.'
                val = first.concat(last)
                _this.settings.shipping_max_price_alert = val
            }

        },
        isNumber: function(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if ((charCode >= 48 && charCode <= 57) || charCode === 46) {
                return true
            } else {
                evt.preventDefault()
            }
        },
        autoUpdatePrice: function () {
            let port = chrome.runtime.connect(chromeExtensionId);
            //Send public token

            //Send auto update price
            const payloadMessageAutoUpdate = {
                data: {
                    action: 'AUTO_UPDATE_PRICE',
                    payload: {
                        shopId: '16331587',
                    }
                }
            }
            port.postMessage(payloadMessageAutoUpdate);
            port.disconnect()

        },
        changeOptionFulfillment: function() {
            let _this = this
            if(!_this.stop_options.is_stop_total_cost_option)
                _this.settings_errors.stop_total_cost_option = ''

            if(!_this.stop_options.is_stop_total_order_processed_option)
                _this.settings_errors.stop_total_order_processed_option = ''

            if(!_this.skip_options.is_skip_shipping_fee_option)
                _this.settings_errors.skip_shipping_fee_option = ''
            
            if(!_this.skip_options.is_skip_product_price_option)
                _this.settings_errors.skip_product_price_option = ''
            
            if(!_this.skip_options.is_skip_earning_lower_option)
                _this.settings_errors.skip_earning_lower_option = ''
        }
    }
});
