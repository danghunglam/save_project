import vue_loaders_circle from '../../components/common/vue_loaders_circle';
new Vue({
    el: "#settings-form",
    data: {
        settings: {},
        is_save: false,
        setting_default: {},
        settings_errors: {
            default_fulfillment_tracking_url: '',
            primary_email_address: ''
        },
        fillable: [
                'notification_email_customer_fulfillment',
                'default_fulfillment_tracking_url',
                'auto_update_when_product_no_longer_available_aliexpress',
                'auto_update_when_product_no_longer_available_aliexpress_notify',
                'auto_update_when_product_variant_no_longer_available_aliexpress',
                'auto_update_when_product_variant_no_longer_available_aliexpress_notify',
                'auto_update_when_product_cost_change_aliexpress',
                'auto_update_when_product_cost_change_aliexpress_notify',
                'when_one_product_is_out_of_stock_on_aliexpress',
                'when_one_product_is_out_of_stock_on_aliexpress_notify',
                'time_zone',
                'primary_email_address'
            ],
        current_tab: 'general',
        loading: true
    },
    mounted: function () {
        let _this = this;
        $('#setting_timezone').select2().on('select2:select', function (e) {
            _this.settings.time_zone = $(e.currentTarget).val()
        });

        $('#default_shipping_method').multiselect({
            enableFiltering: false,
            nonSelectedText: 'None',
            buttonContainer: '<div class="selected-parents-container select-no-checked"></div>',
        }).change(function(event) {
            _this.settings.default_shipping_method = $(event.currentTarget).val()
        });
    },
    created: function () {
        let _this = this
        axios.get(appUrl+'/setting/all')
            .then(function (response) {
                let { status, settings, setting_default } = response.data
                _this.$nextTick(function () {
                    _this.settings = settings
                    _this.setting_default = setting_default
                    $('#setting_timezone').select2({
                        theme: 'bootstrap',
                        width: '100%',
                    }).val(_this.settings.time_zone)
                        .trigger('change')

                    // $('#default_shipping_method').multiselect('select', _this.settings.default_shipping_method);
                })
                _this.loading=false
            })
            .catch(function (error) {
                notify('error', error)
            })
    },
    components:{
        vue_loaders_circle
    },
    methods: {
        validSetting: function (settings) {
            let _this = this
            _this.settings_errors = {
                default_fulfillment_tracking_url: '',
                primary_email_address: ''
            }
            let default_fulfillment_tracking_url = settings['default_fulfillment_tracking_url']
            let primary_email_address = settings['primary_email_address']

            if(primary_email_address) {
                const regex_email = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                if( ! regex_email.test(String(primary_email_address).toLowerCase()))
                    _this.settings_errors.primary_email_address = 'Valid'
            }

            if(default_fulfillment_tracking_url)
            {
                const regex_tracking = new RegExp('^((https|http):\\/\\/)?(www.)?[a-z0-9-_]+\\.[a-z]+(\\/[a-zA-Z0-9#-_]+\\/?)*$')
                if( ! regex_tracking.test(default_fulfillment_tracking_url))
                    _this.settings_errors.default_fulfillment_tracking_url = 'Valid'
            }


            return ! (
                _this.settings_errors.default_fulfillment_tracking_url !== '' ||
                _this.settings_errors.primary_email_address !== ''
            )
        },
        saveSettings: function () {
            //validate price rule
            let _this = this
            this.is_save = true

            if( ! this.validSetting(_this.settings))
            {
                this.is_save = false
                notify('warning', 'Please check valid form')
                return false
            }
            settings = _.pickBy(_this.settings, function (value, key) {
                return _this.fillable.indexOf(key) > -1
            });
            axios.post(appUrl+'/setting/handle', settings)
                .then(function (response) {
                    _this.is_save = false
                    let { status, message } = response.data
                    if(status)
                        notify('success', message)
                    else
                        notify('error', message)
                })
                .catch(function (error) {
                    _this.is_save = false
                    notify('error', error)
                })
        },
        restoreSettings: function () {
            this.settings = Object.assign({}, this.setting_default)
            setTimeout(function () {
                $('#setting_timezone').select2({
                    theme: 'bootstrap',
                    width: '100%',
                }).val(_this.settings.time_zone)
                    .trigger('change')
            }, 0)
        },
        changeSettingRoute: function(route_link) {
            window.location = route_link;
        }
    }
});
