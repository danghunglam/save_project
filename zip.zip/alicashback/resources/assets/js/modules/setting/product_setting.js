import vue_loaders_circle from '../../components/common/vue_loaders_circle';
new Vue({
    el: "#product-setting",
    data: {
        settings: {},
        is_save: false,
        setting_default: {},
        settings_errors: {
            default_fulfillment_tracking_url: '',
            primary_email_address: ''
        },
        fillable: [
                'auto_update_when_product_no_longer_available_aliexpress_notify',
                'auto_update_when_product_no_longer_available_aliexpress',
                'auto_update_when_product_variant_no_longer_available_aliexpress',
                'auto_update_when_product_variant_no_longer_available_aliexpress_notify',
                'auto_update_when_product_cost_change_aliexpress',
                'auto_update_when_product_cost_change_aliexpress_notify',
                'when_one_product_is_out_of_stock_on_aliexpress',
                'when_one_product_is_out_of_stock_on_aliexpress_notify'
            ],
        current_tab: 'general',
        loading: true
    },
    created: function () {
        let _this = this
        axios.get(appUrl+'/setting/all')
            .then(function (response) {
                let { status, settings, setting_default } = response.data
                _this.$nextTick(function () {
                    _this.setting_default = setting_default
                    _this.settings = settings
                    _this.loading=false
                })
                setTimeout(function() {
                    $('[data-toggle="tooltip"]').tooltip({
                        html: true,
                        container: 'body'
                    });
                }, 0)
            })
            .catch(function (error) {
                notify('error', error)
            })
    },
    mounted: function() {
        // $('[data-toggle="tooltip"]').tooltip({
        //     html: true,
        //     container: 'body'
        // });
    },
    components:{
        vue_loaders_circle
    },
    methods: {
        saveSettings: function () {
            //validate price rule
            let _this = this
            this.is_save = true

            settings = _.pickBy(_this.settings, function (value, key) {
                return _this.fillable.indexOf(key) > -1
            });
            axios.post(appUrl+'/setting/handle', settings)
                .then(function (response) {
                    _this.is_save = false
                    let { status, message } = response.data
                    if(status)
                        notify('success', message)
                    else
                        notify('error', message)
                })
                .catch(function (error) {
                    _this.is_save = false
                    notify('error', error)
                })
        },
        changeSettingRoute: function(route_link) {
            window.location = route_link;
        },
        restoreDefault: function () {
            this.settings = Object.assign({}, this.setting_default)
        }
    }
});
