import price_rule from '../../components/setting/price_rule.vue'
import vue_loaders_circle from '../../components/common/vue_loaders_circle';
import Pusher from "pusher-js";
import toast_process_not_data from '../../components/common/toast_process_not_data'

window.vueSetting = new Vue({
    el: "#settings-form",
    data: {
        loading: true,
        settings: {},
        setting_default: {},
        settings_errors: {
            price_rule: [],
            rest_of_the_price_ranges: [],
            message_validate_price_rule: []
        },
        settings_errors_var: {},
        fillable: [
            'is_compared_price',
            'rest_of_the_price_ranges',
            'price_rule',
            'is_convert_currency',
            'assign_cent_price_check',
            'assign_cent_price',
            'assign_cent_compare_at_check',
            'assign_cent_compare_at'
        ],
        is_save: false,
        settings_old: [],
        current_tab: 'pricing_rule',
        price_rule: [],
        rest_of_the_price_ranges: [],
        add_rule_for_products: [],
        process_title: 'Updating Pricing Rules.',
        add_rule_process_type: ['add_rule_product']
    },
    mounted: function () {
        this.pusherSubscribe()
    },
    created: function () {
        let _this = this
        axios.get(appUrl+'/setting/all')
            .then(function (response) {
                let { status, settings, setting_default } = response.data
                _this.$nextTick(function () {
                    _this.settings = settings
                    if(_this.settings.is_convert_currency) {
                        _this.settings.is_convert_currency = +_this.settings.is_convert_currency
                    }
                    _this.price_rule = settings.price_rule
                    _this.rest_of_the_price_ranges = settings.rest_of_the_price_ranges
                    _this.filterSettings()
                    _this.setting_default = setting_default
                    _this.loading = false
                })
            })
            .catch(function (error) {
                notify('error', error)
            })
    },
    components: {
        price_rule,
        vue_loaders_circle,
        toast_process_not_data
    },
    methods: {
        filterSettings: function () {
            this.settings.price_rule =  this.settings.price_rule.map(function (price) {
                return {
                    min : price.min,
                    max : price.max,
                    item_price : price.item_price,
                    compared_price : price.compared_price,
                    item_price_type: price.item_price_type ? price.item_price_type : 'multiply',
                    compared_price_type: price.compared_price_type ? price.compared_price_type : 'multiply'
                }
            })
            this.settings.rest_of_the_price_ranges = {
                min : this.settings.rest_of_the_price_ranges.min,
                max : this.settings.rest_of_the_price_ranges.max,
                item_price : this.settings.rest_of_the_price_ranges.item_price,
                compared_price : this.settings.rest_of_the_price_ranges.compared_price,
                item_price_type : (this.settings.rest_of_the_price_ranges.item_price_type) ? this.settings.rest_of_the_price_ranges.item_price_type : 'multiply',
                compared_price_type : (this.settings.rest_of_the_price_ranges.compared_price_type) ? this.settings.rest_of_the_price_ranges.compared_price_type : 'multiply',
            }
        },
        validSetting: function (settings) {
            let _this = this
            const regex_cent_price = new RegExp('^[0-9][0-9]?$')
            const rest_of_the_price_ranges = settings['rest_of_the_price_ranges']
            const price_rule = settings['price_rule']
            const assign_cent_price_check = settings['assign_cent_price_check']
            const assign_cent_price = settings['assign_cent_price']
            const assign_cent_compare_at_check = settings['assign_cent_compare_at_check']
            const assign_cent_compare_at = settings['assign_cent_compare_at']

            _this.settings_errors['price_rule'] = [];
            _this.settings_errors['rest_of_the_price_ranges'] = [];
            _this.settings_errors_var = {}
            if(rest_of_the_price_ranges) {
                //Valid rest of the price ranges
                if(typeof rest_of_the_price_ranges.item_price !== 'undefined' && rest_of_the_price_ranges.item_price <= 0)
                    _this.settings_errors['rest_of_the_price_ranges']['item_price'] = 'Valid'

                if((!rest_of_the_price_ranges.compared_price || rest_of_the_price_ranges.compared_price <= 0) && _this.settings.is_compared_price)
                    _this.settings_errors['rest_of_the_price_ranges']['compared_price'] = 'Valid'
            }
            if(price_rule) {
                //Valid price rules
                price_rule.map(function (price, k) {
                    let tmp_obj = {}
                    if(price['item_price'] <= 0)
                        tmp_obj['item_price'] = 'Valid'

                    if(price['compared_price'] <= 0 && _this.settings.is_compared_price)
                        tmp_obj['compared_price'] = 'Valid'

                    if(price['min'] < 0 || price['min'] == null || price['min'] === "")
                        tmp_obj['min'] = 'Valid'

                    if(price['max'] <= 0)
                        tmp_obj['max'] = 'Valid'

                    if(Object.keys(tmp_obj).length > 0)
                        _this.settings_errors['price_rule'][k] = tmp_obj
                })
            }
            let isValidPriceRule = Object.values(_this.settings_errors['price_rule']).length
            let isValidRestPriceRule = Object.values(_this.settings_errors['rest_of_the_price_ranges']).length
            //valid assign_cent_price
            if(assign_cent_price_check) {
                if( ! regex_cent_price.test(assign_cent_price))
                    _this.settings_errors_var['assign_cent_price'] = 'Assign cents field value should be an integer between 0 and 99'
            }

            if(assign_cent_compare_at_check) {
                if( ! regex_cent_price.test(assign_cent_compare_at))
                    _this.settings_errors_var['assign_cent_compare_at'] = 'Assign compared at cents field value should be an integer between 0 and 99'
            }

            return ! (isValidPriceRule > 0 ||
                isValidRestPriceRule > 0 ||
                Object.keys(_this.settings_errors_var).length > 0 ||
                _this.settings_errors.message_validate_price_rule.length > 0
            )
        },
        priceRuleChange: function (price_rule) {
            this.$nextTick(function () {
                this.price_rule = price_rule;
                this.settings.price_rule  = price_rule
            })
        },
        restPriceRuleChange: function (rest_price_rule) {
            this.$nextTick(function () {
                this.settings = Object.assign({}, this.settings, {rest_of_the_price_ranges: rest_price_rule})
            })
        },
        validPriceRule: function (valid_message) {
            this.message_validate_price_rule = valid_message
            this.settings_errors.message_validate_price_rule = valid_message
        },
        checkIsComparedPrice: function (is_compared_price) {
            this.settings = Object.assign({}, this.settings, {is_compared_price: is_compared_price})
        },
        saveSettings: function () {
            //validate price rule
            let _this = this
            _this.is_save = true
            //valid cent
            console.log(_this.settings_errors_var)


            if( ! this.validSetting(_this.settings))
            {
                this.is_save = false

                if(this.settings_errors_var.assign_cent_price) {
                    notify('warning', this.settings_errors_var.assign_cent_price)
                    return false
                }

                if(this.settings_errors_var.assign_cent_compare_at) {
                    notify('warning', this.settings_errors_var.assign_cent_compare_at)
                    return false
                }

                notify('warning', 'Please check valid form')
                return false


            }
            settings = _.pickBy(_this.settings, function (value, key) {
                return _this.fillable.indexOf(key) > -1
            });
            this.price_rule = settings.price_rule
            axios.post(appUrl+'/setting/handle', settings)
                .then(function (response) {
                    _this.is_save = false
                    let { status, message } = response.data
                    if(status)
                        notify('success', message)
                    else
                        notify('error', message)

                })
                .catch(function (error) {
                    _this.is_save = false
                    notify('error', error)
                })
        },
        restoreSettings: function () {
            this.price_rule = JSON.parse(JSON.stringify(this.setting_default.price_rule))
            this.rest_of_the_price_ranges = JSON.parse(JSON.stringify(this.setting_default.rest_of_the_price_ranges))
            this.settings = JSON.parse(JSON.stringify(this.setting_default))
        },
        changeSettingTab: function(tab_name) {
            this.current_tab = tab_name
        },
        changeSettingRoute: function(route_link) {
            window.location = route_link;
        },

        applyRuleForImportList:function(){
            let _this = this
            if( ! this.validSetting(_this.settings))
            {
                this.is_save = false

                if(this.settings_errors_var.assign_cent_price) {
                    notify('warning', this.settings_errors_var.assign_cent_price)
                    return false
                }

                if(this.settings_errors_var.assign_cent_compare_at) {
                    notify('warning', this.settings_errors_var.assign_cent_compare_at)
                    return false
                }

                notify('warning', 'Please check valid form')
                return false


            }
            settings = _.pickBy(_this.settings, function (value, key) {
                return _this.fillable.indexOf(key) > -1
            });
            this.price_rule = settings.price_rule

            axios.post(appUrl+ '/setting/add_rule_import_list',settings)
                .then(function (response) {
                    let {status, message, count_product } = response.data

                    if(status){

                        _this.add_rule_for_products = [{
                            type: 'add_rule_product',
                            data:[{
                                status: 'pending',
                                count: count_product,
                                title: 'Products left to update: ' + count_product
                            }]
                        }]

                        return false
                    }
                    notify('error', message)

                })
        },
        pusherSubscribe: function () {
            let _this = this;
            let pusher = new Pusher(pusherEnv.app_key, {
                cluster: pusherEnv.app_cluster,
                encrypted: true
            });
            let channel = pusher.subscribe(shopId);



            channel.bind('add_rule_product', function(product) {

                let count_product = product.product.count_product

                let status = 'pending'
                let title = 'Products left to update: '+ count_product

                if(count_product == -1){
                    status = 'error'
                    title = 'Update pricing rules unsuccessful. Please try again.'
                }

                if(count_product == 0){
                    status = 'success'
                    title =  ' Updated pricing for: '+product.product.total_products+' products.'
                }

                _this.add_rule_for_products =
                    [{
                        type: 'add_rule_product',
                        data:[{
                            status: status,
                            count: count_product,
                            title: title
                        }]
                    }]

            });
        },
        closeToastProcess: function (process) {
            this.import_process.forEach(element => {
                $(`#product-list-item-${element.product_id}`).removeClass('product_process_override')
            });
            this.import_process = process
        },

        showNotify: function(notifySetting) {
            notify(notifySetting.type, notifySetting.content)
        },
    }
});
