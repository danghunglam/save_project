
import status_delete from '../components/product_status/status_delete'
import type_product from '../components/product_status/type_product'
import pagination from '../components/common/pagination'
import vue_loaders_circle from '../components/common/vue_loaders_circle'
import Axios from 'axios'
new Vue({
    el : '#page-products',
    data: {

        products_notify: [],
        type_config: {
            product_miss_link: {
                title: 'Product miss link',
                header: [
                    {
                        title: 'Product name',
                        key: 'product_name'
                    },
                    {
                        title: 'Current orders',
                        key: 'current_order'
                    } ,
                    {
                        title: 'Shopify link',
                        key: 'shopify_link',
                        is_link: {
                            title: 'Open in Shopify'
                        }
                    }]
            },
            product_miss_variant: {
                title: 'Product miss variant',
                header: [
                    {
                        title: 'Product name',
                        key: 'product_name'
                    },
                    {
                        title: 'Variant',
                        key: 'variant'
                    },
                    {
                        title: 'Current Orders',
                        key: 'current_order'
                    },
                    {
                        title: 'Shopify link',
                        key: 'shopify_link',
                        is_link: {
                            title: 'Open in Shopify'
                        }
                    }]
            },
            product_change_cost: {
                title: 'Product change cost',
                header: [
                    {
                        title: 'Product name',
                        key: 'product_name'
                    },
                    {
                        title: 'Variant',
                        key: 'variant'
                    },
                    {
                        title: 'Old price',
                        key: 'old_price'
                    },
                    {
                        title: 'New price',
                        key: 'new_price'
                    },
                    {
                        title: 'Shopify link',
                        key: 'shopify_link',
                        is_link: {
                            title: 'Open in Shopify'
                        }
                    },
                    {
                        title: 'Aliexpress link',
                        key: 'aliexpess_link',
                        is_link: {
                            title: 'Open in Aliexpress'
                        }
                    }]
            },
            product_out_of_stock: {
                title: 'Product out of stock',
                header: [
                    {
                        title: 'Product name',
                        key: 'product_name'
                    },
                    {
                        title: 'Stock',
                        key: 'stock'
                    },
                    {
                        title: 'Shopify link',
                        key: 'shopify_link',
                        is_link: {
                            title: 'Open in Shopify'
                        }
                    },
                    {
                        title: 'Aliexpress link',
                        key: 'aliexpess_link',
                        is_link: {
                            title: 'Open in Aliexpress'
                        }
                    }]
            }
        },
        product_notify_id : 0,
        notify_page: 1,
        pagination: [],
        products:[],
        loading_page: true,
        current_object: [],
        current_type: null,
        total_notify: 0

    },
    created: function () {
        this.getProductsNotify();
    },
    components: {
        type_product,
        pagination,
        status_delete,
        vue_loaders_circle
    },
    methods: {
        getProductsNotify:function(paged = 1){
            let _this = this;
            this.loading_page=true


            Axios.get(notify_domain+'/api/product/all/group_date?page='+paged, {
                headers: {
                    Authorization: JSON.stringify({shop_id: window.shopId}),
                }
            })
                .then(function(response) {
                    let { product, object } = response.data
                    console.log(response.data)
                    _this.products_notify = product
                    _this.pagination = {
                        last_page: object.last_page,
                        current_page: object.current_page
                    }
                    _this.total_notify  = object.total
                    _this.loading_page = false
                    // console.log(response.data)
                })
                .catch(function(error) {
                    console.log(error)
                })
        },
        showDetail:function(type, object, id) {
            Axios.put(notify_domain+'/api/product/'+id, {
                status: false
            }, {
                headers: {
                    Authorization: JSON.stringify({shop_id: window.shopId}),
                }
            })
            this.current_type = type;
            this.current_object = object
        },
        setProductIdDelete:function(notify_id){
            this.product_notify_id = notify_id
        },
        clickPagination: function (paged) {
            this.notify_page = paged
            this.getProductsNotify(paged)
        },
        loadPage:function () {
            console.log(this.total_notify)
            console.log(10 * (this.notify_page - 1))
            if((this.total_notify - 1 <= 10 * (this.notify_page - 1)) && (this.notify_page > 1))
                this.notify_page = this.notify_page - 1

            this.getProductsNotify(this.notify_page)
        }
    }
});
