new Vue({
    el: '#install-app-wrap',
    data: {
        shop_url: '',
        shop_url_error: false
    },
    mounted: function() {
        console.log('#install-app-wrap', this.shop_url_error)
        this.InstallPageValidateDomain()
    },
    methods: {
        validateDomainShop: function (_domain) {
            var pattHTTP_HTTPS = /^(https?:\/\/)/gi;
            var pattMyShopify = /(.myshopify.com)$/gi;
            var pattNotSpecial = /[^a-zA-Z0-9-_]/gi;

            if(_domain.match(pattHTTP_HTTPS)) {
                _domain = _domain.split("//")[1];
            }

            if(_domain.match(pattMyShopify)) {
                _domain = _domain.split(".myshopify.com")[0];

                if( !_domain.match(pattNotSpecial) ) {
                    return true;
                }
            }

            return false;
        },

        InstallPageValidate: function () {
            let _this = this
            const pattHTTP_HTTPS = /^(https?:\/\/)/gi;
            let domain = $('.welcome-page input[name="shop"]');
            let domain_val = $(domain).val();

            if( _this.validateDomainShop(domain_val) && domain_val !== '' ) {
                // true
                let new_domain = domain_val.match(pattHTTP_HTTPS) ? domain_val.split("//")[1] : domain_val;
                new_domain = new_domain.replace('_', '-');
                //$(domain).val(new_domain);
                _this.shop_url = new_domain
                $('form[name="installShopify"]')[0].submit();
            } else {
                // false
                //$('#shop-error').text('Please type your myshopify link (store_name.myshopify.com)');
                _this.shop_url_error = true
            }
        },

        InstallPageValidateDomain: function () {
            let _this = this
            // Click button submit
            $('form[name="installShopify"] .buttn__submit').on('click', function(e) {
                _this.InstallPageValidate();
            });

            // Enter submit
            $('form[name="installShopify"]').submit(function(e) {
                e.preventDefault();
                _this.InstallPageValidate();
            });
        }
    }
})