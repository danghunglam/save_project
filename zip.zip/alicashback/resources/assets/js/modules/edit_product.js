
import 'vue-loaders/dist/vue-loaders.css';
import trumbowyg from '../components/common/trumbowyg'
import vue_loaders_circle from '../components/common/vue_loaders_circle'
import modal_item_image from '../components/common/modal_item_image'
import modal_shipping_country from '../components/import/modal-shipping-country'

new Vue({
    el: '#page-edit-product',
    data: {
        appUrl: window.appUrl,
        product: { modal_images: false},
        loading_page: false,
        itemPrice: {
            showBox: false,
            placeHolder: null,
            type: null,
            value: null
        },
        comparedPrice: {
            showBox: false,
            placeHolder: null,
            type: null,
            value: null
        },
        body_html: '',
        sort_image: [],
        custom_collection : [],
        options: [],
        product_type: [],
        freight_product_id: '',
        freight:{price:0},
        current_collection:[],
        obj_collections:[],
        product_show_shiping:{},
        profit : 0,
        exchange: window.exchange ? window.exchange : 1,
        product_custom_collection:[],
        image_selected: 0,
        variants:[],
        optionFilter:{},
        isAnd:true,
        numVariantSelected: 0,
        totalVariant: 0,
        showChangePrice: false,
        showChangeComparePrice: false,
        countOptionFilter:{},
        selectAll:true,
        priceVariantSelect: null,
        comparePriceVariantSelect: null
    },

    mounted: function() {
        //load product
        let _this = this

        let product_id = this.$refs.product_id.value

        this.loadProduct(product_id)
        this.getProductType()


        /*$('.dropdown-collection .result-multiselect li:last-child input').click(function () {
            $(this).parents('.dropdown-collection').toggleClass('open')
        })*/

        $(document).on('click','.dropdown-collection .box-dropdown-menu li',function () {
            $(this).parents('.dropdown-collection').removeClass('open')
        })

        /*$('.dropdown-collection .box-dropdown-menu li').click(function () {
            $(this).parents('.dropdown-collection').removeClass('open')
        })*/



        $('.product-collection').select2({
            width: '100%'
        });
        $('#collection-edit').on("select2:select", function (evt) {
            var element = evt.params.data.element;
            var $element = $(element);
            $element.detach();
            $(this).append($element);
            $(this).trigger("change");
        })

        $('document').ready(function() {
            $('#product-tag').tagsinput();

            const x = $('#product-tag').prev().find('input');
            $(x).on('focus', function() {
                $('.product-import-wrap .tab-product-info .bootstrap-tagsinput-wrap .box-dropdown-menu').appendTo(x.parent());
            })
        });

        $(document.body).on('click', function(event) {
            if (!$(event.target).closest('.change-price').length) {
                _this.comparedPrice.showBox = false;
                _this.itemPrice.showBox = false;
            }

            if (!$(event.target).closest('.change-price').length) {
                _this.showChangePrice = false;
                _this.showChangeComparePrice = false;
            }

            if (!$(event.target).closest('.dropdown-collection').length) {
                $('.dropdown-collection').removeClass('open')
            }
        });
        $(document).on('click','.dropdown-option-variant .dropdown-menu, .dropdown-option-variant .dropdown-menu li',function () {
            $(this).parents('.dropdown-option-variant').addClass('open');
        })
        var el_sortable = document.getElementById('el-variant-image');
        Sortable.create(el_sortable, {

            ghostClass: "sortable-ghost",  // Class name for the drop placeholder
            chosenClass: "sortable-chosen",  // Class name for the chosen item
            dragClass: "sortable-drag",  // Class name for the dragging item
            setData: function (/** DataTransfer */dataTransfer, /** HTMLElement*/dragEl) {
                dataTransfer.setData('Text', dragEl.textContent); // `dataTransfer` object of HTML5 DragEvent
            },

            // Element is chosen
            onChoose: function (/**Event*/evt) {
                evt.oldIndex;  // element index within parent
            },

            // Element dragging started
            onStart: function (/**Event*/evt) {
                evt.oldIndex;  // element index within parent
            },

            // Element dragging ended
            onEnd: function (/**Event*/evt) {
                var itemEl = evt.item;  // dragged HTMLElement
                const element = evt.from.querySelectorAll('.variant-image-list li img')
                let args = []
                element.forEach(function(item, key) {
                    let tmp = {
                        id: item.getAttribute('data-id'),

                        src: item.getAttribute('src'),
                        width: item.getAttribute('width'),
                        height: item.getAttribute('height')
                    }
                    tmp['position'] = key + 1
                    tmp['sort'] = key + 1

                    tmp['status'] = (key === 0) ? true : ((item.getAttribute('data-status') == 'true') ? true : false)
                    tmp['selected'] = (key === 0) ? true : ((item.getAttribute('data-status') == 'true') ? true : false)
                    args.push(tmp)

                })
                _this.sortImage(args)
                // _this.product.image = $(evt.item).find('img').attr('src');
                evt.to;    // target list
                evt.from;  // previous list
                evt.oldIndex;  // element's old index within old parent
                evt.newIndex;  // element's new index within new parent

            },

            // Element is dropped into the list from another list
            onAdd: function (/**Event*/evt) {
                // same properties as onEnd
            },

            // Changed sorting within list
            onUpdate: function (/**Event*/evt) {
                // same properties as onEnd
            },

            // Called by any change to the list (add / update / remove)
            onSort: function (/**Event*/evt) {
                // same properties as onEnd
            },

            // Element is removed from the list into another list
            onRemove: function (/**Event*/evt) {
                // same properties as onEnd
            },

            // Attempt to drag a filtered element
            onFilter: function (/**Event*/evt) {
                var itemEl = evt.item;  // HTMLElement receiving the `mousedown|tapstart` event.
            },

            // Event when you move an item in the list or between lists
            onMove: function (/**Event*/evt, /**Event*/originalEvent) {
                // Example: http://jsbin.com/tuyafe/1/edit?js,output
                evt.dragged; // dragged HTMLElement
                evt.draggedRect; // TextRectangle {left, top, right и bottom}
                evt.related; // HTMLElement on which have guided
                evt.relatedRect; // TextRectangle
                originalEvent.clientY; // mouse position
                // return false; — for cancel
            },

            // Called when creating a clone of element
            onClone: function (/**Event*/evt) {
                var origEl = evt.item;
                var cloneEl = evt.clone;
            }
        });

        $(document).on('paste','.form-group-tag .bootstrap-tagsinput-wrap input', function(e) {
            let valpaste=e.originalEvent.clipboardData.getData('text');
            let val= $(this).val()+valpaste;
            $(this).attr('size',val.length);
        });
        $('[data-toggle="tooltip"]').tooltip({
            html: true,
            container: 'body'
        });
    },
    created: function() {
        let _this = this
        axios.get(appUrl+'/import/collection')
            .then(function (response) {
                const { data } = response
                if(data.status) {
                    _this.custom_collection = data.custom_collection
                    _this.obj_collections = _this.custom_collection.map((item) => ({ id: item.id, title: item.title }))
                    _this.setCollection(_this.product_custom_collection)
                    /*$('#collection-edit').select2({
                        width: '100%',
                        data: _this.custom_collection.map((item) => ({ id: item.id, title: item.title }))
                    }).on('change', function (e) {
                        let data = $(this).select2('data')
                        data = data.map(function (d) {
                            return d.id
                        })
                        _this.product.custom_collection = data
                    })
                    $('#collection-edit').val(_this.product.custom_collection).trigger('change')*/
                }
            })
            .catch(function (error) {
                notify('error', error)
            });
    },
    components: {
        trumbowyg,
        vue_loaders_circle,
        modal_item_image,
        modal_shipping_country
    },
    methods: {
        loadProduct: function (id) {
            let _this = this
            axios.get(appUrl+'/products/detail/'+id)
                .then(function (response) {
                    // let {product = {}, message = ''} = response.data
                    // console.log('product', product);
                    // _this.product = product
                    // _this.body_html = product.body_html
                    //
                    // _this.product.custom_collection = _this.product.custom_collection ? JSON.parse(_this.product.custom_collection) : []

                    let {status = false, product = {}, message = '', exchange} = response.data
                    if(status) {
                        product.types = {
                            city: null,
                            country: null,
                            province: null
                        }
                        _this.product = Object.assign({}, product)
                        _this.product_show_shiping = JSON.parse(JSON.stringify(product))
                        _this.product_show_shiping.types = {
                            city: null,
                            country: null,
                            province: null
                        }
                        _this.product_show_shiping.freights = []
                        _this.body_html = product.body_html
                        if (_this.product.options || _this.product.options == "[[]]") {
                            _this.options = JSON.parse(_this.product.options)
                            _this.options = _.orderBy(_this.options, ['name'], ['asc']);
                        }
                        _this.product.custom_collection = _this.product.custom_collection ? JSON.parse(_this.product.custom_collection) : []
                        _this.product.product_variant.forEach(element => {
                            element.selected = true
                        })

                        _this.product.product_image.forEach(element => {
                            element.status = true
                            element.selected = true
                        })
                        _this.image_selected = _this.product.product_image.length
                        _this.product.auto_update_price = _this.product.auto_update_price == 1 ? true : false
                        if (_this.product.custom_collection) {
                            $('#collection-edit').val(_this.product.custom_collection).trigger('change')
                        } else {
                            _this.product.custom_collection = []
                        }
                        $('#product-tag').val(_this.product.tag)
                        $('#product-tag').tagsinput('add', _this.product.tag)
                        $('#product-tag').on('itemAdded', function(event) {
                            _this.product.tag = _this.$refs.product_tag.value
                        })
                        $('#product-tag').on('itemRemoved', function(event) {
                            _this.product.tag = _this.$refs.product_tag.value
                        })
                        _this.product_custom_collection=_this.product.custom_collection;
                        _this.profit_calculate()
                        _this.getAllOptionVariant(_this.product.product_variant)
                    }

                }).catch(function (error) {
                // notify('error', error)
            });
        },
        selectAllVariants: function(event) {
            let _this = this
            let checked = $(event.currentTarget).prop('checked');
            let count = 0

            //remove all options
            for(let key in _this.optionFilter){
                for(let [k, value] of Object.entries(_this.optionFilter[key])){
                    value.selected=false
                    value.total = 0
                }
            }

            //Xử lý checked variants, nếu checked == true thì sẽ check 100 variants đầu tiên
            //Nếu checked == false thì sẽ check variant đầu tiên
            this.product.product_variant  = this.product.product_variant.map(function (variant) {
                if(checked) {
                    $(event.currentTarget).parents('.ars-table-row-item').addClass('active');
                    variant.selected = false
                    _this.product.product_image = _this.product.product_image.map(function(product_image) {
                        if( product_image.id === variant.image_id ) {
                            product_image = Object.assign({}, product_image, {
                                status: checked,
                                selected: true
                            })
                        }
                        return product_image
                    })

                    if(count < 100) {
                        variant.selected = checked
                        variant.product_image.status = checked
                        count++

                        for(let key in _this.optionFilter){

                            _this.optionFilter[key][variant.optionNew[key]].selected=true
                            _this.optionFilter[key][variant.optionNew[key]].total++
                        }
                    }
                } else {
                    if(count === 0)
                    {
                        variant.selected = true
                        _this.product.product_image = _this.product.product_image.map(function(product_image) {
                            if( product_image.id === variant.image_id ) {
                                product_image = Object.assign({}, product_image, {
                                    status: true,
                                    selected: true
                                })
                            }
                            return product_image
                        })
                        count++

                        for(let key in _this.optionFilter){
                            for(let [k, value] of Object.entries(_this.optionFilter[key])){
                                if(k == variant.optionNew[key]){
                                    value.selected=true
                                    value.total=1
                                }else{
                                    value.selected=false
                                    value.total=0
                                }
                            }
                        }

                    } else {
                        variant.selected = checked
                        _this.product.product_image = _this.product.product_image.map(function(product_image) {
                            if( product_image.id === variant.image_id ) {
                                product_image = Object.assign({}, product_image, {
                                    status: checked,
                                    selected: checked
                                })
                            }
                            return product_image
                        })
                    }
                    $(event.currentTarget).parents('.ars-table-row-item').removeClass('active');
                }

                return variant
            })

            this.numVariantSelected = this.lengthVariantChecked(this.product.product_variant);

            if(checked) {
                if(count >= 100) {
                    notify('warning', 'You can select a maximum of 100 variants.')
                }
                notify('success', 'Selected successfully')
            }
            else {
                notify('success', 'The variants were successfully unselected. Note at least one variant must stay selected')
                notify('warning', 'You must select at least 1 variant.')
            }
        },
        selectVariant: function (obj_variant) {
            let _this = this
            this.product.product_variant = this.product.product_variant.map(function (variant) {
                if(obj_variant.id === variant.id) {
                    variant.selected = ! variant.selected
                    variant.product_image.status = variant.selected
                    _this.product.product_image = _this.product.product_image.map(function(product_image) {
                        if( product_image.id === variant.image_id ) {
                            product_image = Object.assign({}, product_image, {
                                status: variant.selected
                            })
                        }
                        return product_image
                    })
                }
                return variant
            })
            const length_variant_checked = this.lengthVariantChecked(this.product.product_variant)
            if(length_variant_checked <= 0 && ! obj_variant.selected) {
                this.$nextTick(function(){
                    _this.product.product_variant = _this.product.product_variant.map(function (variant) {
                        if(obj_variant.id === variant.id) {
                            variant.selected = true
                            _this.product.product_image = _this.product.product_image.map(function(product_image) {
                                if( product_image.id === variant.image_id ) {
                                    product_image = Object.assign({}, product_image, {
                                        status: variant.selected
                                    })
                                }
                                return product_image
                            })
                        }
                        return variant
                    })
                })

                notify('warning', 'You must select at least 1 variant.')
                return false
            }
            /*check select variant equal 0 remove check*/
            let currentOption = Object.assign({}, obj_variant.optionNew)
            Object.keys(obj_variant.optionNew).forEach(function (key) {
                currentOption[key] = {
                    value: obj_variant.optionNew[key],
                    number: 0
                }
            })

            _this.variants = _this.variants.map(function (variant) {
                // if (obj_variant.id === variant.id) {
                //     variant.selected = obj_variant.selected
                // }
                // if(variant.selected) {
                //
                // }
                for (let key in currentOption) {
                    if(currentOption[key]['value'] == variant.optionNew[key] && variant.selected == true) {
                        currentOption[key]['number']++
                    }
                }

                return variant
            })

            for (let key in currentOption) {
                if(_this.countOptionFilter[key][currentOption[key]['value']]['total'] == currentOption[key]['number']) {
                    _this.optionFilter[key][currentOption[key]['value']]['selected'] = true
                } else if(currentOption[key]['number'] == 0) {
                    _this.optionFilter[key][currentOption[key]['value']]['selected'] = false
                }
            }
            _this.numVariantSelected = _this.lengthVariantChecked(_this.product.product_variant);
        },
        lengthVariantChecked: function(variants) {
            let variant_checked = []
            variant_checked = variants.filter(function(variant) {
                return variant.selected
            })

            return variant_checked.length
        },
        viewOriginSize: function () {
            $('.variant-image-list').magnificPopup({
                delegate: 'a', // child items selector, by clicking on it popup will open
                type: 'image',
                callbacks: {
                    open: function () {
                        const el = $('.mfp-close')[0];
                        $(el).html(`<button title="Close (Esc)" type="button" class="mfp-close"><span>x</span></button>`).click(function () {
                            $.magnificPopup.close();
                        })
                    },
                }
                // other options
            });
        },
        changeItemPrice: function (type) {
            this.itemPrice.type = type
            this.itemPrice.value = null
            if(type === 'multiply_by')
                this.itemPrice.placeHolder = 'Multiply by price'
            else if(type === 'new_value')
                this.itemPrice.placeHolder = 'New value price'
            else if(type === 'plus')
                this.itemPrice.placeHolder = 'Plus by price'

            this.comparedPrice.showBox = false
            this.itemPrice.showBox = true
        },
        changeComparedPrice: function (type) {
            this.comparedPrice.type = type
            this.comparedPrice.value = null
            if(type === 'multiply_by')
                this.comparedPrice.placeHolder = 'Multiply by compared price'
            else if(type === 'new_value')
                this.comparedPrice.placeHolder = 'New value compared price'
            else if(type === 'plus')
                this.comparedPrice.placeHolder = 'Plus by compared price'

            this.itemPrice.showBox = false
            this.comparedPrice.showBox = true
        },
        saveItemPrice: function () {
            let _this = this

            if( ! validNumber(_this.itemPrice.value))
                return false

            this.product.product_variant =  this.product.product_variant.map(function (variant) {
                if(_this.itemPrice.type === 'multiply_by')
                    variant = Object.assign({}, variant, {
                        price : Number(parseFloat(_this.itemPrice.value) * parseFloat(variant.source_price) * _this.exchange).toFixed(2)
                    })
                else if(_this.itemPrice.type === 'new_value')
                    variant = Object.assign({}, variant, {
                        price: Number(parseFloat(_this.itemPrice.value)).toFixed(2)
                    })
                else if(_this.itemPrice.type === 'plus')
                    variant = Object.assign({}, variant, {
                        price: Number((parseFloat(_this.itemPrice.value) + parseFloat(variant.source_price)) * _this.exchange).toFixed(2)
                    })

                return variant
            })
            this.itemPrice.showBox = false

            this.profit_calculate()
        },
        saveComparedPrice: function () {
            let _this = this
            if( ! validNumber(_this.comparedPrice.value) )
                return false;

            this.product.product_variant = this.product.product_variant.map(function (variant) {
                if(_this.comparedPrice.type === 'multiply_by')
                    variant = Object.assign({}, variant, {
                        compare_at_price : Number(parseFloat(_this.comparedPrice.value) * parseFloat(variant.source_price) * _this.exchange).toFixed(2)
                    })
                else if(_this.comparedPrice.type === 'new_value')
                    variant = Object.assign({}, variant, {
                        compare_at_price : Number(_this.comparedPrice.value).toFixed(2)
                    })
                else if(_this.comparedPrice.type === 'plus')
                    variant = Object.assign({}, variant, {
                        compare_at_price : Number((parseFloat(_this.comparedPrice.value) + parseFloat(variant.source_price)) * _this.exchange).toFixed(2)
                    })

                return variant;
            })
            this.comparedPrice.showBox = false
        },
        changeBodyHtml: function (content) {
            this.product.body_html = content
        },
        selectImageContainer: function (obj_image, index) {
            if(index == 0) {
                return false;
            }
            obj_image.status = !obj_image.status;
            obj_image.selected = !obj_image.selected;
            this.selectImage(obj_image);
        },
        selectImage: function(obj_image) {
            let _this = this
            this.image_selected = this.imageSelected()
            this.$nextTick(function() {
                _this.product.product_variant = _this.product.product_variant.map(function (product_variant) {
                    if( obj_image.id === product_variant.image_id ) {
                        product_variant.product_image = Object.assign({}, product_variant.product_image, {
                            id: obj_image.status ? obj_image.id : '',
                            src: obj_image.status ? obj_image.src : `${appUrl}/images/default.png`
                        })
                    }
                    return product_variant
                })
            })
        },
        showModalImage: function(obj_variant) {
            let _this = this
            this.$nextTick(function() {
                _this.product = Object.assign({}, _this.product, {
                    modal_images: true,
                    variant_image: obj_variant
                })
            })
        },
        closeModalImages: function(obj_modal_images) {
            let _this = this
            this.$nextTick(function() {
                _this.product = Object.assign({}, _this.product, {
                    modal_images: obj_modal_images.status
                })
            })
        },
        addVariantImage: function(obj_image) {
            let _this = this
            this.$nextTick(function() {
                _this.product.product_variant = _this.product.product_variant.map(function(product_variant) {
                    if(product_variant.id === _this.product.variant_image.id) {
                        product_variant = Object.assign({}, product_variant, {
                            image_id: obj_image.id
                        })
                        product_variant.product_image = Object.assign({}, product_variant.product_image, {
                            id: obj_image.id,
                            src: obj_image.src,
                            status: true
                        })
                    }
                    return product_variant
                })
                _this.product.product_image = _this.product.product_image.map(function(product_image) {
                    if(product_image.id === obj_image.id) {
                        product_image = Object.assign({}, product_image, {
                            status: true
                        })
                    }
                    return product_image
                })
                _this.product = Object.assign({}, _this.product, {
                    modal_images: false
                })
            })
        },
        isNumber: function(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if ((charCode >= 48 && charCode <= 57) || charCode === 46) {
                return true
            } else {
                evt.preventDefault()
            }
        },
        isNumberKeyup: function(event, index, name) {
            let val = $(event.currentTarget).val()
            let str_split = val.split('.');
            if( str_split[1] != undefined &&  str_split[1].length >= 3 || str_split.length >=3) {
                let last = str_split[1].slice(0, 2)
                let first = str_split[0] + '.'
                val = first.concat(last)
                //$(event.currentTarget).val(val)

                // index !== '' ? this.product.product_variant[index][name] = val : this.product.product_variant[name] = val
                // if( name == 'itemPrice' ) {
                //     this.itemPrice.value = val
                // }
                // if( name == 'comparedPrice') {
                //     this.comparedPrice.value = val
                // }

                switch (name) {

                    case 'itemPrice':

                        this.itemPrice.value = val
                        break;

                    case 'comparedPrice':

                        this.comparedPrice.value = val
                        break;

                    case 'priceVariantSelect':

                        this.priceVariantSelect = val
                        break;

                    case 'comparePriceVariantSelect':

                        this.comparePriceVariantSelect = val
                        break;
                }

            }
        },
        saveEditProduct: function () {
            let _this = this
            this.loading_page = true
            axios.post(appUrl+'/products/editHandle', {product: _this.product})
                .then(function(response) {
                    _this.loading_page = false
                    notify('success', 'Update success')
                })
                .catch(function (error) {
                    console.log(error)
                    _this.loading_page = false
                    notify('error', 'Update error')
                })
        },
        /*show modal shipping country*/

        showModalShipingCountry:function (obj_product) {
            if( ! checkExtension())
                return false
            this.$refs.modal_shipping_country.initDataShip()

            if($('.modal-shipping-country').length){
                $('.modal-shipping-country').addClass('show-modal-shipping')
                $('body').append('<div class="bg-modal-shipping"></div>')
            }
            /*$('.modal-shipping-country').modal('show');*/
            /*$('#modal-shipping-country-'+this.product_show_shiping.aliexpress_product_id).modal('show');*/
        },

        changePrice:function () {
            this.profit_calculate()

        },
        setNull:function({ type, target }){
            if(target.value==''){
                this.profit_calculate()
            }
        },
        profit_calculate:function () {
            let _this = this
            _this.product.product_variant.map(function (variant) {
                variant.profit = ((parseFloat(variant.price) / _this.exchange) - (parseFloat(variant.source_price) + parseFloat(_this.freight.price))).toFixed(2)
                variant.profit = (variant.profit == -0.00) ? 0.00 : variant.profit;
                return variant
            })
        },

        infoShipping:function(freight){
            this.freight = freight
            this.product.types = JSON.parse(JSON.stringify(freight.types))
            this.profit_calculate()
            // this.product.variants = this.product.variants.map(function (variant) {
            //
            //         variant = Object.assign({}, variant, {
            //             price_shipping : Number(parseFloat(freight.price)).toFixed(2)
            //         })
            //     return variant;
            // })
            //
            // this.product.country_shipping = freight.shipTo
            // console.log(this.product)
            // //Update product
            //
            // axios.post(appUrl+'/import/country_shipping', this.product)
            //     .then(function (response) {
            //
            //     })
            //     .catch(function (error) {
            //
            //     })
            //
            // //Update variants
            // axios.post(appUrl+'/import/variants', this.product.variants)
            //     .then(function (response) {
            //
            //     })
            //     .catch(function (error) {
            //
            //     })
            // // this.freight = freight
        },
        showFreight:function (freight) {
            this.freight = freight
        },
        //end modal country shipping
        getProductType: function () {
            let _this = this;
            axios.get(appUrl+'/import/product_type')
                .then(function (response) {
                    const x = response.data.product_type;
                    _this.product_type = x
                })
                .catch(function (error) {

                })
        },
        selectType: function(obj_type) {
            this.product = Object.assign({}, this.product, { type: obj_type })
            this.product.product_type = obj_type.name
            axios.post(appUrl+'/import/products', {product: this.product})
                .then(function (response) {
                    let { data } = response
                })
                .catch(function (error) {

                })
        },

        removeproductType:function () {
            this.product.product_type='';
            axios.post(appUrl+'/import/products', {product: this.product})
                .then(function (response) {
                    let { data } = response
                })
                .catch(function (error) {

                })
        },
        keyupProductType: function(event) {
            let target = event.currentTarget
            $(target).parents('.box-dropdown').removeClass('open')
            $(target).parents('.box-dropdown.dropdown-product-type').addClass('open-keep-label')
            if($(target).val()==''){
                $(target).parents('.box-dropdown').addClass('open')
                $(target).parents('.box-dropdown.dropdown-product-type').removeClass('open-keep-label')
            }
        },
        keyupEnterProductType:function(e){
            let target = event.currentTarget
            let valCollection=$(target).val().trim()
            if(valCollection!=''){
                this.product.product_type = valCollection
                $(target).val('')
                $(target).parents('.box-dropdown').addClass('open')
                $(target).parents('.box-dropdown.dropdown-product-type').removeClass('open-keep-label')
                axios.post(appUrl+'/import/products', {product: this.product})
                    .then(function (response) {
                        let { data } = response
                    })
                    .catch(function (error) {

                    })
            }
        },

        /*collection*/
        /*setCollection: function (value) {
            let _this = this
            if(value && _.isObject(value))
            {
                Object.values(value).forEach(function (collect) {
                    _this.obj_collections.push({
                        id: collect.id,
                        title:  collect.title,
                        selected: false
                    })
                })
            }

            if(this.product.custom_collection) {
                this.obj_collections = this.obj_collections.map(function(collection) {
                    if(_this.product.custom_collection.includes(collection.id)) {
                        _this.current_collection.push(collection)
                    }
                    return collection
                })
            }
            console.log('cus',_this.custom_collection)
            console.log('current',_this.obj_collections)
        },*/

        setCollection:function(custom_collection){
            let _this=this
            if(custom_collection){
                let length_obj_collection = _this.obj_collections.length;
                let length_custom_collection = custom_collection.length
                for(var i= 0; i<length_custom_collection;i++)
                {
                    for(var j=0;j<length_obj_collection;j++){
                        if(_this.obj_collections[j].id==custom_collection[i]){
                            _this.obj_collections[j].selected=true
                            _this.current_collection.push(_this.obj_collections[j])
                        }
                    }
                }
            }
        },
        addCollection:function (obj_collection) {
            let _this = this
            this.obj_collections = this.obj_collections.map(function (collection) {
                if(obj_collection.id === collection.id) {
                    collection = Object.assign({}, collection, {
                        selected: true,
                    })
                }
                if(_this.product.custom_collection != null) {
                    if( ! _this.product.custom_collection.includes(obj_collection.id)) {
                        _this.product.custom_collection.push(obj_collection.id)
                        _this.current_collection.push(obj_collection)
                    }
                } else {
                    _this.product.custom_collection = []
                    _this.product.custom_collection.push(obj_collection.id)
                    _this.current_collection.push(obj_collection)
                }
                return collection
            })

            let target=event.currentTarget
            $(target).parents('.dropdown-collection').find('.result-multiselect li:last-child input').val('')
            $(target).parents('.dropdown-collection').find('.box-dropdown-menu li').css('display','block')

            axios.post(appUrl+'/import/products', {product: this.product})
                .then(function (response) {
                    let { data } = response
                })
                .catch(function (error) {

                })
        },

        removeCollection:function (obj_collection) {
            let target=event.currentTarget
            $(target).parents('.dropdown-collection').addClass('open')
            let _this = this
            _this.obj_collections = _this.obj_collections.map(function (collection) {
                if(obj_collection.id === collection.id) {
                    collection = Object.assign({}, collection, {
                        selected: false,
                    })
                }
                return collection
            })
            if(_this.product.custom_collection!=null) {
                var index = _this.product.custom_collection.indexOf(obj_collection.id);
                if (index > -1) {
                    _this.product.custom_collection.splice(index, 1);
                    _this.current_collection.splice(index, 1);
                }
            }
            axios.post(appUrl+'/import/products', {product: this.product})
                .then(function (response) {
                    let { data } = response
                })
                .catch(function (error) {

                })

        },

        keyupCollection:function () {
            let target=$(event.currentTarget)
            let val=target.val().toLowerCase()
            $(target).parents('.dropdown-collection').find('.box-dropdown-menu li').each(function () {
                if(val!='') {
                    var value = $(this).text()
                    if (value.toLowerCase().indexOf(val) >= 0) {
                        $(this).css('display', 'block')
                    }
                    else {
                        $(this).css('display', 'none')
                    }
                }
                else{
                    $(this).css('display', 'block')
                }
            })
        },

        sortImage: function(data) {
            this.product.product_image = data
            this.product.image = data[0].src
        },
        checkAllImage(e) {
            let _this = this
            if(e.target.checked == true) {
                // select all image non select
                _this.imageSort.forEach(function(image) {
                    if(!image.status) {
                        image.status = true
                        image.selected = true
                        _this.selectImage(image);
                    }
                });
            } else {
                _this.imageSort.forEach(function(image, index) {
                    if(image.status && index > 0) {
                        image.status = false
                        image.selected = false
                        _this.selectImage(image);
                    }
                });
            }
        },
        imageSelected() { // need improve
            if(typeof this.product.product_image == "undefined") {
                return 0
            }
            return this.product.product_image.filter(function (image) {
                return (image.selected == true || image.status == true)
            }).length;
        },

        getAllOptionVariant: function (variant) {
            let _this = this;
            for(let i=0;i<variant.length;i++){
                variant[i].optionNew=new Object();
                for(let j=0;j<_this.options.length;j++){
                    let optionKey=_this.options[j].name
                    let value='option'+(j+1)
                    variant[i].optionNew[optionKey]=variant[i][value];
                }
            }

            this.variants = variant
            this.variants = this.variants.map(function (variant) {
                variant.selected = true
                return variant
            })

            this.optionFilter = {}

            variant.forEach(function (variant) {
                for (let optionKey in variant.optionNew) {
                    if (typeof _this.optionFilter[optionKey] == 'undefined') {
                        _this.optionFilter[optionKey] = {
                            [variant.optionNew[optionKey]]: {
                                selected: true,
                                total: 1
                            }
                        }
                    } else {
                        if (typeof _this.optionFilter[optionKey][variant.optionNew[optionKey]] == 'undefined') {
                            _this.optionFilter[optionKey][variant.optionNew[optionKey]] = {
                                selected: true,
                                total: 1
                            }
                        } else {
                            _this.optionFilter[optionKey][variant.optionNew[optionKey]]['total']++
                        }
                    }
                }
            });

            _this.countOptionFilter = JSON.parse(JSON.stringify(_this.optionFilter))

            this.numVariantSelected = this.lengthVariantChecked(variant)
            this.totalVariant=this.getTotalVariant(variant)
        },
        selectOptionFilter(option) {
            let _this = this
            let filterOject = {}
            let allEmpty = true
            let count = 0

            Object.keys(this.optionFilter).forEach(function (key) {
                filterOject[key] = Object.keys(_this.optionFilter[key]).filter(function (keyValue) {
                    return _this.optionFilter[key][keyValue]['selected'] == true
                })
            })

            if(Object.keys(filterOject).filter(function(key) {
                return filterOject[key].length > 0
            }).length > 0) {
                allEmpty = false
            }
            this.product.product_variant = this.product.product_variant.map(function (variant) {
                if(allEmpty == true) {
                    variant.selected = false
                } else {
                    variant.selected = _this.isAnd
                    for (let key in filterOject) {
                        if(_this.isAnd) {
                            if (filterOject[key].length != 0 && filterOject[key].indexOf(variant.optionNew[key]) == -1) {
                                variant.selected = false
                            }
                        } else {
                            if (filterOject[key].length != 0 && filterOject[key].indexOf(variant.optionNew[key]) > -1) {
                                variant.selected = true
                            }
                        }
                    }
                }
                return variant
            });
            _this.numVariantSelected = _this.lengthVariantChecked(_this.product.product_variant)

            if(_this.numVariantSelected ==0){
                _this.product.product_variant[0].selected = true

                for(let key in _this.optionFilter){
                    _this.optionFilter[key][_this.product.product_variant[0].optionNew[key]].selected=true
                    _this.optionFilter[key][_this.product.product_variant[0].optionNew[key]].total++
                }
                notify('success', 'The variants were successfully unselected. Note at least one variant must stay selected')
                notify('warning', 'You must select at least 1 variant.')

                _this.numVariantSelected = 1
            }
        },

        getTotalVariant: function (variant) {

            return variant.length;
        },

        showInputChangePrice: function () {
            this.showChangeComparePrice = false
            this.showChangePrice = true
        },
        showInputChangeComparePrice: function () {
            this.showChangePrice = false
            this.showChangeComparePrice = true
        },
        saveChangePrice:function () {
            let _this = this

            for (let key in _this.product.product_variant){
                if(_this.product.product_variant[key].selected)
                    _this.product.product_variant[key].price = Number(_this.priceVariantSelect).toFixed(2)
            }
            _this.priceVariantSelect = null
            //hide input change price
            _this.showChangePrice = false
            _this.profit_calculate()
        },
        saveChangeComparePrice:function () {
            let _this = this

            for (let key in _this.product.product_variant){
                if(_this.product.product_variant[key].selected)
                    _this.product.product_variant[key].compare_at_price = Number(_this.comparePriceVariantSelect).toFixed(2)
            }
            _this.comparePriceVariantSelect = null
            //hide input change compare price
            _this.showChangeComparePrice = false
            _this.profit_calculate()
        }
    },
    computed: {
        imageSort() {
            if(typeof this.product.product_image == "undefined") {
                return []
            }
            return this.product.product_image.sort(function (image1, image2) {
                return image1.sort - image2.sort
            });
        }
    },
    watch:{
        numVariantSelected:function(value){
            if(value == this.product.product_variant.length) this.selectAll = true
            else this.selectAll = false

        },
    }
})
