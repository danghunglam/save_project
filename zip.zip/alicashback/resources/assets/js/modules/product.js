import add_variant_aliexpress from '../components/product/add_variant_aliexpress.vue'
import override_product from '../components/product/override_product.vue'
import delete_product from '../components/product/delete_product.vue'
import import_all_reviews from '../components/product/import_review/modal_import_all_reviews.vue'
import import_reviews from '../components/product/import_review/modal_import_reviews.vue'
import modal_install_alireview from '../components/product/import_review/modal_install_alireviews'
import toast_process from '../components/common/toast_process'
import Pusher from "pusher-js"
import add_variant from '../components/product/add_variant/add_variant_modal'


import vue_loaders_circle from '../components/common/vue_loaders_circle'

new Vue({
    el : '#page-products',
    data: {
        step: null,
        products: [],
        total_product: 0,
        fetchProductComplete: false,
        pagination_html: '',
        product_current: {
            step : null,
            product_image : null,
            product_title : null,
            product_id : '',
            supplier_name : '',
            supplier_url : '',
            source_product_link: '',
            listen_variant_aliexpress: false,
            source_product_link_override: ''
        },
        override_product: {},
        add_variant_product: {},
        settings: {},
        override_process: [],
        override_process_type: ['override_product','add_variant_product'],
        alireviews_default_setting: {},
        // alireviews_countries: {},
        shopify_domain: '',
        product_id: null,
        countries: {},
        alireviews_api_url: window.alireviews_api,
        alireviews_url : window.alireviews_url,
        api_popup_review_return: false,
        isInstallAlireviews: false,
        loading: true,
        process_title: 'Processing product'
    },
    created: function () {
        let _this = this;
        this.getProducts();
        axios.get(appUrl+'/setting/all')
            .then(function (response) {
                let {status, settings} = response.data
                _this.settings = settings
            })
            .catch(function (error) {
                console.log(error)
            })
        let fullDomain = $('li.shopify-profile').find('span').text();
        _this.shopify_domain = fullDomain;
        let subDomain = fullDomain.substr(0, fullDomain.length - 14);
        let checkInstallAlireviewsRequest = _this.alireviews_api_url+'/v1/shops/me?subdomain='+subDomain;
        console.log('checkInstallAlireviewsRequest',checkInstallAlireviewsRequest )
        fetch(checkInstallAlireviewsRequest)
            .then((response) => response.json())
            .then((responseJSON) => {
                console.log('responseJSON',responseJSON)
                let {status} = responseJSON;
                if(status) {
                    _this.isInstallAlireviews = true;
                    let getDefaultSettingRequest = _this.alireviews_api_url+'/v1/shops/settings/'+subDomain;
                    fetch(getDefaultSettingRequest)
                        .then((response) => response.json())
                        .then((responseJSON) => {
                            let {result, status} = responseJSON;
                            if(status) {
                                _this.alireviews_default_setting = result;
                                _this.api_popup_review_return = true;
                            }
                        })
                        .catch(function (error) {
                            console.log(error)
                        });
                }
            })
            .catch(function (error) {
                console.log(error)
            });
    },
    mounted: function () {
        let _this = this;
        //Shop Domain
        $('.filter-product-status').multiselect({
            enableHTML: true,
            enableFiltering: false,
            buttonContainer: '<div class="selected-parents-container-dropdown select-no-checked"></div>',
        }).change(function (event) {
            $('form#filter-product').submit();
        });
        window.getVariantAliexpress = function(args)
        {
            _this.product_current = Object.assign({}, _this.product_current, {
                supplier_name: args.supplierName,
                supplier_url: args.supplierLink.replace(/^\/\//,''),
                supplier_id: (args.supplierLink) ? args.supplierLink.match(/[0-9]+$/)[0] : null,
                skus: args.skus,
                listen_variant_aliexpress: true
            })
        }
        $('#language-of-reviews').multiselect({
            enableHTML: true,
            enableFiltering: true,
            nonSelectedText: 'All language',
            buttonContainer: '<div class="selected-parents-container"></div>',
            // optionLabel: function (element) {
            //     return '<span class="' + $(element).data('icon-class') + '"></span>' + $(element).text();
            // }
        })
        //Get override process
        this.getToastProcess()
        //Listen pusher
        _this.pusherSubscribe()

        if(jQuery('#data_shop_id').length > 0) {
            this.shopId = $('#data_shop_id').val();
        }
    },
    components: {
        add_variant_aliexpress,
        override_product,
        delete_product,
        import_all_reviews,
        import_reviews,
        toast_process,
        modal_install_alireview,
        vue_loaders_circle,
        add_variant
    },
    methods: {
        getProducts: function () {
            let _this = this;
            axios.get(appUrl+'/products/all', { params: window.product_filter })
                .then(function (res) {
                    let { data } = res;
                    if(data.products) {
                        _this.products = _this.formatProduct(data.products.data);
                        _this.pagination_html = data.pagination_html;
                        _this.total_product = data.products.total;
                    } else {
                        _this.products = null;
                    }
                    _this.fetchProductComplete = true;
                    _this.loading = false
                }).catch(function (error) {
                console.log(error)
                _this.loading = false
            });
        },
        showPriceRange(product) {
            let priceRange = '', sourcrPriceRange = ''
            if(product.minPrice == product.maxPrice) {
                priceRange = '$' + product.minPrice
            } else {
                priceRange = '$' + product.minPrice + '<span>-</span>' + '$' + product.maxPrice
            }

            if(product.minSourcePrice == product.maxSourcePrice) {
                sourcrPriceRange = '$' + product.maxSourcePrice
            } else {
                sourcrPriceRange = '$' + product.minSourcePrice + '<span>-</span>' + '$' + product.maxSourcePrice
            }
            let htmlLabel = '<span class="ao__rangce_price"><b>Price:</b> ' + priceRange + '</span>'
            if(product.minSourcePrice && product.maxSourcePrice) {
                htmlLabel += '<span class="ao__rangce_cost"><b>Cost:</b> ' + sourcrPriceRange + '</span>'
            }
            return htmlLabel
        },
        formatProduct(data) {
            return data.map(function (product) {
                if(product.product_variant.length > 0) {
                    let minSourcePrice, maxSourcePrice, minPrice, maxPrice;
                    minSourcePrice = product.product_variant[0].source_price
                    maxSourcePrice = product.product_variant[0].source_price
                    minPrice = product.product_variant[0].price
                    maxPrice = product.product_variant[0].price
                    product.product_variant.forEach(function (item) {
                        if(parseFloat(item.source_price) > parseFloat(maxSourcePrice)) {
                            maxSourcePrice = item.source_price;
                        }

                        if(parseFloat(item.source_price) < parseFloat(minSourcePrice))
                            minSourcePrice = item.source_price;

                        if(parseFloat(item.price) < parseFloat(minPrice))
                            minPrice = item.price;

                        if(parseFloat(item.price) > parseFloat(maxPrice))
                            maxPrice = item.price;
                    })
                    if(maxSourcePrice) {
                        product.maxSourcePrice = parseFloat(maxSourcePrice).toFixed(2)
                    }

                    if(minSourcePrice) {
                        product.minSourcePrice = parseFloat(minSourcePrice).toFixed(2)
                    }
                    
                    product.minPrice = parseFloat(minPrice / window.exchange).toFixed(2);
                    product.maxPrice = parseFloat(maxPrice / window.exchange).toFixed(2);
                    
                }
                return product
            });
        },
        formatImage(img) {
            return img
        },
        setToastProcess: function (products) {
            let _this = this
            axios.post(appUrl+'/toast_process', {products: products, type: _this.override_process_type})
        },
        getToastProcess: function () {
            let _this = this

            axios.get(appUrl+'/toast_process', {
                params: {
                    type: _this.override_process_type
                }
            })
                .then(function (response) {
                    _this.override_process = response.data
                })
                .catch(function (error) {
                    console.log(error)
                })
        },
        closeToastProcess: function (process) {
            this.override_process.forEach(element => {
                $(`#product-list-item-${element.product_id}`).removeClass('product_process_override')
            });
            this.override_process = process
        },
        //Push queue show process override
        overrideProcess: function (product,type) {
            let _this = this
            $('#overrideProductModal').modal('hide')
            product = Object.assign({}, product, {
                product_link: 'https://'+shopDomain+'/admin/products/'+product.id,
                status: 'pending'
            })
            _this.override_process.forEach(function (item) {
                if(item.type === 'override_product') {
                    _this.process_title= 'Overriding product'
                    item.data.unshift(product)
                }
            })
            // this.setToastProcess(this.override_process)
        },
        addVariantProcess: function (product) {
            let _this = this
            $('#addVariantProductModal').modal('hide')
            product = Object.assign({}, product, {
                product_link: 'https://'+shopDomain+'/admin/products/'+product.id,
                status: 'pending'
            })
            _this.override_process.forEach(function (item) {
                if(item.type === 'add_variant_product') {
                    _this.process_title= 'Adding variant'
                    if( typeof item.data ==='object') item.data = Object.values(item.data)
                    item.data.unshift(product)
                }
            })
            console.log(_this.override_process)
            // this.setToastProcess(this.override_process)
        },
        pusherSubscribe: function () {
            let _this = this;
            let pusher = new Pusher(pusherEnv.app_key, {
                cluster: pusherEnv.app_cluster,
                encrypted: true
            });
            let channel = pusher.subscribe(shopId);

            channel.bind('override_product', function(product) {
                console.log('bind', product)
                _this.override_process = _this.override_process.map(function (process_with_type) {
                    if(_this.override_process_type.indexOf(process_with_type.type) == -1)
                        return process_with_type
                    else {
                        return {
                            type: process_with_type.type,
                            data: process_with_type.data.map(function (product_process) {
                                if(product.product.id === product_process.id) {
                                    if(product.product.status == 'success') {
                                        return Object.assign({}, product_process, {
                                            status: 'success',
                                            product_link: product.product.product_link
                                        })
                                    } else if(product.product.status == 'error' && product_process.status != 'success') {
                                        return Object.assign({}, product_process, {
                                            status: 'error'
                                        })
                                    }
                                }
                                else {
                                    return product_process
                                }
                            })
                        }
                    }
                })
                // _this.setToastProcess(_this.override_process)
            });

            channel.bind('add_variant_product', function(product) {
                _this.override_process = _this.override_process.map(function (process_with_type) {
                    if(_this.override_process_type.indexOf(process_with_type.type) == -1)
                        return process_with_type
                    else {
                        return {
                            type: process_with_type.type,
                            data: process_with_type.data.map(function (product_process) {
                                if(product.product.id === product_process.id) {
                                    if(product.product.status == 'success') {
                                        return Object.assign({}, product_process, {
                                            status: 'success',
                                            product_link: product_process.product_link
                                        })
                                    } else if(product.product.status == 'error' && product_process.status != 'success') {
                                        return Object.assign({}, product_process, {
                                            status: 'error'
                                        })
                                    } else if(product.product.status){

                                        notify('error',product.product.message.message.message)
                                        return Object.assign({}, product_process, {
                                            status: 'error'
                                        })
                                    }
                                }
                                else {
                                    return product_process
                                }
                            })
                        }
                    }
                })
                // _this.setToastProcess(_this.override_process)
            });
        },
        deleteProduct: function (product) {
            let _this = this
            _this.currentProduct = {}

            _this.product_current = Object.assign({}, _this.product_current,
                {
                    product_image : (product.image ? product.image : appUrl+'/images/default.png'),
                    product_title: product.title,
                    product_id : product.id
                });

            $('#deleteProduct').modal();
        },
        addNewVariantProduct:function(product){
            if( ! checkExtension())
                return false

            this.add_variant_product = {}

            this.product_current = {}
            this.product_current = product
            this.product_current.step =  'add_link'
            this.product_current.product_image = product.image ? product.image : appUrl+'/images/default.png'

            let total_variant_select = 100 - this.product_current.product_variant.length

            if(total_variant_select === 0){
                notify('warning', 'Your product has 100 variants already. Can not add new variant.')
                return false
            }

            $('#addVariantProductModal').modal()
        },
        addVariantProduct: function (product) {
            if( ! checkExtension())
                return false

            this.product_current = {}
            // this.currentProduct = 'start'
            this.product_current = Object.assign({}, this.product_current,
                {
                    step: 'start',
                    product_image : (product.image ? product.image : appUrl+'/images/default.png'),
                    product_title: product.title,
                    product_id : product.id
                });

            $('#addVariantAliexpress').modal();
        },
        overrideProduct: function (product) {
            if( ! checkExtension())
                return false;
    
            this.product_current = Object.assign({}, product,
                {
                    step: 'input_link',
                    product_image : (product.image ? product.image : appUrl+'/images/default.png'),
                    product_title: product.title,
                    product_id : product.id
                });

            $('#overrideProductModal').modal();
        },
        filters: function () {
            $('form#filter-product').submit();
        },
        inputAliexpress: function (source_product_link) {
            this.product_current.source_product_link = source_product_link;
        },
        editProduct: function (product_id) {
            window.open(appUrl+'/products/edit/'+product_id, '_blank')
        },
        importAllReviews: function() {
            if(!checkAlireviewsExtension()) {
                return false;
            }
            // let _this = this
            // if( ! checkExtension())
            //     return false
            //
            // if(!_this.api_popup_review_return)
            //     $('#popup-install-alireview').modal('show');
            // else
            //     $('#import-all-reviews-modal').modal();
        },
        importReviews: function(product) {
            let _this = this;
            let isInstallAliorderExt =  checkExtension()
            if( ! checkExtension())
                return false

            if(isInstallAliorderExt && _this.isInstallAlireviews) {
                _this.product_current = product
                $('#import-reviews-modal').modal('show')
                return
            }else{
                $('#popup-install-alireview').modal('show')
            }
        },
        updatePrice:function (event, product) {
            product.auto_update_price = $(event.currentTarget).is(':checked') ? 1 : 2;
            axios.post(appUrl+'/products/auto_update_price', {productId: product.id, checked: $(event.currentTarget).is(':checked')})
                .then(function (response) {
                    let { status } = response.data
                    if(status) {
                    }
                })
                .catch(function (error) {
                    notify('error', error);
                })
        },
        manageReview:function (shopDomain,product) {
            let _this = this
            // let port = chrome.runtime.connect(chromeExtensionId);
            // const payloadMessage = {
            //     data: {
            //         action: 'ACTION_CHECK_ALIREVIEWS_LOGIN_STATUS',
            //         payload: {shop_domain: shopDomain,link:_this.alireviews_url+'/manage-reviews/'+product.id}
            //     }
            // }
            // port.postMessage(payloadMessage);
            // port.disconnect()
            if( ! checkExtension())
                return false

            window.postMessage({action: 'ACTION_CHECK_ALIREVIEWS_LOGIN_STATUS', payload: {shop_domain: shopDomain,link:_this.alireviews_url+'/manage-reviews/'+product.id}}, '*')
            _this.showAlert()
        },
        showAlert:function () {
            let _this = this

            this.$nextTick(function () {
                window.notifyExtensiond = function(msg)
                {
                   notify('error',msg.message)
                }
            })
        }
    },
    computed: {
        getTotalItemHtml: function() {
            let htmlTotalItem = 'Total: '
            if(!this.total_product || this.total_product == 0) {
                htmlTotalItem += '<span class="fw-600">0</span> Products';
            } else {
                if(this.total_product == 1){
                    htmlTotalItem += '<span class="fw-600">' + this.total_product + '</span> Product'
                }
                else{
                    htmlTotalItem += '<span class="fw-600">' + this.total_product + '</span> Products'
                }
            }
            return htmlTotalItem;
        }
    },
    watch: {
        override_process: function(value) {
            value.forEach(element => {
                if(element.override_status == 'success') {
                    $(`#product-list-item-${element.product_id}`).removeClass('product_process_override')
                } else {
                    $(`#product-list-item-${element.product_id}`).addClass('product_process_override')
                }
            });
        },

    }
});
