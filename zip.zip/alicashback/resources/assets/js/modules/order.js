import add_variant_aliexpress from '../components/product/add_variant_aliexpress'
import send_message_customer from '../components/order/send_message_customer'
import modal_shipping from '../components/order/modal_shipping'
import modal_shippings from '../components/order/model_shippings'
import modal_trackingcode from '../components/tracking_code/modal_trackingCode'
import line_item from '../components/order/line_item'
import pagination from '../components/common/pagination'
import modal_place_page_orders from '../components/order/modal_place_page_orders'
import toast_process from '../components/common/toast_process'
import moment from 'moment-timezone'
import Pusher from 'pusher-js'
import queryString from 'query-string'
import vue_loaders_circle from '../components/common/vue_loaders_circle'
import popup_import_tracking_code from '../components/order/popup_import_tracking_code'
import toast_process_percent from '../components/common/toast_process_percent'
import _ from "lodash";

new Vue({
    el: '#order-fulfillment',
    data: {
        currentProduct: {
            step : '',
            product_image : '',
            product_title : '',
            product_id : '',
            supplier_name : '',
            supplier_url : '',
            source_product_link: '',
            listen_variant_aliexpress: false
        },
        customer: {
        },
        statusCount: {
            total: 0,
            to_order: 0,
            order_placed: 0,
            shipped: 0
        },
        orders: {},
        filters: {
            keyword: '',
            fulfillment_status: [],
            financial_status: [],
            flag: [],
            status: [1],
            date_range : 'last_30days',
            filter_date_from : moment(this.date_to).add(-1, 'month').format('MMM DD, YYYY'),
            filter_date_to   : moment().format('MMM DD, YYYY'),
            paged: 1
        },
        orderStatus: [],
        fulfillmentStatus : [],
        financialStatus : [],
        classStatus: {
            1 : 'status-to-order',
            2 : 'status-order-placed',
            3 : 'status-shipped'
        },
        flags: {},
        current_flag: 'none',
        itemDetail: {},
        itemsDetail: [],
        shopId : '',
        errors: {
            tracking_code: {}
        },
        shopDomain : '',
        accessToken : '',
        settings: {},
        is_export: {
            csv: false,
            xls: false
        },
        pagination: [],
        loading: true,
        loading_page: true,
        loading_filter: true,
        trackingCodeId:'',
        is_sync_ali_order_no: false,
        is_get_tracking_code: false,
        tracking_code_process: [],
        tracking_code_process_type: ['tracking_code_from_file'],
        filter_search: true,
        process_percent:[]
    },
    created: function () {
        let _this = this
        _this.loading_page = true
        axios.get(appUrl+'/orders/config')
            .then(function (response) {
                let {status = false,
                    orderStatus = {},
                    fulfillmentStatus = {},
                    financialStatus = {},
                    flags = {}
                } = response.data
                _this.orderStatus = Object.assign({}, orderStatus)
                _this.fulfillmentStatus = Object.assign({}, fulfillmentStatus)
                _this.financialStatus = Object.assign({}, financialStatus )
                _this.flags = Object.assign({}, flags)
            })
            .catch(function (error) {

            })

        //Get default setting
        axios.get(appUrl+'/setting/all')
            .then(function (response) {
                let {status, settings} = response.data
                if(typeof settings.automation_fulfillment == 'undefined') {
                    settings.automation_fulfillment = 1
                }
                if( ! status)
                    console.log('Get settings error')
                else
                    _this.settings = Object.assign(_this.settings, settings);
            })
            .catch(function (error) {
                console.log(error)
            })
        this.checkFilterOrder()
    },
    mounted: function () {
        let _this = this;
        let queryString = _this.getQueryString();
        //init build query string
        if(Object.keys(queryString).length) {
            //Get query string
            // _this.filters = {}
            _this.filters = Object.assign(_this.filters, queryString)
            if(queryString.reject_filter && Array.isArray(queryString.reject_filter)) {
                queryString.reject_filter.forEach(function (filter) {
                    delete _this.filters[filter]
                })
            }
        }
        //add paged to filters
        axios.get(appUrl+'/orders/all', { params: this.filters })
            .then(function (response) {
                let {status = false,
                    ordersData = {},
                    pagination = {}
                } = response.data

                let orderDt = ordersData
                _this.orders = _this.formatDataGroupSupplier(orderDt)
                for(let key in _this.orders) {
                    _this.orders[key] = Object.assign({}, _this.orders[key], {
                        save_order_note_button: false
                    })
                }
                // _this.orders = _this.orders.map(function(order) {
                //     let obj_order = Object.assign({}, order, { save_order_note_button: false })
                //     return obj_order
                // })
                _this.pagination = pagination
                _this.loading_page = false
                _this.loading_filter = false
                _this.updateStatusCount()
                if(orderDt.length==0){
                    _this.filter_search=true
                }
            })
            .catch(function (error) {
                console.log(error)
            });

        this.checkFilterOrder()

        let shopId = $('#data_shop_id').val();


        if(jQuery('#data_shop_id').length > 0) {
            this.shopId = $('#data_shop_id').val();
        }
        if(jQuery('#data_shop_domain').length > 0) {
            this.shopDomain = $('#data_shop_domain').val();
        }

        if(jQuery('#data_access_token').length > 0)
        {
            this.accessToken = $('#data_access_token').val();
        }

        this.shopId = window.shopId
        this.shopDomain = window.shopDomain
        _this.accessToken = window.accessToken
        //Listen from extension
        window.getVariantAliexpress = function(args)
        {
            _this.currentProduct.supplier_name = args.supplierName;
            _this.currentProduct.supplier_url = args.supplierLink.replace(/^\/\//,'');
            _this.currentProduct.supplier_id = (args.supplierLink) ? args.supplierLink.match(/[0-9]+$/)[0] : null;
            _this.currentProduct.skus = args.skus;
            _this.currentProduct.listen_variant_aliexpress = true;
        };

        window.getTrackingCodeSuccess = function(args) {
            notify('success', 'Get tracking code successfully');
            $('body').find('.loading-blur-o').remove();
        }

        // window.setPercentProcess = function(obj) {
        //     let index = _.findIndex(_this.process_percent, {type: obj.type})
        //     console.log('obj.percent', obj)
        //     if(index >= 0)
        //     {
        //         console.log(_this.process_percent[index])
        //         _this.process_percent[index].percent = obj.percent
        //         console.log('obj.percent', obj.percent)
        //         if(obj.percent == 100) {
        //             document.querySelector('#ao__1_click_spin').classList.remove('animate-spin')
        //         }
        //     } else {
        //         _this.process_percent.push(obj)
        //     }

        // }

        jQuery('[data-toggle="tooltip"]').tooltip({
            html: true,
            container: 'body'
        });

        //Pusher
        this.pusherSubscribe(this.shopId)
        //Default selected
        //this.selectedFilter()

        // _.forEach(this.orders, function(value, key) {
        //     // console.log('value', value);
        //     $(`.order-id-${value.id}`).scroll(function() {
        //         let _this = this
        //         console.log('this.offsetTop', $(_this).scrollTop())
        //     })

        // })
        // $(window).scroll(function() {
        //     let _this = this
        //     _.forEach(this.orders, function(value, key) {
        //         // console.log('order-id:', $(`.order-id-${value.id}`))
        //         console.log('$(this).scrollTop()', $('#order-id-520110112802').scrollTop())
        //     })
        // })

        // $(window).scroll(function() {
        //     console.log($(this).scrollTop())
        // })

        let autoExpand = function (field) {

            // Reset field height
            field.style.height = 'inherit';

            // Get the computed styles for the element
            let computed = window.getComputedStyle(field);

            // Calculate the height
            let height = field.scrollHeight

            field.style.height = height + 'px';

        };

        document.addEventListener('input', function (event) {
            if ((event.target.tagName.toLowerCase() == 'textarea') && (event.target.className == 'order_note-textarea') ) {
                autoExpand(event.target);
            } else {
                return false
            }

        }, false);

        let orders_button_notify_close = localStorage.getItem('orders_button_notify_close')
        if(orders_button_notify_close) {
            $('.orders__notify-wrap').hide()
        } else {
            $('.orders__notify-wrap').show()
        }
        $('.button__notify-close').on('click', function() {
            localStorage.setItem('orders_button_notify_close', true)
            $('.orders__notify-wrap').hide()
        })
    },
    components: {
        add_variant_aliexpress,
        send_message_customer,
        modal_shipping,
        modal_trackingcode,
        pagination,
        modal_place_page_orders,
        popup_import_tracking_code,
        line_item,
        vue_loaders_circle,
        toast_process,
        toast_process_percent,
        modal_shippings
    },

    methods: {
        updateStatusCount() {
            let _this = this;
            axios.get(appUrl+'/orders/count/status', { params: this.filters })
                .then(function (response) {
                    let {status = false,
                        data = {}
                    } = response.data
                    _this.statusCount = data
                })
                .catch(function (error) {
                    console.log(error)
                });
        },
        formatDataGroupSupplier(orderDt) {
            orderDt = _.mapValues(orderDt, function (order) {
                let lineItemGroup = [];
                _.forEach(order.line_items, function (lineItem) {
                    let tmpCheck = false;
                    _.forEach(lineItemGroup, function(group) {
                        if(lineItem.status == group.status
                            && lineItem.supplier_id != null
                            && lineItem.supplier_id == group.supplier_id
                            && lineItem.tracking_code == group.tracking_code) {
                            group.lineItem[lineItem.id] = lineItem;
                            group.line_item_ids.push(lineItem.id)
                            tmpCheck = true;
                            return false;
                        }
                    });
                    if(!tmpCheck) {
                        lineItemGroup.push({
                            status: lineItem.status,
                            supplier_id: lineItem.supplier_id,
                            tracking_code: lineItem.tracking_code,
                            line_item_ids: [lineItem.id],

                            lineItem: {
                                [lineItem.id]: lineItem // init object line item
                            },
                            first_line_item: lineItem

                        })
                    }
                })
                order.lineItemGroup = lineItemGroup
                return order;
            });
            return orderDt
        },
        selectedFilter: function () {
            let _this = this
            let status = _this.filters.status ? _this.filters.status : []
        },
        totalLineItemShipping: function (line_items) {
            let count = 0
            for (let i = 0; i < line_items.length; i++)
            {
                if(line_items[i].status != 3)
                    count++
            }

            return count
        },
        orderHasSourceProductLink: function(line_items) {
            let lineItems = []
            for (let i = 0; i < line_items.length; i++)
            {
                if(line_items[i].source_product_link != '' && line_items[i].status == 1)
                    lineItems.push(line_items[i])
            }
            return lineItems
        },
        orderCanPlace(order) {
            return $('.order_product_' + order.id).length >= 2
        },
        setQueryString: function () {
            let _this = this
            let queryString = $.param(this.filters)
            history.pushState(this.filters, '', appUrl+'/orders?'+queryString)
        },
        getQueryString: function () {
            return queryString.parse(location.search, {arrayFormat: 'bracket'})
        },
        getOrders: function (filters, refresh = true) {
            let _this = this
            _this.filters = Object.assign({}, filters)
            _this.setQueryString()
            _this.loading_page = true
            axios.get(appUrl+'/orders/all', {params: filters})
                .then(function (response) {
                    let {status = false,
                        ordersData = {},
                        pagination = {}
                    } = response.data

                    let orderDt = ordersData
                    _this.orders = _this.formatDataGroupSupplier(orderDt)
                    _this.loading_page = false
                    _this.pagination = pagination
                    _this.updateStatusCount()
                    if(orderDt.length==0){
                        _this.filter_search=true
                    }
                })
                .catch(function (error) {
                    console.log(error)
                });
            console.log(_this.filter_search)
        },
        filterLineItemHasOptions: function(line_items) {
            return Object.values(line_items).filter(function (item) {
                return ((item.aliexpress_options || item.variant_title == 'Default Title' || !item.variant_options) && item.status == 1)
            })
        },
        showPlaceAll: function(line_items) {
            line_items = this.filterLineItemHasOptions(line_items)
            return (line_items.length > 1)
        },
        openNote: (ev) => {
            let target = ev.currentTarget;
            $(target).parents('.orders-list-header').addClass('active-add-note');

            const w_order_header = $(target).parents('.orders-list-header');
            const w_order_id = $(target).parents('.orders-list-header').find('.order-id').outerWidth();
            const w_order_date = $(target).parents('.orders-list-header').find('.order-date').outerWidth();
            const w_order_customer = $(target).parents('.orders-list-header').find('.order-customer').outerWidth();
            $(target).parents('.orders-list-header').find('.order-note').width(w_order_header - w_order_id - w_order_date - w_order_customer - 72);
        },
        saveNote: function(ev, orderId) {
            let target = ev.currentTarget;
            if($(target).val()==''){
                $(target).parent('.orders-notes-input').find('.order_note-textarea-border').css({ 'background' : '#E9E9F0'})
            }
            let orderNote = $(target).parent('.orders-notes-input').find('textarea').val()
            axios.post(appUrl+'/orders/update',{
                'orderId' : orderId,
                'note': orderNote
            }).then(function (response) {
                if(response.status)
                {
                    notify('success', 'Update note success');
                } else {
                    notify('error', 'Update note error');
                }
            }).catch(function (error) {
                notify('error', error);
            });
            this.orders[orderId] = Object.assign({}, this.orders[orderId], {
                note: orderNote,
                save_order_note_button: false
            })
            $(target).parents('.orders-list-notes').removeClass('show-notes')
        },
        saveNoteEmpty: function(ev, orderId) {
            let _this = this
            let target = ev.currentTarget;
            let orderNote = $(target).parent().find('textarea').val()
            axios.post(appUrl+'/orders/update',{
                'orderId' : orderId,
                'note': orderNote
            }).then(function (response) {
                if(response.status)
                {
                    notify('success', 'Update note success');
                    _this.orders[orderId] = Object.assign({}, _this.orders[orderId], { note: orderNote})
                } else {
                    notify('error', 'Update note error');
                }
            }).catch(function (error) {
                notify('error', error);
            });

            this.orders[orderId] = Object.assign({}, this.orders[orderId], {
                save_order_note_button: false
            })
        },
        placeAllOrder: function(event, order, line_item) {
            let _this = this
            if( ! checkExtension())
                return false

            let target = event.currentTarget;
            $('.order-list-item').removeClass('active')
            $('.orders-list-wrap').removeClass('active')
            $(target).parents('.orders-list-wrap').addClass('active')
            // let line_item_tmp
            line_item = this.filterLineItemHasOptions(line_item)

            let aliexpress = Object.values(line_item)[0]['source_product_link'];
            line_item = line_item.map(function (v, k) {
                // $('#order-list-item-' + v.id).addClass('active');
                return {
                    ali_ext_id: v.aliexpress_options,
                    quantity: v.quality,
                    product_ext_id: v.aliexpress_product_id,
                    source_product_link: v.source_product_link,
                    line_item_id: v.id,
                    total_price_item: v.total_price_item
                }
            })


            let orderItem = [{
                orderId: order.id,
                orderName: order.order_name,
                shipping_city: change_alias(order.city),
                shipping_country: change_alias(order.country),
                shipping_country_code: (order.country_code == 'GB' ? 'UK' : order.country_code),
                shipping_name: change_alias(order.full_name),
                shipping_phone: order.phone,
                shipping_phone_code: order.phone_code,
                shipping_province: change_alias(order.province),
                shipping_province_code: order.province_code,
                shipping_zip: order.zip,
                shipping_email: window.shopMail,
                currency: order.currency,
                shipping_address1: change_alias(order.address1),
                shipping_address2: change_alias(order.address2),
                total_price_order: order.total_price_order,
                orderitems: mergeLineItem(line_item),
            }]


            let port = chrome.runtime.connect(chromeExtensionId);
            const payloadMessage = {
                data: {
                    action: 'ACTION_ORDER_FULFILL',
                    payload: {
                        shop: _this.shopDomain,
                        orderData: orderItem,
                        default_setting: _this.settings,
                        maximum_cost: 0, maximum_order: 0,
                        place_this_order: true
                    }
                }
            }
            port.postMessage(payloadMessage);
            port.disconnect()
        },
        saveTrackingCode: function(items_detail, send_mail_customer, tracking_code) {
            let _this = this
            $(event.currentTarget).loading();

            items_detail.map(function(item,key) {
                axios.post(appUrl+'/orders/update_tracking_code', {item: item, send_mail_customer: send_mail_customer})
                    .then(function (response) {
                        const res = response.data;
                        if(res.status) {
                            const lineItemUpdate = res.lineItemUpdate;
                            _this.orders[lineItemUpdate.orders_id]['line_items'][lineItemUpdate.id]['status'] = lineItemUpdate.status;
                            _this.orders[lineItemUpdate.orders_id]['line_items'][lineItemUpdate.id]['tracking_code'] = lineItemUpdate.tracking_code;
                            _this.orders = _this.formatDataGroupSupplier(_this.orders)
                            notify('success', 'Update success');
                        } else {
                            notify('error', res.message);
                        }
                        $(event.currentTarget).loading_finish();
                        $('#productShippedModal').modal('hide');
                    })
                    .catch(function (error) {
                        $(event.currentTarget).loading_finish();
                        notify('error', error);
                    })
            })
        },
        saveMultipleTrackingCode: function(items_detail, send_mail_customer, tracking_code) {
            let _this = this
            $(event.currentTarget).loading();

            // items_detail.map(function(item,key) {
                axios.post(appUrl+'/orders/update_multiple_tracking_code', {data: items_detail, send_mail_customer: send_mail_customer, tracking_code: tracking_code})
                    .then(function (response) {
                        const res = response.data;
                        if(res.status) {
                            const lineItemUpdate = res.lineItemUpdate;
                            lineItemUpdate.forEach((item) => {
                                _this.orders[item.orders_id]['line_items'][item.id]['status'] = item.status;
                                _this.orders[item.orders_id]['line_items'][item.id]['tracking_code'] = item.tracking_code;
                                _this.orders = _this.formatDataGroupSupplier(_this.orders)
                                notify('success', 'Update success');
                            })


                        } else {
                            notify('error', res.message);
                        }
                        $(event.currentTarget).loading_finish();
                        $('#productShippedModal').modal('hide');
                    })
                    .catch(function (error) {
                        $(event.currentTarget).loading_finish();
                        notify('error', error);
                    })
            // })
        },
        //Open multi shipping modal
        openShippingsModal: function (line_items) {
            let _this = this
            this.errors.tracking_code = ''
            this.itemsDetail = []
            this.itemsDetail = Object.values(line_items).filter(function (line_item) {
                return ! line_item.tracking_code
            })

            $('#productShippedModal').modal()
        },
        //Open once shipping modal
        openShippingModal: function(line_item) {
            let _this = this
            this.$nextTick(function () {
                _this.itemsDetail = []
                _this.itemsDetail = line_item
                $('#productShippedModal').modal();
            })

        },
        //listen child emit add variant aliexpress
        inputAliexpress: function (source_product_link) {
            this.currentProduct = Object.assign({}, this.currentProduct, {source_product_link : source_product_link});
        },
        //Listen child emit list_item
        addVariantProduct: function (line_item) {

            if( ! checkExtension())
                return false

            this.currentProduct = Object.assign({}, this.currentProduct,
                {
                    step: 'start',
                    product_image : (line_item.product_variant_image),
                    product_title: line_item.product_title,
                    product_id : line_item.product_id,
                    source_product_link: line_item.product_has_source_link
                });
            console.log(this.currentProduct)
            $('#addVariantAliexpress').modal()
        },

        moment: function (time) {
            let time_zone = (this.settings.time_zone) ? this.settings.time_zone : 'UTC'
            return moment.utc(time).tz(time_zone);
        },

        copyToClipboard(element) {
            const $temp = $("<input>");
            $("body").append($temp);
            $temp.val($(element).text()).select();
            document.execCommand("copy");
            $temp.remove();
        },
        copyClipboard(event) {
            const target = event.currentTarget;
            const selector = $(target).parent().find('.customer-text-name');
            this.copyToClipboard(selector);
        },

        pusherSubscribe: function (shopId) {
            let self = this;
            let pusher = new Pusher(pusherEnv.app_key, {
                cluster: pusherEnv.app_cluster,
                encrypted: true
            });
            let channel = pusher.subscribe(shopId);
            let chk = 0; 
            channel.bind('sync_all_orders', function(data) {
                if(data.status) {
                    chk++;
                    if (chk == 3) {
                        $('.job-orders-btn').loading_finish();
                        chk = 0;
                    }
                }
            });
            channel.bind('update-view-order', function(data) {
                console.log(data)
                // self.processOrder = false;
                const line_item_id = data.lineItem.id;
                const type = data.type
                let success_noti = '';
                let error_noti = '';
                switch (type) {
                    case 'ali_order_number':
                        $('#order-list-item-'+line_item_id).removeClass('active');
                        $('#order-line-item-'+line_item_id).find('.order-loading').addClass('hidden');
                        success_noti = 'Fulfillment success'
                        error_noti = 'Fulfillment error'
                        break
                    case 'tracking_code':
                        $('body').loading_id_finish('tracking_code-'+line_item_id);
                        success_noti = 'Get tracking code success'
                        error_noti = 'Tracking code not found'
                        // test
                        if(data.status) {
                            const lineItemUpdate = data.lineItem;
                            self.orders[lineItemUpdate.orders_id]['line_items'][lineItemUpdate.id]['status'] = lineItemUpdate.status;
                            self.orders[lineItemUpdate.orders_id]['line_items'][lineItemUpdate.id]['tracking_code'] = lineItemUpdate.tracking_code;
                            self.orders = self.formatDataGroupSupplier(self.orders)
                        }
                        // end
                        break
                    default :
                        success_noti = 'Success'
                        error_noti = 'Error'
                        break
                }

                if( ! data.status)
                {
                    notify('error', error_noti);
                    $('body').find('.loading-blur-o').remove();
                    return false;
                }

                // const { orders_id, id } = data.lineItem;
                // console.log(data)
                // console.log(data.lineItem.aliexpress_order_no)
                //
                // const {line_items} = self.orders[orders_id];
                // console.log(line_items)
                // console.log(id)
                // let firstObj = line_items[id];
                // firstObj.aliexpress_order_no = data.lineItem.aliexpress_order_no;
                // firstObj.tracking_code = data.lineItem.tracking_code;
                // firstObj.status = data.lineItem.status;
                notify('success', success_noti);
            });

            channel.bind('tracking_code_from_file', function(product) {
                self.tracking_code_process = self.tracking_code_process.map(function (process_with_type) {
                    if(process_with_type.type !== 'tracking_code_from_file')
                        return process_with_type
                    else {
                        return {
                            type: process_with_type.type,
                            data: process_with_type.data.map(function (product_process) {

                                if(product.product.id == product_process.id)
                                {
                                    return Object.assign({}, product_process, {
                                        status: 'success'
                                    })
                                }

                                else
                                    return product_process
                            })
                        }
                    }
                })
                self.setToastProcess(self.tracking_code_process)
            });
        },
        showOrderCustomer: function (event) {
            let target = event.currentTarget;
            // $(target).parents('.box-orders-list-info').toggleClass('show-customer');
        },
        showOrderNotes: function(event) {
            let target = event.currentTarget;
            $(target).parent().addClass('show-notes');
            let _textarea = $(target).parent().find('textarea')
            $(_textarea).css({'height': $(_textarea).get(0).scrollHeight + 'px'})
            $(_textarea).focus()
        },
        blurHandle: function(event) {
            let target = event.currentTarget;
            let nextTarget = event.relatedTarget;
            if(!nextTarget || nextTarget.classList.value !== 'save-ali-order-note-btn') {
                $(target).parents('.orders-list-notes').removeClass('show-notes')
            }
        },
        closePromotionOrderProduct: function(event) {
            let _this = this
            $('.promotion-order-product-wrap').remove();
            axios.post(appUrl+'/shop/update', {shop_id: _this.shopId, is_hide_video: true});
        },
        sendMessageTo: function(order) {
            this.customer = Object.assign({}, this.customer, {
                full_name: order.full_name,
                email: order.email,
                title: `Hello ${order.full_name}, regarding your order ${order.order_name}`,
                content: `Hello ${order.full_name}!\n`
            })
            $('#send-message-to-modal').modal('show');
        },
        choiceFlag: function (flag, order_id) {
            let _this = this
            axios.post(appUrl+'/orders/update', {flag: flag, orderId: order_id})
                .then(function (response) {
                    let { status } = response.data
                    if(status) {
                        _this.orders[order_id].flag = flag
                        notify('success', 'Update success');
                    }
                })
                .catch(function (error) {
                    notify('error', error);
                })
        },
        clickPagination: function (paged) {
            let _this = this;
            this.filters.paged = paged
            this.pagination.current_page = paged
            this.getOrders(this.filters, false)

            _this.gotoOrder();

        },
        gotoOrder: function() {
            location.hash = "#order-fulfillment";
        },
        fulfillment_status:function (order) {
            if(order.fulfillment_status == null){
                return 1;
            }
            return order.fulfillment_status;
        },
        financial_status:function (order) {
            if(order.financial_status == null){
                return 1;
            }
            return order.financial_status;
        },
        placePageOrder: function() {

            if( ! checkExtension())
                return false

            $('#place-all-order-modal').modal();
        },
        classFulfillmentStatus: function(order) {
            if(this.fulfillmentStatus[this.fulfillment_status(order)]) {
                return `fulfillment-icon-status-${this.fulfillmentStatus[this.fulfillment_status(order)].toLowerCase().trim().replace(' ','-')}`
            }
        },
        classFinancialStatus: function(order) {
            if(this.financialStatus[this.financial_status(order)]) {
                return `financial-icon-status-${this.financialStatus[this.financial_status(order)].toLowerCase().trim().replace(' ','-')}`
            }
        },
        trackingCode:function (trackingCode) {
            let _this = this
            _this.trackingCodeId = trackingCode
            $('#trackingCodeModal').modal()
        },
        filterOrders: function() {
            this.getOrders(this.filters, false)
            $('body').find('.loading-blur-o').remove();
            this.checkFilterOrder()
        },
        filterOrdersStatus: function(event, status) {
            switch(status) {
                case 0:
                    this.filters.status = []
                    this.filters.status.push('1', '2', '3')
                    break
                case 1:
                    this.filters.status = []
                    this.filters.status.push(status)
                    break
                case 2:
                    this.filters.status = []
                    this.filters.status.push(status)
                    break
                case 3:
                    this.filters.status = []
                    this.filters.status.push(status)
                    break
            }
            this.filters.paged = 1;
            $('.tabs-orders-list').find('li').removeClass('active')
            $(event.currentTarget).addClass('active')
            this.getOrders(this.filters, false)
            $('body').find('.loading-blur-o').remove();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        },
        importFromFile: function() {
            $('#tracking-code-modal').modal('show')
        },
        getAllTrackingCode:function (orders) {
            let _this = this
            if( ! checkExtension())
                return false;
            _this.is_get_tracking_code = true;
            let lineItems = _this.addArrayLineItem(orders)
            const port = chrome.runtime.connect(chromeExtensionId);
            $(event.currentTarget).loading_spin();
            const payloadMsg = {
                data: {
                    action: 'ACTION_GET_TRACKING_CODE',
                    payload: {
                        data: lineItems,
                        shop_domain: _this.shopDomain,
                        access_token: _this.accessToken,
                        shop_id: _this.shopId,
                        bulk_all_tracking_code: true
                    }
                }
            }
            port.postMessage(payloadMsg);
            port.disconnect();
            setTimeout(function () {
                _this.is_get_tracking_code = false
            },3000)
        },
        addArrayLineItem: function (orders) {

            let items = []

            Object.values(orders).forEach(order=>{

                let line_items = order.line_items

                Object.values(line_items).forEach(line_item=>{

                    const { id = "", aliexpress_order_no = 0, tracking_code = ""} = line_item;

                    if (aliexpress_order_no && !tracking_code)
                    {
                        items.push({
                            line_item_id:[id],
                            ali_order_no: aliexpress_order_no
                        })
                    }
                })
            })
            return items
        },
        autoUpdateHeight: function(event, obj_order) {
            let target = event.currentTarget;
            $(target).parent('.orders-notes-input').find('.order_note-textarea-border').css({ 'background' : 'transparent'})
            this.orders[obj_order.id] = Object.assign({}, this.orders[obj_order.id], {
                save_order_note_button: true
            })
        },
        syncAliOrderNo:function () {
            let _this = this

            if( ! checkExtension())
                return false

            _this.is_sync_ali_order_no = true
            let port = chrome.runtime.connect(chromeExtensionId);
            const payloadMessage = {
                data: {
                    action: 'ACTION_SYNC_ORDERS_FROM_OBERLO',
                    payload: {
                        from_date: '2009-01-01',
                        to_date: moment().format('MMM DD, YYYY')
                    }
                }
            }
            port.postMessage(payloadMessage);
            port.disconnect()
            setTimeout(function () {
                _this.is_sync_ali_order_no = false
            },3000)
        },
        // pusherSubscribe: function () {
        //     let _this = this;
        //     let pusher = new Pusher(pusherEnv.app_key, {
        //         cluster: pusherEnv.app_cluster,
        //         encrypted: true
        //     });
        //     let channel = pusher.subscribe(shopId);
        //     channel.bind('tracking_code_from_file', function(product) {
        //         _this.tracking_code_process = _this.tracking_code_process.map(function (process_with_type) {
        //             if(process_with_type.type !== 'tracking_code_from_file')
        //                 return process_with_type
        //             else {
        //                 return {
        //                     type: process_with_type.type,
        //                     data: process_with_type.data.map(function (product_process) {
        //
        //                         if(product.product.id == product_process.id)
        //                         {
        //
        //                             return Object.assign({}, product_process, {
        //                                 status: 'success'
        //                             })
        //                         }
        //
        //                         else
        //                             return product_process
        //                     })
        //                 }
        //             }
        //         })
        //         _this.setToastProcess(_this.tracking_code_process)
        //     });
        // },
        setToastProcess: function (products) {
            let _this = this
            axios.post(appUrl+'/toast_process', {products: products, type: _this.tracking_code_process_type})
        },
        callPopup:function (e) {
            let _this = this
            _this.tracking_code_process=[{
                type : 'tracking_code_from_file',
                data : [{
                    id:e[0],
                    title : 'Get tracking code from file',
                    status : 'pending',
                }]
            }]
        },
        closeToastProcess: function () {
            this.tracking_code_process = []
        },

        checkFilterOrder:function () {
            if(this.filters.keyword ==='' && this.filters.fulfillment_status.length===0 && this.filters.financial_status.length===0 && this.filters.flag.length===0){
                this.filter_search=false
            }
            else {
                this.filter_search=true
            }
        },
        closeProcessPercent: function() {
            this.process_percent = []
        },

        exportFile: function () {
            let _this = this
            const urlParams = new URL(appUrl+'/orders/export');
            $.each(this.filters, function(index, value) {
                urlParams.searchParams.set(index, value);
            });

            window.open(urlParams.href, '_blank');
        },

        runJobOrders: function (event) {
            var createdAtMin = moment($('#filter_date_from').val()).add(0, 'month').format('YYYY-MM-DD');
            var createdAtMax = moment($('#filter_date_to').val()).add(0, 'month').format('YYYY-MM-DD');
            let target = event.currentTarget;
            $('[data-toggle="tooltip"]').tooltip("hide");
            $(target).loading_spin();
            axios.post(appUrl+'/orders/run_job_sync_orders', {
                'createdAtMin' : createdAtMin,
                'createdAtMax': createdAtMax
            });
        }
    }

});
