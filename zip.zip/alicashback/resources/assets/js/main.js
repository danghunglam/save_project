jQuery.fn.extend({
    // notify: function(type, string) {
    //     this.find('.notification').remove();
    //     if(type == 'success') {
    //         var class_noti = 'notification';
    //         var ele = '<div class="notification success"><p><i class="demo-icon icon-ok-circle"></i>'+string+'</p></div>';
    //         this.append(ele);
    //         this.find('.notification').fadeIn(300,'swing').delay(4000).slideUp(500);
    //     }

    //     if(type == 'error') {
    //         var class_noti = 'notification';
    //         var ele = '<div class="notification error"><p><i class="demo-icon icon-warning"></i>'+string+'</p></div>';
    //         this.append(ele);
    //         this.find('.notification').fadeIn(300,'swing').delay(4000).slideUp(500);
    //     }
    //     if(type == 'warning') {
    //         var class_noti = 'notification';
    //         var ele = '<div class="notification warning"><p><i class="demo-icon icon-attention-circled"></i>'+string+'</p></div>';
    //         this.append(ele);
    //         this.find('.notification').fadeIn(300,'swing').delay(4000).slideUp(500);
    //     }
    //     if(type == 'info') {
    //         var class_noti = 'notification';
    //         var ele = '<div class="notification info"><p><i class="demo-icon icon-info"></i>'+string+'</p></div>';
    //         this.append(ele);
    //         this.find('.notification').fadeIn(300,'swing').delay(4000).slideUp(500);
    //     }
    // },
    loading_spin: function(parents) {
        if (typeof parents !== "undefined") {
            //== loading for parent element
            var $ele = $(this).parents('.'+parents);
        } else {
            //== loading for this
            var $ele = $(this);
        }

        var _el = '<div class="loading-blur loading-blur-o"><div class="loading-overlay"><div class="loading-icon animate-spin"><i class="mdi mdi-autorenew mdi-spin"></i></div></div></div>';
        $('body').append(_el);
        $('body').find('.loading-blur-o').css({
            'position': 'absolute',
            'z-index': 1080,
            'top': $ele.offset().top,
            'left': $ele.offset().left,
            'width': $ele.outerWidth() + 0.2,
            'height': $ele.outerHeight()
        });
    },
    loading: function(parents) {
        if (typeof parents !== "undefined") {
            //== loading for parent element
            var $ele = $(this).parents('.'+parents);
        } else {
            //== loading for this
            var $ele = $(this);
        }

        var _el = '<div class="loading-blur loading-blur-o"><div class="loading-overlay"><div class="loading-icon animate-spin"><i class="mdi mdirenew mdi-spin"></i></div></div></div>';
        $('body').append(_el);
        $('body').find('.loading-blur-o').css({
            'position': 'absolute',
            'z-index': 1080,
            'top': $ele.offset().top,
            'left': $ele.offset().left,
            'width': $ele.outerWidth() + 0.2,
            'height': $ele.outerHeight()
        });
    },
    loading_finish: function() {
        $('body').find('.loading-blur-o').remove();
    },
    //== Loading by element id
    loading_id: function(parents) {
        if (typeof parents !== "undefined") {
            //== loading for parent element
            var $ele = $(this).parents('.'+parents);
        } else {
            //== loading for this
            var $ele = $(this);
        }

        var Id = '';
        Id = $ele.attr('id');
        let target=event.currentTarget

        if (typeof Id != '') {
            loading_Id = 'loading-' + Id;
            var _el = '<div id="'+ loading_Id +'" class="loading-blur"><div class="loading-overlay"><div class="loading-icon animate-spin"><i class="mdi mdi-autorenew"></i></div></div></div>';
            /*$('body').append(_el);*/
            if($('#'+loading_Id).length == 0){
                $(target).addClass('loading-tracking-code').append(_el)
            }
            /*$(document.getElementById(loading_Id)).css({
                'position': 'absolute',
                'z-index': 1080,
                'top': $ele.offset().top,
                'left': $ele.offset().left,
                'width': $ele.outerWidth(),
                'height': $ele.outerHeight()
            });*/
        }
    },
    //== Finish loading by element id
    loading_id_finish: function(elementId) {
        var loading_Id = 'loading-' + elementId;
        $(document.getElementById(loading_Id)).remove();
    }
});

jQuery(document).ready(function($) {
    /*$(document.body).on('click', function(event) {
		if (!$(event.target).closest('.shopify-name-wrap').length) {
			$('.shopify-name-wrap').find('li').removeClass('open-shopify-name');
        }
        // if (!$(event.target).closest('.menu-help-center-box').length) {
		// 	$('.menu-help-center-box').removeClass('active');
        // }
    });*/
    if($('.sidebar-container .sidebar-product').hasClass('active')==true){
        $('.sidebar-container').next().addClass('sub-menu-left')
    }
    if($('.sidebar-container .sidebar-product').hasClass('active-subnav')==true){
        $('.sidebar-container').next().addClass('subnav-menu-left')
    }
    if($('.sidebar-container .sidebar-import,.sidebar-container .sidebar-orders').hasClass('active-subnav')==true){
        $('.menu-help-center-box').css('top','35px')
    }
    if($('.sidebar-container .sidebar-import,.sidebar-container .sidebar-orders').hasClass('active')==true){
        $('.menu-help-center-box').css('top','-30px')
    }


	$('[data-toggle="tooltip"]').tooltip({
		html: true,
		container: 'body'
	});

    $('.chosen-container').on('click', function() {
        $(this).closest('div').find('input').focus();
    });

    // $('.nav-menu-a').hover(
    //     function() {
    //         var menu_id = $(this).data('menu-id');
    //         $('.nav-sidebar-tooltip-list li').eq(menu_id).addClass('active');
    //     },
    //     function() {
    //         $('.nav-sidebar-tooltip-list li').removeClass('active');
    //     }
    // );

    $('.shopify-name li').on('click', function() {
        var has_class = $(this).hasClass('open-shopify-name');
        if( has_class ) {
            $('.shopify-name li').removeClass('open-shopify-name');
        } else {
            $('.shopify-name li').removeClass('open-shopify-name')
            $(this).addClass('open-shopify-name');
        }
    });

    if($(window).width >= 1366) {
        $('.sidebar-container').mCustomScrollbar({
            callbacks:{
                whileScrolling:function() {
                    $('.sidebar-tooltip').css({'top': 70 + this.mcs.top + 'px'})
                }
            }
        });
    }

    $(document.body).on('click', function(event) {
        if (!$(event.target).closest('.shopify-name-wrap').length) {
            $('.shopify-name-wrap').find('li').removeClass('open-shopify-name');
        }

        if (!$(event.target).closest('.menu-help-center-box').length) {
            if ($(event.target).closest('.sidebar-help-center').length) {
                if(!$('.menu-help-center-box').hasClass('active')) {
                    $('.menu-help-center-box').addClass('active');
                } else {
                    $('.menu-help-center-box').removeClass('active');
                }
            } else {
                $('.menu-help-center-box').removeClass('active');
                // Pause video if hidden help menu
                $("iframe.youtube-video").each(function () {
                    $(this)[0].contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
                });
            }
        } else {

        }
        if (!$(event.target).closest('.open-shopify-name').length && !$(event.target).closest('.open-shopify-name .see-all-notifications').length && !$(event.target).closest('.open-shopify-name .see-all-notifications span').length) {
            $('.open-shopify-name').removeClass('.open-shopify-name')
        }
    });

    /*$('.shopify-name-wrap li').click(function () {
        if($(this).hasClass('open-shopify-name')==false){
            $(this).removeClass('open-shopify-name')
        }
        else{
            $('.shopify-name-wrap li').removeClass('open-shopify-name')
            $(this).addClass('open-shopify-name')
        }
    })*/

    $('body .see-all-notifications span').on('click', function() {
        $(this).closest('li').addClass('open-shopify-name');
    });

    $('.nav-menu-help').on('click', function() {
        // console.log('close')
        $("iframe.youtube-video").each(function () {
            $(this)[0].contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
        });

        // $('.menu-help-center-box').toggleClass('active');
    });


    //Pusher
    // Enable pusher logging - don't include this in production
    Pusher.logToConsole = false;

    $('.shopify-vote').click(function (e) {
       e.preventDefault();
        var modal = '#voteForUsModal';
        var originalModal = $(modal).clone();

        $(modal).on('shown.bs.modal', function () {
            // $('form',modal).submit();
        });

        $(modal).on('hidden.bs.modal', function () {
            $(modal).remove();
            var myClone = originalModal.clone();
            $('body').append(myClone);
        });

        $(modal).modal({
            show: 'true'
        });
    });

    $("body").delegate(".btn-bad-review", "click", function(e) {
        var obj = $(this);
        var ctn = obj.closest('form');
        $('.step-1',ctn).hide();
        $('.step-2',ctn).fadeIn();
        // ctn.submit();
    });

    $("body").delegate(".btn-good-review", "click", function(e) {
        $('#voteForUsModal').modal('hide');
    });

    $("#formVoteForUs").on("submit", function(e) {
        e.preventDefault();
        var obj = $(this);
        obj.validate({
            submitHandler: function (form) {
                $.ajax({
                    type : "post",
                    url: appUrl + '/feedback/save',
                    dataType : 'json',
                    data : $(form).serialize(),
                    beforeSend: function () {
                        $('input, button, textarea', $(form)).attr('disabled', true).css('opacity', 0.5);
                    },
                    success: function (data, statusText, xhr) {
                        if (data.status == 'success'){
                            notify('success',data.message);

                            $('#voteForUsModal').modal('hide');
                        }else{
                            $('input, button, textarea', $(form)).attr('disabled', false).css('opacity', 1);
                            // notify('error',data.message);

                        }
                    },
                    error: function () {
                        $('input, button, textarea', $(form)).attr('disabled', false).css('opacity', 1);
                        notify('error','An error, please try again.');
                    }
                });
            }
        });
        $('#feedback-vote').rules('add', {
            required: true
        });
    });

    // $('.extension-modal-wrap .close-modal').click(function (e) {
    //     e.preventDefault();
    //     $('#modal-chrome-extension').modal('show')
    // });


    //== Onboarding
    $('#tutorial-welcome-btn').on('click', function() {
        $('.tutorial-modal-welcome').remove();
    });

    $('.tutorial-step-next-btn').on('click', function() {
        var step_current = $(this).parents('.tutorial-modal-step').data('tutorial-step');
        var step_next = step_current + 1;
        var body_tutorial_current = 'tutorial-onboarding-step-' + step_current;
        var body_tutorial_next = 'tutorial-onboarding-step-' + step_next;
        if( step_current < 8 ) {
            $('body').removeClass(body_tutorial_current).addClass(body_tutorial_next);
        }
    });

    $('.tutorial-step-prev-btn').on('click', function() {
        var step_current = $(this).parents('.tutorial-modal-step').data('tutorial-step');
        var step_prev = step_current - 1;
        var body_tutorial_current = 'tutorial-onboarding-step-' + step_current;
        var body_tutorial_prev = 'tutorial-onboarding-step-' + step_prev;
        if( step_current > 1 ) {
            $('body').removeClass(body_tutorial_current).addClass(body_tutorial_prev);
        }
    });

    $('.tutorial-step-finish').on('click', function() {
        $('body').removeClass('tutorial-onboarding').removeClass('tutorial-onboarding-step-7');
    });

    $('.view-tutorial-onboard').on('click', function() {
        $('.shopify-profile').removeClass('open-shopify-name');
        var active_sidebar_import = $('.sidebar-import').hasClass('active');
        var sub_sidebar_import = $('.sidebar-import').hasClass('active-subnav');
        if( active_sidebar_import || sub_sidebar_import) {
            $('body').addClass('onboarding-sidebar-import');
        }
        var active_sidebar_product = $('.sidebar-product').hasClass('active');
        var sub_sidebar_product = $('.sidebar-product').hasClass('active-subnav');
        if( active_sidebar_product || sub_sidebar_product ) {
            $('body').addClass('onboarding-sidebar-product');
        }
        var active_sidebar_orders = $('.sidebar-orders').hasClass('active');
        var sub_sidebar_orders = $('.sidebar-orders').hasClass('active-subnav');
        if( active_sidebar_orders || sub_sidebar_orders ) {
            $('body').addClass('onboarding-sidebar-orders');
        }
        $('body').addClass('tutorial-onboarding tutorial-onboarding-step-1');
    });

    $('.tutorial-modal-close').on('click', function() {
        var step_current = $(this).parents('.tutorial-modal-step').data('tutorial-step');
        var body_tutorial_current = 'tutorial-onboarding-step-' + step_current;
        $('body').removeClass('tutorial-onboarding').removeClass(body_tutorial_current);
    });

    let objShopName = window.shopName.split(' ');
    let avatarName = ((objShopName[0]) ? objShopName[0].slice(0,1) : '')+ ((objShopName[1]) ? objShopName[1].slice(0,1) : '')
    $('#shopAvatar, .avatar-current-shop .avatar').text(avatarName.toUpperCase());
});

//Push public token to extension

let port = chrome.runtime.connect(chromeExtensionId);
//Send public token
const payloadMessagePublicToken = {
    data: {
            action: 'ACTION_STORE_TOKEN',
            payload: {
                public_token: publicToken
            }
        }
}
port.postMessage(payloadMessagePublicToken);
// // port.postMessage(payloadMessageAutoUpdate);
port.disconnect()

// Call api to check order_sync. If order_sync = 3 => reset to 0 and post Extension get data from Oberlo

if(window.order_type_sync >= 3) {
    $.ajax({
        type : "post",
        url: appUrl + '/extension/check_order_type_sync',
        data: { _token: $('meta[name="csrf-token"]').attr('content') },
        dataType : 'json',
        success: function (data) {
            if (data.status){
                let port = chrome.runtime.connect(chromeExtensionId);
                //Send public token

                //Send auto update price
                let payloadMessageSyncOrderProductFromOberlo = {
                    data: {
                        action: 'ACTION_SYNC_ORDERS_PRODUCT_FROM_OBERLO',
                        payload: {
                            public_token: publicToken,
                            shop_domain: window.shopDomain,
                            from_date: '2009-01-01',
                            to_date: moment().format('MMM DD, YYYY'),
                            response_info: false
                        }
                    }
                }
                port.postMessage(payloadMessageSyncOrderProductFromOberlo);
                port.disconnect()
            }
        },
    })
}

// Auto update price extension
if(!window.last_time_update || moment.utc().unix() - window.last_time_update > 172800) {
    $.ajax({
        type : "put",
        url: appUrl + '/extension/last_time_update',
        data: { _token: $('meta[name="csrf-token"]').attr('content') },
        dataType : 'json',
        success: function (data) {
            if (data.status && data.token){
                let port = chrome.runtime.connect(chromeExtensionId);
                //Send public token

                //Send auto update price
                const payloadMessageAutoUpdate = {
                    data: {
                        action: 'AUTO_UPDATE_PRICE',
                        payload: {
                            shopId: window.shopId,
                            // shopId: '16331587',
                            token: data.token
                        }
                    }
                }
                port.postMessage(payloadMessageAutoUpdate);
                port.disconnect()
            }
        },
    })
}

// auto update tracking code
let n = 1; // number of date
let numberOfDate = n * (24*60*60);
if(!window.last_time_update_tracking_code || moment.utc().unix() - window.last_time_update_tracking_code > numberOfDate) {
    axios.put(appUrl + '/extension/last_time_update_tracking_code', {numberOfDate}).
    then(function (res) {
        let {status} = res.data;
        if (status){
            let {lineItemTrackingCodeNull, shop} = res.data;
            if(lineItemTrackingCodeNull.length > 0) {
                let port = chrome.runtime.connect(chromeExtensionId);
                const payloadMessageAutoUpdateTrackingCode = {
                    data: {
                        action: 'AUTO_UPDATE_TRACKING_CODE',
                        payload: {
                            shop_id: shop.id,
                            access_token: shop.access_token,
                            shop_domain: shop.domain,
                            data: lineItemTrackingCodeNull,
                            auto_update_tracking_code: true
                        }
                    }
                };
                port.postMessage(payloadMessageAutoUpdateTrackingCode);
                port.disconnect();
            }
        }
    });
}

let delayUpdateTime = (1*30*60);
if(window.last_time_update_tracking_code 
    && (window.fulfillmented_with_tracking_code == 1 || window.fulfillmented_with_tracking_code <= 4) 
    && moment.utc().unix() - window.last_time_update_tracking_code > (window.fulfillmented_with_tracking_code * 6 * 3600)) {
    axios.get(appUrl + '/orders/refulfillment', {})
            .then(function (res) {
            });
}
