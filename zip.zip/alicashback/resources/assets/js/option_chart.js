export let chart_line_modal = {
    type: 'line',
    data: {
        labels: [],
        datasets: []
    }
}
Chart.controllers.LineWithLine = Chart.controllers.line.extend({
    draw: function(ease) {
        if (this.chart.tooltip._active && this.chart.tooltip._active.length) {
            var activePoint = this.chart.tooltip._active[0],
                ctx = this.chart.ctx,
                x = activePoint.tooltipPosition().x,
                topY = this.chart.scales['y-axis-0'].top,
                bottomY = this.chart.scales['y-axis-0'].bottom;

            // draw line
            ctx.save();
            ctx.beginPath();
            ctx.moveTo(x, topY);
            ctx.lineTo(x, bottomY);
            ctx.lineWidth = 0.2;
            this.chart.data.datasets.yAxisID='y-axis-1';
            ctx.strokeStyle = '#7009FF';
            ctx.stroke();
            ctx.restore();
        }
        Chart.controllers.line.prototype.draw.call(this, ease);
    }
});
/*Chart.defaults.global.legend.borderRadius=5;*/
export let chart_line = {
    type: 'LineWithLine',
    data: {
        labels: [],
        datasets: []
    },
    options: {
        animation: {
            duration: 300
        },
        responsive: true,
        defaultFontFamily: "'Poppins', sans-serif",
        legend: {
            position: "bottom",
            fill: true,
            display: false
        },
        legendCallback: function(chart) {
            var text = [];
            function newLegendClickHandler (e, legendItem) {
                var index = legendItem;
                var ci = chart;
                var meta = ci.getDatasetMeta(index);

                // See controller.isDatasetVisible comment
                meta.hidden = meta.hidden === null? !ci.data.datasets[index].hidden : null;

                // We hid a dataset ... rerender the chart
                ci.update();
            };
            text.push('<ul>');
            for (var i=0; i<chart.data.datasets.length; i++) {
                text.push('<li class="update-dataset" dataset="'+chart.legend.legendItems[i].datasetIndex+'" >');
                text.push('<span style="background-color:' + chart.data.datasets[i].backgroundColor + '"></span>' + chart.data.datasets[i].label);
                text.push('</li>');
            }
            text.push('</ul>');

            $(document).on('click','.update-dataset',function () {
                var dataset_index=$(this).attr('dataset');
                /*newLegendClickHandler(event,dataset_index);*/
                $(this).toggleClass('line-through');
                if($(this).hasClass('line-through')){
                    chart.data.datasets[dataset_index].borderColor = 'transparent';
                    chart.data.datasets[dataset_index].pointBorderColor = 'transparent';
                    chart.data.datasets[dataset_index].pointBackgroundColor = 'transparent';
                }
                else{
                    if(dataset_index==0){
                        chart.data.datasets[dataset_index].borderColor = '#7B1FA2';
                        chart.data.datasets[dataset_index].pointBorderColor = '#A4A1FB';
                        chart.data.datasets[dataset_index].pointBackgroundColor = '#fff';
                    }
                    else if(dataset_index==1){
                        chart.data.datasets[dataset_index].borderColor = '#54D8FF';
                        chart.data.datasets[dataset_index].pointBorderColor = '#54D8FF';
                        chart.data.datasets[dataset_index].pointBackgroundColor = '#fff';
                    }
                    else {
                        chart.data.datasets[dataset_index].borderColor = '#F63665';
                        chart.data.datasets[dataset_index].pointBorderColor = '#F63665';
                        chart.data.datasets[dataset_index].pointBackgroundColor = '#fff';
                    }

                }
                chart.update();
            });
            return text.join("");
        },

        scales: {
            yAxes: [{
                ticks: {
                    fontColor: "rgba(36,37,57,0.5)",
                    fontStyle: "400",
                    beginAtZero: true,
                    padding: 10,
                    fontSize: 11,
                    autoSkip: true,
                    suggestedMax: 20,
                    maxRotation: 0,
                    minRotation: 0
                },
                gridLines: {
                    drawTicks: false,
                    color: "#EAF0F4",
                    zeroLineColor: '#EAF0F4',
                    zeroLineWidth: 3
                }
            }],
            xAxes: [{
                gridLines: {
                    color: "#EAF0F4",
                    display: false
                },
                ticks: {
                    padding: 10,
                    fontColor: "rgba(36,37,57,0.5)",
                    fontStyle: "400",
                    fontSize: 11,
                    autoSkip: true,
                    autoSkipPadding: 20,
                    maxTicksLimit: 0,
                    suggestedMax: 20,
                    suggestedMin: 20,
                    maxRotation: 0,
                    minRotation: 0,
                }
            }]
        },
        tooltips: {
            enabled: false,
            mode: 'index',
            intersect: false,
            position: 'nearest',
            backgroundColor: "#FFF",
            borderColor: "#242539",
            borderWidth: 1,
            bodyFontSize: 14,
            bodyFontColor: "#333c48",
            titleFontSize: 14,
            titleFontColor: "#333c48",
            bodySpacing: 2,
            titleMarginBottom: 10,
            xPadding: 20,
            yPadding: 12,
            caretSize: 2,
            yAlign: 'right',
            callbacks: {
                label: function(tooltipItem, data) {
                    var label = data.datasets[tooltipItem.datasetIndex].label || '';
                    if (label) {
                        label += ': ';
                    }
                    label += '$' + tooltipItem.yLabel
                    return label;
                }
            },
            custom: function(tooltipModel) {
                if($('#legend-line-chart .update-dataset:first-child').hasClass('line-through')){
                    $('#chartjs-tooltip').addClass('point-one')
                }
                else{
                    $('#chartjs-tooltip').removeClass('point-one')
                }
                if($('#legend-line-chart .update-dataset:nth-child(2)').hasClass('line-through')){
                    $('#chartjs-tooltip').addClass('point-two')
                }
                else {
                    $('#chartjs-tooltip').removeClass('point-two')
                }
                // Tooltip Element
                var tooltipEl = document.getElementById('chartjs-tooltip');

                // Create element on first render
                if (!tooltipEl) {
                    tooltipEl = document.createElement('div');
                    tooltipEl.id = 'chartjs-tooltip';
                    tooltipEl.innerHTML = "<table></table>"
                    document.body.appendChild(tooltipEl);
                }

                // Hide if no tooltip
                if (tooltipModel.opacity === 0) {
                    tooltipEl.style.opacity = 0;
                    tooltipEl.style.visibility = 'hidden';
                    return;
                }

                // Set caret Position
                tooltipEl.classList.remove('above', 'below', 'no-transform');
                if (tooltipModel.yAlign) {
                    tooltipEl.classList.add(tooltipModel.yAlign);
                } else {
                    tooltipEl.classList.add('no-transform');
                }

                function getBody(bodyItem) {
                    return bodyItem.lines;
                }
                // Set Text
                if (tooltipModel.body) {
                    var titleLines = tooltipModel.title || [];
                    var bodyLines = tooltipModel.body.map(getBody);
                    var innerHtml = '<thead>';

                    titleLines.forEach(function(title) {
                        innerHtml += '<tr><th>' + title + '</th></tr>';
                    });
                    innerHtml += '</thead><tbody>';

                    bodyLines.forEach(function(body, i) {
                        var colors = tooltipModel.labelColors[i];
                        var style = 'background:' + colors.backgroundColor;
                        style += '; border-color:' + colors.borderColor;
                        style += '; border-width: 2px';
                        var span = '<span class="chartjs-tooltip-key" style="' + style + '"></span>';
                        innerHtml += '<tr><td>' + span + body + '</td></tr>';
                    });
                    innerHtml += '</tbody>';

                    var tableRoot = tooltipEl.querySelector('table');
                    tableRoot.innerHTML = innerHtml;
                }

                // `this` will be the overall tooltip
                var position = this._chart.canvas.getBoundingClientRect();
                // Display, position, and set styles for font
                tooltipEl.style.position = 'absolute';
                tooltipEl.style.opacity = 1;
                tooltipEl.style.left = tooltipModel.caretX + 27 +'px';
                tooltipEl.style.top = tooltipModel.caretY + 60 + 'px';
                if((tooltipModel.caretX + 27) > 1000){
                    var widthTooltip = $('#chartjs-tooltip').outerWidth();
                    tooltipEl.style.left = tooltipModel.caretX - widthTooltip + 11 +'px';
                    $('#chartjs-tooltip').addClass('tooltip-left');
                }
                else{
                    $('#chartjs-tooltip').removeClass('tooltip-left');
                }
                // tooltipEl.style.fontFamily = tooltipModel._fontFamily;
                tooltipEl.style.fontSize = tooltipModel.fontSize;
                tooltipEl.style.fontStyle = tooltipModel._fontStyle;
                tooltipEl.style.padding = '10px 15px';
                tooltipEl.style.visibility = 'visible';
            }
        }
    }
}
