<template>
    <!-- Modal -->
    <div id="place-all-order-modal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md-540">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Place All Orders</h4>
                    <button type="button" class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                </div>
                <div class="modal-body">
                    <div class="place__all_orders">
                        <p>All orders from product page will be auto fulfilled</p>
                        <div class="m-t-15">
                            <label for="use_setting_default" class="checkbox-style">
                                <input id="use_setting_default" type="checkbox" name="use_setting_default" v-model="use_setting_default">
                                <span class="checked-style"></span>
                                Use default Fulfillment Settings
                            </label>
                        </div>
                        <div v-show="! use_setting_default">
                            <div class="settings-place-all-orders">
                                <div class="settings-input-wrap setting-warning-price m-b-20">
                                    <label for="automation_fulfillment" class="checkbox-style">
                                        <input type="checkbox" name="automation_fulfillment" id="automation_fulfillment" class="shipping_max_price_alert"  v-model="settings.automation_fulfillment">
                                        <span class="checked-style"></span>
                                        Auto solve AliExpress captcha <b>(BETA)</b>
                                    </label>
                                </div>
                                <div class="settings-input-wrap setting-warning-price">
                                    <label for="text_auto_completed_order" class="checkbox-style">
                                        <input type="checkbox" name="auto_completed_order" id="text_auto_completed_order" v-model="settings.auto_completed_order">
                                        <span class="checked-style"></span>
                                        Auto completed order (automation payment)
                                    </label>
                                    <div class="ao-block-options-fulfilled p-l-25 m-t-20 p-b-20" v-bind:class="settings.auto_completed_order ? '' : 'ao-block-options-fulfilled-disabled'">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <p class="fz-15 fw-500 m-t-15 m-b-20 stop-options-fulfilled">Stop options</p>
                                                <div class="ao-block-flex ao-options-fulfillment">
                                                    <label for="option_total_cost_hight" class="checkbox-style">
                                                        <input id="option_total_cost_hight" type="checkbox" name="option_total_cost_hight" @change="changeOptionFulfillment" v-model="stop_options.is_stop_total_cost_option">
                                                        <span class="checked-style"></span>
                                                        Stop if total cost is higher than
                                                    </label>
                                                    <div class="settings-input-group">
                                                        <div class="field-group-container" v-bind:class="settings_errors.stop_total_cost_option != '' ? 'ao-field-group-valid' : ''">
                                                            <input type="text" pattern="\d{1,5}" :disabled="! stop_options.is_stop_total_cost_option" @keyup="isNumberKeyup($event)" @keypress="isNumber($event)" v-model="settings.stop_total_cost_option">
                                                            <span>USD</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="ao-block-flex ao-options-fulfillment m-t-10">
                                                    <label for="option_total_order_hight" class="checkbox-style">
                                                        <input id="option_total_order_hight" type="checkbox" name="option_total_order_hight" @change="changeOptionFulfillment" v-model="stop_options.is_stop_total_order_processed_option">
                                                        <span class="checked-style"></span>
                                                        Stop if total order processed is higher than
                                                    </label>
                                                    <div class="settings-input-group">
                                                        <div class="field-group-container" v-bind:class="settings_errors.stop_total_order_processed_option != '' ? 'ao-field-group-valid' : ''">
                                                            <input type="text" pattern="\d{1,5}" :disabled="! stop_options.is_stop_total_order_processed_option" @keyup="isNumberKeyup($event)" @keypress="isNumber($event)" v-model="settings.stop_total_order_processed_option">
                                                            <span>USD</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="ao-block-flex ao-options-fulfillment m-t-20">
                                                    <label for="option_charge_failed" class="checkbox-style">
                                                        <input id="option_charge_failed" type="checkbox" name="option_charge_failed" v-model="settings.stop_charge_failed_option">
                                                        <span class="checked-style"></span>
                                                        Stop if charge failed
                                                    </label>
                                                </div>

                                            </div>
                                            <div class="col-md-12">
                                                <p class="fz-15 fw-500 m-t-15 m-b-20 skip-options-fulfilled">Skip options</p>
                                                <div class="ao-block-flex ao-options-fulfillment">
                                                    <label for="option_shipping_fee_hight" class="checkbox-style">
                                                        <input id="option_shipping_fee_hight" type="checkbox" name="option_shipping_fee_hight" @change="changeOptionFulfillment" v-model="skip_options.is_skip_shipping_fee_option">
                                                        <span class="checked-style"></span>
                                                        Skip if shipping fee is higher than
                                                    </label>
                                                    <div class="settings-input-group">
                                                        <div class="field-group-container" v-bind:class="settings_errors.skip_shipping_fee_option != '' ? 'ao-field-group-valid' : ''">
                                                            <input type="text" pattern="\d{1,5}" :disabled="! skip_options.is_skip_shipping_fee_option" @keyup="isNumberKeyup($event)" @keypress="isNumber($event)" v-model="settings.skip_shipping_fee_option">
                                                            <span>USD</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="ao-block-flex ao-options-fulfillment m-t-10">
                                                    <label for="option_product_price_hight" class="checkbox-style">
                                                        <input id="option_product_price_hight" type="checkbox" name="option_product_price_hight" @change="changeOptionFulfillment" v-model="skip_options.is_skip_product_price_option">
                                                        <span class="checked-style"></span>
                                                        Ship if product price is higher than
                                                    </label>
                                                    <div class="settings-input-group">
                                                        <div class="field-group-container" v-bind:class="settings_errors.skip_product_price_option != '' ? 'ao-field-group-valid' : ''">
                                                            <input type="text" pattern="\d{1,5}" :disabled="! skip_options.is_skip_product_price_option" @keyup="isNumberKeyup($event)" @keypress="isNumber($event)" v-model="settings.skip_product_price_option">
                                                            <span>USD</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="ao-block-flex ao-options-fulfillment m-t-10">
                                                    <label for="option_earning_lower" class="checkbox-style">
                                                        <input id="option_earning_lower" type="checkbox" name="option_earning_lower" @change="changeOptionFulfillment" v-model="skip_options.is_skip_earning_lower_option">
                                                        <span class="checked-style"></span>
                                                        Skip if earning lower than
                                                    </label>
                                                    <div class="settings-input-group">
                                                        <div class="field-group-container" v-bind:class="settings_errors.skip_earning_lower_option != '' ? 'ao-field-group-valid' : ''">
                                                            <input type="text" pattern="\d{1,5}" :disabled="! skip_options.is_skip_earning_lower_option" @keyup="isNumberKeyup($event)" @keypress="isNumber($event)" v-model="settings.skip_earning_lower_option">
                                                            <span>USD</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="ao-block-flex ao-options-fulfillment m-t-20">
                                                    <label for="option_cannot_fulfilled" class="checkbox-style">
                                                        <input id="option_cannot_fulfilled" type="checkbox" name="option_cannot_fulfilled" v-model="settings.skip_cannot_fulfilled_option">
                                                        <span class="checked-style"></span>
                                                        Skip if order cannot be fulfilled
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click="placeAllOrder" :disabled="is_load" v-text="is_load ? 'Please wait...' : 'Place All Order'"></button>
                </div>
            </div>

        </div>
    </div>
</template>

<script type="text/javascript">
    export  default {
        props: ['current_page', 'filters', 'shop_domain'],
        data: function() {
            return {
                errors: {},
                options: {
                    place_options: 1,
                    current_page: this.current_page,
                    maximum_cost_check: false,
                    maximum_order_check: false,
                    maximum_cost: '',
                    maximum_order: '',
                    filters: this.filters
                },
                settings: {
                    automation_fulfillment: 1,
                    auto_completed_order: true,
                    stop_total_cost_option: '',
                    stop_total_order_processed_option: '',
                    stop_charge_failed_option: false,
                    skip_shipping_fee_option: '',
                    skip_product_price_option: '',
                    skip_earning_lower_option: '',
                    skip_cannot_fulfilled_option: false
                },
                settings_errors: {
                    stop_total_cost_option: '',
                    stop_total_order_processed_option: '',
                    skip_shipping_fee_option: '',
                    skip_product_price_option: '',
                    skip_earning_lower_option: ''
                },
                stop_options: {
                    is_stop_total_cost_option: false,
                    is_stop_total_order_processed_option: false
                },
                skip_options: {
                    is_skip_shipping_fee_option: false,
                    is_skip_product_price_option: false,
                    is_skip_earning_lower_option: false
                },
                use_setting_default: true,
                is_load: false
            }
        },
        mounted: function () {
            if(! this.options.maximum_cost_check) {
                delete this.errors['maximum_cost']
            }
            if(! this.options.maximum_order_check) {
                delete this.errors['maximum_order']
            }
        },
        watch:{
            filters:function (filters) {
                this.options.filters = filters
            }
        },
        methods: {
            validate: function () {
                let _this = this
                let errors = {}
                if(this.settings.auto_completed_order) {
                    if(this.stop_options.is_stop_total_cost_option && this.settings.stop_total_cost_option == '')
                    {
                        this.settings_errors.stop_total_cost_option = 'Invalid'
                        errors['stop_total_cost_option'] = 'Invalid'
                    }
                    
                    if(this.stop_options.is_stop_total_order_processed_option && this.settings.stop_total_order_processed_option == '')
                    {
                        this.settings_errors.stop_total_order_processed_option = 'Invalid'
                        errors['stop_total_order_processed_option'] = 'Invalid'
                    }
                        
                    
                    if(this.stop_options.is_skip_shipping_fee_option && this.settings.skip_shipping_fee_option == '')
                    {
                        this.settings_errors.skip_shipping_fee_option = 'Invalid'
                        errors['skip_shipping_fee_option'] = 'Invalid'
                    }
                        
                    
                    if(this.stop_options.is_skip_product_price_option && this.settings.skip_product_price_option == '')
                    {
                        this.settings_errors.skip_product_price_option = 'Invalid'
                        errors['skip_product_price_option'] = 'Invalid'
                    }
                        
                    
                    if(this.stop_options.is_skip_earning_lower_option && this.settings.skip_earning_lower_option == '')
                    {
                        this.settings_errors.skip_earning_lower_option = "Invalid"
                        errors['skip_earning_lower_option'] = 'Invalid'
                    }
                        
                }
                return errors
            },
            isNumber: function(evt) {
                evt = (evt) ? evt : window.event;
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if ((charCode >= 48 && charCode <= 57) || charCode === 46) {
                    return true
                } else {
                    evt.preventDefault()
                }
                // parseFloat(Math.round(num1 * 100) / 100).toFixed(2)
            },
            isNumberKeyup: function(event) {
                console.log(name)
                let val = $(event.currentTarget).val()
                let str_split = val.split('.');
                if( str_split[1] != undefined &&  str_split[1].length >= 3 || str_split.length >=3) {
                    let last = str_split[1].slice(0, 2)
                    let first = str_split[0] + '.'
                    val = first.concat(last)
                    this.options.maximum_cost = val
                }
            },
            isIntNumberKeyup: function(event) {
                console.log(name)
                let val = $(event.currentTarget).val()
                val = val.replace('.','')
                this.options.maximum_order = val

                // if( str_split[1] != undefined &&  str_split[1].length >= 3 || str_split.length >=3) {
                //     let val = str_split[0]
                //
                //     this.options.maximum_order = val
                // }
            },
            placeAllOrder: function () {
                let _this = this

                // _this.is_load = true
                this.errors = this.validate()
                if(Object.values(this.errors).length > 0)
                    return false;
                
                _this.is_load = true
                axios.get(appUrl+'/orders/place/all', {
                    params: _this.options
                }).then(function(response) {
                    let { orders, default_setting } = response.data
                    console.log('orders---', orders)
                    console.log('default_setting before', default_setting)
                    if(! _this.use_setting_default) {
                        default_setting = Object.assign({}, default_setting, {
                            automation_fulfillment: _this.settings.automation_fulfillment,
                            auto_completed_order: _this.settings.auto_completed_order,
                            stop_total_cost_option: _this.stop_options.is_stop_total_cost_option ? _this.settings.stop_total_cost_option : '',
                            stop_total_order_processed_option: _this.stop_options.is_stop_total_order_processed_option ? _this.settings.stop_total_order_processed_option : '',
                            stop_charge_failed_option: _this.settings.stop_charge_failed_option,
                            skip_shipping_fee_option: _this.skip_options.is_skip_shipping_fee_option ? _this.settings.skip_shipping_fee_option : '',
                            skip_product_price_option: _this.skip_options.is_skip_product_price_option ? _this.settings.skip_product_price_option : '',
                            skip_earning_lower_option: _this.skip_options.is_skip_earning_lower_option ? _this.settings.skip_earning_lower_option : '',
                            skip_cannot_fulfilled_option: _this.settings.skip_cannot_fulfilled_option
                        })
                    }
                    console.log('default_setting after', default_setting)
                    let orderss = []
                    if(orders.length > 0) {
                        let port = chrome.runtime.connect(chromeExtensionId);
                        const payloadMessage = {
                            data: {
                                action: 'ACTION_MULTI_ORDER_FULFILL',
                                payload: {
                                    is_multi_order: true,
                                    shop: _this.shop_domain,
                                    orderData: orders,
                                    default_setting: default_setting,
                                    maximum_cost: _this.options.maximum_cost,
                                    maximum_order: _this.options.maximum_order,
                                    place_this_order: true
                                }
                            }
                        }
                        // notify('success', 'Place all order successful')
                        port.postMessage(payloadMessage);
                        port.disconnect()
                    } else {
                        notify('warning', 'There are no eligible orders to place')
                    }
                    _this.is_load = false
                    $('#place-all-order-modal').modal('hide')
                }).catch(function(error) {
                    _this.is_load = false
                    console.log(error)
                })

            },
            maximumCostCheckChange: function() {
                if(! this.options.maximum_cost_check) {
                    delete this.errors['maximum_cost']
                }
            },
            maximumOrderCheckChange: function() {
                if(! this.options.maximum_order_check) {
                    delete this.errors['maximum_order']
                }
            },
            
            changeOptionFulfillment: function() {
                let _this = this
                if(!_this.stop_options.is_stop_total_cost_option)
                    _this.settings_errors.stop_total_cost_option = ''

                if(!_this.stop_options.is_stop_total_order_processed_option)
                    _this.settings_errors.stop_total_order_processed_option = ''

                if(!_this.skip_options.is_skip_shipping_fee_option)
                    _this.settings_errors.skip_shipping_fee_option = ''
                
                if(!_this.skip_options.is_skip_product_price_option)
                    _this.settings_errors.skip_product_price_option = ''
                
                if(!_this.skip_options.is_skip_earning_lower_option)
                    _this.settings_errors.skip_earning_lower_option = ''
            }
        }
    }
</script>
