<template>
    <div id="tracking-code-modal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-sm">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" data-dismiss="modal" class="close"><i class="icon-ali icon-ic-highlight-off-24px"></i></button>
                    <h4 class="modal-title">Import Tracking Code</h4>
                </div>
                <div class="modal-body">
                    <div class="import-tracking-code-wrap">
                        <h3>File Format</h3>
                        <p>Your CSV file format include:</p>
                        <div class="ars-table">
                            <div class="ars-table-head">
                                <div class="ars-table-col">Order ID</div>
                                <div class="ars-table-col">Supplier ID</div>
                                <div class="ars-table-col">Tracking Code</div>
                            </div>
                            <div class="ars-table-row">
                                <div class="ars-table-col">#1001</div>
                                <div class="ars-table-col">534738</div>
                                <div class="ars-table-col">1021548</div>
                            </div>
                        </div>
                        <h3 style="padding-top: 24px; margin-top: 20px; border-top: 1px solid #d2d4d6;">How to find Supplier ID</h3>
                        <p>Click into store name at AliEpxress link: </p>
                        <div style="text-align: center;">
                            <img v-bind:src="link('/images/backend/guide-find-suplier.png')" />
                        </div>
                        <div style="text-align: center; padding-top: 20px; margin-top: 20px; border-top: 1px solid #d2d4d6;">
                            <img v-bind:src="link('/images/backend/guide-find-suplier-id.png')" />
                        </div>

                        <div class="import-tracking-code-btn-wrap">
                            <div>
                                <a v-bind:href="link('/storage/csv/trackingcode.csv')" >Click here to download file template</a>
                            </div>
                        </div>
                        </div>
                    </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click="">
                        <div id="dvImportSegments">
                            <label style="cursor: pointer; width: 100%" class="fw-500">
                                <input type="file" @change="chooseFile($event)" name="trackingCode" accept=".csv" style="display: none;"/>
                                <span v-if="nameFile == '' " class="ars-btn">Import File</span>
                                <span v-else v-html="nameFile" class="ars-btn"></span>
                            </label>
                        </div>
                    </button>
                </div>
            </div>

        </div>
    </div>
</template>
<script>
    import download from 'downloadjs'
    export default {
        props: {},
        data: function(){
            return {
                nameFile:'',
                file:[],
                data:[]
            }
        },
        mounted: function () {


            // $('#filter-flags_status').multiselect({
            //     enableHTML: true,
            //     enableFiltering: false,
            //     nonSelectedText: 'Flags Status',
            //     buttonContainer: '<div class="selected-parents-container"></div>',
            //     optionLabel: function (element) {
            //         return '<span class="' + $(element).data('icon-class') + '"></span>' + $(element).text();
            //     }
            // }).change(function (event) {
            //     _this.filters.paged = 1
            //     _this.filters.flag = $(event.currentTarget).val()
            //     _this.getOrders()
            // });


        },
        methods: {
            // downloadFile:function(){
            //     let url = appUrl+'/storage/csv/trackingcode.csv'
            //     console.log(url)
            //     download(url);
            // },
            link:function(link){
                return appUrl + link
            },
            searchKeyword: function () {
                this.getOrders()
            },
            getOrders: function () {
                this.$emit('get_order', this.filters)
            },
            chooseFile: function (event) {
                let _this = this;
                let day = new Date();
                let time = day.getTime();
                let file = event.target.files[0]
                _this.nameFile = file.name

                _this.$emit('call-popup',[time,_this.nameFile]);

                var reader = new FileReader()
                reader.readAsText(file);

                

                reader.onload = function(event) {
                    var csvData = event.target.result
                    try {
                        _this.data = $.csv.toArrays(csvData)
                    
                        axios.post(appUrl+'/tracking-code/import',
                            {
                                data:{
                                    data:_this.data,
                                    time: time
                                }
                            })
                            .then(function (response) {

                            })
                    } catch(e) {
                        alert('Unable to read ' + file.fileName)
                    }
                }
                reader.onerror = function() {
                    alert('Unable to read ' + file.fileName)
                }
                $('#tracking-code-modal').modal('hide')
                _this.nameFile = ''
                event.target.value = ""
            },
        },
    }
</script>
<style lang="scss" scoped>
    .import-tracking-code-wrap {
        padding: 5px 0 15px;
        > h3 {
            margin: 0 0 10px;
            font-size: 13px;
            font-weight: 600;
            color: #242539;
        }
        p {
            font-size: 11px;
            color: #242539;
        }
        .ars-table {
            font-size: 11px;
            border:1px solid #e5ebf2;
            margin-bottom: 20px;
            .ars-table-head {
                .ars-table-col {
                    font-weight: 500;
                }
            }
            .ars-table-col {
                width: 33.333%;
                padding: 5px 0;
                text-align: center;
                border-right:1px solid #e5ebf2;
                color: #242539;
                &:last-child {
                    border-right: none;
                }
            }
        }
    }
    .import-tracking-code-btn-wrap {
        text-align: center;
        margin-top: 10px;
        a {
            font-size: 13px;
            color: #3B86FF;
            &:hover {
                text-decoration: underline;
            }
        }
        .ars-btn {
            margin-top: 15px;
        }
    }
</style>


