<template>
    <div class="order-list-item" v-bind:id="'order-list-item-'+line_item_first.id" v-bind:class="[class_status[line_item_first.status], ('line_item_' + order.id + '_' + key_group)]">

        <div class="order-item-header" v-if="index == 0" v-bind:class="[actionClass.active_add_ali_no, (line_item_first.status == window.configOrder.status.to_order && ! line_item_first.aliexpress_options) && (! line_item_first.variant_deleted_at) ? 'order-item-header-update-link' : '']">

            <div class="order-item-status">
                <p>
                    {{ window.jsUcfirst(order_status[line_item_first.status]) }}
                </p>
            </div>

            <div class="order-item-supplier">
                <!--<span class="icon-ali icon-ali-aliexpress"></span>-->
                <span class="fw-600">Supplier</span>
                <a class="fz-11" v-bind:href="'https://'+line_item_first.supplier['url']" target="_blank" data-toggle="tooltip" v-bind:title="line_item_first.supplier['name']" data-placement="top">{{ line_item_first.supplier['name'] }}</a>
            </div>
            <div class="order-item-shipped">
                <p class="ali-order-no-wrap">
                    <span class="fw-600">Ali Order No</span>
                    <span class="add-ali-order-no-id"
                          v-bind:class="{'ali-order-no-empty' : (line_item_first.aliexpress_order_no === '' || line_item_first.aliexpress_order_no === null)}">
                        <a v-bind:href="'https://trade.aliexpress.com/order_detail.htm?orderId='+line_item_first.aliexpress_order_no" target="_blank" class="text-ali-order-no fz-11">
                            {{ line_item_first.aliexpress_order_no }}
                        </a>
                        <span class="add-ali-order-no-edit-btn" @click.prevent="openAliOrderNo">
                            <i class="mdi mdi-pencil fz-15"></i>
                        </span>
                    </span>
                    <span class="add-ali-order-no-btn" @click.prevent="openAliOrderNo">
                        <span class="fz-11">Edit number</span> <i class="mdi mdi-pencil fz-15"></i>
                    </span>
                    <input type="text" v-model="line_item_first.aliexpress_order_no" autofocus class="input-ali-order-no fz-11" @blur="saveAliOrderNo(line_item_first.aliexpress_order_no, line_item_ids, event)" @keypress.enter="saveAliOrderNo(line_item_first.aliexpress_order_no, line_item_ids, event)">

                    <!-- <a @click.prevent="saveAliOrderNo(line_item.aliexpress_order_no, line_item.id, event)" class="save-ali-order-no-btn" >Save</a> -->

                </p>
                <!-- <a v-show=" ! (line_item_first.status == window.configOrder.status.shipped)" class="order-shipped-btn ali-noselect" @click="open_shipping_modal(line_item)">Mark as shipped</a> -->

                <!--<span class="tracking-code-order" v-show="line_item_first.tracking_code && (line_item_first.status != window.configOrder.status.to_order && line_item_first.status != window.configOrder.status.order_placed)">
                    <span>Tracking Code:</span><a @click="trackingCode(line_item_first.tracking_code)"> {{ line_item_first.tracking_code }} </a>
                </span>-->
            </div>
            <div class="order-item-tracking-code">
                <span v-if="line_item_first.tracking_code && (line_item_first.status != window.configOrder.status.to_order && line_item_first.status != window.configOrder.status.order_placed)">
                    <span class="fw-600">Tracking Code</span>
                    <span class="fz-11" @click="trackingCode(line_item_first.tracking_code)"> {{ line_item_first.tracking_code }} </span>
                </span>
                <span v-else>
                    <span class="fw-600">Tracking Code</span>

                        <a class="text-link fz-11" @click="open_shipping_modal(order, line_item_ids, line_item_first)">Mark as shipped</a>
                    <!--<span v-if="line_item.status == window.configOrder.status.to_order  && (! line_item.variant_deleted_at)">-->

                        <!--<span class="fw-600">Tracking Code</span>-->
                        <!--<a class="text-link fz-11" @click="open_shipping_modal(order, line_item_ids, line_item)">Mark as shipped</a>-->
                    <!--</span>-->
                    <!--<span v-else ><span class="fw-600">Tracking Code</span><span class="fz-11">No code</span></span>-->
                </span>
            </div>
            <div class="order-product-to-order">
                <button class="item-add-aliexpress-btn" v-show="(line_item_first.status == window.configOrder.status.to_order && line_item_first.product_has_source_link == '')"  @click="addVariantProduct(line_item_first)">
                    Update Link
                </button>

                <a v-bind:class="['item-place-order-btn', 'order_product_' + order.id, line_item_number ? 'item-place-order-btn-o': '']" href="#" @click.prevent="placeOrder(order, line_item_first, line_item_ids)" v-if="(line_item_first.aliexpress_product_id != '' && line_item_first.status == window.configOrder.status.to_order && (line_item_first.aliexpress_options || !line_item_first.variant_options || line_item_first.variant_title == 'Default Title') ) && line_item_first.product_in_app == 1">

                    Order Product
                </a>

                <button class="get-tracking-code-btn"
                    v-bind:id="'tracking_code-'+line_item_first.id" v-show="line_item_first.status == window.configOrder.status.order_placed"
                    @click="getTrackingCode(line_item_ids, line_item_first.aliexpress_order_no, $event)">Get tracking code</button>

                <div class="dropdown box-dropdown box-dropdown-tracking-code">
                    <div class="box-dropdown-toggle" data-toggle="dropdown">
                        Action
                    </div>
                    <div class="dropdown-menu box-dropdown-menu">
                        <ul class="">
                            <li @click="showHideProduct(keyShowHideProduct)" v-show="line_item_first.status == window.configOrder.status.shipped"><a v-text="keyShowHideProduct == 'hide' ? 'Show all products' : 'Hide all products'"></a></li>

                            <li v-show="! line_item_first.variant_deleted_at && line_item_first.product_has_source_link  && line_item_first.product_in_app == 1"><a  @click="reOrder(order, line_item_first, line_item_ids)">Re-Order Product</a></li>

                            <li v-if="line_item_first.aliexpress_order_no"><a v-bind:id="'tracking_code-'+line_item_first.id" @click="getTrackingCode(line_item_ids, line_item_first.aliexpress_order_no, $event)">Get Tracking Code</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div> <!-- end header -->


        <div v-for="line_item in line_items" v-bind:key="line_item.id" class="order-item-product-info">

            <div class="order-item-product-img ">
                <img v-bind:src="line_item.product_variant_image" alt="">
            </div>
            <div class="order-item-product-title">
                <h2>
                    <a v-if="line_item.source_product_link" v-bind:href="line_item.source_product_link" target="_blank">
                        {{ line_item.product_title }}
                    </a>
                    <span v-else>{{ line_item.product_title }}</span>
                </h2>
                <p class="text-ellipsis" v-text="line_item.variant_title"></p>
            </div>
            <!--<div class="order-item-tracking-code">
                &lt;!&ndash; <a v-show=" ! (line_item.status == window.configOrder.status.shipped)" @click="open_shipping_modal(line_item)">Mark as shipped</a> &ndash;&gt;
                <span v-if="line_item.tracking_code && (line_item.status != window.configOrder.status.to_order && line_item.status != window.configOrder.status.order_placed)">
                    {{ line_item.tracking_code }}
                </span>
                <span v-else>
                    <span v-if="(line_item.status == window.configOrder.status.to_order && ! line_item.aliexpress_options) && (! line_item.variant_deleted_at)">Tracking: <a class="text-link" @click="open_shipping_modal(line_item)">Mark as shipped</a></span>
                    <span v-else>No Tracking Code</span>
                </span>
            </div>-->
            <div class="order-item-quantity-price">
                <span class="number">{{line_item.quality}}</span>
                <i class="mdi mdi-close"></i>
                <span class="price">{{line_item.price}} {{order.currency}}</span>
            </div>

        </div> <!-- end line_item -->
    </div>
</template>

<script type="text/javascript">
    export  default {
        props: [
            'class_status', 'line_item_first',

            'line_item_number',

            'line_items',
            'order_status', 'order',
            'current_product', 'shop_id',
            'shop_domain', 'access_token',
            'settings', 'index',
            'line_item_ids', 'key_group'
        ],
        data: function() {
            return {
                actionClass: {
                    active_add_ali_no : '',
                    trackingCurrentTarget : ''
                },
                errors: {},
                labelShowHideProduct: {
                    hide : 'Hide Product',
                    show : 'Show Product'
                },
                keyShowHideProduct: 'hide',
                window: window
            }
        },
        mounted: function () {
            let _this=this
            jQuery('[data-toggle="tooltip"]').tooltip({
                html: true,
                container: 'body'
            });
            $('body').on('click',function (event) {
                if ($(event.target).closest('.input-ali-order-no, .add-ali-order-no-btn, .add-ali-order-no-edit-btn').length === 0) {
                    _this.actionClass.active_add_ali_no = '';
                }
            })

        },
        methods: {
            openAliOrderNo: function () {
                this.actionClass.active_add_ali_no = 'active-add-ali-no'
            },
            saveAliOrderNo: function (aliOrderNo, lineItemId, $event) {
                $(event.currentTarget).loading();

                let self = this;
                axios.post(appUrl+'/orders/update_ali_order_no', {
                    'lineItemId' : lineItemId,
                    'aliexpress_order_no' : aliOrderNo,
                }).then(function (response) {
                    self.actionClass.active_add_ali_no = '';
                    if(response.data.status)
                    {
                        // const lastUpdate = response.data.lastUpdate;
                        const dataUpdate = response.data.data;
                        lineItemId.forEach(ItemId => {
                            self.line_items[ItemId].status = dataUpdate[ItemId].lastUpdate.status;
                        });
                        notify('success', 'Update success');
                    } else {
                        notify('error', 'Update error');
                    }
                    $(event.currentTarget).loading_finish();
                }).catch(function (error) {
                    notify('error', error);
                    $(event.currentTarget).loading_finish();
                });
            },
            //Open shipping modal
            open_shipping_modal : function (order, line_item_ids, line_item) {
                let tmp = []
                let line_items = order.line_items
                tmp = line_item_ids.map(function(item) {
                    return line_items[item]
                })

                this.$emit('open_shipping_modal', tmp)
            },


            //Re Order
            reOrder: function (order, line_item, line_item_ids) {
                /*let target=event.currentTarget
                $(target).preventDefault()*/
                let target=event.currentTarget
                $('.order-list-item').removeClass('active')
                $('.orders-list-wrap').removeClass('active')
                $(target).parents('.order-list-item').addClass('show-before')
                let _this = this
                if( ! checkExtension())
                    return false

                let obj_line_items = order.line_items
                let total_price_order = 0
                let orderItem = {
                    orderId: order.id,
                    orderName: order.order_name,
                    shipping_city: change_alias(order.city),
                    shipping_country: change_alias(order.country),
                    shipping_country_code: (order.country_code == 'GB' ? 'UK' : order.country_code),
                    shipping_name: change_alias(order.full_name),
                    shipping_phone: order.phone,
                    shipping_phone_code: order.phone_code,
                    shipping_province: change_alias(order.province),
                    shipping_province_code: order.province_code,
                    shipping_zip: order.zip,
                    shipping_email: window.shopMail,
                    currency: order.currency,
                    shipping_address1: change_alias(order.address1),
                    shipping_address2: change_alias(order.address2)
                }
                

                $('.order-list-item').removeClass('active')
                $('.orders-list-wrap').removeClass('active')
                orderItem['orderitems'] = line_item_ids.map(function(line_item) {
                    $('#order-list-item-'+line_item).addClass('active')
                    total_price_order += obj_line_items[line_item].total_price_item
                    return {
                        ali_ext_id : obj_line_items[line_item].aliexpress_options,
                        quantity : obj_line_items[line_item].quality,
                        product_ext_id : obj_line_items[line_item].aliexpress_product_id,
                        source_product_link: obj_line_items[line_item].source_product_link,
                        line_item_id : obj_line_items[line_item].id,
                        total_price_item : obj_line_items[line_item].total_price_item

                    }
                })

                orderItem['total_price_order'] = total_price_order

                let port = chrome.runtime.connect(chromeExtensionId);

                port.postMessage({
                    data: {
                        action: 'ACTION_ORDER_FULFILL',
                        payload: {
                            shop: _this.shop_domain,
                            orderData: [orderItem],
                            default_setting: _this.settings,
                            maximum_cost: 0, maximum_order: 0,
                            place_this_order: true
                        }
                    }
                });
                port.disconnect()
            },
            showHideProduct: function () {
                if(this.keyShowHideProduct === 'hide') {
                    $('.line_item_' + this.order.id + '_' + this.key_group).addClass('active-show-product');
                    this.keyShowHideProduct = 'show';
                }
                else {
                    $('.line_item_' + this.order.id + '_' + this.key_group).removeClass('active-show-product');
                    this.keyShowHideProduct = 'hide';
                }

            },

            placeOrder: function (order, line_item, line_item_ids) {
                let _this = this
                if( ! checkExtension())
                    return false
                let obj_line_items = order.line_items
                let total_price_order = 0
                let orderItem = {
                    orderId: order.id,
                    orderName: order.order_name,
                    shipping_city: change_alias(order.city),
                    shipping_country: change_alias(order.country),
                    shipping_country_code: (order.country_code == 'GB' ? 'UK' : order.country_code),
                    shipping_name: change_alias(order.full_name),
                    shipping_phone: order.phone,
                    shipping_phone_code: order.phone_code,
                    shipping_province: change_alias(order.province),
                    shipping_province_code: order.province_code,
                    shipping_zip: order.zip,
                    shipping_email: window.shopMail,
                    currency: order.currency,
                    shipping_address1: change_alias(order.address1),
                    shipping_address2: change_alias(order.address2)
                }

                $('.order-list-item').removeClass('active')
                $('.orders-list-wrap').removeClass('active')
                orderItem['orderitems'] = line_item_ids.map(function(line_item) {
                    $('#order-list-item-'+line_item).addClass('active')
                    total_price_order += obj_line_items[line_item].total_price_item
                    return {
                        ali_ext_id : obj_line_items[line_item].aliexpress_options,
                        quantity : obj_line_items[line_item].quality,
                        product_ext_id : obj_line_items[line_item].aliexpress_product_id,
                        source_product_link: obj_line_items[line_item].source_product_link,
                        line_item_id : obj_line_items[line_item].id,
                        total_price_item : obj_line_items[line_item].total_price_item

                    }
                })
                orderItem['total_price_order'] = total_price_order


                // let orderItem = [{
                //     orderId: order.id,
                //     orderName: order.order_name,
                //     shipping_city: change_alias(order.city),
                //     shipping_country: change_alias(order.country),
                //     shipping_country_code: order.country_code,
                //     shipping_name: change_alias(order.full_name),
                //     shipping_phone: order.phone,
                //     shipping_phone_code: order.phone_code,
                //     shipping_province: change_alias(order.province),
                //     shipping_province_code: order.province_code,
                //     shipping_zip: order.zip,
                //     shipping_email: order.email,
                //     currency: order.currency,
                //     shipping_address1: change_alias(order.address1),
                //     shipping_address2: change_alias(order.address2),
                //     total_price_order: line_item.total_price_item,
                //     orderitems: [{
                //         ali_ext_id : line_item.aliexpress_options,
                //         quantity : line_item.quality,
                //         product_ext_id : line_item.aliexpress_product_id,
                //         source_product_link: line_item.source_product_link,
                //         line_item_id : line_item.id,
                //         total_price_item : line_item.total_price_item
                //     }],
                // }];

                // console.log(orderItem)
                // return false

                let port = chrome.runtime.connect(chromeExtensionId);

                let place_this_order = false;
                if(order.lineItemGroup.length == 1) {
                    place_this_order = true
                }

                port.postMessage(
                    {
                        data:
                            {
                                action: 'ACTION_ORDER_FULFILL',
                                payload: {
                                    shop: _this.shop_domain,
                                    orderData: [orderItem],
                                    default_setting: _this.settings,
                                    maximum_cost: 0,
                                    maximum_order: 0,
                                    place_this_order: place_this_order
                                }
                            }
                    });
                port.disconnect()

            },
            getTrackingCode: function (line_item_ids, aliexpress_order_no, event) {
                if( ! checkExtension())
                    return false

                const port = chrome.runtime.connect(chromeExtensionId);
                $(event.currentTarget).loading_spin();
                let dataPayLoad = line_item_ids.map(function(item) {
                                return {
                                    line_item_id: [item],
                                    ali_order_no: aliexpress_order_no
                                }
                            });
                const payloadMsg = {
                    data: {
                        action: 'ACTION_GET_TRACKING_CODE',
                        payload: {
                            data: dataPayLoad,
                            shop_domain: this.shop_domain,
                            access_token: this.access_token,
                            shop_id: this.shop_id
                        }
                    }
                }
                port.postMessage(payloadMsg);
                port.disconnect();
            },
            addVariantProduct: function (line_item) {
                this.$emit('add_variant_product', line_item);
            },
            trackingCode: function (trackingCode) {
                 // this.$emit('tracking_code', trackingCode)
            },
        }
    };
</script>
