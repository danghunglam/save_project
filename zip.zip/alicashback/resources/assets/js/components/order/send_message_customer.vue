<template>
    <div id="send-message-to-modal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <h4 class="modal-title">Send messenger to customer</h4>
                </div>
                <div class="modal-body">
                    <div class="orders__send_message">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="fw-600">Sent from</label>
                                    <input type="text" placeholder="Dropshipper mail" readonly v-bind:value="settings.primary_email_address">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="fw-600">Sent to</label>
                                    <input type="email" v-model="customer.email" placeholder="Customer email">
                                    <p v-if="errors.sentTo !== ''" style="color: red">{{ errors.sentTo }}</p>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="fw-600">Subject</label>
                            <input type="text" v-model="customer.title" placeholder="Fill your title">
                            <p v-if="errors.title !== ''" style="color: red">{{ errors.title }}</p>
                        </div>

                        <div class="form-group m-b-0">
                            <label class="fw-600">Message</label>
                            <textarea v-model="customer.content" placeholder="Message"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click="sendMessage" v-bind:disabled="is_send" v-text="is_send ? 'Sending...' : 'Send'"></button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props: ['customer', 'settings'],
        data: function () {
            return {
                is_send: false,
                isFormValid: true,
                errors: {
                    sentTo: '',
                    title: ''
                }
            }
        },
        mounted: function () {
            let _this = this;
            $("#send-message-to-modal").on("hide.bs.modal", function () {
                _this.isFormValid = true;
                _this.errors = {
                    sentTo: '',
                    title: ''
                }
            });
        },
        methods: {
            validateForm: function () {
                let _this = this;
                _this.isFormValid = true;
                _this.errors = {
                    sentTo: '',
                    title: ''
                }
                if(_this.customer.email.length === 0) {
                    _this.errors.sentTo = 'Customer email is empty';
                    _this.isFormValid = false;
                } else {
                    if(_this.customer.email.indexOf('@') < 0) {
                        _this.errors.sentTo = 'This is not email formatted';
                        _this.isFormValid = false;
                    }
                }
                if(_this.customer.title.length === 0) {
                    _this.errors.title = 'Subject can not empty';
                    _this.isFormValid = false;
                }
            },
            sendMessage: function () {
                let _this = this
                _this.validateForm();
                if(_this.isFormValid) {
                    _this.is_send = true
                    axios.post(appUrl+'/orders/send_mail_customer', this.customer)
                        .then(function (response) {
                            let {status} = response
                            if(status)
                            {
                                notify('success', 'Send mail success')
                                $('#send-message-to-modal').modal('hide');
                            }
                            _this.is_send = false
                        })
                        .catch(function (error) {
                            notify('error', error)
                            _this.is_send = false
                        })
                }
            }
        }
    }
</script>
