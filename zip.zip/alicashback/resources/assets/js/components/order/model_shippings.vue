<!--Multi shipping modal-->
<template>
    <div id="productShippedModal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <h4 class="modal-title">Mark as shipped</h4>
                </div>
                <div class="modal-body">
                    <div class="mark__shipped-wrap">
                        <div class="override__product-info" v-for="(item, key) in items">
                            <div class="override__product-img">
                                <img v-bind:src="item.product_variant_image" v-bind:alt="item.product_title" />
                            </div>
                            <div class="override__product-title">
                                <a class="text-link" v-bind:href="item.product_link" v-if="item.product_link!=''" v-text="item.product_title"></a>
                                <p v-else v-text="item.product_title"></p>
                                <p v-if="item.supplier">Supplier: <a :href="item.supplier.url" target="_blank" v-text="item.supplier.name" class="text-link"></a></p>
                                <p v-if="item.variant_sku" v-text="item.variant_sku"></p>
                            </div>
                        </div>
                        <div class="form-group m-b-0 mark__shipped-input">
                            <label class="fw-600">Tracking code</label>
                            <input class="shipped-tracking-code" v-model="tracking_code" type="text" placeholder="Enter tracking code">
                            <label class="error" v-text="(errors_tracking_code) ? errors_tracking_code : ''"></label>
                        </div>
                        <div class="m-t-30">
                            <label class="checkbox-style" for="check-send-email">
                                <input type="checkbox" id="check-send-email" v-model="send_mail_customer">
                                <span class="checked-style"></span>
                                Send a notification email to the customer
                            </label>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click="saveTrackingCode">Mark as Shipped</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export  default {
        name: 'modal_shipping',
        props: {
            items_detail: {
                required: true,
            },
            settings: {
                required: true
            }
        },
        data: function () {
            return {
                errors_tracking_code: null,
                send_mail_customer: false,
                items: null,
                tracking_code: null,
            }
        },
        mounted: function () {
            let _this = this
            $('#productShippedModal').on('hidden.bs.modal', function () {
                _this.errors_tracking_code = ''
            })
        },
        methods: {
            saveTrackingCode: function () {
                let _this = this
                this.errors_tracking_code = ''

                if ( ! this.tracking_code) {
                    this.errors_tracking_code = 'Please input tracking code'
                    return false
                }

                this.errors_tracking_code = ''
                let items = this.items.map(function(item){
                    return Object.assign({}, item, {
                        tracking_code: _this.tracking_code
                    })
                })

                console.log(items)

                this.$emit('save_tracking_code', items, this.send_mail_customer, _this.tracking_code)
            }
        },
        watch: {
            items_detail: {
                handler: function (new_val) {
                    this.items = Object.values(new_val).map(function (obj) {
                        return {
                            id: obj.id,
                            product_link: obj.source_product_link,
                            product_variant_image: obj.product_variant_image,
                            product_title: obj.product_title,
                            variant_sku: obj.variant_sku,
                            supplier: {
                                name: _.has(obj, 'supplier.name') ? obj.supplier.name : null,
                                url: _.has(obj, 'supplier.url') ? obj.supplier.url : null
                            },
                            tracking_code: null,
                            orders_id: obj.orders_id
                        }
                    })
                },
                deep: true
            },
            settings: {
                handler: function (new_val) {
                    this.send_mail_customer = new_val.notification_email_customer_fulfillment
                },
                deep: true
            }

        }
    }
</script>
