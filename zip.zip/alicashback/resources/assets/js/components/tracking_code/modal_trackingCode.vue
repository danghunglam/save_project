<template>
    <div id="trackingCodeModal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><i class="icon-ali icon-ic-highlight-off-24px"></i></button>
                    <h4 class="modal-title">Package Tracking</h4>
                </div>
                <div class="modal-body" style="height: 600px">
                    <iframe v-bind:src="'https://t.17track.net/en#nums='+tracking_code_id" style="width: 100%; height: 500px"></iframe>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "modal_trackingCode",
        props:['tracking_code_id'],
        data() {
            return {

            }
        },
    }
</script>
