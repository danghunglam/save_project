<template>
    <div class="ars-table-row ars-table-row-item">
        <div class="ars-table-col col-variant-select">
            <label v-bind:for="'select-variant-'+variant.id" class="checkbox-style checkbox-text-o">
                <input v-bind:id="'select-variant-'+variant.id" value="1" v-model="variant.selected" v-on:change="selectVariant(variant)" type="checkbox">
                <span class="checked-style"></span>
            </label>
        </div>
        <div class="ars-table-col col-variant-product">
            <div class="box-variant-content">
                <img v-bind:src="variant.image" alt="">
                <span v-if="!variant.selected"></span>
                <div v-if="variant.selected" class="select-variant-image" @click="showModalImage(variant)"><i class="mdi mdi-plus"></i></div>
            </div>
        </div>
        <div class="ars-table-col col-variant-color" v-for="(option, label, key) in variant.options" v-bind:key="key">
            <div class="box-variant-content">
                <input type="text" @change="checkUpdateVariant(variant, option, label)" v-bind:value="option">
                <span v-if="!variant.selected"></span>
            </div>
        </div>
        <div class="ars-table-col col-variant-cost">
            <div class="box-variant-content">
                <input type="text" readonly disabled @change="updateVariant()" v-bind:value="'$'+variant.cost">
                <span v-if="!variant.selected"></span>
            </div>
        </div>

        <div class="ars-table-col col-variant-shipping">
            <div class="box-variant-content">
                <input v-if="price_shipping" type="text" readonly disabled v-bind:value="'$'+price_shipping">
                <input v-else type="text" readonly disabled value="$0">
                <span v-if="!variant.selected"></span>
            </div>
        </div>
        <div class="ars-table-col col-variant-price">
            <div class="box-variant-content">
                <div class="input-group">
                    <input type="text" :id="variant.id" @keyup="isNumberKeyup($event, 'price')" @keypress="isNumber($event)" @change="changePrice" v-model="variant.price">
                    <span class="input-group-addon" v-text="currency ? currency : 'USD'"></span>
                </div>
                <span v-if="!variant.selected"></span>
            </div>
        </div>
        <div class="ars-table-col col-variant-profit">
            <div class="box-variant-content">
                <input type="text" v-bind:style=" profit < 0 ? 'color: red;' : ''" readonly disabled v-bind:value="'$'+profit">
                <!--<input v-else type="text" v-bind:style="variant.cost < 0 ? 'color: red;' : ''" readonly disabled v-bind:value="'$'+variant.cost">-->
                <span v-if="!variant.selected"></span>
            </div>
        </div>
        <div class="ars-table-col col-variant-compared-at-price">
            <div class="box-variant-content">
                <div class="input-group">
                    <input type="text" @keyup="isNumberKeyup($event, 'compare_at_price')" @keypress="isNumber($event)" @change="changeComparePrice" v-model:value="variant.compare_at_price">
                    <span class="input-group-addon" v-text="currency ? currency : 'USD'"></span>
                </div>
                <span v-if="!variant.selected"></span>
            </div>
        </div>
        <div class="ars-table-col col-variant-inventory">
            <div class="box-variant-content">
                <input type="text" disabled @change="updateVariant()" v-model="variant.inventory_quantity">
                <span v-if="!variant.selected"></span>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
    import modal_item_image from '../../components/common/modal_item_image'
    import Vue from 'vue'
    export default {
        props: {
            props_variant: {
                required: true,
                type: Object
            },
            settings: {
                required: true
            },
            price_shipping:{
                required: true,
                value: 0
            }
        },
        data() {
            return {
                variant: Object.assign({}, this.props_variant),
                profit : 0,
                cost : 0,
                currency: window.currency ? window.currency : 'USD',
                exchange: window.exchange ? window.exchange : 1
            }
        },
        mounted: function() {
            this.profit_calculate()

            if(this.variant.price < 0)
                Math.abs(variant.price)
            if(this.variant.compare_at_price < 0)
                Math.abs(variant.compare_at_price)
        },
        methods: {
            selectVariant: function (variant) {
                // this.variant = variant
                // console.log(variant)
                this.$emit('select-variant', variant)
            },
            isNumber: function(evt) {
                evt = (evt) ? evt : window.event;
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if ((charCode >= 48 && charCode <= 57) || charCode === 46) {
                    return true
                } else {
                    evt.preventDefault()
                }
                // parseFloat(Math.round(num1 * 100) / 100).toFixed(2)
            },
            isNumberKeyup: function(event, name) {
                console.log(name)
                let val = $(event.currentTarget).val()
                let str_split = val.split('.');
                if( str_split[1] != undefined &&  str_split[1].length >= 3 || str_split.length >=3) {
                    let last = str_split[1].slice(0, 2)
                    let first = str_split[0] + '.'
                    val = first.concat(last)
                    this.variant[name] = val
                }
            },
            showModalImage: function(obj_variant) {
                this.$emit('show-modal-images', obj_variant)
            },
            setPrice:function ({ type, target }) {
                this.variant.price = target.value
                this.profit_calculate()

            },
            changePrice:function({ type, target }){
                let _this = this
                let value = target.value
                if(value == '' || isNaN(value))
                    value = 0
                _this.variant.price = parseFloat(value).toFixed(2)
                _this.props_variant.price = _this.variant.price
                _this.profit_calculate()
                _this.$emit('save-item')
            },
            setComparePrice:function({ type, target }){
                this.variant.compare_at_price = target.value
                this.profit_calculate()

            },
            changeComparePrice:function({ type, target }){
                let _this = this
                let value = target.value
                if(value =='' || isNaN(value))
                    value = 0

                _this.variant.compare_at_price = parseFloat(value).toFixed(2)
                _this.props_variant.compare_at_price = _this.variant.compare_at_price

                _this.profit_calculate()
                _this.$emit('save-item')
            },
            updateVariant: function () {
                this.$emit('save-item')
            },

            checkUpdateVariant:function (variant, option = '', key = '') {
                let _this = this
                let new_value = event.target.value

                if(! new_value){
                    notify('error', 'Variant not null')
                    event.target.value = new_value
                }else{
                    // let options = Object.assign({}, _this.variant.options)
                    // options[key] = new_value
                    // _this.variant = Object.assign({}, _this.variant, {
                    //     options : options
                    // })
                    console.log(variant)
                    _this.variant.options[key] = new_value

                    // console.log(_this.variant)
                    // this.$emit('save-item', _this.variant)
                }
            },
            
            profit_calculate:function () {
                this.profit =  ( (parseFloat(this.variant.price) / this.exchange) - (parseFloat(this.variant.cost)+ parseFloat(this.price_shipping ? this.price_shipping : 0))).toFixed(2)
                this.profit = (this.profit == -0.00) ? 0.00 : this.profit;
            }
        },
        computed: {
            computedImage: function() {
                return this.variant.image
            }
        },
        components: {
            modal_item_image
        },
        watch:{
            variant: function (value) {
                this.profit_calculate()
            },
            props_variant: {
                handler: function(val, oldVal) {
                    this.variant = Object.assign({}, val)
                },
                deep: true
            },
            price_shipping: {
                handler: 'profit_calculate',
                immediate: true
            },
            current_product:{
                handler: function(val, oldVal) {
                    this.variant = Object.assign({}, val)
                        this.profit_calculate()
                },
                deep: true
            }
            
        }
    }
</script>
