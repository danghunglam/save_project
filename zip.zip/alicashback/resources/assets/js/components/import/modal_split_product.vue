<template>
    <div :id="'modal_split_product'" data-backdrop="static" data-keyboard="false" class="modal split-modal-container" role="dialog">
        <div class="modal-dialog split-modal" v-if="split_product">
            <div class="modal-content  split-modal">
                <div class="modal-body">
                    <div class="override__from_note split-popup__header">
                        <span>Split Product</span>
                        <div class="split-popup__tip"><p
                                v-bind:class="{override__note_warning: true, split_note_message: !disabled}">
                                <i class="mdi mdi-alert-circle"></i>
                                {{ message}}
                            </p>
                        </div>
                        <div class="override__note_button">
                            <span class="button-style-sm-o button-remove-product" @click="cancel">Cancel</span>
                            <button class="button-style-dark-sm btn-submit" v-bind:disabled="disabled" type="button"
                                    @click="splitProduct">Split Product
                            </button>
                        </div>
                    </div> <!-- end button header -->
                    <div class="m-t-20 split-popup__help">
                        <p>Select which option you want to use for splitting the product</p>
                    </div>
                    <div class="list-variant-popup__body">
                        <div class="list-variant__container">
                            <div class="variant__container row" v-for="(option, label, key) in optionFilter" :key=key>
                                <label for="" class="variant__label col-lg-1">{{ label }}</label>
                                <div class="variant-list__value col-lg-10">
                                    <label class="checkbox-style checkbox-text-o col-lg-3"
                                           v-for="(select, value, optionKey) in option" :key="optionKey">
                                        <input v-model="option[value]['selected']" v-on:change="selectOptionFilter(select)"
                                               v-bind:for="'select-variant-split-'+key+'-'+optionKey" value="1"
                                               type="checkbox">
                                        <span class="checked-style"></span> <span
                                            class="variant-value">{{ value }}</span>
                                    </label>
                                </div>
                            </div>
                        </div> <!-- list options -->
                        <div class="tab-content">
                            <div v-bind:id="'variants-split'+product_id" class="tab-variants tab-pane fade in active">
                                <div class="tab-variants-wrap">
                                    <div class="ars-table">
                                        <div class="ars-table-head">
                                            <div class="ars-table-col col-variant-select">
                                                <label class="checkbox-style checkbox-text-o"
                                                       v-bind:for="'select-variant-all-split-'+product_id"
                                                       title="You can selected a maximum of 100 variants">
                                                    <input v-bind:id="'select-variant-all-split-'+product_id"
                                                           @change="selectAllVariants" value="1" type="checkbox">
                                                    <span class="checked-style"></span>
                                                </label>
                                            </div>
                                            <div class="ars-table-col col-variant-product">Products</div>
                                            <div class="ars-table-col" :key="key"
                                                 v-for="(option, label, key) in optionFilter">
                                                {{ label }}
                                            </div>
                                            <div class="ars-table-col col-variant-cost">Cost</div>
                                            <div class="ars-table-col col-variant-price">
                                                Price
                                            </div>
                                            <div class="ars-table-col col-variant-compared-at-price">
                                                Compare At Price
                                            </div>
                                            <div class="ars-table-col col-variant-inventory">Inventory</div>
                                        </div> <!-- end header text -->
                                        <div class="ars-table-row ars-table-row-item"
                                             v-for="(variant, index) in variants"
                                             :key="index">
                                            <div class="ars-table-col col-variant-select">
                                                <label v-bind:for="'select-variant-split-'+variant.id"
                                                       class="checkbox-style checkbox-text-o">
                                                    <input v-bind:id="'select-variant-split-'+variant.id"
                                                           v-model="variant.selected"
                                                           v-on:change="selectVariant(variant)"
                                                           type="checkbox">
                                                    <span class="checked-style"></span>
                                                </label>
                                            </div>
                                            <div class="ars-table-col col-variant-product">
                                                <div class="box-variant-content">
                                                    <img v-bind:src="variant.image ? variant.image : ''" alt="">
                                                    <span v-if="!variant.selected"></span>
                                                </div>
                                            </div>
                                            <div class="ars-table-col col-variant-color" :key="key"
                                                 v-for="(option, label, key) in variant.options">
                                                <div class="box-variant-content">
                                                    <input disabled readonly type="text" v-bind:value="option">
                                                    <span v-if="!variant.selected"></span>
                                                </div>
                                            </div>
                                            <div class="ars-table-col col-variant-cost">
                                                <div class="box-variant-content">
                                                    <input disabled readonly type="text"
                                                           v-bind:value="'$'+variant.source_price">
                                                    <span v-if="!variant.selected"></span>
                                                </div>
                                            </div>
                                            <div class="ars-table-col col-variant-price">
                                                <div class="box-variant-content">
                                                    <div class="input-group">
                                                        <input disabled readonly type="text" v-model="variant.price">
                                                        <span class="input-group-addon">{{ currency }}</span>
                                                    </div>
                                                    <span v-if="!variant.selected"></span>
                                                </div>
                                            </div>
                                            <div class="ars-table-col col-variant-compared-at-price">
                                                <div class="box-variant-content">
                                                    <div class="input-group">
                                                        <input disabled readonly type="text" v-model="variant.compare_at_price">
                                                        <span class="input-group-addon">{{ currency }}</span>
                                                    </div>
                                                    <span v-if="!variant.selected"></span>
                                                </div>
                                            </div>
                                            <div class="ars-table-col col-variant-inventory">
                                                <div class="box-variant-content">
                                                    <input type="text" disabled v-model="variant.inventory_quantity">
                                                    <span v-if="!variant.selected"></span>
                                                </div>
                                            </div>
                                        </div> <!-- end v-for variant -->
                                    </div> <!-- end tab content -->
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: {
            split_product: {
                type: Object,
                required: true
            }
        },
        data() {
            return {
                currency: window.currency ? window.currency : 'USD',
                variants: [],
                product_id: null,
                optionFilter: {},
                disabled: false,
                isAnd: true
            }
        },
        methods: {

            selectVariant(objVariant) {
                let currentOption = Object.assign({}, objVariant.options)
                Object.keys(objVariant.options).forEach(function (key) {
                    currentOption[key] = {
                        value: objVariant.options[key],
                        number: 0
                    }
                })
                this.variants = this.variants.map(function (variant) {
                    if (objVariant.id === variant.id) {
                        variant.selected = objVariant.selected
                    }
                    if(variant.selected) {

                    }
                    for (let key in currentOption) {
                        if(currentOption[key]['value'] == variant.options[key] && variant.selected == true) {
                            currentOption[key]['number']++
                        }
                    }

                    return variant
                })
                for (let key in currentOption) {
                    if(this.optionFilter[key][currentOption[key]['value']]['total'] == currentOption[key]['number']) {
                        this.optionFilter[key][currentOption[key]['value']]['selected'] = true
                    } else if(currentOption[key]['number'] == 0) {
                        this.optionFilter[key][currentOption[key]['value']]['selected'] = false
                    }
                }
            },
            cancel() {
                $('#modal_split_product').modal('hide');
            },
            selectAllVariants: function (event) {
                let checked = $(event.currentTarget).prop('checked');
                this.variants = this.variants.map(function (variant) {
                    variant.selected = checked
                    return variant
                })
            },
            splitProduct() {
                let _this = this;
                let ids = this.variants.filter(function (variant) {
                    return variant.selected == true;
                }).map(function (variant) {
                    return variant.id;
                });

                let relicateData = {
                    product_id: _this.product_id,
                    variant_selected: ids
                };

                axios.post(appUrl + '/import/relicate_product', relicateData)
                    .then(function (response) {
                        let {status} = response
                        if (status) {
                            notify('success', 'Success')
                            _this.$emit('refesh_page')
                            _this.cancel()
                        }
                    })
                    .catch(function (error) {
                    })
            },
            selectOptionFilter(option) {
                let _this = this
                let filterOject = {}
                let allEmpty = true
                Object.keys(this.optionFilter).forEach(function (key) {
                    filterOject[key] = Object.keys(_this.optionFilter[key]).filter(function (keyValue) {
                        return _this.optionFilter[key][keyValue]['selected'] == true
                    })
                })
                if(Object.keys(filterOject).filter(function(key) {
                    return filterOject[key].length > 0
                }).length > 0) {
                    allEmpty = false
                }
                this.variants = this.variants.map(function (variant) {
                    if(allEmpty == true) {
                        variant.selected = false
                    } else {
                        variant.selected = _this.isAnd
                        for (let key in filterOject) {
                            if(_this.isAnd) {
                                if (filterOject[key].length != 0 && filterOject[key].indexOf(variant.options[key]) == -1) {
                                    variant.selected = false
                                }
                            } else {
                                if (filterOject[key].length != 0 && filterOject[key].indexOf(variant.options[key]) > -1) {
                                    variant.selected = true
                                }
                            }

                        }
                    }
                    return variant
                });
            }
        },
        computed: {
            message() {
                let selected_variant = this.variants.filter(function (variant) {
                    return variant.selected
                }).length

                if (selected_variant == 0) {
                    this.disabled = true
                    return 'Please choose at least 1 variant to split product'
                }

                if (selected_variant == this.variants.length) {
                    this.disabled = true
                    return 'Can not split all variants to another product'
                }
                this.disabled = false
                return selected_variant + (selected_variant == 1 ? ' variant ' : ' varians ') + ' will be split to another product'
            }
        },
        watch: {
            split_product: {
                handler(value) {
                    // this.split_product = value
                    this.product_id = value.id
                    this.variants = JSON.parse(JSON.stringify(value.variants))
                    this.variants = this.variants.map(function (variant) {
                        variant.selected = false
                        return variant
                    })
                    this.optionFilter = {}
                    let _this = this;
                    this.variants.forEach(function (variant) {
                        for (let optionKey in variant.options) {
                            if (typeof _this.optionFilter[optionKey] == 'undefined') {
                                _this.optionFilter[optionKey] = {
                                    [variant.options[optionKey]]: {
                                        selected: false,
                                        total: 1
                                    }
                                }
                            } else {
                                if (typeof _this.optionFilter[optionKey][variant.options[optionKey]] == 'undefined') {
                                    _this.optionFilter[optionKey][variant.options[optionKey]] = {
                                        selected: false,
                                        total: 1
                                    }
                                } else {
                                    _this.optionFilter[optionKey][variant.options[optionKey]]['total']++
                                }
                            }
                        }
                    });
                }
            }
        }
    }
</script>
<style scoped lang="scss">
    html, body {
        height: 100%;
    }
    p {
        &.split_note_message {
            background: #D8E7FF;
        }
    }

    .btn-submit {
        &[disabled="disabled"] {
            opacity: 0.3;
            &:hover {
                background: #333;
            }
        }
    }

    .split-modal-container {
        /*width: 1170px;*/
        .split-modal {
            width: 1170px;
            max-height: 85%;
            overflow-y: hidden;
            .modal-body {
                max-height: -webkit-fill-available;
            }
            .split-popup__header {
                justify-content: space-between;
                & > span {
                }
                .split-popup__tip {
                    flex: 1;
                    margin-left: 25px;
                    & > p {
                        width: fit-content;
                    }
                }

                .mdi {
                    &.mdi-alert-circle {
                        font-size: 14px;
                        margin: 0px 5px 0 0;
                        // color: #3E88FF;
                    }
                }
            }
            .list-variant-popup__body {
                max-height: calc(90vh - 180px);
                overflow-y: scroll;
                .tab-variants {
                    overflow-y: unset;
                }
            }
            .split-popup__help {
                position: relative;
                padding-bottom: 2px;
                & > p {
                    position: relative;
                    width: 100%;
                }
                &:after {
                    width: 100%;
                    content: '';
                    position: absolute;
                    bottom: 0px;
                    height: 1px;
                    background: #E9E9F0;
                }
            }
            .list-variant__container {
                .variant__container {
                    /*display: flex;*/
                    /*flex-direction: column;*/
                    //
                    margin-left: 0px;
                    margin-right: 0px;
                    border-radius: 6px;
                    padding: 15px;
                    background: #F8F2FF;
                    margin-top: 18px;
                    label.checkbox-style {
                        /*margin-top: 10px;*/
                    }
                    .variant__label {
                        margin-top: 5px;
                        width: 100px;
                    }
                    .variant-list__value {
                      & > label {
                          flex-grow:0;
                          flex-shrink:0;
                          margin: 5px 0px;
                      }
                        /*width: calc(100% - 100px);*/
                    }
                    .variant-value {
                        margin-left: 10px;
                        width: calc(100% - 20px);
                        display: block;
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                    }

                }
            }
            .tab-content {
                padding-top:0px;
                margin-top: 18px;
                .tab-variants-wrap {
                }
            }
        }
    }

</style>
