<template>
    <div :id="'modal-shipping-country-'+props_product.aliexpress_product_id" class="modal-shipping-country" role="dialog">
    <!--<div :id="'modal-shipping-country-'+product.aliexpress_product_id" class="modal fade in modal-shipping-country" role="dialog">-->
        <div class="modal-dialog modal-lg width-600">

            <div class="modal-content modal__content_icon content-shipping-country">
                <div class="modal-header">
                    <button class="close"><i class="mdi mdi-close"></i></button>
                    <div class="modal__header_icon">
                        <h4>Shipping methods</h4>
                    </div>
                </div> <!-- end modal-header -->
                <div class="modal-body">
                    <div class="shipping-price-country">
                        <span>Ship my order(s) to: </span>
                        <div class="dropdown box-dropdown">
                            <span class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <div v-if="!checkNullObject(country_select) && chooseCountry">
                                    <span :class="'css_flag css_'+country_select.code.toUpperCase()"></span>
                                    <span :class="'pad-left-30'">{{country_select.name}}</span>
                                </div>
                                <div v-else>
                                    <span>Select Country</span>
                                </div>
                            </span>
                            <div class="dropdown-menu box-dropdown-menu" style="max-height: 286px; overflow-x: auto;">
                                <ul>
                                    <li v-for="country in countries" @click="selectCountry(country)"><!--<img v-bind:src="'/images/backend/country/'+country.code+'.png'" :alt="country.name">-->
                                        <span :class="'css_flag css_'+country.code.toUpperCase()"></span>
                                        <span :id="country.code" :class="'pad-left-30'" :needChildren="country.needChildren" >{{ country.name }}</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="shipping-price-province" v-bind:style="checkNullObject(provinces) ? 'display: none;' : ' float: right;'" >

                                <div class="dropdown box-dropdown" id="province">
                                <span v-if="!checkNullObject(defaultProvince)" class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                                       {{defaultProvince.n}}
                                </span>
                                    <div class="dropdown-menu box-dropdown-menu" style="max-height: 286px; overflow-x: auto; right: 0; left: auto;">
                                        <ul>
                                            <li v-for="province in provinces" :id="province.c" @click="selectProvince(province)">{{province.n}}</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="dropdown box-dropdown" id="city">
                                    <!--v-text="province_city.c == defaultCity && province_city.children"-->
                                    <span  v-if="!checkNullObject(defaultCity)" class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        {{defaultCity.n}}
                                    </span>
                                    <div class="dropdown-menu box-dropdown-menu" style="max-height: 286px; overflow-x: auto; right: 0; left: auto;">
                                    <ul>
                                        <li v-if="!checkNullObject(cities)" v-for="city in cities" :id="city.c" @click="selectCity(city)">{{city.n}}</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <p v-show="freights.length>0">These are shipping methods you will be able to select when processing orders:</p>

                    <div class="shipping-table" ref="shippingTable" v-show="freights.length>0">
                        <div class="ars-table">
                            <div class="ars-table-head">
                                <div class="ars-table-col">
                                    Shipping Method
                                </div>
                                <div class="ars-table-col" style="width: 150px">
                                    Estimated Delivery Time
                                </div>
                                <div class="ars-table-col" style="width: 150px">
                                    Shipping Cost
                                </div>
                                <div class="ars-table-col" style="width: 150px">
                                    Tracking Information
                                </div>
                            </div>
                            <div v-for="freight, key in freights" class="ars-table-row">
                                <div class="ars-table-col">
                                    <label class="radio-style radio-style-modal">
                                        <input @click.self="selectCompanyShip(freight, key)" v-bind:value="key" type="radio" name="shipping-company">
                                        <span class="checked-style"></span>
                                        {{freight.companyDisplayName}}
                                    </label>
                                </div>
                                <div class="ars-table-col">
                                    {{freight.time}} days
                                </div>
                                <div v-text="freight.price==0 ? 'Free Shipping' : freight.priceFormatStr" class="ars-table-col">

                                </div>
                                <div class="ars-table-col">
                                    <span v-text="freight.isTracked ? 'Available' : 'Not available' "></span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div> <!-- end modal-body -->
                <div class="modal-footer">
                    <button class="btn-shipping button-style-sm" @click="useCompanyShip" type="button" >Apply</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
    export  default {
        name: 'modal_shipping_country',
        props: ['props_product'],
        data: function () {
            return {
                product: Object.assign({}, this.props_product),
                defaultCity: {},
                defaultProvince: {},
                cities: [],
                provinces: {},
                types: {
                    city: null,
                    country: null,
                    province: null
                },
                chooseCountry: false,

                countries:[],
                country_select: {},
                freights:[],
                infoCompany: null,
                keySelect: null
            }
        },
        created: function() {

            this.getCountries()
        },
        mounted: function(){
            $(document).on('click','.modal-shipping-country .close,.bg-modal-shipping, .modal-shipping-country .bg-white-modal',function () {
                $('.modal-shipping-country').removeClass('show-modal-shipping')
                $('.bg-modal-shipping').remove()
            });
            $('.modal-shipping-country').click(function (event) {
                if (!$(event.target).closest('.modal-shipping-country .modal-dialog').length) {
                    $('.modal-shipping-country').removeClass('show-modal-shipping')
                    $('.bg-modal-shipping').remove()
                }
            })
        },
        methods: {
            getCountries: function(){
                let _this = this
                let file = appUrl+'/json/shipping/countries.txt';

                let rawFile = new XMLHttpRequest();
                rawFile.open("GET", file, false);
                rawFile.send(null);

                let res = JSON.parse(rawFile.response)
                _this.countries = res
            },
            setfreights:function(){
                let _this = this

                this.$nextTick(function () {
                    window.getFreightAliExpress = function(args)
                    {
                        _this.freights = args.freight.map(function (object) {
                            return {
                                companyDisplayName : object.companyDisplayName,
                                time : object.time,
                                price : object.price,
                                priceFormatStr: object.priceFormatStr,
                                isTracked: object.isTracked,
                            }
                        })
                        _this.$nextTick(function () {
                            _this.updateSelectedRadio()
                        })
                    }
                })
            },
            checkNullObject(obj){
                return $.isEmptyObject(obj)
            },
            loadProvincecity(country_code){
                let _this = this

                let file = appUrl+'/json/shipping/'+country_code+'.txt';

                let rawFile = new XMLHttpRequest();
                rawFile.open("GET", file, false);
                rawFile.send(null);

                let res = JSON.parse(rawFile.response)
                _this.provinces = res.addressList

                _this.defaultProvince =  _this.provinces[0]
                _this.defaultCity = _this.defaultProvince.children[0]

                _this.cities = _this.defaultProvince.children

                _this.types.province = _this.defaultProvince.c
                _this.types.city = _this.defaultCity.c
            },
            selectCountry:function (country) {
                let _this = this
                _this.chooseCountry = true
                _this.country_select = country
                if(country.needChildren=="true"){
                    _this.loadProvincecity(country.code)
                }else{
                    _this.provinces={}
                    _this.types.province = null
                    _this.types.city = null
                }
                _this.types.country = country.code
                _this.getMethod()

            },
            selectProvince:function (province_select) {
                let _this = this
                _this.defaultProvince = province_select
                _this.cities = province_select.children
                _this.defaultCity = _this.cities[0]
                _this.types.province = province_select.c
                _this.getMethod()
            },
            selectCity:function (city) {
                let _this = this
                _this.defaultCity = city
                _this.types.city = city.c
                _this.getMethod()
            },
            getMethod:function () {
                let _this = this
                let priceMinMax = _this.product.price_range ? typeof (_this.product.price_range)== "object" ? _this.product.price_range : JSON.parse(_this.product.price_range) : 0
                let url = 'https://freight.aliexpress.com/ajaxFreightCalculateService.htm?' +
                    'callback=jQuery18309588254488714415_1539076163637&f=d&productid='+_this.product.aliexpress_product_id+'&' +
                    'count=1&minPrice='+priceMinMax.minPrice+'&maxPrice='+priceMinMax.maxPrice+'&currencyCode=USD&transactionCurrencyCode=USD&sendGoodsCountry=&' +
                    'country='+_this.types.country.toUpperCase()+'&' +
                    'province='+_this.types.province+'&' +
                    'city='+_this.types.city+'&' +
                    'abVersion=1&_=1539076181301'

                // let url = 'https://freight.aliexpress.com/ajaxFreightCalculateService.htm?' +
                //     'callback=jQuery18309588254488714415_1539076163637&f=d&productid='+_this.product.aliexpress_product_id+'&' +
                //     'count=1&minPrice=10&maxPrice=10&currencyCode=USD&transactionCurrencyCode=USD&sendGoodsCountry=&' +
                //     'country='+_this.types.country.toUpperCase()+'&' +
                //     'province='+_this.types.province+'&' +
                //     'city='+_this.types.city+'&' +
                //     'abVersion=1&_=1539076181301'

                window.postMessage({action: 'ACTION_GET_FREIGHT_FROM_ALIEXPRESS', payload: {url: url}}, '*')
                _this.setfreights()
            },
            useCompanyShip() {
                this.$emit('freight', this.infoCompany, this.product)
                 // $('#modal-shipping-country-'+_this.product.aliexpress_product_id).modal('hide');
                $('.modal-shipping-country').removeClass('show-modal-shipping')
                $('.bg-modal-shipping').remove()
            },
            selectCompanyShip:function (infoCompany, key) {
                let _this = this
                this.infoCompany = infoCompany
                if(this.infoCompany.price=="0")
                    this.infoCompany.priceFormatStr = 'Free Shipping'

                this.infoCompany.shipTo = _this.country_select.name
                this.infoCompany.types = Object.assign({}, _this.types)
                this.infoCompany.types.key = key
                // _this.$emit('freight', infoCompany, _this.product)
                //  // $('#modal-shipping-country-'+_this.product.aliexpress_product_id).modal('hide');
                // $('.modal-shipping-country').removeClass('show-modal-shipping')
                // $('.bg-modal-shipping').remove()
            },
            setinfoCompanyByKey(key) {
                if(typeof this.freights[key] != 'undefined') {
                    let infoCompany = this.freights[key]
                    this.selectCompanyShip(infoCompany, key)
                }
            },
            updateSelectedRadio: function() {
                let topPosition = 0;
                $('[name=shipping-company]').prop('checked', false)
                if(typeof this.product.types != 'undefined') {
                    if(this.product.types.country == this.types.country &&
                        this.product.types.province == this.types.province &&
                        this.product.types.city == this.types.city) {
                            $('[name=shipping-company][value='+this.product.types.key+']').prop('checked', true)
                            topPosition = this.product.types.key;
                            this.setinfoCompanyByKey(this.product.types.key)
                        } else {
                            $('[name=shipping-company][value=0]').prop('checked', true)
                            this.setinfoCompanyByKey(0)
                        }
                } else {
                    $('[name=shipping-company][value=0]').prop('checked', true)
                    this.setinfoCompanyByKey(0)
                }
                if(typeof $('[name=shipping-company]:checked').val() == 'undefined') {
                    this.setinfoCompanyByKey(0)
                }

                this.$refs.shippingTable.scrollTop = topPosition*40;
            },
            initDataShip() {
                if(typeof this.product.types != 'undefined') {
                    this.types = JSON.parse(JSON.stringify(this.product.types))
                } else {
                    this.types = {
                        city: null,
                        country: null,
                        province: null
                    }
                    this.provinces = null
                    this.cities = null
                    this.freights = []
                }
                if(this.types.country == null) {
                    this.country_select = null
                    this.freights = []
                } else {
                    let _this = this;
                    let country_select = this.countries.filter(
                                        function(item) {
                                            return item.code == _this.types.country
                                        });
                    if(country_select.length > 0) {
                        country_select = country_select[0]
                        this.country_select = country_select
                        this.chooseCountry = true
                        if(country_select.needChildren=="true"){

                            let file = '/storage/shipping/' + this.types.country + '.txt';

                            let rawFile = new XMLHttpRequest();
                            rawFile.open("GET", file, false);
                            rawFile.send(null);

                            let res = JSON.parse(rawFile.response)
                            this.provinces = res.addressList

                            let province_select = this.provinces.filter(
                                        function(item) {
                                            return item.c == _this.types.province
                                        });
                            if(province_select.length > 0) {
                                this.province_select = province_select[0]
                                this.cities = this.province_select.children
                                let defaultCity = this.cities.filter(
                                        function(item) {
                                            return item.c == _this.types.city
                                        });
                                if(defaultCity.length > 0) {
                                    this.defaultCity = defaultCity[0]
                                }
                            }
                        } else {
                            _this.provinces={}
                            _this.types.province = null
                            _this.types.city = null
                        }

                    }
                    this.getMethod()
                }
            }
        },
        watch:{
            props_product: {
                handler: function(val, oldVal) {
                    this.product = Object.assign({}, val)
                    // this.initDataShip()
                },
                deep: true
            }
        }
    };
</script>
<style lang="scss" scoped>
    .btn-shipping {
        display: block;
        width: auto;
        background: #ffffff;
        margin: 20px auto;
        padding-left: 25px;
        padding-right: 25px;
        font-size: 13px;
        font-weight: 400;
        border: solid 1px #D7DAE2;
        -webkit-box-shadow: none;
        box-shadow: none;
        line-height: 34px;
        color: #242539;
        border-radius: 6px;
        user-select: none;
        outline: none;
        vertical-align: middle;
        text-align: center;
        cursor: pointer;
        transition: 0.3s;
        &:hover{
            border: solid 1px #7009FF;
            background-color: #7009FF;
            color: #ffffff;
        }
    }
</style>

