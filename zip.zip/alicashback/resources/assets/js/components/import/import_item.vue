<template>
    <li v-bind:class="(product.selected) ? 'active' : ''">
        <!--{{ product }}-->
        <div class="product-import-wrap">
            <div class="header-import-wrap">
                <div class="import-product-action">
                    <div class="pull-left">
                        <label class="checkbox-style" v-bind:for="'select-'+product.id">
                            <input type="checkbox" @click="checkedProduct(product)" v-model="product.selected"
                                   v-bind:id="'select-'+product.id">
                            <span class="checked-style"></span>
                            Select this product
                        </label>
                    </div>
                    <div class="header-import-action">
                        <div class="auto-update-price">
                            <label class="switch-style" v-bind:for="'switch-style-'+ product.id">
                                <input v-bind:id="'switch-style-'+ product.id" type="checkbox"
                                       v-model="product.auto_update_price" v-on:change="autoUpdatePrice">
                                <span class="switch-button">
                                    <span>Auto Update Price</span>
                                    <span>Auto Update Price</span>
                                </span>
                            </label>
                        </div>
                        <div class="dropdown box-dropdown box-action">
                            <span class="box-dropdown-toggle" data-toggle="dropdown">More Action</span>
                            <div class="dropdown-menu box-dropdown-menu">
                                <ul>
                                    <!--disable split function when just one variants-->
                                    <li @click.prevent="splitProduct" v-if="product.variants.length >= 2">Split Product</li>
                                    <li @click.prevent="splitwarning" v-if="product.variants.length <=1">Split Product</li>
                                    <li @click.prevent="removeItem" :disabled="is_delete">Remove Product</li>
                                </ul>
                            </div>
                        </div>
                        <!-- <span class="button-style-sm-o button-remove-product" @click.prevent="removeItem" :disabled="is_delete">Remove</span> -->
                        <button class="button-style-dark-sm push-to-shop-btn" @click.prevent="pushItemToShop"
                                :disabled="is_push" v-text="(is_push) ? 'Pushing...' : 'Push to Shop'"></button>
                    </div>
                </div>
                <ul class="nav nav-tabs">
                    <li class="active tab-p-id"><a data-toggle="tab" v-bind:href="'#product-'+product.id">Product</a>
                    </li>
                    <li class="tab-p-description"><a data-toggle="tab" v-bind:href="'#description-'+product.id">Description</a>
                    </li>
                    <li class="tab-p-variant" @click="loadShipping(product)"><a data-toggle="tab"
                                                                                v-bind:href="'#variants-'+product.id">Variants
                        ({{ (product.variants) ? product.variants.length : 0 }})</a></li>
                    <li class="tab-p-image">
                        <a data-toggle="tab" v-bind:href="'#images-'+product.id">
                            Images
                            <span class="tooltip-style-wrap color-skin" style="margin-left: 3px" data-toggle="tooltip"
                                  title="Drag and drop image to select your product thumbnail">
                                <i class="mdi mdi-alert-circle"></i>
                            </span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="tab-content">
                <div v-bind:id="'product-'+product.id" class="tab-pane fade in active">
                    <div class="tab-product-wrap">
                        <div class="tab-product-image">
                            <img v-bind:src="optimizeImg(product.image, '_200x200.jpg')" v-bind:alt="product.title">
                        </div>
                        <div class="tab-product-info">
                            <p class="product-info-from">Product from <img data-toggle="tooltip" title="AliExpress" v-bind:src="appUrl+'/images/icon-ali-aliexpress.png'" alt=""></p>
                            <h2>
                                <a v-bind:href="product.source_product_link" target="_blank"
                                   v-text="product.title_source!=null ? product.title_source : product.title"></a>
                            </h2>
                            <div class="form-group">
                                <label class="fz-13">Name on Shopify</label>
                                <input class="fz-13" type="text" v-model="product.title" v-on:keyup="changeTitle">
                            </div>
                            <div class="form-group m-b-0" v-show="collections">
                                <label class="fz-13 m-b-0">
                                    Collections
                                    <span class="tooltip-style-wrap color-skin" style="margin-left: 3px"
                                          data-toggle="tooltip" title="Maximum of 250 collections">
                                        <i class="mdi mdi-alert-circle"></i>
                                    </span>
                                </label>
                                <!--<select v-bind:id="'product-collection-'+product.id" v-model="current_collection" multiple>
                                    <option v-for="collection in obj_collections" v-bind:key="collection.id" v-bind:value="collection.id">{{ collection.title }}</option>
                                </select>-->
                                <div class="dropdown box-dropdown dropdown-collection">
                                    <span class="box-dropdown-toggle" data-toggle="dropdown">
                                        <span class="result-multiselect">
                                            <ul>
                                                <li v-for="collection in current_collection" v-bind:key="collection.id">{{ collection.title }} <span
                                                        @click="removeCollection(collection)"
                                                        class="mdi mdi-close"></span></li>
                                                <li><input type="text" @keyup="keyupCollection()"
                                                           placeholder="Choose Collections"></li>
                                            </ul>
                                        </span>
                                    </span>
                                    <div class="dropdown-menu box-dropdown-menu">
                                        <ul v-if="obj_collections.length > 0">
                                            <li v-for="collection in obj_collections"
                                                :class="collection.selected?'selected':''"
                                                @click="addCollection(collection)">{{ collection.title }}
                                            </li>
                                        </ul>
                                        <span class="no-results" v-else>No results found</span>
                                    </div>
                                </div>
                            </div>
                            <div class="row m-t-30">
                                <div class="col-xs-6">
                                    <div class="form-group dropdown box-dropdown">
                                        <label class="fz-13">Type</label>
                                        <div class="dropdown box-dropdown dropdown-product-type">
                                            <span class="box-dropdown-toggle" data-toggle="dropdown">
                                                <span class="result-multiselect">
                                                    <ul>
                                                        <li v-if="product.product_type">{{product.product_type}}<span
                                                                @click="removeproductType()"
                                                                class="mdi mdi-close"></span></li>
                                                        <li><input class="product__type_input fz-13"
                                                                   placeholder="Choose Type" type="text"
                                                                   @keyup="keyupProductType($event)"
                                                                   @keyup.enter="keyupEnterProductType()"
                                                                   @blur="keyupEnterProductType()"></li>
                                                    </ul>
                                                    <span class="box-dropdown-menu-label">Add new type by pressing Enter key</span>
                                                </span>
                                            </span>
                                            <div class="dropdown-menu box-dropdown-menu" v-if="product_type.length!=0">
                                                <ul>
                                                    <li v-for="type in product_type" @click="selectType(type)"
                                                        v-text="type.name"></li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-xs-6">
                                    <div class="form-group form-group-tag m-b-0">
                                        <label class="fz-13">Tags</label>
                                        <div class="bootstrap-tagsinput-wrap">
                                            <input class="product-tag" ref="product_tag" placeholder="Insert Tags Here"
                                                   v-bind:value="product.tag" v-bind:id="'product-tag'+product.id"/>
                                            <span class="box-dropdown-menu">Add new tag by pressing Enter key</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div v-bind:id="'description-'+product.id" class="tab-description tab-pane fade in">
                    <div class="tab-description-wrap">
                        <trumbowyg v-bind:content="product.body_html" v-on:change-content="changeBodyHtml"></trumbowyg>
                    </div>
                </div>
                <div v-bind:id="'variants-'+product.id" class="tab-variants tab-pane fade in">
                    <div class="tab-variants-wrap">
                        <div class="ars-table">
                            <div class="ars-table-head">
                                <div class="ars-table-col col-variant-select">
                                    <label class="checkbox-style checkbox-text-o"
                                           v-bind:for="'select-variant-all'+product.id"
                                           title="You can selected a maximum of 100 variants">
                                        <input v-bind:id="'select-variant-all'+product.id" @click="selectAllVariants"
                                               value="1" type="checkbox">
                                        <span class="checked-style"></span>
                                    </label>
                                </div>
                                <div class="ars-table-col col-variant-product">Product</div>
                                <!--<div class="ars-table-col col-variant-color" v-for="(option, label, key) in product.variants[0].options" v-bind:key="key"></div>-->
                                <div class="ars-table-col col-variant-color" v-for="(option, label, key) in optionFilter" :key=key>
                                    <div class="dropdown box-dropdown dropdown-option-variant">
                                        <div class="parent-dropdown" data-toggle="dropdown">{{label}}<i class="mdi mdi-menu-down"></i> </div>
                                        <div class="dropdown-menu box-dropdown-menu">
                                            <ul>
                                                <li v-for="(select, value, optionKey) in option" :key="optionKey">
                                                    <label class="checkbox-style">
                                                        <input type="checkbox" :id="value.split(' ').join('_')" v-model="option[value]['selected']" v-on:change="selectOptionFilter(select, value, optionKey, label)">
                                                        <span class="checked-style"></span>
                                                        {{ value }}
                                                    </label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-cost">Cost</div>
                                <div class="ars-table-col col-variant-shipping">Shipping</div>
                                <div class="ars-table-col col-variant-price">
                                    Price
                                    <span class="tooltip-style-wrap color-skin" data-toggle="tooltip"
                                          title="The Price value is calculated based on Cost value">
                                        <i class="mdi mdi-alert-circle"></i>
                                    </span>
                                </div>
                                <div class="ars-table-col col-variant-profit">Profit</div>
                                <div class="ars-table-col col-variant-compared-at-price">
                                    Compare At Price
                                    <span class="tooltip-style-wrap color-skin" data-toggle="tooltip"
                                          title="The Compare At Price value is calculated based on Cost value">
                                        <i class="mdi mdi-alert-circle"></i>
                                    </span>
                                </div>
                                <div class="ars-table-col col-variant-inventory">Inventory</div>
                            </div>
                            <div class="num-variant-selected">
                                <div class="count-select-variant">
                                    <span>{{numVariantSelected}}</span> of <span>{{product.variants.length}}</span> Variants
                                </div>
                                <div v-if="numVariantSelected > 1" class="change-price">
                                    <div class="dropdown box-dropdown">
                                        <span class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Action
                                        </span>
                                        <div class="dropdown-menu box-dropdown-menu">
                                            <ul>
                                                <li @click="showInputChangePrice"><a href="javascript:void(0)">Change Price</a></li>
                                                <li @click="showInputChangeComparePrice"><a href="javascript:void(0)">Change Compare Price</a></li>
                                            </ul>
                                        </div>
                                        <div class="box box-variant-price" style="z-index: 99;" v-show="showChangePrice">
                                            <div>
                                                <input type="text" class="form-control" placeholder="New value price" @keyup.enter="saveChangePrice" @keyup="isNumberKeyup($event, 'priceVariantSelect')" @keypress="isNumber($event)" v-model="priceVariantSelect">
                                            </div>
                                            <div>
                                                <button class="btn btn-warning" @click.prevent="saveChangePrice">Apply</button>
                                            </div>
                                        </div>
                                        <div class="box box-variant-price" style="z-index: 99;" v-show="showChangeComparePrice">
                                            <div>
                                                <input type="text" class="form-control" placeholder="New value compared price" @keyup.enter="saveChangeComparePrice" @keyup="isNumberKeyup($event, 'comparePriceVariantSelect')" @keypress="isNumber($event)" v-model="comparePriceVariantSelect">
                                            </div>
                                            <div>
                                                <button class="btn btn-warning" @click.prevent="saveChangeComparePrice">Apply</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="ars-table-row ars-table-row-change-price">
                                <div class="ars-table-col col-variant-select count-select-variant"></div>
                                <div class="ars-table-col col-variant-product"></div>
                                <div class="ars-table-col col-variant-color"
                                     v-for="(option, label, key) in product.variants[0].options"></div>
                                <div class="ars-table-col col-variant-cost"></div>
                                <div class="ars-table-col col-variant-shipping">
                                    <div class="shipping-country">
                                        <a v-text="product.shipTo == ''? 'Shipping to' : product.shipTo "
                                           href="javascript:;" @click="showModalShipingCountry(product)"></a>
                                        <div class="dropdown box-dropdown">

                                        </div>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-price">
                                    <div class="change-price">
                                        <!-- Single button -->
                                        <div class="dropdown box-dropdown">
                                            <span class="box-dropdown-toggle" data-toggle="dropdown"
                                                  aria-haspopup="true" aria-expanded="false">
                                                Change All
                                            </span>
                                            <div class="dropdown-menu box-dropdown-menu">
                                                <ul>
                                                    <li @click.prevent="changeItemPrice('new_value')"><a href="#">Set
                                                        New Value</a></li>
                                                    <li @click.prevent="changeItemPrice('multiply_by')"><a href="#">Multiply
                                                        by</a></li>
                                                    <li @click.prevent="changeItemPrice('plus')"><a href="#">Plus by</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="box box-variant-price" style="z-index: 99;"
                                             v-show="itemPrice.showBox">
                                            <div>
                                                <input type="text" class="form-control"
                                                       @keyup="isNumberKeyup($event, 'itemPrice')"
                                                       @keypress="isNumber($event)" v-model="itemPrice.value"
                                                       v-bind:placeholder="itemPrice.placeHolder">
                                            </div>
                                            <div>
                                                <button class="btn btn-warning" @click.prevent="saveItemPrice">Apply
                                                </button>
                                            </div>
                                            <div class="glyphicon">
                                                <span class="glyphicon glyphicon-remove"
                                                      @click.prevent="closeChangeItemPrice"></span>
                                            </div>
                                            <div class="arrow-down"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-profit"></div>
                                <div class="ars-table-col col-variant-compared-at-price">
                                    <div class="change-price">
                                        <div class="dropdown box-dropdown">
                                            <span class="box-dropdown-toggle" data-toggle="dropdown"
                                                  aria-haspopup="true" aria-expanded="false">
                                                Change All
                                            </span>
                                            <div class="dropdown-menu box-dropdown-menu">
                                                <ul>
                                                    <li @click.prevent="changeComparedPrice('new_value')"><a href="#">Set
                                                        New Value</a></li>
                                                    <li @click.prevent="changeComparedPrice('multiply_by')"><a href="#">Multiply
                                                        by</a></li>
                                                    <li @click.prevent="changeComparedPrice('plus')"><a href="#">Plus
                                                        by</a></li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="box box-variant-price" style="z-index: 99"
                                             v-show="comparedPrice.showBox">
                                            <div>
                                                <input type="text" class="form-control"
                                                       @keyup="isNumberKeyup($event, 'comparedPrice')"
                                                       @keypress="isNumber($event)" v-model="comparedPrice.value"
                                                       v-bind:placeholder="comparedPrice.placeHolder">
                                            </div>
                                            <div>
                                                <button class="btn btn-warning" @click.prevent="saveComparedPrice">
                                                    Apply
                                                </button>
                                            </div>
                                            <div class="glyphicon">
                                                <span class="glyphicon glyphicon-remove"
                                                      @click.prevent="closeComparedPrice"></span>
                                            </div>
                                            <div class="arrow-down"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-inventory">
                                </div>
                            </div>

                            <!--variant begin-->
                            <div class="ars-table-row ars-table-row-item" v-bind:key="variant.id"
                                 v-for="(variant) in product.variants">
                                <!--{{variant}}-->
                                <div class="ars-table-col col-variant-select">
                                    <label v-bind:for="'select-variant-'+variant.id"
                                           class="checkbox-style checkbox-text-o">
                                        <input v-bind:id="'select-variant-'+variant.id" value="1"
                                               v-model="variant.selected" v-on:change="selectVariant(variant)"
                                               type="checkbox">
                                        <span class="checked-style"></span>
                                    </label>
                                </div>
                                <div class="ars-table-col col-variant-product">
                                    <div class="box-variant-content">
                                        <img v-bind:src="variant.image" alt="">
                                        <span v-if="!variant.selected"></span>
                                        <div v-if="variant.selected" class="select-variant-image"
                                             @click="showModalImages(variant)"><i class="mdi mdi-plus"></i></div>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-color"
                                     v-for="(option, label, key) in variant.options" v-bind:key="key">
                                    <div class="box-variant-content">
                                        <input type="text" @change="checkUpdateVariant(variant, option, label)"
                                               v-bind:value="option">
                                        <span v-if="!variant.selected"></span>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-cost">
                                    <div class="box-variant-content">
                                        <input type="text" readonly disabled v-bind:value="'$'+variant.cost">
                                        <span v-if="!variant.selected"></span>
                                    </div>
                                </div>

                                <div class="ars-table-col col-variant-shipping">
                                    <div class="box-variant-content">
                                        <input v-if="product.price_shipping" type="text" readonly disabled
                                               v-bind:value="'$'+product.price_shipping">
                                        <input v-else type="text" readonly disabled value="$0">
                                        <span v-if="!variant.selected"></span>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-price">
                                    <div class="box-variant-content">
                                        <div class="input-group">
                                            <input type="text" :id="variant.id" @keyup="isNumberKeyup($event, 'price')"
                                                   @keypress="isNumber($event)" @change="changePrice"
                                                   v-model="variant.price">
                                            <span class="input-group-addon" v-text="currency ? currency : 'USD'"></span>
                                        </div>
                                        <span v-if="!variant.selected"></span>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-profit">
                                    <div class="box-variant-content">
                                        <input type="text" v-bind:style=" variant.profit < 0 ? 'color: red;' : ''"
                                               readonly disabled v-bind:value="'$'+variant.profit">
                                        <!--<input v-else type="text" v-bind:style="variant.cost < 0 ? 'color: red;' : ''" readonly disabled v-bind:value="'$'+variant.cost">-->
                                        <span v-if="!variant.selected"></span>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-compared-at-price">
                                    <div class="box-variant-content">
                                        <div class="input-group">
                                            <input type="text" @keyup="isNumberKeyup($event, 'compare_at_price')"
                                                   @keypress="isNumber($event)" @change="changeComparePrice"
                                                   v-model:value="variant.compare_at_price">
                                            <span class="input-group-addon" v-text="currency ? currency : 'USD'"></span>
                                        </div>
                                        <span v-if="!variant.selected"></span>
                                    </div>
                                </div>
                                <div class="ars-table-col col-variant-inventory">
                                    <div class="box-variant-content">
                                        <input type="text" disabled v-model="variant.inventory_quantity">
                                        <span v-if="!variant.selected"></span>
                                    </div>
                                </div>
                            </div>
                            <!--end variant-->
                            <!--<item_variant  v-bind:settings="settings" v-on:save-item="saveItem" v-on:select-variant="selectVariant" v-bind:price_shipping="product.price_shipping " v-bind:props_variant="variant" v-bind:key="variant.id" v-on:show-modal-images="showModalImages"></item_variant>-->
                        </div>
                    </div>
                </div>
                <div v-bind:id="'images-'+product.id" class="tab-images tab-pane fade in">
                    <div class="tab-images-wrap">
                        <div class="variant-image-wrap">
                            <div class="select-all-group">
                                <label class="checkbox-style checkbox-text-o"
                                       v-bind:for="'select-image-all'+product.id">
                                    <input v-on:change="checkAllImage($event)" type="checkbox"
                                           v-bind:id="'select-image-all'+product.id">
                                    <span class="checked-style"></span>
                                </label>
                                <span class="select-all-text">
                                     <b v-text="image_selected"></b> of
                                    <b v-text="product.images.length"></b>
                                    <span v-text="((product.images.length > 1 || product.images.length==0)) ? 'images' : 'image'"></span>
                                </span>
                            </div>
                            <ul v-bind:id="'el-variant-image-'+product.id" class="variant-image-list">
                                <li v-for="(image, key) in product.images" v-bind:key="image.id">
                                    <div class="variant-images" v-bind:class="image.status ? 'active' : ''">
                                        <img class="prod-image" v-on:click="selectImageContainer(image, key)"
                                             v-bind:source_src="image.src"
                                             v-bind:src="optimizeImg(image.src, key == 0 ? '_200x200.jpg' : '_100x100.jpg')"
                                             :data-id="image.id" :data-status="image.status"
                                             :data-in-variant="image.in_variant">
                                        <!-- <label v-show="key !== 0" v-bind:for="'select-image-'+image.id" class="checkbox-style check-variant-image">
                                            <input type="checkbox" v-bind:id="'select-image-'+image.id" v-model="image.status" v-on:change="selectImage(image)" v-bind:data-id="image.id">
                                            <span class="checked-style"></span>
                                        </label> -->
                                        <a v-bind:href="image.src" class="view-original-image-size"
                                           v-bind:class="image.status ? 'active' : ''" @click="viewOriginSize"
                                           target="_blank"><i class="mdi mdi-magnify-plus-outline"></i></a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <modal_item_image v-bind:props_product_images="product.images" v-show="product.modal_images"
                          v-on:close-modal-images="closeModalImages"
                          v-on:add-variant-image="addVariantImage"></modal_item_image>

    </li>
</template>

<script type="text/javascript">
    import trumbowyg from '../common/trumbowyg'
    import item_variant from './item_variant.vue'
    import modal_item_image from '../../components/common/modal_item_image'
    import swal from 'sweetalert2'
    import Rx from 'rxjs/Rx';

    export default {
        props: {
            props_product: {
                required: true,
            },
            collections: {
                required: true,
                default: false
            },
            product_type: {
                required: true,
                default: []
            },
            settings: {
                required: true
            },
            props_freight: {
                required: true
            },
            props_current_product: {
                required: true
            }
        },
        data: function () {
            return {
                // product: Object.assign({}, this.props_product, { modal_images: false, variant_image: {}}),
                product_type: [{id: '1', text: 'product type 1'}, {id: '2', text: 'product type 2'}, {
                    id: '3',
                    text: 'product type 3'
                }],
                product: Object.assign({},
                    this.props_product,
                    {
                        modal_images: false,
                        variant_image: {},
                        type: {id: '1111', text: 'product type 1'},
                        freights: [],
                    }
                ),
                appUrl: window.appUrl,
                itemPrice: {
                    showBox: false,
                    placeHolder: null,
                    type: null,
                    value: null
                },
                comparedPrice: {
                    showBox: false,
                    placeHolder: null,
                    type: null,
                    value: null
                },
                is_push: false,
                is_delete: false,
                obj_collections: [],
                current_collection: [],
                countries: [],
                freight: this.props_freight,
                exchange: window.exchange ? parseFloat(window.exchange) : 1,
                currency: window.currency ? window.currency : 'USD',
                image_selected: 0,
                subject_tag:null,
                update_product : null,
                is_update_product: false,
                variants:[],
                optionFilter:{},
                isAnd:true,
                numVariantSelected: 0,
                showChangePrice: false,
                showChangeComparePrice: false,
                countOptionFilter:{},
                selectAll:true,
                priceVariantSelect: null,
                comparePriceVariantSelect: null
            }
        },
        computed: {
            isShowChangePrice: function () {
                let count = 0;
                if (this.product.variants) {
                    for (let i = 0; i < this.product.variants.length; i++) {
                        if (this.product.variants[i].selected)
                            count++
                    }
                }

                return (count > 0)
            }
        },
        components: {
            item_variant,
            trumbowyg,
            modal_item_image,
            // modal_shipping_country
        },
        created:function(){
            this.subject_tag = new Rx.BehaviorSubject();
            let _this = this;
            this.subject_tag
                .debounceTime(1000)
                .subscribe(
                    function() {
                        _this.saveTags()
                    }
                );

            this.update_product = new Rx.BehaviorSubject();
            this.update_product
                .debounceTime(1000)
                .subscribe(
                    function() {
                        if(_this.is_update_product){
                            _this.updateProduct()
                        }
                    }
                );
        },
        mounted: function () {
            let _this = this

            $('.form-group-tag .bootstrap-tagsinput input').on('paste', function (e) {
                let valpaste = e.originalEvent.clipboardData.getData('text')
                let val = $(this).val() + valpaste
                $(this).attr('size', val.length)
            });

            this.setCollection(_this.collections)

            /*$('.dropdown-collection .result-multiselect li:last-child input').click(function () {
                $(this).parents('.dropdown-collection').toggleClass('open')
            })*/
            $('.dropdown-collection .box-dropdown-menu li').click(function () {
                $(this).parents('.dropdown-collection').removeClass('open')
            })

            $('#product-collection-' + this.product.id).select2({
                width: '100%'
            }).on('change', function (e) {
                let data = $(this).select2('data')
                data = data.map(function (d) {
                    return d.id
                })
                _this.product.custom_collection = data
                axios.post(appUrl + '/import/products', {product: _this.product})
                    .then(function (response) {
                        let {data} = response
                    })
                    .catch(function (error) {
                    })
            });

            $('#product-collection-' + this.product.id).on("select2:select", function (evt) {
                var element = evt.params.data.element;
                var $element = $(element);
                $element.detach();
                $(this).append($element);
                $(this).trigger("change");
            });

            $('#product-tag' + this.product.id).tagsinput({
                'confirmKeys': [13],
                'focusClass': 'my-focus-class'
            })

            $('#product-tag'+_this.product.id).on('beforeItemAdd', function(event) {
                _this.product.tag =  $('#product-tag'+_this.product.id).tagsinput('items')
                // _this.saveTags()
                _this.subject_tag.next();

            });
            $('#product-tag'+_this.product.id).on('beforeItemRemove', function(event) {
                _this.product.tag =  $('#product-tag'+_this.product.id).tagsinput('items')
                // _this.saveTags()
                _this.subject_tag.next();
            })

            // $('#product-tag'+_this.product.id).tagsinput('add', _this.product.tag)

            $(document.body).on('click', function (event) {
                if (!$(event.target).closest('.change-price').length) {
                    _this.comparedPrice.showBox = false;
                    _this.itemPrice.showBox = false;
                }

                if (!$(event.target).closest('.change-price').length) {
                    _this.showChangePrice = false;
                    _this.showChangeComparePrice = false;
                }

                if (!$(event.target).closest('.product__images_modal_overlay').length) {
                    _this.product.modal_images = false;
                }

                if (!$(event.target).closest('.dropdown-collection').length) {
                    $('.dropdown-collection').removeClass('open')
                }

            });
            $(document).on('click','.dropdown-option-variant .dropdown-menu, .dropdown-option-variant .dropdown-menu li',function () {
                $(this).parents('.dropdown-option-variant').addClass('open');
            })

            $('.product-import-wrap .tab-product-info .bootstrap-tagsinput-wrap .box-dropdown-menu').each(function () {
                $(this).appendTo($(this).parents('.bootstrap-tagsinput-wrap').find('.bootstrap-tagsinput'));
            });
            _this.image_selected = _this.imageSelected()
            let el_sortable = document.getElementById(`el-variant-image-${_this.product.id}`);
            Sortable.create(el_sortable, {

                ghostClass: "sortable-ghost",  // Class name for the drop placeholder
                chosenClass: "sortable-chosen",  // Class name for the chosen item
                dragClass: "sortable-drag",  // Class name for the dragging item
                setData: function (/** DataTransfer */dataTransfer, /** HTMLElement*/dragEl) {
                    dataTransfer.setData('Text', dragEl.textContent); // `dataTransfer` object of HTML5 DragEvent
                },

                // Element is chosen
                onChoose: function (/**Event*/evt) {
                    evt.oldIndex;  // element index within parent
                },

                // Element dragging started
                onStart: function (/**Event*/evt) {
                    evt.oldIndex;  // element index within parent
                },

                // Element dragging ended
                onEnd: function (/**Event*/evt) {
                    var itemEl = evt.item;  // dragged HTMLElement
                    // console.log('image src', $(evt.item).find('img').attr('src'))
                    // _this.product.image = $(evt.item).find('img').attr('src');
                    const element = evt.from.querySelectorAll('.variant-image-list li img.prod-image')
                    let args = []
                    element.forEach(function (item, key) {
                        let tmp = {
                            id: item.getAttribute('data-id'),
                            src: item.getAttribute('source_src'),
                            'in-variant': item.getAttribute('data-in-variant'),
                        }
                        tmp['sort'] = key
                        tmp['status'] = (key === 0) ? true : ((item.getAttribute('data-status') == 'true') ? true : false)
                        args.push(tmp)

                    })

                    _this.sortImage(args)
                }
            });

            $('[data-toggle="tooltip"]').tooltip({
                html: true,
                container: 'body'
            });

            this.profit_calculate()
        },
        methods: {
            //modal countryShipping
            /*show modal shipping country*/
            splitwarning: function () {
                notify('warning', 'Product must have at least 2 variants');
            },
            showModalShipingCountry: function (obj_product) {
                if (!checkExtension())
                    return false
                this.$emit('show_shipping_method', obj_product)
            },
            //
            // infoShipping:function(freight){
            //     console.log(freight)
            //     console.log(Object.keys(this.product.variants).length)
            //     this.freight = freight
            //     // this.product.variants = this.product.variants.map(function (variant) {
            //     //
            //     //         variant = Object.assign({}, variant, {
            //     //             price_shipping : Number(parseFloat(freight.price)).toFixed(2)
            //     //         })
            //     //     return variant;
            //     // })
            //     //
            //     // this.product.country_shipping = freight.shipTo
            //     // console.log(this.product)
            //     // //Update product
            //     //
            //     // axios.post(appUrl+'/import/country_shipping', this.product)
            //     //     .then(function (response) {
            //     //
            //     //     })
            //     //     .catch(function (error) {
            //     //
            //     //     })
            //     //
            //     // //Update variants
            //     // axios.post(appUrl+'/import/variants', this.product.variants)
            //     //     .then(function (response) {
            //     //
            //     //     })
            //     //     .catch(function (error) {
            //     //
            //     //     })
            //     // // this.freight = freight
            // },
            ////end modal country shipping
            checkNumber: function (event) {
                let _this = this;
                if (event.keyCode === 189 || event.keyCode === 190) {
                    event.preventDefault()
                }
            },

            pushItemToShop: function () {
                let _this = this;

                _this.product = Object.assign({}, _this.product, {
                    is_push: true
                })

                if (!_this.product.title) {
                    _this.product = Object.assign({}, _this.product, {
                        is_push: false
                    })
                    notify('warning', 'The product title field is required')
                    return false
                }
                _this.$emit('push-product', _this.product);
            },
            removeItem: function () {
                let _this = this
                swal({
                    title: '<span class="sweetalert-icon icon-delete"><i class="mdi mdi-delete-forever"></i></span>',
                    html: '<h4 class="text-left sweetalert-title-delete">Remove Product</h4><div class="text-left">Remove selected product from Import List?</div>',
                    showCloseButton: true,
                    showCancelButton: true,
                    focusConfirm: false,
                    position: 'top',
                    confirmButtonText: '<span class="text-button-remove">Remove</span>',
                    cancelButtonText: '<span class="text-button-remove">Cancel</span>'
                })
                    .then(function (action) {
                        if (action.value) {
                            _this.is_delete = true
                            _this.$emit('remove-product', _this.product)
                        }
                    })
            },
            selectType: function (obj_type) {
                this.product = Object.assign({}, this.product, {type: obj_type})
                this.product.product_type = obj_type.name
                // console.log('selectType')
                // this.updateProduct()
                this.is_update_product = true
                this.update_product.next()

            },
            keyupProductType: function (event) {
                let target = event.currentTarget
                $(target).parents('.box-dropdown').removeClass('open')
                $(target).parents('.box-dropdown.dropdown-product-type').addClass('open-keep-label')
                if ($(target).val() == '') {
                    $(target).parents('.box-dropdown').addClass('open')
                    $(target).parents('.box-dropdown.dropdown-product-type').removeClass('open-keep-label')
                }

                /*axios.post(appUrl+'/import/products', {product: this.product})
                    .then(function (response) {
                        let { data } = response
                    })
                    .catch(function (error) {

                    })*/
            },
            saveTags: function () {
                if(this.first_load){
                    this.updateProduct()
                }else{
                    this.first_load = true
                }
            },
            keyupEnterProductType: function (e) {
                let target = event.currentTarget
                let valCollection = $(target).val().trim()
                if (valCollection != '') {
                    this.product.product_type = valCollection
                    $(target).val('')
                    $(target).parents('.box-dropdown').addClass('open')
                    $(target).parents('.box-dropdown.dropdown-product-type').removeClass('open-keep-label')
                    // console.log('keyupEnterProductType')
                    // this.updateProduct()
                    this.is_update_product = true
                    this.update_product.next()
                }
            },
            blurProductType: function (event) {

            },
            checkedProduct: function (event) {
                this.$emit('check-product', this.product)
            },
            changeItemPrice: function (type) {
                this.itemPrice.type = type
                this.itemPrice.value = null
                if (type === 'multiply_by')
                    this.itemPrice.placeHolder = 'Multiply by price'
                else if (type === 'new_value')
                    this.itemPrice.placeHolder = 'New value price'
                else if (type === 'plus')
                    this.itemPrice.placeHolder = 'Plus by price'

                this.comparedPrice.showBox = false
                this.itemPrice.showBox = true
            },
            changeComparedPrice: function (type) {
                this.comparedPrice.type = type
                this.comparedPrice.value = null
                if (type === 'multiply_by')
                    this.comparedPrice.placeHolder = 'Multiply by compared price'
                else if (type === 'new_value')
                    this.comparedPrice.placeHolder = 'New value compared price'
                else if (type === 'plus')
                    this.comparedPrice.placeHolder = 'Plus by compared price'

                this.itemPrice.showBox = false
                this.comparedPrice.showBox = true
            },
            closeComparedPrice: function () {
                this.comparedPrice.showBox = false
            },
            closeChangeItemPrice: function () {
                this.itemPrice.showBox = false
            },
            saveComparedPrice: function () {
                let _this = this

                if (!validNumber(_this.comparedPrice.value))
                    return false;
                this.product.variants = this.product.variants.map(function (variant) {
                    if (_this.comparedPrice.type === 'multiply_by')
                        variant = Object.assign({}, variant, {
                            compare_at_price: Number(parseFloat(_this.comparedPrice.value) * parseFloat(variant.cost) * _this.exchange).toFixed(2)
                        })
                    else if (_this.comparedPrice.type === 'new_value')
                        variant = Object.assign({}, variant, {
                            compare_at_price: Number(_this.comparedPrice.value).toFixed(2)
                        })
                    else if (_this.comparedPrice.type === 'plus')
                        variant = Object.assign({}, variant, {
                            compare_at_price: Number((parseFloat(_this.comparedPrice.value) + parseFloat(variant.cost)) * _this.exchange).toFixed(2)
                        })

                    return variant;
                })
                this.comparedPrice.showBox = false

                //Update database
                axios.post(appUrl + '/import/variants', this.product.variants)
                this.profit_calculate()
            },
            saveItemPrice: function () {
                let _this = this

                if (!validNumber(_this.itemPrice.value))
                    return false
                this.product.variants = this.product.variants.map(function (variant) {
                    if (_this.itemPrice.type === 'multiply_by')
                        variant = Object.assign({}, variant, {
                            price: Number(parseFloat(_this.itemPrice.value) * parseFloat(variant.cost) * _this.exchange).toFixed(2)
                        })
                    else if (_this.itemPrice.type === 'new_value')
                        variant = Object.assign({}, variant, {
                            price: Number(_this.itemPrice.value).toFixed(2)
                        })
                    else if (_this.itemPrice.type === 'plus')
                        variant = Object.assign({}, variant, {
                            price: Number((parseFloat(_this.itemPrice.value) + parseFloat(variant.cost)) * _this.exchange).toFixed(2)
                        })

                    return variant
                })

                this.itemPrice.showBox = false
                //Update database
                axios.post(appUrl + '/import/variants', this.product.variants)

                this.profit_calculate()

            },
            selectImageContainer: function (img, key) {
                if (key == 0)
                    return false;
                img.status = !img.status;
                img.selected = img.status;
                this.selectImage(img);
            },
            selectImage: function (img) {
                this.image_selected = this.imageSelected()
                this.product.variants = this.product.variants.map(function (variant) {
                    if (img.id === variant.image_id || (
                        typeof variant.current_img != 'undefined' && variant.current_img == img.id
                    )) {
                        variant.image_id = img.status ? img.id : '',
                            variant.current_img = img.id
                        variant.image_status = img.status,
                            variant.image = img.status ? img.src : `${appUrl}/images/default.png`
                        //Handle save checked variant to database
                        axios.post(appUrl + '/import/variant', variant)

                    }
                    return variant
                })

                //Update database
                axios.post(appUrl + '/import/select_image', img)
                    .then(function (response) {
                        const {data} = response;

                    })
                    .catch(function (error) {

                    })
            },
            selectAllVariants: function (event) {
                let _this = this
                let checked = $(event.currentTarget).prop('checked');
                let count = 0
                //Xử lý checked variants, nếu checked == true thì sẽ check 100 variants đầu tiên
                //Nếu checked == false thì sẽ check variant đầu tiên

                //add  all options
                for(let key in _this.optionFilter){
                    for(let [k, value] of Object.entries(_this.optionFilter[key])){
                        value.selected=true
                    }
                }

                this.product.variants  = this.product.variants.map(function (variant) {
                    if(checked) {
                        $(event.currentTarget).parents('.ars-table-row-item').addClass('active');
                        variant.selected = false

                        if(count < 100) {
                            variant.selected = checked
                            count++
                        }else{
                            for(let key in _this.optionFilter){
                                _this.optionFilter[key][variant.options[key]].selected=false
                            }
                        }
                    } else {
                        if(count === 0)
                        {
                            variant.selected = true
                            count++

                            for(let key in _this.optionFilter){
                                for(let [k, value] of Object.entries(_this.optionFilter[key])){
                                    if(k == variant.options[key]){
                                        value.selected=true
                                        value.total=1
                                    }else{
                                        value.selected=false
                                        value.total=0
                                    }
                                }
                            }

                        } else {
                            variant.selected = checked
                        }
                        $(event.currentTarget).parents('.ars-table-row-item').removeClass('active');
                    }

                    return variant
                })

                this.numVariantSelected = this.lengthVariantChecked(this.product.variants);
                //Xử lý việc update lại trạng thái selected vào csdl
                axios.post(appUrl+'/import/variants', this.product.variants)
                    .then(function (respose) {
                        if(checked) {
                            if(count >= 100) {
                                notify('warning', 'You can select a maximum of 100 variants.')
                            }
                            notify('success', 'Selected successfully')
                        }
                        else {
                            notify('success', 'The variants were successfully unselected. Note at least one variant must stay selected')
                            notify('warning', 'You must select at least 1 variant.')
                        }
                    })
                    .catch(function (error) {
                        notify('error', 'Update error')
                    })
            },
            selectVariant: function (obj_variant) {
                // console.log(obj_variant)
                // this.product.variants = this.product.variants.map(function (variant) {
                //     if(obj_variant.id === variant.id) {
                //         return Object.assign({}, obj_variant, {selected: variant.selected})
                //     } else
                //         return variant
                //     // return variant
                // })

                // console.log(this.product)

                const length_variant_checked = this.lengthVariantChecked(this.product.variants)

                if (length_variant_checked > 100 && obj_variant.selected) {
                    this.$nextTick(function () {
                        this.product.variants = this.product.variants.map(function (variant) {
                            if (obj_variant.id === variant.id)
                                variant.selected = false

                            return variant
                        })
                    })

                    notify('warning', 'You can select a maximum of 100 variants.')
                    return false
                }
                if (length_variant_checked <= 0 && !obj_variant.selected) {
                    this.$nextTick(function () {
                        this.product.variants = this.product.variants.map(function (variant) {
                            if (obj_variant.id === variant.id)
                                variant.selected = true

                            return variant
                        })
                    })

                    notify('warning', 'You must select at least 1 variant.')
                    return false
                }
                /*check select variant equal 0 remove check*/
                let currentOption = Object.assign({}, obj_variant.options)
                Object.keys(obj_variant.options).forEach(function (key) {
                    currentOption[key] = {
                        value: obj_variant.options[key],
                        number: 0
                    }
                })
                this.variants = this.variants.map(function (variant) {
                    // if (obj_variant.id === variant.id) {
                    //     variant.selected = obj_variant.selected
                    // }
                    // if(variant.selected) {
                    //
                    // }
                    for (let key in currentOption) {
                        if(currentOption[key]['value'] == variant.options[key] && variant.selected == true) {
                            currentOption[key]['number']++
                        }
                    }

                    return variant
                })

                for (let key in currentOption) {
                    if(this.countOptionFilter[key][currentOption[key]['value']]['total'] == currentOption[key]['number']) {
                        this.optionFilter[key][currentOption[key]['value']]['selected'] = true
                        continue
                    }

                    if(currentOption[key]['number'] == 0) {
                        this.optionFilter[key][currentOption[key]['value']]['selected'] = false
                        continue
                    }
                }

                this.numVariantSelected = this.lengthVariantChecked(this.product.variants);
                //Handle save checked variant to database
                // console.log('obj_variant', obj_variant)
                axios.post(appUrl + '/import/variant', obj_variant)
            },
            lengthVariantChecked: function (variants) {
                let variant_checked = []
                variant_checked = variants.filter(function (variant) {
                    return variant.selected
                })

                return variant_checked.length
            },

            //Handle edit body html
            changeBodyHtml: function (content) {
                let _this = this
                //axios.post(appUrl+'/import/products', {product: _this.product})
                _this.product.body_html = content
                axios.post(appUrl + '/import/content_products', {productId: _this.product.id, content: content})
                    .then(function (response) {
                        const {data} = response
                    })
                    .catch(function (error) {
                        let {status, data} = error.response
                    })
            },
            //
            changeTitle: function () {
                // console.log('changeTitle')
                // this.updateProduct()
                this.is_update_product = true
                this.update_product.next()
            },
            updateProduct: function () {
                let _this = this
                axios.post(appUrl+'/import/products', {product: this.product})
                    .then(function (repo) {
                        if(repo.data.status){
                            _this.$emit('check_edit_product', repo.data.status)
                        }
                    })
                _this.$emit('check-product', this.product)
            },
            choiceProductType: function (event) {
                var target = event.currentTarget;
                var _txt = $(target).text();
                $(target).parents('.import-product-type-wrap').find('.product-type-field').val(_txt);
            },
            viewOriginSize: function () {
                $('.variant-image-list').magnificPopup({
                    delegate: 'a', // child items selector, by clicking on it popup will open
                    type: 'image',
                    callbacks: {
                        open: function () {
                            const el = $('.mfp-close')[0];
                            $(el).html(`<button title="Close (Esc)" type="button" class="mfp-close"><span>x</span></button>`).click(function () {
                                $.magnificPopup.close();
                            })
                        },
                    }
                    // other options
                });
            },
            autoUpdatePrice: function () {
                // console.log('autoUpdatePrice')
                // this.updateProduct()
                this.is_update_product = true
                this.update_product.next()
            },
            isNumber: function (evt) {
                evt = (evt) ? evt : window.event;
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if ((charCode >= 48 && charCode <= 57) || charCode === 46) {
                    return true
                } else {
                    evt.preventDefault()
                }
            },
            isNumberKeyup: function (event, name) {
                let val = $(event.currentTarget).val()
                let str_split = val.split('.');
                if (str_split[1] != undefined && str_split[1].length >= 3 || str_split.length >= 3) {
                    let last = str_split[1].slice(0, 2)
                    let first = str_split[0] + '.'
                    val = first.concat(last)
                    $(event.currentTarget).val(val)
                    // if( name == 'itemPrice' ) {
                    //     this.itemPrice.value = val
                    // }
                    // if( name == 'comparedPrice') {
                    //     this.comparedPrice.value = val
                    // }
                    switch (name) {
                        case 'itemPrice':

                            this.itemPrice.value = val
                            break;

                        case 'comparedPrice':

                            this.comparedPrice.value = val
                            break;

                        case 'priceVariantSelect':

                            this.priceVariantSelect = val
                            break;

                        case 'comparePriceVariantSelect':

                            this.comparePriceVariantSelect = val
                            break;
                    }
                }
            },
            setCollection: function (value) {
                let _this = this
                /*if(value && _.isObject(value))
                {
                    Object.values(value).forEach(function (collect) {
                        _this.obj_collections.push({
                            id: collect.id,
                            title:  collect.title
                        })
                    })
                    _this.current_collection = _this.product.custom_collection ? _this.product.custom_collection : []
                }*/

                if (value && _.isObject(value)) {
                    Object.values(value).forEach(function (collect) {
                        _this.obj_collections.push({
                            id: collect.id,
                            title: collect.title,
                            selected: false
                        })
                    })
                }

                if (this.product.custom_collection) {
                    this.obj_collections = this.obj_collections.map(function (collection) {
                        if (_this.product.custom_collection.includes(collection.id)) {
                            _this.current_collection.push(collection)
                            collection.selected = true
                        }
                        return collection
                    })
                }
            },
            showModalImages: function(obj_variant) {
                let _this = this
                this.$nextTick(function () {
                    _this.product = Object.assign({}, _this.product, {
                        modal_images: true,
                        variant_image: obj_variant
                    })
                })
            },
            closeModalImages: function (obj_modal_images) {
                let _this = this
                this.$nextTick(function () {
                    _this.product = Object.assign({}, _this.product, {
                        modal_images: obj_modal_images.status
                    })
                })
            },
            addVariantImage: function (obj_image) {
                let _this = this
                this.$nextTick(function () {
                    _this.product.variants = _this.product.variants.map(function (variant) {
                        if (variant.id === _this.product.variant_image.id) {
                            // variant = Object.assign({}, variant, {
                            variant.image_status = true
                            variant.image_id = obj_image.id
                            variant.image = obj_image.src
                            variant.current_img = obj_image.id
                            // })
                            //Handle save checked variant to database
                            axios.post(appUrl + '/import/variant', variant)
                                .then(function (respose) {

                                })
                                .catch(function (error) {

                                })
                            let obj_image_update = Object.assign({}, obj_image, {
                                status: true,
                                selected: true
                            })
                            axios.post(appUrl + '/import/select_image', obj_image_update)
                                .then(function (response) {
                                    const {data} = response;

                                })
                                .catch(function (error) {

                                })
                        }
                        return variant
                    })
                    _this.product.images = _this.product.images.map(function (pimage) {
                        if (pimage.id === obj_image.id) {
                            pimage.status = true
                            pimage.selected = true
                        }
                        return pimage
                    })
                    _this.product = Object.assign({}, _this.product, {
                        modal_images: false
                    })
                })

            },

            addMultiSelectDropdown: function () {
                let value = $(this).attr('value');
                $('.result-multiselect ul').append('<li>' + value + '</li>')
            },

            showFreight: function (freight) {
                this.freight = freight
            },
            checkNullObject(obj) {
                return $.isEmptyObject(obj)
            },
            removeproductType:function () {
                this.product.product_type='';
                // console.log('removeproductType')
                // //update product
                // this.updateProduct()
                this.is_update_product = true
                this.update_product.next()
            },

            /*collection*/
            addCollection: function (obj_collection) {
                let _this = this
                this.obj_collections = this.obj_collections.map(function (collection) {
                    if (obj_collection.id === collection.id) {
                        collection = Object.assign({}, collection, {
                            selected: true,
                        })
                    }
                    if (_this.product.custom_collection != null) {
                        if (!_this.product.custom_collection.includes(obj_collection.id)) {
                            _this.product.custom_collection.push(obj_collection.id)
                            _this.current_collection.push(obj_collection)
                        }
                    } else {
                        _this.product.custom_collection = []
                        _this.product.custom_collection.push(obj_collection.id)
                        _this.current_collection.push(obj_collection)
                    }
                    return collection
                })
                /*_this.current_collection = Object.assign([])
                this.obj_collections = this.obj_collections.map(function(collection) {
                    if(_this.product.custom_collection.includes(collection.id)) {
                        _this.current_collection.push(collection)
                    }
                    return collection
                })*/
                let target = event.currentTarget
                $(target).parents('.dropdown-collection').find('.result-multiselect li:last-child input').val('')
                $(target).parents('.dropdown-collection').find('.box-dropdown-menu li').css('display','block')

                // console.log('addCollection')
                // //update product
                // this.updateProduct()
                this.is_update_product = true
                this.update_product.next()
            },

            removeCollection: function (obj_collection) {
                let target = event.currentTarget
                $(target).parents('.dropdown-collection').addClass('open')
                let _this = this
                this.obj_collections = this.obj_collections.map(function (collection) {
                    if (obj_collection.id === collection.id) {
                        collection = Object.assign({}, collection, {
                            selected: false,
                        })
                    }
                    return collection
                })
                if (this.product.custom_collection != null) {
                    var index = this.product.custom_collection.indexOf(obj_collection.id);
                    if (index > -1) {
                        this.product.custom_collection.splice(index, 1);
                        this.current_collection.splice(index, 1);
                    }
                }
                // console.log('removeCollection')
                // this.updateProduct()
                this.is_update_product = true
                this.update_product.next()

                /*if(_this.current_collection!=null) {
                    var length_current_collection=_this.current_collection.length;
                    for(var i=0;i<length_current_collection;i++){
                        if(_this.current_collection[i].id===obj_colection.id){
                            _this.current_collection.splice(i, 1);
                        }
                    }
                }*/
            },

            keyupCollection: function () {
                let target = $(event.currentTarget)
                let val = target.val().toLowerCase()
                $(target).parents('.dropdown-collection').find('.box-dropdown-menu li').each(function () {
                    if (val != '') {
                        var value = $(this).text()
                        if (value.toLowerCase().indexOf(val) >= 0) {
                            $(this).css('display', 'block')
                        }
                        else {
                            $(this).css('display', 'none')
                        }
                    }
                    else {
                        $(this).css('display', 'block')
                    }
                })
            },

            saveItem: function () {
                //Update database
                axios.post(appUrl + '/import/variants', this.product.variants)
                    .then(function (respose) {
                        console.log(respose.data)
                        if (respose.data.status == 402)
                            notify('error', 'Variant duplicate')
                        else
                            notify('success', 'Update success')
                    })
                    .catch(function (error) {
                        notify('error', 'Update error')
                    })


                this.profit_calculate()
            },
            sortImage: function (data) {
                this.product.images = data
                this.product.image = data[0].src
                axios.post(appUrl + '/import/product_image',
                    {
                        product_id: this.product.id,
                        images: data
                    })
                    .then(function (response) {
                        console.log(response.data)
                    })
                    .catch(function (error) {
                        console.log(error)
                    })
            },
            checkUpdateVariant: function (obj_variant, option = '', key = '') {
                let _this = this
                let new_value = event.target.value

                if (!new_value) {
                    notify('error', 'Variant not null')
                    event.target.value = new_value
                } else {
                    this.product.variants = this.product.variants.map(function (variant) {
                        if (obj_variant.id === variant.id) {
                            variant.options[key] = new_value
                            return variant
                        } else
                            return variant
                    })

                    this.saveItem()
                }
            },
            changeComparePrice: function ({type, target}) {
                let _this = this
                let value = target.value
                if (value == '' || isNaN(value))
                    value = 0

                _this.profit_calculate()
                _this.saveItem()
                // _this.$emit('save-item')
            },

            changePrice: function ({type, target}) {
                let _this = this
                let value = target.value
                if (value == '' || isNaN(value))
                    value = 0
                // _this.variant.price = parseFloat(value).toFixed(2)
                // _this.props_variant.price = _this.variant.price
                _this.profit_calculate()
                _this.saveItem()
            },
            profit_calculate: function () {
                let _this = this
                this.product.variants = this.product.variants.map(function (variant) {
                    variant.profit = ((parseFloat(variant.price) / parseFloat(_this.exchange)) - (parseFloat(variant.cost) + parseFloat(_this.product.price_shipping))).toFixed(2)
                    return variant
                })
                // console.log(this.product.variants)
                // this.product
                // this.profit =  ( (parseFloat(this.variant.price) / this.exchange) - (parseFloat(this.variant.cost)+ parseFloat(this.price_shipping ? this.price_shipping : 0))).toFixed(2)
                // this.profit = (this.profit == -0.00) ? 0.00 : this.profit;
            },
            checkAllImage(e) {
                let _this = this
                if (e.target.checked == true) {
                    // select all image non select
                    _this.product.images.forEach(function (image) {
                        if (!image.status || !image.selected) {
                            image.status = true
                            image.selected = true
                            _this.selectImage(image);
                        }
                    });
                } else {
                    _this.product.images.forEach(function (image, index) {
                        if (image.status && index > 0) {
                            image.status = false
                            image.selected = false
                            _this.selectImage(image);
                        }
                    });
                }
            },
            imageSelected() { // need improve
                if (typeof this.product.images == "undefined") {
                    return 0
                }
                return this.product.images.filter(function (image) {
                    return (image.selected == true || image.status == true)
                }).length;
            },
            loadShipping: function (product) {
                this.$emit('load_shipping', product)
                /*get option variant*/
                this.getAllOptionVariant(product.variants);
                this.numVariantSelected = this.lengthVariantChecked(product.variants);
            },
            splitProduct() {
                if (this.product.variants.length > 1) {
                    this.$emit('split_product', this.product)
                }
            },
            optimizeImg(src, size) {
                if(!src)
                    return src
                if (src.endsWith('_640x640.jpg')) {
                    src = src.slice(0, src.lastIndexOf('_640x640.jpg'))
                }

                return src + size
            },
            getAllOptionVariant: function (variant) {
                let _this = this;
                let count = 0
                let options = []

                this.variants = variant
                this.variants = this.variants.map(function (variant) {
                    // variant.selected = false
                    if(count < 100) {
                        // variant.selected = true
                        count++

                        for(let [optionKey, value] of Object.entries(variant.options)){

                            if(typeof options[optionKey] == 'undefined'){
                                options[optionKey] = [value]
                                continue
                            }

                            if(options[optionKey].indexOf(value) != -1) continue

                            options[optionKey].push(value)
                        }
                    }
                    return variant

                })

                this.optionFilter = {}
                variant.forEach(function (variant) {
                    for (let optionKey in variant.options) {
                        if (typeof _this.optionFilter[optionKey] == 'undefined') {
                            _this.optionFilter[optionKey] = {
                                [variant.options[optionKey]]: {
                                    selected: true,
                                    total: 1
                                }
                            }

                            continue
                        }

                        if (typeof _this.optionFilter[optionKey][variant.options[optionKey]] != 'undefined') {
                            _this.optionFilter[optionKey][variant.options[optionKey]]['total']++
                            continue
                        }

                        _this.optionFilter[optionKey][variant.options[optionKey]] = {
                            selected: true,
                            total: 1
                        }
                    }
                });

                //uncheck option in variant selected=false
                for (let optionKey in options) {
                    variant.forEach(function (variant) {

                        if(!variant.selected){
                            _this.optionFilter[optionKey][variant.options[optionKey]].selected = false
                        }
                    });
                }

                _this.countOptionFilter = JSON.parse(JSON.stringify(_this.optionFilter))
            },
            selectOptionFilter(select, value, optionKey, optionFilterKey) {
                let _this = this
                let filterOject = {}
                let allEmpty = true
                let count = 0

                Object.keys(_this.optionFilter).forEach(function (key) {
                    filterOject[key] = Object.keys(_this.optionFilter[key]).filter(function (keyValue) {
                        return _this.optionFilter[key][keyValue]['selected'] == true
                    })
                })

                if(Object.keys(filterOject).filter((key)=>filterOject[key].length > 0).length > 0)
                    allEmpty = false

                _this.variants = _this.variants.map(function (variant) {

                    if(allEmpty == true) {
                        variant.selected = false
                        return variant
                    }
                    variant.selected = _this.isAnd
                    for (let key in filterOject) {
                        if(_this.isAnd) {
                            if (filterOject[key].length != 0 && filterOject[key].indexOf(variant.options[key]) == -1)
                                variant.selected = false

                            continue
                        }

                        if (filterOject[key].length != 0 && filterOject[key].indexOf(variant.options[key]) > -1)
                            variant.selected = true

                    }

                    return variant
                });


                _this.numVariantSelected = _this.lengthVariantChecked(_this.product.variants);

                if(select.selected){

                    count = _this.numVariantSelected + select.total

                    if( count > 100){

                        _this.variants.forEach(function (variant) {
                            for (let optionKey in variant.options) {
                                if(variant.options[optionKey]==value){
                                    variant.selected=false
                                }
                            }
                        });

                        notify('warning', 'You can select a maximum of 100 variants.')

                        _this.optionFilter[optionFilterKey][value].selected = false

                        let id = value.split(' ').join('_')

                        $('#'+id).prop("checked",_this.optionFilter[optionFilterKey][value].selected);

                        return false
                    }

                }

                if(_this.numVariantSelected == 0 ){
                    this.product.variants[0].selected = true

                    for(let key in _this.optionFilter){
                        _this.optionFilter[key][_this.product.variants[0].options[key]].selected=true
                    }
                    notify('success', 'The variants were successfully unselected. Note at least one variant must stay selected')
                    notify('warning', 'You must select at least 1 variant.')

                    _this.numVariantSelected = 1;
                }

                axios.post(appUrl+'/import/variants', this.product.variants)
            },

            showInputChangePrice: function () {
                this.showChangeComparePrice = false
                this.showChangePrice = true
            },
            showInputChangeComparePrice: function () {
                this.showChangePrice = false
                this.showChangeComparePrice = true
            },
            saveChangePrice:function () {
                let _this = this
                _this.product.variants = _this.product.variants.map(function (variant) {
                    if(variant.selected)
                        variant.price = Number(_this.priceVariantSelect).toFixed(2)

                    return variant
                })
                _this.priceVariantSelect = null
                _this.showChangePrice = false
                //Update database
                axios.post(appUrl+'/import/variants', this.product.variants)
            },
            saveChangeComparePrice:function () {
                let _this = this
                _this.product.variants = _this.product.variants.map(function (variant) {
                    if(variant.selected)
                        variant.compare_at_price = Number(_this.comparePriceVariantSelect).toFixed(2)
                    return variant
                })
                _this.comparePriceVariantSelect = null
                _this.showChangeComparePrice = false
                //Update database
                axios.post(appUrl+'/import/variants', this.product.variants)
            }
        },
        watch: {
            collections: function (value) {
                this.setCollection(value)
            },
            numVariantSelected:function(value){
                if(value == this.product.variants.length) this.selectAll = true
                else this.selectAll = false

            },
            props_product: {
                handler: function(val, oldVal) {
                    let _this = this

                    if(!$.isEmptyObject(val.tag) && !$.isEmptyObject(_this.product.tag)){
                        val.tag = typeof val.tag === "string" ? val.tag : val.tag.toString()

                        _this.product.tag = typeof _this.product.tag === "string" ? _this.product.tag : _this.product.tag.toString()
                    }

                    if(val.tag != _this.product.tag) {
                        if(!$.isEmptyObject(_this.product.tag) || _this.product.tag === "string"){
                            let array_old_tag = Array.isArray(_this.product.tag) ? _this.product.tag : _this.product.tag.split(',')

                            array_old_tag.forEach(function (old_tag) {
                                $('#product-tag'+_this.product.id).tagsinput('remove',  old_tag)
                            })
                        }
                        let array_new_tag = Array.isArray(val.tag) ? val.tag : val.tag.split(',')

                        array_new_tag.forEach(function (new_tag) {
                            $('#product-tag'+_this.product.id).tagsinput('add',  new_tag)
                        })
                        _this.is_update_product = true
                    }

                    if(val.custom_collection != _this.product.custom_collection) {

                        _this.current_collection= []

                        this.obj_collections = this.obj_collections.map(function(collection) {
                            if(val.custom_collection.includes(collection.id)) {
                                _this.current_collection.push(collection)
                                collection.selected=true
                            }
                            return collection
                        })
                        _this.is_update_product = true
                    }

                    if(val.body_html != _this.product.body_html) {
                        _this.product.body_html = val.body_html
                        _this.is_update_product = true
                    }

                    if(val.title != _this.product.title) {
                        _this.product.title = val.title
                        _this.is_update_product = true
                    }

                    _this.product = Object.assign({}, val)
                    this.update_product.next()

                },
                deep: true
            },
            props_current_product: {
                handler: function (val, oldVal) {
                    // this.price_shipping = val.price_shipping
                    // follow case about check aliexpress_product_id !!!
                    if (val.id == this.product.id) {
                        this.product = Object.assign({}, val)
                    }

                    this.profit_calculate()
                },
                deep: true
            },
        }
    }
</script>
<style scoped lang="scss">
    .select-all-group {
        margin-bottom: 15px;
        height: 34px;
        label {
            font-size: 15px;
            line-height: 34px;
            vertical-align: middle;
        }
        .select-all-text {
            font-size: 15px;
            line-height: 34px;
            vertical-align: middle;
            b {
                color: #7009FF;
            }
        }
    }

    .header-import-action .dropdown.box-dropdown {
        margin-right: 20px;
    }
</style>

