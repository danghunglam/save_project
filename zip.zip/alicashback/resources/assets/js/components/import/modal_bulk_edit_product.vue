<template>
    <div class="modal fade" id="bulkEditProduct" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg-1170" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="pull-left ao__bulk_edit_title_left">
                        <h2 class="modal-title">Mass Apply Edit</h2>
                        <span v-if="check_active_field"><i class="mdi mdi-alert-circle"></i>Apply all changes on this form to all selected products</span>
                    </div>
                    <div class="pull-right ao__bulk_edit_title_right">
                        <button class="button-style-sm-o m-r-10" @click="cancelBulkEdit()" data-dismiss="modal">Cancel</button>
                        <button class="button-style-dark-sm push-to-shop-btn" @click="saveBulkProduct()" v-text= "is_loading ? 'Saving...' : 'Save' "> Save </button>
                    </div>
                </div>

                <div class="modal-body">
                    <div class="ao__import_choose_product">
                        <span>Choose product as template</span>
                        <div class="dropdown box-dropdown">
                            <span class="box-dropdown-toggle" id="select-product" data-toggle="dropdown">
                                <img data-v-633f6ea2="" v-bind:src="choose_product_img_src" class="img-product-choose" alt="">
                                <span class="text-product-choose">{{choose_product_title}}</span>
                            </span>
                            <div class="dropdown-menu box-dropdown-menu product-template">
                                <ul>
                                    <li v-if="props_products_select" v-for="product in props_products_select" @click="chooseProduct(product)">
                                        <div class="box-variant-content">
                                            <img v-bind:src="product.image" alt="">
                                            <span class="text-product">
                                            {{product.title}}
                                            </span>

                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="m-b-30 m-t-20">
                        <label class="checkbox-style checkbox-text-o" style="vertical-align: middle;" for="select-title">
                            <input id="select-title" type="checkbox" @click="choosePropertiesProduct('name' , is_title = !is_title)">
                            <span class="checked-style"></span>
                        </label>
                        <label class="fw-600">Name on Shopify</label>
                        <div class="form-group m-b-0">
                            <input type="text" id="name_product" v-model="props_bulk_edit_product.name.text">
                            <span v-show="error" style="color: red"> The product title field is required </span>
                        </div>
                    </div>

                    <div class="m-b-30 ao__dropdown_tags" v-show="collections">
                        <label class="checkbox-style checkbox-text-o" style="vertical-align: middle;" for="select-collections">
                            <input id="select-collections" type="checkbox" @click="choosePropertiesProduct('collection' , is_collection = !is_collection)">
                            <span class="checked-style"></span>
                        </label>
                        <label class="fz-13 m-b-0 fw-600">
                            Collections
                            <span class="tooltip-style-wrap color-skin" style="margin-left: 3px" data-toggle="tooltip" title="Maximum of 250 collections">
                                <i class="mdi mdi-alert-circle"></i>
                            </span>
                        </label>
                        <div class="dropdown box-dropdown dropdown-collection m-t-10">
                                <span class="box-dropdown-toggle" data-toggle="dropdown">
                                    <span class="result-multiselect">
                                        <ul>
                                            <li v-for="collection in bulk_edit_current_collection" v-bind:key="collection.id">{{ collection.title }} <span @click="removeCollectionBulkEdit(collection)" class="mdi mdi-close"></span></li>
                                            <li><input class="ao__import_choose_collections" type="text" @keyup="keyupCollection()" id="collection" placeholder="Choose Collections"></li>
                                        </ul>
                                    </span>
                                </span>
                            <div class="dropdown-menu box-dropdown-menu">
                                <ul v-if="bulk_edit_obj_collections.length > 0">
                                    <li v-for="collection in bulk_edit_obj_collections" :class="collection.selected?'selected':''" @click="addCollectionBulkEdit(collection)">{{ collection.title }}</li>
                                </ul>
                                <span class="no-results" v-else>No results found</span>
                            </div>
                        </div>
                    </div>

                    <div class="row ao__dropdown_tags">
                        <div class="col-md-6 m-b-10">
                            <div class="form-group-tag m-b-0">
                                <label class="checkbox-style checkbox-text-o" for="select-type">
                                    <input id="select-type" type="checkbox" @click="choosePropertiesProduct('type' , is_type = !is_type)">
                                    <span class="checked-style"></span>
                                </label>
                                <label class="fz-13 m-b-0 fw-600">Type</label>
                                <!--<div class="bootstrap-tagsinput-wrap form-group m-t-5">-->
                                <!--<input class="product-type tagsinput" ref="product-type" placeholder="Insert Type Here" data-role="tagsinput" v-model="props_bulk_edit_product.type.text" id="product-type" />-->
                                <!--</div>-->
                                <div class="dropdown box-dropdown dropdown-product-type">
                                            <span class="box-dropdown-toggle" data-toggle="dropdown">
                                                <span class="result-multiselect">
                                                    <ul>
                                                        <li v-if="product.product_type">{{product.product_type}}<span @click="removeproductType()" class="mdi mdi-close"></span></li>
                                                        <li><input class="product-type product__type_input fz-13" placeholder="Choose Type" type="text" @keyup="keyupProductType($event)" @keyup.enter="keyupEnterProductType()" @blur="keyupEnterProductType()"></li>
                                                    </ul>
                                                    <span class="box-dropdown-menu-label">Add new type by pressing Enter key</span>
                                                </span>
                                            </span>
                                    <div class="dropdown-menu box-dropdown-menu" v-if="product_type.length!=0">
                                        <ul>
                                            <li v-for="type in product_type" @click="selectType(type)" v-text="type.name"></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 m-b-10">
                            <div class="form-group-tag m-b-0">
                                <label class="checkbox-style checkbox-text-o" for="select-tag">
                                    <input id="select-tag" type="checkbox" @click="choosePropertiesProduct('tag' , is_tag = !is_tag)">
                                    <span class="checked-style"></span>
                                </label>
                                <label class="fz-13 m-b-0 fw-600">Tags</label>
                                <div class="bootstrap-tagsinput-wrap form-group m-t-5">
                                    <input class="tagsinput" ref="product_tag" placeholder="Insert Tags Here" data-role="tagsinput" v-model="props_bulk_edit_product.tag.text" id="product-tag" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-description-wrap m-b-30 ao__dropdown_tags">
                        <label class="checkbox-style checkbox-text-o" for="select-description">
                            <input id="select-description" type="checkbox" @click="choosePropertiesProduct('description' , is_description = !is_description)">
                            <span class="checked-style"></span>
                        </label>
                        <label class="fz-13 m-b-0 fw-600">Description</label>
                        <div class="m-t-10">
                            <trumbowyg  v-bind:content="props_bulk_edit_product.description.text" v-on:change-content="changeBodyHtml"></trumbowyg>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>

</template>

<script>
    import trumbowyg from '../common/trumbowyg'
    import Rx from 'rxjs/Rx';
    export default {
        name: 'modal_bulk_edit_product',
        props: {
            props_products_select: {
                required: true,
            },
            collections : {
                required: true,
                default: false
            },
            props_bulk_edit_product: {
                required: true
            },
            props_is_loading_bulk_edit:{
                required: true
            },
            product_type: {
                required: true,
                default: []
            }
        },
        data: function(){
            return {
                bulk_edit_obj_collections: [],
                bulk_edit_current_collection: [],
                custom_collection_bulk_edit:[],
                product:{},
                is_title:false,
                is_collection:false,
                is_type:false,
                is_tag:false,
                is_description:false,
                choose_product_img_src:'',
                choose_product_title:'',
                error:false,
                is_loading: false,
                select_property_edit: false,
                call_choose_product : null,
                check_active_field: false,
            }
        },
        components:{
            trumbowyg
        },
        created: function(){
            let _this = this
            _this.call_choose_product = new Rx.BehaviorSubject();
            _this.call_choose_product
                .debounceTime(1000)
                .subscribe(
                    function(product) {
                        if(product)
                            _this.chooseProduct(product)
                    }
                );
            _this.$emit('call_choose_product',_this.call_choose_product);
        },
        mounted: function(){
            let _this = this
            $('.tagsinput').tagsinput({
                'confirmKeys': [13],
                'focusClass': 'my-focus-class'
            })
            $('#product-type').on('beforeItemAdd', function(event) {
                $('#product-type').tagsinput('removeAll');
            });
            $('#name_product').focus(function () {
                _this.error = false
                $('#name_product').css({'border-color':''})
            })
            //check select field, if all field uncheck is disabled btn save and hide waning
            if(_this.is_title===false&&_this.is_collection===false&&_this.is_type===false&&_this.is_type===false&&_this.is_description===false){
                _this.check_active_field = false
                $('.ao__bulk_edit_title_right .push-to-shop-btn').attr('disabled','disabled')
            }
            else{
                _this.check_active_field = true
                $('.ao__bulk_edit_title_right .push-to-shop-btn').removeAttr('disabled')
            }
        },
        methods:{
            chooseProduct:function (product) {
                let _this = this
                _this.removeAllCollection()
                _this.choose_product_img_src = product.image
                _this.choose_product_title   = product.title
                _this.custom_collection_bulk_edit = product.custom_collection
                $('.tagsinput').tagsinput('removeAll');
                _this.custom_collection_bulk_edit = product.custom_collection
                _this.props_bulk_edit_product.name.text = product.title
                _this.props_bulk_edit_product.type.text = product.product_type
                _this.props_bulk_edit_product.tag.text = product.tag == null ? product.tag : product.tag.toString()
                _this.props_bulk_edit_product.description.text =product.body_html
                product.tag = product.tag ? product.tag.toString() : product.tag
                product.product_type = product.product_type ? product.product_type.toString() : product.product_type
                $('#product-tag').tagsinput('add', product.tag);
                $('#product-type').tagsinput('add', product.product_type);
                _this.setCollectionBulkEdit(_this.collections)
                _this.initBulkEdit()
            },
            choosePropertiesProduct:function(type,boolean){
                if(boolean) this.select_property_edit = true
                this.props_bulk_edit_product[type]['active'] = boolean
                //check active field
                this.checkSelectField()
            },
            changeBodyHtml: function (content) {
                this.props_bulk_edit_product['description']['text'] = content
            },
            validateInput: function(){
                let _this = this
                if(this.props_bulk_edit_product['name']['active'] && this.props_bulk_edit_product['name']['text']=='') {
                    $('#name_product').css({'border-color':'red'});
                    _this.error = true
                    return false
                }
                return true
            },
            saveBulkProduct:function(){
                let _this = this
                if(!_this.select_property_edit){
                    notify('warning','Choose 1 properties edit')
                    return false
                }
                if(!_this.validateInput()) return false
                _this.is_loading = true
                _this.props_bulk_edit_product['collection']['text'] = _this.bulk_edit_current_collection
                _this.props_bulk_edit_product['type']['text'] = this.product.product_type
                _this.props_bulk_edit_product['tag']['text'] = $('#product-tag').tagsinput('items').toString()
                _this.props_bulk_edit_product.productsId = _this.props_products_select.map(function (product_select) {
                    return product_select.id
                })
                _this.choose_product_title   = _this.props_bulk_edit_product.name.text
                _this.$emit('save_bulk_product', _this.props_bulk_edit_product,_this.bulk_edit_current_collection)
            },
            removeAllCollection:function(){
                this.bulk_edit_obj_collections = []
                this.bulk_edit_current_collection= []
            },
            removeCollectionBulkEdit:function (obj_collection) {
                let target=event.currentTarget
                $(target).parents('.dropdown-collection').addClass('open')
                let _this = this
                _this.bulk_edit_obj_collections = _this.bulk_edit_obj_collections.map(function (collection) {
                    if(obj_collection.id === collection.id) {
                        collection = Object.assign({}, collection, {
                            selected: false,
                        })
                    }
                    return collection
                })
                if(_this.custom_collection_bulk_edit!=null) {
                    var index = _this.custom_collection_bulk_edit.indexOf(obj_collection.id);
                    if (index > -1) {
                        _this.custom_collection_bulk_edit.splice(index, 1);
                        _this.bulk_edit_current_collection.splice(index, 1);
                    }
                }
            },
            keyupCollection:function () {
                let target=$(event.currentTarget)
                let val=target.val().toLowerCase()
                $(target).parents('.dropdown-collection').find('.box-dropdown-menu li').each(function () {
                    if(val!='') {
                        var value = $(this).text()
                        if (value.toLowerCase().indexOf(val) >= 0) {
                            $(this).css('display', 'block')
                        }
                        else {
                            $(this).css('display', 'none')
                        }
                    }
                    else{
                        $(this).css('display', 'block')
                    }
                })
            },
            addCollectionBulkEdit:function (obj_collection) {
                let _this = this
                this.bulk_edit_obj_collections = this.bulk_edit_obj_collections.map(function (collection) {
                    if(obj_collection.id === collection.id) {
                        collection = Object.assign({}, collection, {
                            selected: true,
                        })
                    }
                    if(_this.custom_collection_bulk_edit != null) {
                        if( ! _this.custom_collection_bulk_edit.includes(obj_collection.id)) {
                            _this.custom_collection_bulk_edit.push(obj_collection.id)
                            _this.bulk_edit_current_collection.push(obj_collection)
                        }
                    } else {
                        _this.custom_collection_bulk_edit = []
                        _this.custom_collection_bulk_edit.push(obj_collection.id)
                        _this.bulk_edit_current_collection.push(obj_collection)
                    }
                    return collection
                })
                let target=event.currentTarget
                $(target).parents('.dropdown-collection').find('.result-multiselect li:last-child input').val('')
                $(target).parents('.dropdown-collection').find('.box-dropdown-menu li').css('display','block')
            },
            setCollectionBulkEdit: function (value) {
                let _this = this
                if(value && _.isObject(value))
                {
                    Object.values(value).forEach(function (collect) {
                        _this.bulk_edit_obj_collections.push({
                            id: collect.id,
                            title:  collect.title,
                            selected: false
                        })
                    })
                }
                if(this.custom_collection_bulk_edit) {
                    this.bulk_edit_obj_collections = this.bulk_edit_obj_collections.map(function(collection) {
                        if(_this.custom_collection_bulk_edit.includes(collection.id)) {
                            _this.bulk_edit_current_collection.push(collection)
                            collection.selected=true
                        }
                        return collection
                    })
                }
            },
            removeproductType:function () {
                this.product.product_type='';
            },
            keyupProductType: function(event) {
                let target = event.currentTarget
                $(target).parents('.box-dropdown').removeClass('open')
                $(target).parents('.box-dropdown.dropdown-product-type').addClass('open-keep-label')
                if($(target).val()==''){
                    $(target).parents('.box-dropdown').addClass('open')
                    $(target).parents('.box-dropdown.dropdown-product-type').removeClass('open-keep-label')
                }
            },
            keyupEnterProductType:function(e){
                let target = event.currentTarget
                let valCollection=$(target).val().trim()
                if(valCollection!=''){
                    this.product.product_type = valCollection
                    $(target).val('')
                    $(target).parents('.box-dropdown').addClass('open')
                    $(target).parents('.box-dropdown.dropdown-product-type').removeClass('open-keep-label')
                }
            },
            selectType: function(obj_type) {
                this.product = Object.assign({}, this.product, { type: obj_type })
                this.product.product_type = obj_type.name
            },
            checkSelectField: function () {//check select field, if all field uncheck is disabled btn save and hide waning
                let _this = this
                if(_this.is_title===false&&_this.is_collection===false&&_this.is_type===false&&_this.is_tag===false&&_this.is_description===false){
                    _this.check_active_field = false
                    $('.ao__bulk_edit_title_right .push-to-shop-btn').attr('disabled','disabled')
                }
                else{
                    _this.check_active_field = true
                    $('.ao__bulk_edit_title_right .push-to-shop-btn').removeAttr('disabled')
                }
            },
            initBulkEdit: function () {
                let _this = this
                $('#name_product').css({'border-color':''})
                _this.error = false
                $('#select-title, #select-collections,#select-type, #select-tag, #select-description').prop('checked', false)
                _this.is_title=false
                _this.is_collection=false
                _this.is_type=false
                _this.is_tag=false
                _this.is_description=false
                _this.checkSelectField()
            },
            cancelBulkEdit: function () {
                this.$emit('cancel_bulk_edit')
            }
        },
        watch:{
            collections: function (value) {
                this.setCollectionBulkEdit(value)
            },
            props_products_select:function (value) {
                if(this.props_products_select.length <= 0) return false
                let product = this.props_products_select[0]
                this.call_choose_product.next(product);
            },
            props_is_loading_bulk_edit:function (value) {
                if(value){
                    this.is_loading = false
                }
            }
        }
    }
</script>

<style scoped>
</style>