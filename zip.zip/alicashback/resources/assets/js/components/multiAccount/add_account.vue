<template>
    <div id="addAccount" class="modal fade" role="dialog">
        <div class="modal-dialog modal-xs">
            <form action="/addAppHandle" ref="add_account_form" method="POST">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <span class="mdi mdi-account-circle"></span>
                    <h4 class="modal-title">Add Store To Link With Current Store</h4>
                </div>
                <div class="modal-body">
                        <input type="hidden" name="_token" id="_token" value="">
                        <div class="form-group" style="margin-bottom: 20px">
                            <input v-model="new_shopdomain" name="shop" id="your-shopify-url" type="text" placeholder="Please enter your Shopify store domain">
                            <span class="text-error" v-if="checkEmpty">Please input your Shopify store's link</span>
                        </div>

                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="modal__ok_button" @click.prevent="addAccount">Add Store</button>
                </div>
            </div>
            </form>
        </div>
    </div>
</template>

<script type="text/javascript">
    export default {
        data() {
            return{
                new_shopdomain: '',
                checkEmpty: false
            }
        },
        methods:{
            addAccount: function () {
                let checkValEmpty = $('#your-shopify-url').val()
                if(checkValEmpty === ''){
                    this.checkEmpty = true
                    return false
                }
                $('#_token').val($('meta[name="csrf-token"]').attr('content'))
                this.$refs.add_account_form.submit()
            }
        }
    }
</script>
