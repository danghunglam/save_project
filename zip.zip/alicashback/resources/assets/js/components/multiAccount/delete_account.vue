<template>
    <div id="removeAccount" class="modal fade" role="dialog">
        <div class="modal-dialog modal-xs">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" data-dismiss="modal" class="close"><i class="mdi mdi-close"></i></button>
                </div>
                <div class="modal-body">
                    <span class="mdi mdi-delete-forever"></span>
                    <h4 class="modal-title">Remove Store</h4>
                    <p>Are you sure to remove Shopify store domain: <a target="_blank" id="popup_remove_shop_domain" class="color-skin"></a> from linked stores list?</p>
                    <input type="text" v-model="shop_id" hidden id="popup_remove_shop_id" />
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click.prevent="removeAccountHandle()">Remove</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script type="text/javascript">
    export  default {
        data() {
            return {
                is_remove_account: false,
                loading: false,
                shop_id: ''
            }
        },
        props: {
            shop_domain: {
                type: String,
                required: true
            }
        },
        mounted: function(){

        },
        methods: {
            removeAccountHandle: function () {
                let _this = this
                axios.post(appUrl + '/removeOwnStore', {shop_id: $('#popup_remove_shop_id').val()})
                    .then(function (response) {
                        let {status} = response
                        if (status) {
                            $('#store_account_' + $('#popup_remove_shop_id').val()).remove();
                            $('#removeAccount').modal('hide')
                            notify('success', 'Success');
                        }
                }).catch(function (error) {})
            }
        }
    };
</script>
