<template>
    <div id="modal-delete-product" class="modal-delete-product modal fade" role="dialog">
        <div class="modal-dialog modal-xs">
            <div class="modal-content modal__content_icon">
                <div class="modal-header">
                    <button class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <div class="modal__header_icon">
                        <div class="icon-delete-accout">
                            <i class="mdi mdi-delete-forever"></i>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <h2 class="modal__body_title">Remove Product</h2>
                    <p>Are you sure to delete this product?</p>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button button-modal-delete" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button color-error button-modal-delete" @click="deleteProduct()" data-dismiss="modal">Remove</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script type="text/javascript">
    import Axios from 'axios'
    export  default {
        name: 'status_delete',
        props: ['product_notify_id'],
        methods: {
            deleteProduct:function () {
                let _this = this
                Axios.delete(notify_domain+'/api/product/'+_this.product_notify_id, {
                    headers: {
                        Authorization: JSON.stringify({shop_id: window.shopId}),
                    }
                })
                    .then(function(response) {
                        let { status } = response.data
                        if(status){
                            notify('success', 'Deleted product success');
                            _this.$emit('load_page')
                        }
                    else
                        notify('error', 'Deleted product error, please refresh page and try again');
                    }).catch(function(error) {
                        notify('error', 'Error');
                    })
            }
        }
    };
</script>
