<template>
    <div id="modal-type-product" class="modal-out-of-stock-product modal fade" role="dialog">
        <div class="modal-dialog" v-bind:class="setClass(product_notify_type_key)">
            <div class="modal-content modal__content_icon">
                <div class="modal-header">
                    <button class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <h4>Product {{ title }}</h4>
                </div>
                <div class="modal-body">
                    <div class="ars-table">
                        <div class="ars-table-row">
                            <div class="ars-table-col" v-for="head in header">
                                <h4>{{ head.title }}</h4>
                            </div>
                        </div>
                        <div class="ars-table-row" v-for="item in object">
                            <div class="ars-table-col" v-for="key in header">
                                <span v-if="key.is_link">
                                    <a :href="item[key.key]" target="_blank">{{key.is_link.title}} <i class="mdi mdi-open-in-new"></i></a>
                                </span>
                                <div v-else>
                                    {{item[key.key]}}
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</template>

<script type="text/javascript">
    export  default {
        name: 'type_product',
        props: ['notify_type','object', 'type_config'],
        data: function() {
            return {
                title: '',
                header: []
            }
        },
        methods: {
            setClass:function (type) {
                let res=''
                switch (type) {
                    case 'product_miss_link':
                        res = 'modal-md'
                        break;
                    case 'product_miss_variant':
                        res = 'modal-md width-560'
                        break;
                    case 'product_change_cost':
                        res = 'modal-lg'
                        break;
                    case 'product_out_of_stock':
                        res = 'modal-lg width-560'
                        break;
                }
                return res
            }
        },
        watch: {
            object: {
                handler: function (val) {
                    this.title = (this.type_config[this.notify_type]) ? this.type_config[this.notify_type].title : ''
                    this.header = (this.type_config[this.notify_type]) ? this.type_config[this.notify_type].header : []
                },
                deep: true
            }
        }
    }
</script>
