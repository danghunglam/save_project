<template>
    <div id="modal_leave_page" class="modal fade" role="dialog">
        <!-- Modal Delete Product -->
        <div class="modal-dialog" v-bind:class="{ size: true }">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header" v-show="title !== ''">
                    <button type="button" class="close" data-dismiss="modal"><i class="icon-ali icon-ic-highlight-off-24px"></i></button>
                    <h4 class="modal-title">{{ title }}</h4>
                </div>
                <div class="modal-body">
                    <div class="delete-product-modal-wrap">
                        <div class="ars-field">
                            <label class="ars-field-title">{{ content }}</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="ars-form-submit-btn-wrap">
                        <button class="ars-btn-o" type="button" data-dismiss="modal">{{ cancel }}</button>
                        <button class="ars-btn" type="button" @click="goPage">{{ submit }}</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
    export  default {
        props: {
            href: {
                default: ''
            },
            submit: {
                default: 'OK'
            },
            cancel: {
                default: 'Cancel'
            },
            title: {
                default : ''
            },
            content: {
                default: ''
            },
            size: {
                default: 'sm'
            }
        },
        data() {
            return {
            }
        },
        methods: {
            goPage() {
                if(this.href) {
                    window.location = this.href
                }
            }
        }
    };

</script>