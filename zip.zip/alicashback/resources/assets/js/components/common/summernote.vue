<template>
    <div></div>
</template>
<script type="text/javascript">
    export default {
        props: {
            content: {
                required: true,
            },
            height: {
                type: Number,
                required: false,
                default: 240
            },
            toolbar: {
                type: Array,
                required: false,
                default: function() {
                    return [
                        ['style', ['bold', 'italic', 'underline', 'clear']],
                        ['font', ['strikethrough', 'superscript', 'subscript']],
                        ['fontsize', ['fontsize']],
                        ['color', ['color']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['height', ['height']],
                        ['insert', ['picture', 'link', 'video', 'table', 'hr']]
                    ];
                }
            }
        },
        mounted: function() {
            let me = this;

            this.control = $(this.$el);

            this.control.summernote({
                height: this.height,
                toolbar: this.toolbar,
                callbacks: {
                    onInit: function() {
                        setTimeout(function () {
                            me.control.summernote('code', me.content);
                        }, 0);
                    },
                    onBlur: function() {
                        me.$emit('change-content', me.control.summernote('code'))
                    }
                }
            });

        },
    };
</script>
<style>
    ul{
        list-style: decimal;
    }
</style>