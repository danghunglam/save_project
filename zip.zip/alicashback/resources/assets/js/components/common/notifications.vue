<template>
    <div class="list-notifications">
        <div class="text-center no-notification" v-if="notifications.length === 0">
            No notification
        </div>
        <div v-else>
            <!--<div class="notifications-item" v-for="notify in notifications" :class="notify.status==1 ? 'new-notifications-item' : ''">-->
            <div class="notifications-item" v-for="notify in notifications" :class="notify.status==1?'notifications-new-item':''">
                <a @click="clickNotify(notify)">
                    <h4>{{ notify.title }}</h4>
                    <p>
                        {{ notify.text }}
                    </p>
                    <!--<i :class=" notify.status==1 ? 'mdi mdi-checkbox-blank-circle' : '' "></i>-->
                    <!--mdi mdi-checkbox-blank-circle mdi-checkbox-blank-circle-outline-->
                </a>
                <div class="loading-notify" v-show="notify.loading">
                    <img v-bind:src="appURL+'/images/backend/loading-notify.gif'" alt="loading notify">
                </div>
            </div>
            <a class="see-all-notifications" v-if="total_product > number_show_product" v-bind:href="productStatusLink">
                <span>See all</span>
            </a>
        </div>

    </div>
</template>

<script>
    import Axios from 'axios'
    export default {
        data: function () {
            return {
                notifications:{},
                number_show_product: 0,
                total_product: 0,
                appURL: window.appUrl,
                new_notications: 0
            }
        },
        created: function () {
            this.getNotify()
        },
        mounted:function(){
            this.pusherNotify()
        },
        computed: {
            productStatusLink: function() {
                return appUrl+'/products/status'
            }
        },
        methods: {
            textNotify: function(data) {
                let _this = this

                this.notifications = data.map(function (notify) {

                    let tmp = {}
                    switch (notify.type_notify){
                        case 'new_order':
                            tmp = {
                                type: notify.type_notify,
                                title: 'New Order',
                                text: 'You have '+ notify.total_order +' new '+(notify.total_order > 1 ? 'orders' : 'order'),
                                link: appUrl+'/orders',
                                status: notify.status
                            }
                            break;
                        case 'product_miss_link':
                            tmp = {
                                _id: notify._id,
                                type: notify.type_notify,
                                title: 'Product Disappears',
                                text: 'Shopify product '+notify.product.title+' is missing!',
                                link: appUrl+'/products/status',
                                status: notify.status
                            }
                            break;
                        case 'product_miss_variant':
                            tmp = {
                                _id: notify._id,
                                type: notify.type_notify,
                                title: 'Variant Disappears',
                                text: 'Shopify product '+notify.product.title+' variant is missing!',
                                link: appUrl+'/products/status',
                                status: notify.status
                            }
                            break;
                        case 'product_change_cost':
                            tmp = {
                                _id: notify._id,
                                type: notify.type_notify,
                                title: 'Cost Change',
                                text: 'Shopify product '+notify.product.title+' variant changed price',
                                link: appUrl+'/products/status',
                                status: notify.status
                            }
                            break;
                        case 'product_out_of_stock':
                            tmp = {
                                _id: notify._id,
                                type: notify.type_notify,
                                title: 'Product Out Of Stock',
                                text: 'Shopify product '+notify.product.title+' is out of stock',
                                link: appUrl+'/products/status',
                                status: notify.status
                            }
                            break;
                    }

                    return tmp
                })

            },
            pusherNotify: function () {
                let _this = this;
                let pusher = new Pusher(pusherEnv.app_key, {
                    cluster: pusherEnv.app_cluster,
                    encrypted: true
                });
                let channel = pusher.subscribe(window.shopId);

                channel.bind('order_created', function(data) {
                    _this.getNotify()
                });
            },
            getNotify: function () {
                let _this = this
                Axios.get(notify_domain+'/api/notify/quick_view', {
                    headers: {
                        Authorization: JSON.stringify({shop_id: window.shopId}),
                    }
                })
                    .then(function (response) {
                        let { total_product, obj, number_show_product, total } = response.data
                        _this.total_product = total_product
                        _this.number_show_product = number_show_product
                        _this.textNotify(obj)
                        console.log(total)
                        _this.$emit('number_notification', total)
                    })
                    .catch(function (error) {
                        console.log(error)
                    })
            },
            clickNotify: function (notify) {
                if(notify.type === 'new_order') {
                    Axios.put(notify_domain+'/api/order/all_status', {
                        status: false
                    }, {
                        headers: {
                            Authorization: JSON.stringify({shop_id: window.shopId}),
                        }
                    }).then(function (response) {
                        let {status} = response.data
                        if(status)
                            window.location.href = notify.link
                    })
                } else {
                    Axios.put(notify_domain+'/api/product/'+notify._id, {
                        status: false
                    }, {
                        headers: {
                            Authorization: JSON.stringify({shop_id: window.shopId}),
                        }
                    }).then(function (response) {
                        const {status} = response.data
                        if(status)
                            window.location.href = notify.link
                    })
                }
                notify.loading=true
            },

        }
    }
</script>
