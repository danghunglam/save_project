<template>
    <textarea v-model="content" class="trumbowyg"></textarea>
</template>
<script>
    export default {
        props: {
            content: {
                type: String,
                default: '',
                required: true,
            },
        },
        mounted: function () {
            let _this = this;

            this.control = $(this.$el);

            this.control.trumbowyg()
                .on('tbwblur', function (event) {
                    let content  = $(event.currentTarget).val()
                    _this.$emit('change-content', content)
                });
        },
        watch: {
            content: function(newVal, oldVal) {
                this.control.trumbowyg('html', newVal)
            } 
        }
    }
</script>