<template>
    <div class="toast-process-wrap" v-bind:class="process_active ? 'active' : ''" v-show="Object.keys(process).length > 0">
        <h4>
            <span @click="toggleProcess">{{ process_title }} ( {{ Object.keys(process).length }} )</span>
            <span class="close-override-product" @click="closeProcess">
                <i class="mdi mdi-autorenew"></i>
            </span>
        </h4>
        <transition name="fade">
            <ul v-if="process_active">
                <!-- Override product -->
                <li>
                    <p>
                        <a>
                            Overriding product name
                        </a>
                    </p>
                    <!-- <span v-if="item.status === 'success'" class="success" data-toggle="tooltip" data-placement="top" title="Done">
                        <i class="ali-icon icon-ic-check-24px"></i>
                    </span> -->
                    <span data-toggle="tooltip" data-placement="top" title="Processing" class="animate-spin">
                        <i class="mdi mdi-autorenew"></i>
                    </span>
                </li>
                <!-- importing reviews for product -->
                <li>
                    <p>
                        <a>
                            Importing reviews for product name
                        </a>
                    </p>
                    <!-- <span v-if="item.status === 'success'" class="success" data-toggle="tooltip" data-placement="top" title="Done">
                        <i class="ali-icon icon-ic-check-24px"></i>
                    </span> -->
                    <span data-toggle="tooltip" data-placement="top" title="Processing" class="animate-spin">
                        <i class="mdi mdi-autorenew"></i>
                    </span>
                </li>

                <!-- Bulk importing reviews for products -->
                <li>
                    <p>
                        <a>
                            Bulk importing reviews for products
                        </a>
                    </p>
                    <!-- <span v-if="item.status === 'success'" class="success" data-toggle="tooltip" data-placement="top" title="Done">
                        <i class="ali-icon icon-ic-check-24px"></i>
                    </span> -->
                    <span data-toggle="tooltip" data-placement="top" title="Processing" class="animate-spin">
                        <i class="mdi mdi-autorenew"></i>
                    </span>
                </li>

                <!-- Sync Ali Order Number -->
                <li>
                    <p>
                        <a>
                            Sync Ali Order Number: <span>65%</span>
                        </a>
                    </p>
                    <!-- <span v-if="item.status === 'success'" class="success" data-toggle="tooltip" data-placement="top" title="Done">
                        <i class="ali-icon icon-ic-check-24px"></i>
                    </span> -->
                    <span data-toggle="tooltip" data-placement="top" title="Processing" class="animate-spin">
                        <i class="mdi mdi-autorenew"></i>
                    </span>
                </li>
                <!-- Get tracking code from AliExpress -->
                <li>
                    <p>
                        <a>
                            Get tracking code from AliExpress: <span>65%</span>
                        </a>
                    </p>
                    <!-- <span v-if="item.status === 'success'" class="success" data-toggle="tooltip" data-placement="top" title="Done">
                        <i class="ali-icon icon-ic-check-24px"></i>
                    </span> -->
                    <span data-toggle="tooltip" data-placement="top" title="Processing" class="animate-spin">
                        <i class="mdi mdi-autorenew"></i>
                    </span>
                </li>

                <!-- Get tracking code from file -->
                <li>
                    <p>
                        <a>
                            Get tracking code from file: <span>65%</span>
                        </a>
                    </p>
                    <!-- <span v-if="item.status === 'success'" class="success" data-toggle="tooltip" data-placement="top" title="Done">
                        <i class="ali-icon icon-ic-check-24px"></i>
                    </span> -->
                    <span data-toggle="tooltip" data-placement="top" title="Processing" class="animate-spin">
                        <i class="mdi mdi-autorenew"></i>
                    </span>
                </li>


                <li class="toast-process-import-product">
                    <p>
                        <a>
                            Sexy Women Fashion High Waist Zip Faux Leather Short Pencil Bodycon Mini Skirt 2017 New Solid White Skirt
                        </a>
                        <a href="" class="toast-edit-on-shopify">Edit on <i></i></a>
                    </p>
                    <span class="success" data-toggle="tooltip" data-placement="top" title="Done">
                        <i class="icon-ali icon-ic-check-24px"></i>
                    </span>
                    <!-- <span data-toggle="tooltip" data-placement="top" title="Processing" class="animate-spin">
                        <i class="mdi mdi-autorenew"></i>
                    </span> -->
                </li>

                <li class="toast-process-import-product" v-for="item in Object.values(process)">
                    <p>
                        <a v-bind:href="(item.source_product_link) ? item.source_product_link : ''" target="_blank">
                            {{ (item.title) ? item.title : ''}}
                        </a>
                        <a v-if="item.status === 'success'" href="#" class="toast-edit-on-shopify">Edit on <i></i></a>
                    </p>

                    <span v-if="item.status === 'success'" class="success" data-toggle="tooltip" data-placement="top" title="Done">
                        <i class="icon-ali icon-ic-check-24px"></i>
                    </span>
                    <span v-else data-toggle="tooltip" data-placement="top" title="Processing" class="animate-spin">
                        <i class="mdi mdi-autorenew"></i>
                    </span>
                </li>
                <!-- <div class="processing-get-tracking-code-metter">
                    <div class="meter get-tracking-meter">
                        <span style="width: 100%"></span>
                    </div>
                </div> -->
            </ul>
        </transition>
    </div>
</template>
<script>
    export default {
        props: {
            process: {
                required: true,
                default: []
            },
            process_type: {
                required: true,
                default: ''
            },
            process_title : {
                required: false,
                default: 'Process'
            }
        },
        data() {
            return {
                process_active: true,
            }
        },
        mounted: function () {
            // $(".get-tracking-meter > span").each(function() {
			// 	$(this)
			// 		.data("origWidth", $(this).width())
			// 		.width(0)
			// 		.animate({
			// 			width: $(this).data("origWidth")
			// 		}, 10000);
			// });

            $(".meter > span").each(function() {
				$(this)
					.data("origWidth", $(this).width())
					.width(0)
					.animate({
						width: $(this).data("origWidth")
					}, 10000);
			});
        },
        methods: {
            toggleProcess: function() {
                this.process_active = ! this.process_active
            },
            closeProcess: function() {
                this.$emit('close_process')
                this.process = Object.assign({})
                axios.post(appUrl+'/toast_process', {products: this.process, type: this.process_type})
            }
        }
    }
</script>
<style lang="css">
.processing-get-tracking-code-metter {
    margin: 15px 0 20px;
    text-align: center;
    font-size: 13px;
    font-weight: 500;
    color: #242539;
    line-height: 20px;
}
.processing-get-tracking-code-metter .meter {
    height: 6px;  /* Can be anything */
    position: relative;
    margin: 10px 0 0; /* Just for demo spacing */
    background: #F0F2F8;
    -moz-border-radius: 30px;
    -webkit-border-radius: 30px;
    border-radius: 30px;
    -webkit-box-shadow: inset 0 -1px 1px rgba(255,255,255,0.3);
    -moz-box-shadow   : inset 0 -1px 1px rgba(255,255,255,0.3);
    box-shadow        : inset 0 -1px 1px rgba(255,255,255,0.3);
}
.processing-get-tracking-code-metter .meter > span {
    display: block;
    height: 100%;
    width: 0;
    border-radius: 30px;
    background-color: #242538;
    background-image: linear-gradient( linear, left bottom, left top, color-stop(0, #242538), color-stop(1, #242538) );
    /* background-image: -moz-linear-gradient(center bottom, #242538 37%, #242538 69%); */

    -webkit-box-shadow:
    inset 0 2px 9px  rgba(255,255,255,0.3),
    inset 0 -2px 6px rgba(0,0,0,0.4);
    -moz-box-shadow:
    inset 0 2px 9px  rgba(255,255,255,0.3),
    inset 0 -2px 6px rgba(0,0,0,0.4);
    box-shadow:
    inset 0 2px 9px  rgba(255,255,255,0.3),
    inset 0 -2px 6px rgba(0,0,0,0.4);
    position: relative;
    overflow: hidden;
}
.processing-get-tracking-code-metter .meter > span:after {
    content: "";
    position: absolute;
    top: 0; left: 0; bottom: 0; right: 0;
    background-image:
    -webkit-gradient(linear, 0 0, 100% 100%,
        color-stop(.25, rgba(255, 255, 255, .2)),
        color-stop(.25, transparent), color-stop(.5, transparent),
        color-stop(.5, rgba(255, 255, 255, .2)),
        color-stop(.75, rgba(255, 255, 255, .2)),
        color-stop(.75, transparent), to(transparent)
    );
    /* background-image:
        -moz-linear-gradient(
        -45deg,
        rgba(255, 255, 255, .2) 25%,
        transparent 25%,
        transparent 50%,
        rgba(255, 255, 255, .2) 50%,
        rgba(255, 255, 255, .2) 75%,
        transparent 75%,
        transparent
    ); */
    z-index: 1;
    -webkit-background-size: 10px 10px;
    -moz-background-size: 10px 10px;
    -webkit-animation: move 1.5s linear infinite;
    -webkit-border-top-right-radius: 8px;
    -webkit-border-bottom-right-radius: 8px;
        -moz-border-radius-topright: 8px;
        -moz-border-radius-bottomright: 8px;
            border-top-right-radius: 8px;
            border-bottom-right-radius: 8px;
        -webkit-border-top-left-radius: 20px;
    -webkit-border-bottom-left-radius: 20px;
            -moz-border-radius-topleft: 20px;
        -moz-border-radius-bottomleft: 20px;
                border-top-left-radius: 20px;
            border-bottom-left-radius: 20px;
    overflow: hidden;
}
</style>
