<template>
    <div class="toast-process-wrap process-percent active" v-if="process_obj.length > 0">
        <h4 @click="toggentProcess()" v-bind:class="is_show_process?'':'active'">
            <span class="icon-success-toast" v-if="is_done">
                <i class="mdi mdi mdi-check"></i>
            </span>

            <span class="icon-load-toast" v-else>
                <i class="mdi mdi-autorenew"></i>
            </span>


            <span v-text="is_done?process_successful:process_title"></span>


            <span class="icon-dropdown-toast">
                <i v-bind:class="is_show_process?'mdi mdi-chevron-down':'mdi mdi-chevron-up'"></i>
            </span>

            <span v-if="is_done" class="close-override-product" @click="closeProcess()">
                <i class="mdi mdi-close"></i>
            </span>

            <!--<span>{{ process_title }}</span>
            <span class="close-override-product">
                <i v-if="is_done" class="mdi mdi-close"  @click="closeProcess()"></i>
                <i v-else class="mdi " @click="toggentProcess()" v-bind:class="is_show_process ? 'mdi-chevron-up' : 'mdi-chevron-down'"></i>
            </span>-->
        </h4>
        <ul v-show="is_show_process">
            <li v-for="process in process_obj">
                <!--<h5 class="bold" v-text="is_done?process_type[process.type].title:process_type[process.type].success"></h5>
                <div class="processing-get-tracking-code-metter">
                    <div class="meter get-tracking-meter">
                        <span :style="{'width' : process.percent+'%'}"></span>
                    </div>
                </div>-->
                <p>
                    <span v-text="process.percent==100?process_type[process.type].success+':':process_type[process.type].title+':'"></span>
                    <span class="bold fw-600"> {{ process.percent }}%</span>
                </p>
                <span data-toggle="tooltip" data-placement="top" title="Processing" v-bind:class="process.percent==100?'success':'animate-spin'">
                    <i class="mdi" v-bind:class="process.percent==100?'mdi mdi-check':'mdi mdi-autorenew'"></i>
                </span>
            </li>
        </ul>
        <!--<ul class="" v-show="is_show_process">
            <li v-for="process in process_obj">
                <div class="title-toast-process-wrap" v-bind:class="process.percent==100?'toast-process-successfull':''">
                    <span class="mdi mdi-autorenew"></span>
                    <span class="mdi mdi-check-circle"></span>
                </div>
                <div class="content-toast-process-wrap" v-bind:class="process.percent==100?'toast-process-successfull':''">
                    <h5 class="bold">{{ process_type[process.type].title }}</h5>
                    <h5 class="bold show-successfull">{{ process_type[process.type].success }}</h5>
                    <div class="processing-get-tracking-code-metter">
                        <div class="meter get-tracking-meter">
                            <span :style="{'width' : process.percent+'%'}"></span>
                        </div>
                    </div>
                    <div class="percent-toast" v-if="process.percent != '100'">Processed: <span class="bold">{{ process.percent }}%</span></div>
                    <div class="percent-toast-finish" v-else style="text-align: center; margin-top: 15px;"><button class="button-style-dark-sm" @click="closeProcess">Finish</button></div>
                </div>
            </li>
        </ul>-->
    </div>
</template>
<script>
    export default {
        props: {
            process_percent: {
                required: true,
                default: []
            },
            process_title : {
                required: false,
                default: 'Process'
            },
            process_successful:{
                required: false,
                default: 'Successfully'
            }
        },
        data() {
            return {
                process_obj: [],
                process_active: true,
                process_type: {
                    tracking_code: {
                        title: 'Getting Tracking Code',
                        success: 'Get Tracking Code Successfully'
                    },
                    ali_order_number: {
                        title: ' Sync Ali Order Number Processing',
                        success: 'Sync Ali Order Numbers successfully'
                    }
                },
                is_show_process: true,
                is_done: false
            }
        },
        methods: {
            toggentProcess: function () {
                this.is_show_process = ! this.is_show_process
            },
            closeProcess: function() {
                this.$emit('close_process')
                // this.process_obj = [];
            }
        },
        watch: {
            process_percent: {
                handler: function (process) {
                    this.process_obj = process
                    for (var val of process){
                        if(val.percent < 100) {
                            this.is_done =  false
                            break
                        } else {
                            this.is_done = true
                        }
                    }
                },
                deep: true
            }
        }
    }
</script>

<style>
    .bold {
        font-weight: bold;
    }
</style>
