<template>
    <ul class="pagination">
        <li v-if="obj_pagination.current_page <= 1" class="disabled">
            <a><i class="mdi mdi-chevron-left"></i></a>
        </li>
        <li v-else @click.prevent="changePage(obj_pagination.current_page - 1)">
            <a><i class="mdi mdi-chevron-left"></i></a>
        </li>
        <li v-for="page in pages" class="page-item"  @click.prevent="changePage(page)" :class="isCurrentPage(page) ? 'active' : ''">
            <a>{{ page }}</a>
        </li>
        <li v-if="obj_pagination.current_page >= obj_pagination.last_page" class="disabled">
            <a><i class="mdi mdi-chevron-right"></i></a>
        </li>
        <li v-else @click.prevent="changePage(obj_pagination.current_page + 1)">
            <a><i class="mdi mdi-chevron-right"></i></a>
        </li>
    </ul>
</template>
<script type="text/javascript">
    export default {
        props: ['pagination', 'offset'],
        data: function() {
            return {
                obj_pagination: Object.assign({}, this.pagination)
            }
        },
        methods: {
            isCurrentPage(page) {
                return this.obj_pagination.current_page === page;
            },
            changePage(paged) {
                if (paged > this.obj_pagination.last_page) {
                    paged = this.obj_pagination.last_page;
                }
                this.obj_pagination.current_page = paged;
                this.$emit('paginate', paged);
            }
        },
        computed: {
            pages() {
                let pages = [];
                let from = this.obj_pagination.current_page - Math.floor(this.offset / 2);
                if (from < 1) {
                    from = 1;
                }
                let to = from + this.offset - 1;
                if (to > this.obj_pagination.last_page) {
                    to = this.obj_pagination.last_page;
                }
                while (from <= to) {
                    pages.push(from);
                    from++;
                }
                return pages;
            }
        },
        watch: {
            pagination : {
                handler(pagination){
                    this.obj_pagination = Object.assign({}, pagination)
                },
                deep: true
            }
        }
    }
</script>

<style>
    .pagination{

    }
    .pagination li{
        cursor: pointer;
    }
</style>
