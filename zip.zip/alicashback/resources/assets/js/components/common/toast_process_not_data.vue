<template>
    <div class="toast-process-wrap" v-bind:class="process_active ? 'active' : ''" v-if="totalProcess > 0">
        <h4 @click="toggleProcess" v-bind:class="process_active?'':'active'">
            <span class="icon-load-toast" v-if="allProcessIsDone != 0">
                <i class="mdi mdi-autorenew"></i>
            </span>
            <span class="icon-success-toast" v-if="allProcessIsSuccess == 0">
                <i class="mdi mdi mdi-check"></i>
            </span>

            <span v-text="allProcessIsDone==0?process_successful:process_title"></span>

            <span class="icon-dropdown-toast">
                <i v-bind:class="process_active?'mdi mdi-chevron-down':'mdi mdi-chevron-up'"></i>
            </span>
            <!--<span v-if="allProcessIsDone == 0" class="close-override-product" @click="closeProcess">-->
                <!--<i class="mdi mdi-close"></i>-->
            <!--</span>-->
        </h4>
        <!-- <transition name="fade"> -->
        <ul>
            <template v-for="process in processFilter" v-if="process_active">

                <li v-if="item.status" v-bind:class="item.status === 'success' ? 'toast-process-import-product' : ''" v-for="item in process.data">
                    <p>
                        <a v-if="item.product_link" v-bind:href="item.product_link" target="_blank" class="product-link">
                            {{ processText(process.type, item) }}
                        </a>
                        <span v-else>
                                {{ processText(process.type, item) }}
                            </span>
                        <a  v-bind:href="item.product_link ? item.product_link : ''" v-if="item.status === 'success' && process.type === 'import_product'" class="toast-edit-on-shopify" target="_blank" style="padding-left:5px;">Edit on <i></i></a>
                    </p>
                    <span data-toggle="tooltip" v-bind:data-type="item.tooltip_message ? 'tooltip_toast' : false" data-placement="left" v-bind:data-original-title="item.tooltip_message" v-bind:class="css_for_type[item.status].icon.span">
                            <i class="mdi" v-bind:class="css_for_type[item.status].icon.i"></i>
                        </span>
                </li>
            </template>
        </ul>
        <!-- </transition> -->
    </div>
</template>
<script>
    export default {
        props: {
            process: {
                required: true,
                default: []
            },
            process_type: {
                required: true,
                default: []
            },
            process_title: {
                required: false,
                default: 'Processing'
            },
            process_successful:{
                required: false,
                default: 'Successfully'
            }
        },
        data() {
            return {
                process_active: true,
                status: {
                    override_product: {
                        type: 'override_product',
                        status: {
                            pending: '{var}',
                            error: '{var}',
                            success: '{var}'
                        }
                    },
                    import_product: {
                        type: 'import_product',
                        status: {
                            pending: '{var}',
                            error: '{var}',
                            success: '{var}'
                        }
                    },
                    tracking_code_from_file: {
                        type: 'tracking_code_from_file',
                        status: {
                            pending: '{var}',
                            error: '{var}',
                            success: '{var}'
                        }
                    },
                    add_variant_product:{
                        type: 'add_variant_product',
                        status: {
                            pending: '{var}',
                            error: '{var}',
                            success: '{var}'
                        }
                    },
                    add_rule_product:{
                        type: 'add_rule_product',
                        status: {
                            pending: '{var}',
                            error: '{var}',
                            success: '{var}'
                        }
                    }
                },
                css_for_type: {
                    success: {
                        'icon': {
                            span: 'success',
                            i: 'mdi-check'
                        }
                    },
                    error: {
                        'icon': {
                            span: 'warning',
                            i: 'mdi-alert-circle-outline'
                        }
                    },
                    pending: {
                        'icon': {
                            span: 'animate-spin',
                            i: 'mdi-autorenew'
                        }
                    }
                } // config css for type
            }
        },
        mounted: function () {
            $(".meter > span").each(function() {
                $(this)
                    .data("origWidth", $(this).width())
                    .width(0)
                    .animate({
                        width: $(this).data("origWidth")
                    }, 10000);
            });

        },
        computed: {
            processFilter() {
                $('[data-type="tooltip_toast"]').tooltip({
                    html: true,
                    container: 'body'
                });
                return this.process.filter((item)=>this.process_type.indexOf(item.type) > -1);
            },

            allProcessIsDone() {
                return this.process
                    .filter((item) => this.process_type.indexOf(item.type) > -1)
                    .reduce((total, item) =>
                        total + item.data.filter(process => process.status == 'pending').length
                        , 0);
            },
            allProcessIsSuccess() {
                return this.process
                    .filter((item) => this.process_type.indexOf(item.type) > -1)
                    .reduce((total, item) =>
                        total + item.data.filter(process => process.status != 'success').length
                        , 0);
            },
            totalProcess() {
                let _this = this
                return this.process
                    .filter(function(item) {
                        if(typeof item.data) item.data = Object.values(item.data)
                        return _this.process_type.indexOf(item.type) > -1
                    } )
                    .reduce((total, item) => total + item.data.length, 0);
            }
        },
        methods: {

            toggleProcess: function() {
                this.process_active = ! this.process_active
            },
            closeProcess: function() {
                let products = this.process
                    .filter((item) => this.process_type.indexOf(item.type) > -1)
                    .map((item) => ({type: item.type, data: []}))
                this.process = this.process.map((item) => {
                    if(this.process_type.indexOf(item.type) > -1) {
                        return {type: item.type, data: []}
                    }
                    return item;
                });
                this.process_active = true
                this.$emit('close_process', this.process)
                axios.post(appUrl+'/toast_process', {type: this.process_type, products: products})
            },
            processText(type, process) {
                process.status = process.status ? process.status : 'pending'
                return this.status[type]['status'][process.status].replace('{var}', process.title); // replace {var} in template
            }
        },
    }
</script>
<style lang="css" scope>
    .tooltip {
        z-index: 10000;

    }

    .processing-get-tracking-code-metter {
        margin: 15px 0 20px;
        text-align: center;
        font-size: 13px;
        font-weight: 500;
        color: #242539;
        line-height: 20px;
    }
    .processing-get-tracking-code-metter .meter {
        height: 6px;  /* Can be anything */
        position: relative;
        margin: 10px 0 0; /* Just for demo spacing */
        background: #F0F2F8;
        -moz-border-radius: 30px;
        -webkit-border-radius: 30px;
        border-radius: 30px;
        -webkit-box-shadow: inset 0 -1px 1px rgba(255,255,255,0.3);
        -moz-box-shadow   : inset 0 -1px 1px rgba(255,255,255,0.3);
        box-shadow        : inset 0 -1px 1px rgba(255,255,255,0.3);
    }
    .processing-get-tracking-code-metter .meter > span {
        display: block;
        height: 100%;
        width: 0;
        border-radius: 30px;
        background-color: #7009FF;
        background-image: linear-gradient( linear, left bottom, left top, color-stop(0, #242538), color-stop(1, #242538) );
        /* background-image: -moz-linear-gradient(center bottom, #242538 37%, #242538 69%); */

        -webkit-box-shadow:
                inset 0 2px 9px  rgba(255,255,255,0.3),
                inset 0 -2px 6px rgba(0,0,0,0.4);
        -moz-box-shadow:
                inset 0 2px 9px  rgba(255,255,255,0.3),
                inset 0 -2px 6px rgba(0,0,0,0.4);
        box-shadow:
                inset 0 2px 9px  rgba(255,255,255,0.3),
                inset 0 -2px 6px rgba(0,0,0,0.4);
        position: relative;
        overflow: hidden;
    }
    .processing-get-tracking-code-metter .meter > span:after {
        content: "";
        position: absolute;
        top: 0; left: 0; bottom: 0; right: 0;
        visibility: hidden;
        background-image:
                -webkit-gradient(linear, 0 0, 100% 100%,
                color-stop(.25, rgba(255, 255, 255, .2)),
                color-stop(.25, transparent), color-stop(.5, transparent),
                color-stop(.5, rgba(255, 255, 255, .2)),
                color-stop(.75, rgba(255, 255, 255, .2)),
                color-stop(.75, transparent), to(transparent)
                );
        /* background-image:
            -moz-linear-gradient(
            -45deg,
            rgba(255, 255, 255, .2) 25%,
            transparent 25%,
            transparent 50%,
            rgba(255, 255, 255, .2) 50%,
            rgba(255, 255, 255, .2) 75%,
            transparent 75%,
            transparent
        ); */
        z-index: 1;
        -webkit-background-size: 10px 10px;
        -moz-background-size: 10px 10px;
        -webkit-animation: move 1.5s linear infinite;
        -webkit-border-top-right-radius: 8px;
        -webkit-border-bottom-right-radius: 8px;
        -moz-border-radius-topright: 8px;
        -moz-border-radius-bottomright: 8px;
        border-top-right-radius: 8px;
        border-bottom-right-radius: 8px;
        -webkit-border-top-left-radius: 20px;
        -webkit-border-bottom-left-radius: 20px;
        -moz-border-radius-topleft: 20px;
        -moz-border-radius-bottomleft: 20px;
        border-top-left-radius: 20px;
        border-bottom-left-radius: 20px;
        overflow: hidden;
    }

    /*.toast-process-wrap ul li.toast-process-import-product p {
        padding-right: 0px;
    }*/
</style>
