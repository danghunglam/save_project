<template>
    <div class="product__images_modal">
        <div class="modal-dialog modal-lg product__images_modal_overlay">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Variant Image</h4>
                    <button type="button" class="close" @click="closeModal"><i class="mdi mdi-close"></i></button>
                </div>
                <div class="modal-body">
                    <div class="item__image-wrap">
                        <ul>
                            <li v-for="(image, index) in product_images" @click="addProductImage(image)" :key="index">
                                <img v-bind:src="image.src" />
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props: {
            props_product_images: {
                required: true
            }
        },
        data() {
            return {
                product_images: this.props_product_images,
            }
        },
        mounted: function() {
            
        },
        methods: {
            addProductImage: function(obj_image) {
                this.$emit('add-variant-image', obj_image)
            },
            closeModal: function() {
                this.$emit('close-modal-images', { status: false })
            }
        },
        watch: {
            props_product_images: {
                handler: function(val, oldVal) {
                    this.product_images = Object.assign({}, val)
                },
                deep: true
            }
        }
    }
</script>