<template>
    <div id="addVariantProductModal" class="modal fade" role="dialog">
        <!-- Modal Add Variant Product -->
        <div class="modal-dialog" v-bind:class="(page === 'add_variant') ? 'modal-lg-1170' : (page === 'add_link') ? 'max-width-517' : 'modal-sm'">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" data-dismiss="modal" class="close"><i class="mdi mdi-close"></i></button>
                    <h4 class="modal-title">Add variant</h4>
                </div>
                <div class="modal-body">
                    <div class="product-add-aliexpress-modal-wrap" v-if="page === 'add_link'">
                        <div class="override__product-wrap">
                            <div class="override__product-box">
                                <h2>Current Product</h2>
                                <div class="override__product-info">
                                    <div class="override__product-img">
                                        <img v-bind:src="current_product.product_image" width="100px" v-bind:alt="current_product.title">
                                    </div>
                                    <div class="override__product-title">
                                        <h2>
                                            <a class="alink" v-bind:href="current_product.source_product_link" target="_blank" v-text="current_product.title"></a>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                            <div class="override__product_optional" v-show="Object.values(add_variant_product).length === 0">
                                <div class="form-group m-b-0">
                                    <label class="form__group-title">Add variant</label>
                                    <input type="text" @keyup.enter="linkAliexpress"  v-model="add_variant_link" placeholder="Enter Aliexpress link of product here">
                                    <label class="error" v-text="validate_message.aliexpress_link"></label>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div v-else-if="page === 'add_variant'">
                        <!--Start override product-->
                        <add_variant_form v-bind:add_variant_product="add_variant_product"
                                       v-bind:current_product="current_product"
                                       v-on:show-modal-images="showModalImages"
                                       v-on:finish-addvariant="finishAddVariant"></add_variant_form>
                        <!--End form override-->
                    </div>

                    <div class="vue__loaders_wrapper" v-show="loading_page">
                        <vue_loaders_circle></vue_loaders_circle>
                    </div>
                </div>
            </div>
        </div>
        <modal_item_image v-bind:props_product_images="add_variant_product.images" v-show="add_variant_product.modal_images" v-on:close-modal-images="closeModalImages" v-on:add-variant-image="addVariantImage"></modal_item_image>
    </div>
</template>


<script type="text/javascript">
    import 'vue-loaders/dist/vue-loaders.css';
    import lodash from 'lodash'
    import vue_loaders_circle from '../../../components/common/vue_loaders_circle';
    Object.defineProperty(Vue.prototype, '$lodash', { value: lodash });
    import modal_item_image from '../../../components/common/modal_item_image'
    import add_variant_form from './add_variant_form'
    export  default {
        name: 'add_variant_product',
        props: {
            current_product: {},
            page: {
                required: false,
                default: 'add_link'
            },
            add_variant_product:{},
            settings: {},
        },

        data: function () {
            return {
                validate_message: {
                    aliexpress_link: ''
                },
                add_variant_link: '',
                settings: {},
                add_variant_option: {
                    title: false,
                    image: false,
                },
                page: this.page,
                loading_page: false,
                add_variant_product:this.add_variant_product,
                is_format:false
            }
        },
        mounted: function () {
            let _this = this
            window.addVariantProductExtension = function (args) {
                _this.is_format = false
                _this.filterAddVariantProduct(args)
            }

            $('#addVariantProductModal').on('hidden.bs.modal', function () {
                _this.removeAddVariantData();
                Vue.nextTick(function () {
                    _this.validate_message.aliexpress_link = '';
                })
            })
            $(document).on('click','.dropdown-option-variant .dropdown-menu, .dropdown-option-variant .dropdown-menu li',function () {
                $(this).parents('.dropdown-option-variant').addClass('open');
            })
            $(document.body).on('click', function(event) {
                if (!$(event.target).closest('.change-price').length) {
                    _this.showChangePrice = false;
                    _this.showChangeComparePrice = false;
                }
            });
        },
        components: {
            modal_item_image,
            vue_loaders_circle,
            add_variant_form
        },
        methods: {
            linkAliexpress: function () {
                let _this = this
                _this.loading_page = true
                if( ! aliexpressValidateUrl(this.add_variant_link))
                {
                    _this.loading_page = false
                    this.validate_message = Object.assign({}, this.validate_message, {aliexpress_link : 'Please enter a valid url address'})
                    return false
                }
                this.add_variant_link = this.formatURL(this.add_variant_link)

                _this.validate_message = {}

                    window.postMessage({action: 'ACTION_ADD_VARIANT_PRODUCT', payload: {aliLink: this.add_variant_link}}, '*')
            },
            //
            formatURL:function(link){
                this.is_format = true
                let id=0;
                let url = new window.URL(link);
                url.search = '?';
                let beforeString = url.href;

                let array_url = beforeString.split("/")

                array_url.forEach(function (e) {

                    if(e.search('.html') != -1){
                        e = e.replace('.html','')
                        if(e.search('_') == -1){
                            id = e

                        }else{
                            e = e.split("_")
                            id = e[1]
                        }
                    }
                })

                return 'https://www.aliexpress.com/item/-/'+id+'.html'
            },
            filterAddVariantProduct: function (add_variant_product) {
                let _this = this
                let count = 0
                const {images, product, supplier, variants, mainBigPic} = add_variant_product

                if(variants){

                    if(typeof _this.current_product.options === 'string')
                        _this.current_product.options = _this.current_product.options ? JSON.parse(_this.current_product.options): []

                    let options_variant_current_product = _this.current_product.options ? _this.current_product.options.length : 0

                    let options_variant_new_product = Object.keys(variants[0].options).length

                    if(_this.current_product.product_variant.length ==1 && variants.length==1 && _this.current_product.product_variant.length==variants.length){
                        options_variant_current_product = 0
                        options_variant_new_product = 0
                    }

                    if((options_variant_current_product != options_variant_new_product)){
                        _this.loading_page = false
                        _this.validate_message.aliexpress_link = 'Product use to add variant must have same options with current product'
                    }else{

                        let tmp_images = []

                        let tmp_variants = variants.map(function (variant) {
                            let tmp = {
                                selected: false
                            }
                            tmp['source_product_link'] = _this.add_variant_link
                            tmp['aliexpress_product_id'] = getAliexressProductId(_this.add_variant_link)

                            let total_variant_select = 100 - _this.current_product.product_variant.length

                            if(variant.source_quantity > 0 && count < total_variant_select)
                            {
                                count = count + 1
                                tmp.selected = true
                                tmp_images.push({
                                    aliexpress_options: variant.aliexpress_options,
                                    src: variant.image,
                                    status: true
                                })
                            }

                            let price = setPrice(variant.source_price, _this.settings.price_rule, _this.settings.rest_of_the_price_ranges, _this.settings.is_compared_price)

                            return Object.assign({}, variant, tmp, price)

                        })

                        images.forEach(function (image) {
                            tmp_images.push(image)
                        })

                        _this.add_variant_product = Object.assign({},
                            {images: tmp_images},
                            product,
                            {supplier:supplier},
                            {variants: tmp_variants},
                            {mainBigPic: mainBigPic} )

                        _this.add_variant_product.price_range = {minPrice: _this.add_variant_product.minPrice , maxPrice: _this.add_variant_product.maxPrice }

                        _this.add_variant_product.freights=[]
                        _this.loading_page = false

                        _this.page = 'add_variant'

                    }
                }

            },
            finishAddVariant:function(){

                let _this = this

                _this.loading_page = true

                _this.add_variant_product.variants = _this.add_variant_product.variants.filter(function (variant) {
                    if(variant.selected)
                        return variant
                })

                if(! _this.add_variant_product.variants ) return false

                axios.post(appUrl+'/products/add_variant',{add_variant_product:_this.add_variant_product,current_product:this.current_product})
                    .then(function (repo) {
                        if(repo.data.status)
                            _this.loading_page = false
                            _this.$emit('add_variant_process', _this.current_product)
                    })
            },

            removeAddVariantData: function () {
                this.page = 'add_link'
                this.add_variant_product = {}
                this.add_variant_link = ''
            },
            showModalImages: function(obj_variant) {

                let _this = this
                this.$nextTick(function() {
                    _this.add_variant_product = Object.assign({}, _this.add_variant_product, {
                        modal_images: true,
                        variant_image: obj_variant
                    })
                })
            },
            closeModalImages: function(obj_modal_images) {
                let _this = this
                this.$nextTick(function() {
                    _this.add_variant_product = Object.assign({}, _this.add_variant_product, {
                        modal_images: obj_modal_images.status
                    })
                })
            },
            addVariantImage: function(obj_image) {
                let _this = this
                this.$nextTick(function() {
                    _this.add_variant_product.variants = _this.add_variant_product.variants.map(function(variant) {
                        if(variant.index === _this.add_variant_product.variant_image.index) {
                            variant = Object.assign({}, variant, {
                                image_status: true,
                                image_id: obj_image.index,
                                image: obj_image.src
                            })
                        }
                        return variant
                    })

                    _this.add_variant_product.images = _this.add_variant_product.images.map(function(product_image) {
                        if(product_image.index === obj_image.index) {
                            product_image = Object.assign({}, product_image, {
                                status: true
                            })
                        }
                        return product_image
                    })
                    _this.add_variant_product = Object.assign({}, _this.add_variant_product, {
                        modal_images: false
                    })
                })
            }
        },
        watch: {
            add_variant_link: function (value) {
                if(!this.is_format)
                    this.linkAliexpress();
            },
            numVariantSelected:function(value){
                if(value == this.product.variants.length) this.selectAll = true
                else this.selectAll = false

            }

        }
    };
</script>
