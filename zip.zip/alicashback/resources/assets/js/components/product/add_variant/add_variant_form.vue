<template>
    <div class="override__from_wrap">
        <div class="override__from_note">
            <p class="override__note_warning" v-text=" count_variant_select > 1 ? count_variant_select +' variants will be update for current product' : count_variant_select +' variant will be update for current product'"></p>
            <div class="override__note_button">
                <button class="button-style-sm" type="button" @click="finishAdd">Add variant</button>
            </div>
        </div>
        <div id="variants" class="tab-variants m-t-30 tab-pane fade in active">
            <div class="tab-variants-wrap">
                <div class="ars-table">
                    <div class="ars-table-head">
                        <div class="ars-table-col col-variant-select">
                            <label class="checkbox-style checkbox-style-modal checkbox-text-o" for="select-variant-all" title="You can selected a maximum of 100 variants">
                                <input id="select-variant-all" @click="selectAllVariants" value="1" type="checkbox">
                                <span class="checked-style"></span>
                            </label>
                        </div>
                        <div class="ars-table-col col-variant-product">Product</div>
                        <!--<div class="ars-table-col col-variant-color" v-for="(label, key) in current_options" v-bind:key="key" v-text="label"></div>-->
                        <div class="ars-table-col col-variant-color" v-for="(option, label, key) in optionFilter" :key=key>
                            <div class="dropdown box-dropdown dropdown-option-variant">
                                <div class="parent-dropdown" data-toggle="dropdown">{{label}}<i class="mdi mdi-menu-down"></i> </div>
                                <div class="dropdown-menu box-dropdown-menu">
                                    <ul>
                                        <li v-for="(select, value, optionKey) in option" :key="optionKey">
                                            <label class="checkbox-style">
                                                <input :id="value.split(' ').join('_')" type="checkbox" v-model="option[value]['selected']" v-on:change="selectOptionFilter(select, value, optionKey, label)">
                                                <span class="checked-style"></span>
                                                {{ value }}
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-cost">Cost</div>
                        <div class="ars-table-col col-variant-shipping">Shipping</div>
                        <div class="ars-table-col col-variant-price">
                            Price
                            <span class="tooltip-style-wrap color-skin" data-toggle="tooltip" title="The Price value is calculated based on Cost value">
                                    <i class="mdi mdi-alert-circle"></i>
                                </span>
                        </div>
                        <div class="ars-table-col col-variant-profit">Profit</div>
                        <div class="ars-table-col col-variant-compared-at-price">
                            Compare At Price
                            <span class="tooltip-style-wrap color-skin" data-toggle="tooltip" title="The Compare At Price value is calculated based on Cost value">
                                    <i class="mdi mdi-alert-circle"></i>
                                </span>
                        </div>
                        <div class="ars-table-col col-variant-inventory">Inventory</div>
                    </div>
                    <div class="num-variant-selected">
                        <div class="count-select-variant">
                            <span>{{count_variant_select}}</span> of <span v-text="totalVariant"></span> Variants
                        </div>
                        <div v-if="count_variant_select > 1" class="change-price">
                            <div class="dropdown box-dropdown">
                                <span class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Action
                                </span>
                                <div class="dropdown-menu box-dropdown-menu">
                                    <ul>
                                        <li @click="showInputChangePrice"><a href="javascript:void(0)">Change Price</a></li>
                                        <li @click="showInputChangeComparePrice"><a href="javascript:void(0)">Change Compare Price</a></li>
                                    </ul>
                                </div>
                                <div class="box box-variant-price" style="z-index: 99;" v-show="showChangePrice">
                                    <div>
                                        <input type="text" class="form-control" placeholder="New value price" @keyup.enter="saveChangePrice" @keyup="isNumberKeyup($event, 'priceVariantSelect')" @keypress="isNumber($event)" v-model="priceVariantSelect">
                                    </div>
                                    <div>
                                        <button class="btn btn-warning" @click.prevent="saveChangePrice">Apply</button>
                                    </div>
                                </div>
                                <div class="box box-variant-price" style="z-index: 99;" v-show="showChangeComparePrice">
                                    <div>
                                        <input type="text" class="form-control" placeholder="New value compared price" @keyup.enter="saveChangeComparePrice" @keyup="isNumberKeyup($event, 'comparePriceVariantSelect')" @keypress="isNumber($event)" v-model="comparePriceVariantSelect">
                                    </div>
                                    <div>
                                        <button class="btn btn-warning" @click.prevent="saveChangeComparePrice">Apply</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ars-table-row ars-table-row-change-price">
                        <div class="ars-table-col col-variant-select"></div>
                        <div class="ars-table-col col-variant-product"></div>
                        <div class="ars-table-col col-variant-color" v-for="(label, key) in current_options"></div>
                        <div class="ars-table-col col-variant-cost"></div>
                        <div class="ars-table-col col-variant-shipping">
                            <div class="shipping-country" v-if="current_product.source_product_link">
                                <a v-text="freight.shipTo == null ? 'Shipping to' : freight.shipTo " href="javascript:;" @click="showModalShipingCountry(current_product)"></a>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-price">
                            <label class="change-price fw-400">
                                <div class="dropdown box-dropdown">
                                        <span class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Change All
                                        </span>
                                    <div class="dropdown-menu box-dropdown-menu">
                                        <ul>
                                            <li @click.prevent="changeItemPrice('new_value')"><a href="#">Set New Value</a></li>
                                            <li @click.prevent="changeItemPrice('multiply_by')"><a href="#">Multiply by</a></li>
                                            <li @click.prevent="changeItemPrice('plus')"><a href="#">Plus by</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="box box-variant-price" style="z-index: 99;" v-show="itemPrice.showBox">
                                    <div>
                                        <input type="text" class="form-control" @keyup="isNumberKeyup($event, 'itemPrice')" @keypress="isNumber($event)" v-model="itemPrice.value" v-bind:placeholder="itemPrice.placeHolder">
                                    </div>
                                    <div>
                                        <button class="btn btn-warning" @click.prevent="saveItemPrice">Apply</button>
                                    </div>
                                </div>
                            </label>
                        </div>
                        <div class="ars-table-col col-variant-profit"></div>
                        <div class="ars-table-col col-variant-compared-at-price">
                            <div class="change-price">
                                <div class="dropdown box-dropdown">
                                        <span class="box-dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Change All
                                        </span>
                                    <div class="dropdown-menu box-dropdown-menu">
                                        <ul>
                                            <li @click.prevent="changeComparedPrice('new_value')"><a href="#">Set New Value</a></li>
                                            <li @click.prevent="changeComparedPrice('multiply_by')"><a href="#">Multiply by</a></li>
                                            <li><a href="#">Plus by</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="box box-variant-price" style="z-index: 99" v-show="comparedPrice.showBox">
                                    <div>
                                        <input type="text" class="form-control" @keyup="isNumberKeyup($event, 'comparedPrice')" @keypress="isNumber($event)" v-model="comparedPrice.value" v-bind:placeholder="comparedPrice.placeHolder">
                                    </div>
                                    <div>
                                        <button class="btn btn-warning" @click.prevent="saveComparedPrice">Apply</button>
                                    </div>
                                    <div class="glyphicon">
                                        <span class="glyphicon glyphicon-remove" @click.prevent="closeComparedPrice"></span>
                                    </div>
                                    <div class="arrow-down"></div>
                                </div>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-inventory"></div>
                    </div>

                    <div v-for="(variant, index) in add_variant_product.variants" v-bind:key="index" class="ars-table-row ars-table-row-item">
                        <div class="ars-table-col col-variant-select">
                            <label v-bind:for="'select-variant-'+variant.aliexpress_options" class="checkbox-style checkbox-style-modal checkbox-text-o">
                                <input v-bind:id="'select-variant-'+variant.aliexpress_options" v-model="variant.selected" @click="selectVariant(variant)" type="checkbox">
                                <span class="checked-style"></span>
                            </label>
                        </div>
                        <div class="ars-table-col col-variant-product">
                            <div class="box-variant-content">
                                <img v-bind:src="variant.image" alt="">
                                <span v-if="! variant.selected"></span>
                                <div v-if="variant.selected" class="select-variant-image" @click="showModalImage(variant)"><i class="mdi mdi-plus"></i></div>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-color" v-for="(option, label, key) in variant.options" v-bind:key="key">
                            <div class="box-variant-content">
                                <input type="text" v-bind:value="option" v-on:change="changeVariantOptions(index, label, $event.target.value)">
                                <span v-if=" ! variant.selected"></span>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-cost">
                            <div class="box-variant-content">
                                <input type="text" readonly disabled v-bind:value="'$'+variant.source_price">
                                <span v-if="!variant.selected"></span>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-shipping">
                            <div class="box-variant-content">
                                <input type="text" readonly disabled v-bind:value="'$'+freight.price">
                                <span v-if="!variant.selected"></span>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-price">
                            <div class="box-variant-content">
                                <div class="input-group">
                                    <input type="text" @keyup="isNumberKeyupVariant($event, index, 'item_price')" @keypress="isNumber($event)" @input="changePrice" @change="setNull" v-model="variant.item_price">
                                    <span class="input-group-addon" v-text="currency ? currency : 'USD'"></span>
                                </div>
                                <span v-if="!variant.selected"></span>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-profit">
                            <div class="box-variant-content">
                                <input type="text" v-bind:style=" variant.profit < 0 ? 'color: red;' : ''" readonly disabled v-bind:value="'$'+variant.profit">
                                <span v-if="!variant.selected"></span>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-compared-at-price">
                            <div class="box-variant-content">
                                <div class="input-group">
                                    <input type="text" @keyup="isNumberKeyupVariant($event, index, 'compare_at_price')" @keypress="isNumber($event)" v-model="variant.compare_at_price= variant.compare_at_price==0?null:variant.compare_at_price">
                                    <span class="input-group-addon" v-text="currency ? currency : 'USD'"></span>
                                </div>
                                <span v-if="!variant.selected"></span>
                            </div>
                        </div>
                        <div class="ars-table-col col-variant-inventory">
                            <div class="box-variant-content">
                                <input type="text" disabled v-bind:value="variant.source_quantity">
                                <span v-if="!variant.selected"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <modal_shipping_country ref="modal_shipping_country" v-on:freight="infoShipping" v-bind:props_product="add_variant_product"></modal_shipping_country>
    </div>
</template>

<script type="text/javascript">
    import lodash from 'lodash'
    Object.defineProperty(Vue.prototype, '$lodash', { value: lodash })
    import modal_shipping_country from '../../import/modal-shipping-country'

    export default {
        props: ['add_variant_product', 'current_product'],
        data: function () {
            return {
                itemPrice: {
                    showBox: false,
                    placeHolder: null,
                    type: null,
                    value: null
                },
                comparedPrice: {
                    showBox: false,
                    placeHolder: null,
                    type: null,
                    value: null
                },
                appUrl: window.appUrl,
                freight_product_id: '',
                freight:{price:0},
                currency: window.currency,
                exchange: window.exchange ? window.exchange : 1,
                image_selected: 0,
                current_options:{},
                count_variant_select:0,
                variants:[],
                optionFilter:{},
                isAnd:true,
                totalVariant: 0,
                showChangePrice: false,
                showChangeComparePrice: false,
                countOptionFilter:{},
                selectAll:true,
                priceVariantSelect: null,
                comparePriceVariantSelect: null
            }
        },
        created:function(){
            console.log('current product', this.current_product)
            this.getAllOptionVariant(this.add_variant_product.variants);
        },
        watch: {
            add_variant_product: {
                handler: function(product) {

                    this.lengthVariantChecked(product.variants)

                    if(product.variants.length > 0 && typeof product.variants[0].profit == 'undefined') {
                        this.profit_calculate()
                    } else {
                        this.add_variant_product = product
                    }
                },
                deep: true
            }
        },
        mounted: function () {
            let _this = this


            _this.current_options = _this.current_product.options.map(function (option) {
                return option.name
            })

            this.add_variant_product.images = this.add_variant_product.images.map(function (item, index) {
                item.index = index
                item.variant_id = null
                return item
            })

            this.add_variant_product.variants = this.add_variant_product.variants.map(function(variant, variantIndex) {
                variant.index = variantIndex
                variant.image_id = null
                _.forEach(_this.add_variant_product.images, function(image, index) {
                    if(variant.image == image.src && image.variant_id == null) {
                        _this.add_variant_product.images[index].variant_id = variantIndex
                        variant.image_id = index
                        return false
                    }
                })
                variant.item_price = (variant.item_price * window.exchange).toFixed(2)
                variant.profit = ((parseFloat(variant.item_price) / parseFloat(_this.exchange)) - (parseFloat(variant.source_price) + parseFloat(_this.freight.price))).toFixed(2)
                variant.compare_at_price = variant.compare_at_price==0 ? null : (variant.compare_at_price * window.exchange).toFixed(2)

                return variant
            })



            this.image_selected = this.imageSelected()
            $('.variant-image-list').magnificPopup({
                delegate: 'a', // child items selector, by clicking on it popup will open
                type: 'image',
                callbacks: {
                    open: function () {
                        const el = $('.mfp-close')[0];
                        $(el).html(`<button title="Close (Esc)" type="button" class="mfp-close"><span>x</span></button>`).click(function () {
                            $.magnificPopup.close();
                        })
                    },
                }
            });

            $(document.body).on('click', function(event) {
                if (!$(event.target).closest('.change-price').length) {
                    _this.comparedPrice.showBox = false;
                    _this.itemPrice.showBox = false;
                }
            });
            let el_sortable = document.getElementById(`el-variant-image-${this.add_variant_product.id}`);
            Sortable.create(el_sortable, {
                ghostClass: "sortable-ghost",  // Class name for the drop placeholder
                chosenClass: "sortable-chosen",  // Class name for the chosen item
                dragClass: "sortable-drag",  // Class name for the dragging item
                setData: function (/** DataTransfer */dataTransfer, /** HTMLElement*/dragEl) {
                    dataTransfer.setData('Text', dragEl.textContent); // `dataTransfer` object of HTML5 DragEvent
                },

                // Element is chosen
                onChoose: function (/**Event*/evt) {
                    evt.oldIndex;  // element index within parent
                },

                // Element dragging started
                onStart: function (/**Event*/evt) {
                    evt.oldIndex;  // element index within parent
                },

                // Element dragging ended
                onEnd: function (/**Event*/evt) {
                    var itemEl = evt.item;  // dragged HTMLElement
                    // console.log('image src', $(evt.item).find('img').attr('src'))
                    // _this.add_variant_product.image = $(evt.item).find('img').attr('src')

                    const element = evt.from.querySelectorAll('.variant-image-list li img')
                    let args = []
                    element.forEach(function(item, key) {
                        let tmp = {
                            index: item.getAttribute('data-id'),
                            src: item.getAttribute('src')
                        }
                        tmp['sort'] = key
                        tmp['status'] = (key === 0) ? true : ((item.getAttribute('data-status') == 'true') ? true : false)
                        args.push(tmp)

                    })
                    _this.sortImage(args)

                    // _this.product.image = $(document.getElementById('el-variant-image').querySelector('li')).find('img').attr('src')
                    evt.to;    // target list
                    evt.from;  // previous list
                    evt.oldIndex;  // element's old index within old parent
                    evt.newIndex;  // element's new index within new parent

                }

            });


            //custom modal shipping country override
            $(document).ready(function () {
                $('#overrideProductModal #modal-shipping-country').removeClass('modal').appendTo('.product-list-container-wrapper');
                $(document).on('click','.bg-modal, #modal-shipping-country .modal-header .close, #overrideProductModal',function () {
                   $('#modal-shipping-country').removeClass('show-modal fade in');
                   $('.bg-modal,.bg-modal-shipping').remove();
                });
            });

            $('[data-toggle="tooltip"]').tooltip({
                html: true,
                container: 'body'
            });
            console.log('tooltip', $('[data-toggle="tooltip"]').tooltip())

            $(document).on('click','.dropdown-option-variant .dropdown-menu, .dropdown-option-variant .dropdown-menu li',function () {
                $(this).parents('.dropdown-option-variant').addClass('open');
            })
            $(document.body).on('click', function(event) {
                if (!$(event.target).closest('.change-price').length) {
                    _this.showChangePrice = false;
                    _this.showChangeComparePrice = false;
                }
            });

        },
        components: {
            modal_shipping_country
        },
        methods: {
            selectImageContainer: function (obj_image, index) {
                if(index == 0)
                    return false;
                obj_image.status = !obj_image.status;
                obj_image.selected = !obj_image.selected;
                this.selectImage(obj_image);
            },
            selectImage: function (obj_image) {
                let _this = this
                this.image_selected = this.imageSelected()
                let tmp_img = {}

                _this.add_variant_product.variants = _this.add_variant_product.variants.map(function (item) {
                    if(item.image_id == obj_image.index) {
                        item.image = obj_image.status ? obj_image.src : `${appUrl}/images/default.png`
                    }
                    return item;
                })

                // _this.add_variant_product.images = Object.assign({},this.add_variant_product.images, tmp_img);
            },

            lengthVariantChecked: function(variants) {
                let variant_checked = []
                variant_checked = variants.filter(function(variant) {
                    return variant.selected
                })

                this.count_variant_select = variant_checked.length

                return variant_checked.length
            },
            selectVariant: function (obj_variant) {
                let _this = this

                let total_variant_select = 100 - _this.current_product.product_variant.length

                _this.add_variant_product.variants = this.add_variant_product.variants.map(function (variant) {
                    if(obj_variant.aliexpress_options === variant.aliexpress_options)
                        variant.selected =! variant.selected

                    return variant
                })

                const length_variant_checked = this.lengthVariantChecked(this.add_variant_product.variants)

                if(length_variant_checked > total_variant_select && obj_variant.selected) {
                    this.$nextTick(function() {
                        _this.add_variant_product.variants = this.add_variant_product.variants.map(function (variant) {
                            if(obj_variant.aliexpress_options === variant.aliexpress_options)
                                variant.selected = false

                            return variant
                        })
                    })

                    notify('warning', 'You can select a maximum of '+total_variant_select+' variants.')
                    return false
                }
                if(length_variant_checked <= 0 && ! obj_variant.selected) {
                    this.$nextTick(function(){
                        _this.add_variant_product.variants = this.add_variant_product.variants.map(function (variant) {
                            if(obj_variant.aliexpress_options === variant.aliexpress_options)
                                variant.selected = true

                            return variant
                        })
                    })

                    notify('warning', 'Please select at least 1 variant (max '+total_variant_select+' variant)')
                    return false
                }
                /*check select variant equal 0 remove check*/
                let currentOption = Object.assign({}, obj_variant.options)
                Object.keys(obj_variant.options).forEach(function (key) {
                    currentOption[key] = {
                        value: obj_variant.options[key],
                        number: 0
                    }
                })
                this.variants = this.variants.map(function (variant) {
                    if (obj_variant.id === variant.id) {
                        variant.selected = obj_variant.selected
                    }
                    if(variant.selected) {

                    }
                    for (let key in currentOption) {
                        if(currentOption[key]['value'] == variant.options[key] && variant.selected == true) {
                            currentOption[key]['number']++
                        }
                    }

                    return variant
                })
                for (let key in currentOption) {
                    if(this.optionFilter[key][currentOption[key]['value']]['total'] == currentOption[key]['number']) {
                        this.optionFilter[key][currentOption[key]['value']]['selected'] = true
                    } else if(currentOption[key]['number'] == 0) {
                        this.optionFilter[key][currentOption[key]['value']]['selected'] = false
                    }
                    else if(this.optionFilter[key]['number']>0){
                        this.optionFilter[key][currentOption[key]['value']] = true
                    }
                }
            },
            showModalImage: function(obj_variant) {
                this.$emit('show-modal-images', obj_variant)
            },
            changeVariantOptions: function(obj_index, obj_label, obj_value) {
                this.add_variant_product.variants = this.add_variant_product.variants.map(function(variant, variantIndex) {
                    if(obj_index == variantIndex) {
                        let opt = `option${obj_index + 1}`
                        variant[opt] = obj_value
                        variant.options[obj_label] = obj_value
                        let opt_val = ''
                        Object.values(variant.options).map(function(val) {
                            opt_val += `${val} `
                        })
                        variant.title = opt_val.trim()
                    }
                    return variant
                })
            },
            selectAllVariants: function (event) {
                let checked = $(event.currentTarget).prop('checked');
                let count = 0
                let total_variant_select = 100 - this.current_product.product_variant.length
                //Xử lý checked variants, nếu checked == true thì sẽ check 100 variants đầu tiên
                //Nếu checked == false thì sẽ check variant đầu tiên
                this.add_variant_product.variants  = this.add_variant_product.variants.map(function (variant) {
                    if(checked) {
                        variant.selected = false
                        if(count < total_variant_select) {
                            $(event.currentTarget).parents('.ars-table-row-item').addClass('active');
                            variant.selected = checked
                            count++
                        }
                    } else {
                        if(count === 0 && count < total_variant_select)
                        {
                            variant.selected = true
                            count++
                        } else {
                            variant.selected = checked
                        }
                        $(event.currentTarget).parents('.ars-table-row-item').removeClass('active');
                    }

                    return variant
                })
                if(checked) {
                    if(count > total_variant_select) {
                        notify('warning', 'You can select a maximum of '+total_variant_select+' variants.')
                    }
                    notify('success', 'Selected successfully')
                }
                else {
                    // notify('success', 'The variants were successfully unselected. Note at least one variant must stay selected')
                    notify('warning', 'Please select at least 1 variant (max '+total_variant_select+' variant)')
                }

            },
            changeItemPrice: function (type) {
                this.itemPrice.type = type
                this.itemPrice.value = null
                if(type === 'multiply_by')
                    this.itemPrice.placeHolder = 'Multiply by price'
                else if(type === 'new_value')
                    this.itemPrice.placeHolder = 'New value price'
                else if(type === 'plus')
                    this.itemPrice.placeHolder = 'Plus value price'

                this.comparedPrice.showBox = false
                this.itemPrice.showBox = true
            },
            changeComparedPrice: function (type) {
                this.comparedPrice.type = type
                this.comparedPrice.value = null
                if(type === 'multiply_by')
                    this.comparedPrice.placeHolder = 'Multiply by compared price'
                else if(type === 'new_value')
                    this.comparedPrice.placeHolder = 'New value compared price'
                else if(type === 'plus')
                    this.comparedPrice.placeHolder = 'Plus value compared price'

                this.itemPrice.showBox = false
                this.comparedPrice.showBox = true
            },
            closeComparedPrice: function () {
                this.comparedPrice.showBox = false
            },
            closeChangeItemPrice: function () {
                this.itemPrice.showBox = false
            },
            saveComparedPrice: function () {
                let _this = this
                if( ! validNumber(_this.comparedPrice.value))
                    return false;

                this.add_variant_product.variants = this.add_variant_product.variants.map(function (variant) {
                    if(_this.comparedPrice.type === 'multiply_by')
                        variant = Object.assign({}, variant, {
                            compare_at_price : Number(parseFloat(_this.comparedPrice.value) * parseFloat(variant.source_price) * _this.exchange).toFixed(2)
                        })
                    else if(_this.comparedPrice.type === 'new_value')
                        variant = Object.assign({}, variant, {
                            compare_at_price : Number(parseFloat(_this.comparedPrice.value)).toFixed(2)
                        })
                    else if(_this.comparedPrice.type === 'plus')
                        variant = Object.assign({}, variant, {
                            compare_at_price: Number((parseFloat(_this.comparedPrice.value) + parseFloat(variant.source_price)) * _this.exchange).toFixed(2)
                        })

                    return variant;
                })
                this.comparedPrice.showBox = false

            },
            saveItemPrice: function () {
                let _this = this

                if( ! validNumber(_this.itemPrice.value))
                    return false

                this.add_variant_product.variants =  this.add_variant_product.variants.map(function (variant) {
                    if(_this.itemPrice.type === 'multiply_by')
                        variant = Object.assign({}, variant, {
                            item_price : Number(parseFloat(_this.itemPrice.value) * parseFloat(variant.source_price) * _this.exchange).toFixed(2)
                        })
                    else if(_this.itemPrice.type === 'new_value')
                        variant = Object.assign({}, variant, {
                            item_price: Number(parseFloat(_this.itemPrice.value)).toFixed(2)
                        })
                    else if(_this.itemPrice.type === 'plus')
                        variant = Object.assign({}, variant, {
                            item_price: Number((parseFloat(_this.itemPrice.value) + parseFloat(variant.source_price)) * _this.exchange).toFixed(2)
                        })

                    return variant
                })
                this.profit_calculate()
                this.itemPrice.showBox = false
            },
            isNumber: function(evt) {
                evt = (evt) ? evt : window.event;
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if ((charCode >= 48 && charCode <= 57) || charCode === 46) {
                    return true
                } else {
                    evt.preventDefault()
                }
            },
            isNumberKeyup: function(event, name) {
                let val = $(event.currentTarget).val()
                let str_split = val.split('.');
                if( str_split[1] != undefined &&  str_split[1].length >= 3 || str_split.length >=3) {
                    let last = str_split[1].slice(0, 2)
                    let first = str_split[0] + '.'
                    val = first.concat(last)
                    // if( name == 'itemPrice' ) {
                    //     this.itemPrice.value = val
                    // }
                    // if( name == 'comparedPrice' ) {
                    //     this.comparedPrice.value = val
                    // }

                    switch (name) {
                        case 'itemPrice':

                            this.itemPrice.value = val
                            break;

                        case 'comparedPrice':

                            this.comparedPrice.value = val
                            break;

                        case 'priceVariantSelect':

                            this.priceVariantSelect = val
                            break;

                        case 'comparePriceVariantSelect':

                            this.comparePriceVariantSelect = val
                            break;
                    }
                }
            },
            isNumberKeyupVariant: function(event, index, name) {
                let val = $(event.currentTarget).val()
                let str_split = val.split('.');
                if( str_split[1] != undefined &&  str_split[1].length >= 3 || str_split.length >=3) {
                    let last = str_split[1].slice(0, 2)
                    let first = str_split[0] + '.'
                    val = first.concat(last)
                    this.add_variant_product.variants[index][name] = val
                }
            },

            /*show modal shipping country*/
            showModalShipingCountry:function (obj_product) {
                if( ! checkExtension())
                    return false
                this.$refs.modal_shipping_country.initDataShip()
                /*$('#modal-shipping-country').addClass('show-modal');
                $('body').append('<div class="bg-modal"></div>');*/
                if($('.modal-shipping-country').length){
                    $('.modal-shipping-country').addClass('show-modal-shipping')
                    $('body').append('<div class="bg-modal-shipping"></div>')
                }

            },
            infoShipping:function(freight){
                this.freight = freight
                this.add_variant_product.types = freight.types
                this.profit_calculate()
            },
            changePrice:function ({ type, target }) {
                // this.prop_freight.price = target.value
                this.profit_calculate()

            },
            setNull:function({ type, target }){
                if(target.value==''){
                    // this.prop_freight.price = 0
                    this.profit_calculate()
                }
            },
            profit_calculate:function () {
                let _this = this
                this.add_variant_product.variants = this.add_variant_product.variants.map(function(variant) {
                    return Object.assign({}, variant, {
                        profit: ((parseFloat(variant.item_price) / parseFloat(_this.exchange)) - (parseFloat(variant.source_price) + parseFloat(_this.freight.price))).toFixed(2)
                    })
                })
            },
            sortImage: function(data) {
                this.add_variant_product.images = data
                this.add_variant_product.mainBigPic = data[0].src
                this.add_variant_product.product_image = data[0].src
                this.add_variant_product.mainBigPic = data[0].src
            },
            checkAllImage(e) {
                let _this = this
                if(e.target.checked == true) {
                    // select all image non select
                    _this.add_variant_product.images.forEach(function(image) {
                        if(!image.status) {
                            image.status = true
                            image.selected = true
                            _this.selectImage(image);
                        }
                    });
                } else {
                    _this.add_variant_product.images.forEach(function(image, index) {
                        if(image.status && index > 0) {
                            image.status = false
                            image.selected = false
                            _this.selectImage(image);
                        }
                    });
                }
            },
            imageSelected() { // need improve
                if(typeof this.add_variant_product.images == "undefined") {
                    return 0
                }
                return this.add_variant_product.images.filter(function (image) {
                    return (image.status == true || image.selected == true)
                }).length;
            },
            finishAdd: function() {
                this.$emit('finish-addvariant')
            },
            getAllOptionVariant: function (variant) {
                let _this = this;
                let count = 0
                let options = []

                this.variants = variant

                this.variants = this.variants.map(function (variant) {
                    variant.selected = false
                    if(count < (100 - _this.current_product.product_variant.length)){
                        variant.selected = true
                        count++

                        for(let [optionKey, value] of Object.entries(variant.options)){

                            if(typeof options[optionKey] == 'undefined'){
                                options[optionKey] = [value]
                                continue
                            }

                            if(options[optionKey].indexOf(value) != -1) continue

                            options[optionKey].push(value)
                        }
                    }
                    return variant
                })

                this.optionFilter = {}
                variant.forEach(function (variant) {
                    for (let optionKey in variant.options) {
                        if (typeof _this.optionFilter[optionKey] == 'undefined') {
                            _this.optionFilter[optionKey] = {
                                [variant.options[optionKey]]: {
                                    selected: true,
                                    total: 1
                                }
                            }
                            continue
                        }

                        if (typeof _this.optionFilter[optionKey][variant.options[optionKey]] == 'undefined') {
                            _this.optionFilter[optionKey][variant.options[optionKey]] = {
                                selected: true,
                                total: 1
                            }
                            continue
                        }

                        _this.optionFilter[optionKey][variant.options[optionKey]]['total']++
                    }
                });

                for (let optionKey in options) {
                    variant.forEach(function (variant) {
                        if( ! variant.selected){
                            _this.optionFilter[optionKey][variant.options[optionKey]].selected = false
                        }
                    });
                }

                _this.countOptionFilter = JSON.parse(JSON.stringify(_this.optionFilter))

                this.totalVariant=this.getTotalVariant(variant)
            },

            selectOptionFilter(select, value, optionKey, optionFilterKey) {
                let _this = this
                let filterOject = {}
                let allEmpty = true
                let count = 0

                Object.keys(this.optionFilter).forEach(function (key) {
                    filterOject[key] = Object.keys(_this.optionFilter[key]).filter(function (keyValue) {
                        return _this.optionFilter[key][keyValue].selected == true
                    })
                })

                if(Object.keys(filterOject).filter((key)=>filterOject[key].length > 0).length > 0)
                    allEmpty = false

                _this.add_variant_product.variants = _this.add_variant_product.variants.map(function (variant) {
                    if(allEmpty == true) {
                        variant.selected = false
                        return variant
                    }

                    variant.selected = _this.isAnd
                    for (let key in filterOject) {

                        if(_this.isAnd) {
                            if (filterOject[key].length != 0 && filterOject[key].indexOf(variant.options[key]) == -1)
                                variant.selected = false

                            continue
                        }

                        if (filterOject[key].length != 0 && filterOject[key].indexOf(variant.options[key]) > -1)
                            variant.selected = true

                    }
                    return variant
                });
                _this.lengthVariantChecked(_this.add_variant_product.variants)
                if(_this.count_variant_select ==0){
                    if(count === 0)
                    {
                        _this.add_variant_product.variants[0].selected = true
                        count++

                        for(let key in _this.optionFilter){
                            _this.optionFilter[key][_this.add_variant_product.variants[0].options[key]].selected=true
                            _this.optionFilter[key][_this.add_variant_product.variants[0].options[key]].total++
                        }
                        notify('success', 'The variants were successfully unselected. Note at least one variant must stay selected')
                        notify('warning', 'You must select at least 1 variant.')
                    }
                }

                if(select.selected){
                    if( _this.count_variant_select > (100 - _this.current_product.product_variant.length)){
                        let variant =_this.add_variant_product.variants
                        variant.forEach(function (variant) {
                            for (let optionKey in variant.options) {
                                if(variant.options[optionKey]==value){
                                    variant.selected=false
                                }
                            }
                        });
                        notify('warning', 'You can select a maximum of '+(100 - _this.current_product.product_variant.length)+' variants.')

                        _this.optionFilter[optionFilterKey][value].selected = false

                        let id = value.split(' ').join('_')

                        $('#'+id).prop("checked",_this.optionFilter[optionFilterKey][value].selected);

                        return false
                    }

                }
            },

            getTotalVariant: function (variant) {

                return variant.length;
            },

            showInputChangePrice: function () {
                this.showChangeComparePrice = false
                this.showChangePrice = true
            },
            showInputChangeComparePrice: function () {
                this.showChangePrice = false
                this.showChangeComparePrice = true
            },
            saveChangePrice:function () {
                let _this = this

                for (let key in _this.add_variant_product.variants){
                    if(_this.add_variant_product.variants[key].selected)
                        _this.add_variant_product.variants[key].item_price = Number(_this.priceVariantSelect).toFixed(2)
                }
                _this.priceVariantSelect = null
                _this.profit_calculate()
            },
            saveChangeComparePrice:function () {
                let _this = this

                for (let key in _this.add_variant_product.variants){
                    if(_this.add_variant_product.variants[key].selected)
                        _this.add_variant_product.variants[key].compare_at_price = Number(_this.comparePriceVariantSelect).toFixed(2)
                }
                _this.comparePriceVariantSelect = null
                _this.profit_calculate()
            }
        }
    }
</script>
<style scoped lang="scss">
    .select-all-group {
		margin-bottom: 15px;
		height: 34px;
		label {
			font-size: 15px;
			line-height: 34px;
			vertical-align: middle;
		}
		.select-all-text {
			font-size: 15px;
			line-height: 34px;
			vertical-align: middle;
			b {
				color: #7009FF;
			}
		}
	}
</style>
