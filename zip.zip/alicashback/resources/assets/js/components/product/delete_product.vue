<template>
    <div id="deleteProduct" class="modal fade" role="dialog">
        <!-- Modal Delete Product -->
        <div class="modal-dialog modal-md">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Delete Product</h4>
                    <button type="button" data-dismiss="modal" class="close"><i class="mdi mdi-close"></i></button>
                </div>
                <div class="modal-body">
                    <div class="delete__product_modal">
                        <div class="override__product-box m-b-25">
                            <h2>Are you sure you want to delete selected products from your Product List?</h2>
                            <div class="override__product-info">
                                <div class="override__product-img">
                                    <img v-bind:src="current_product.product_image" v-bind:alt="current_product.product_title">
                                </div>
                                <div class="override__product-title">
                                    <h2>
                                        <a class="alink" v-bind:href="current_product.source_product_link" target="_blank" v-text="current_product.product_title"></a>
                                    </h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label class="checkbox-style checkbox-style-modal m-b-0" for="delete-product-1">
                        <input id="delete-product-1" type="checkbox" v-model="is_delete_product_shopify" @checked="is_delete_product_shopify">
                        <span class="checked-style"></span>
                        Also delete from Shopify store
                    </label>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click.prevent="deleteProductHandle(current_product.product_id, $event)">Delete Product</button>
                </div>
                <div class="vue__loaders_wrapper" v-show="loading">
                    <vue_loaders_circle></vue_loaders_circle>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">

    export  default {
        props: ['current_product'],
        data() {
            return {
                is_delete_product_shopify: false,
                loading: false
            }
        },
        methods: {
            deleteProductHandle: function (productId, event) {
                let _this = this
                _this.loading = true
                axios.post(appUrl+'/products/delete', {
                    'is_delete_product_shopify' : this.is_delete_product_shopify,
                    'product_id' : productId
                })
                .then(response => {
                    let { status } = response.data
                    if(status) {
                        notify('success', 'Deleted product success');
                        $('#product-list-item-'+productId).remove();
                        location.reload();
                    } else {
                        notify('error', 'Deleted product error, please refresh page and try again');
                    }
                    _this.loading = false

                    //Hide modal
                    $('#deleteProduct').modal('hide');
                })
                .catch(error => {
                    notify('error', error);
                    _this.loading = false
                    //Hide modal
                    $('#deleteProduct').modal('hide');
                });
            }
        }
    };

</script>
