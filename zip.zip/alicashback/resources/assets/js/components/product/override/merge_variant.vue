<template>
    <div class="merge__variants-wrap">
        <div class="merge__variants-fulfilled" v-text="old_variants.length+' variants need to update for fulfilled order'"></div>

        <!-- <div class="row">
            <div class="col-xs-6">
                <div class="ars-field">
                    <label class="ars-field-title">Old Variant</label>
                </div>
            </div>
            <div class="col-xs-6">
                <div class="ars-field">
                    <label class="ars-field-title">New Variant</label>
                </div>
            </div>
        </div> -->
        <div class="override__product-varriant-list m-b-10">
            <div class="override__product-varriant-old fz-13 fw-600">Current Variant</div>
            <div class="icon-swap"></div>
            <div class="override__product-varriant-new fz-13 fw-600">New Variant</div>
        </div>
        <div class="override__product-wrap">
            <div class="override__product-varriant-list" v-for="old_variant in old_variants">
                <div class="override__product-varriant-old">
                    <div class="override__product-info">
                        <div class="override__product-img">
                            <img v-bind:src="($lodash.has(old_variant, 'product_image.src')) ? old_variant.product_image.src : appUrl+'/images/backend/default.png'" alt="">
                        </div>
                        <div class="override__product-title">
                            <h2>{{ old_variant.title }}</h2>
                            <p>SKU: {{ old_variant.sku }}</p>
                        </div>
                    </div>
                </div>
                <div class="icon-swap">
                    <i class="mdi mdi-swap-horizontal"></i>
                </div>
                <div class="override__product-varriant-new dropdown box-dropdown">
                    <div class="override__product-info" data-toggle="dropdown">
                        <div class="override__product-img">
                            <img v-bind:src="appUrl+'/images/backend/select-variant-update.png'" alt="">
                        </div>
                        <div class="override__product-title">
                            <h2>Select variant to override</h2>
                        </div>
                    </div>
                    <div class="dropdown-menu box-dropdown-menu">
                        <ul class="product__variant_new" v-bind:data-id="old_variant.id">
                            <li class="product-variant-enable" v-for="(new_variant,index) in new_variants" v-bind:data-value="index" @click="selectProductVariant(old_variant, new_variant, $event)">
                                <div class="product__variant_override">
                                    <div class="productvariant-type-block">
                                        <div class="productvariant-type-image">
                                            <img v-bind:src="new_variant.image" alt="">
                                        </div>
                                        <p class="product-variant-title">{{ new_variant.title }} - {{ new_variant.price }} $</p>
                                    </div>
                                </div>
                            </li>
                            <li class="product-variant-enable" @click="selectProductVariant(old_variant, {}, $event)">
                                <div class="product__variant_override">
                                    <div class="productvariant-type-block">
                                        <div class="productvariant-type-image">
                                            <img v-bind:src="appUrl+'/images/do-not-image.png'" alt="">
                                        </div>
                                        <p class="product-variant-title">Do not override this variant</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>



        <!-- <div class="row list-variant" v-for="old_variant in old_variants">
            <div class="col-xs-6">
                <div class="ars-field">
                    <div class="productvariant-override-block productvariant-old">
                        <div class="productvariant-type-block">
                            <div class="productvariant-type-image">

                                <img v-bind:src="($lodash.has(old_variant, 'product_image.src')) ? old_variant.product_image.src : appUrl+'/images/do-not-image.png'" alt="">
                            </div>
                            <p class="product-variant-title-old">{{ old_variant.title }}</p>
                            <span>SKU: {{ old_variant.sku }}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xs-6">
                <div class="ars-field">
                    <div class="productvariant-override-block productvariant-new">
                        <div class="productvariant-type-block dropdown-toggle" data-toggle="dropdown">
                            <div class="productvariant-type-image-new">
                                <img v-bind:src="appUrl+'images/do-not-image.png'" alt="">
                            </div>
                            <p class="product-variant-title-new" v-bind="selectProductVariant(old_variant, {})">Do not override this product</p>
                        </div>


                        <ul class="productvariant-new-list dropdown-menu" v-bind:data-id="old_variant.id">

                            <li class="product-variant-enable" @click="selectProductVariant(old_variant, {})">
                                <div class="productvariant-override-block">
                                    <div class="productvariant-type-block">
                                        <div class="productvariant-type-image">
                                            <img v-bind:src="appUrl+'/images/do-not-image.jpg'" alt="">
                                        </div>
                                        <p class="product-variant-title">Do not override this product</p>
                                    </div>
                                </div>
                            </li>
                            <li class="product-variant-enable" v-for="(new_variant,index) in new_variants" v-bind:data-value="index" @click="selectProductVariant(old_variant, new_variant)">
                                <div class="productvariant-override-block">
                                    <div class="productvariant-type-block">
                                        <div class="productvariant-type-image">
                                            <img v-bind:src="new_variant.image" alt="">
                                        </div>
                                        <p class="product-variant-title">{{ new_variant.title }} - {{ new_variant.price }} $</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div> -->


    </div>
</template>

<script type="text/javascript">
    import lodash from 'lodash'
    Object.defineProperty(Vue.prototype, '$lodash', { value: lodash })
    export default {
        props: ['old_variants', 'new_variants'],
        data: function () {
            return {
                appUrl: window.appUrl
            }
        },
        mounted: function() {
            console.log('appURL')
        },
        methods: {
            // selectProductVariant: function (old_variant, new_variant) {
            //     let _this = this;
            //     let target = event.currentTarget;
            //     let _text = $(target).find('.product-variant-title').text();
            //     let _src = $(target).find('img').attr('src');
            //     $(target).parents('.productvariant-new').find('.product-variant-title-new').text(_text);
            //     $(target).parents('.productvariant-new').find('.productvariant-type-image-new').find('img').attr('src', _src);

            //     _this.$emit('choose_variant', old_variant, new_variant)
            // }

            selectProductVariant: function(old_variant, new_variant, event) {
                let _this = this;
                let target = event.currentTarget;
                let _text = $(target).find('.product-variant-title').text();
                let _src = $(target).find('img').attr('src');
                $(target).parents('.override__product-varriant-new').find('.override__product-title').find('h2').text(_text);
                $(target).parents('.override__product-varriant-new').find('.override__product-img').find('img').attr('src', _src);
                _this.$emit('choose_variant', old_variant, new_variant)
            }
        }
    }
</script>