<template>
    <div id="addVariantAliexpress" data-keyboard="false" data-backdrop="static"  class="modal fade" role="dialog">
        <!-- Modal Add Variant Product -->
        <div class="modal-dialog modal-sm" v-show="current_product.step==='start'">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Update AliExpress Link</h4>
                    <button type="button" data-dismiss="modal" class="close"><i class="mdi mdi-close"></i></button>
                </div>
                <div class="modal-body">
                    <div class="override__product-wrap">
                        <div class="override__product-box">
                            <h2>Current Product</h2>
                            <div class="override__product-info">
                                <div class="override__product-img">
                                    <img v-bind:src="current_product.product_image" width="100px" v-bind:alt="current_product.product_title">
                                </div>
                                <div class="override__product-title">
                                    <h2>
                                        <a class="text-link" href="#" v-text="current_product.product_title"></a>
                                    </h2>
                                </div>
                            </div>
                        </div>
                        <div class="override__product_optional">
                            <div class="form-group m-b-0">
                                <label class="form__group-title">New product link</label>
                                <input type="text" v-model="add_variant_link"  @keyup.enter="addVariantAliexpress" placeholder="Enter Aliexpress link of product here">
                                <label class="error">{{ validate_message.aliexpress_link }}</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click.prevent="addVariantAliexpress()">Update</button>
                </div>
                <div class="vue__loaders_wrapper" v-show="loading_page">
                    <vue_loaders_circle></vue_loaders_circle>
                </div>
            </div>
        </div>

        <!--Success notice-->
        <div class="modal-dialog modal-lg" v-show="current_product.step==='success'">
            <!-- Modal content-->
            <div class="modal-content modal-content-success">
                <div class="modal-header">
                    <h4 class="modal-title">Update AliExpress Link</h4>
                    <button type="button" data-dismiss="modal" class="close"><i class="mdi mdi-close"></i></button>
                </div>
                <div class="modal-body">
                    <div class="product-override-modal-wrap product-override-success">
                        <i class="icon-ali icon-ic-check-circle-24px"></i>
                        <h1 class="text-center">Update link and variants successfully</h1>
                    </div>
                </div>
            </div>
        </div>
        <!--Merge product-->
        <div class="modal-dialog modal-lg max-width-517" v-show="current_product.step==='merge'">
            <!-- Modal content-->
            <div class="modal-content modal-content-merge">
                <div class="modal-header">
                    <h4 class="modal-title">Variants need to be updated</h4>
                    <button type="button" data-dismiss="modal" @click="reloadWindow" class="close"><i class="mdi mdi-close"></i></button>
                </div>
                <div class="modal-body">
                    <div class="override__product-wrap">
                        <div class="override__product-varriant-list" v-for="variant in variants">
                            <div class="override__product-varriant-old">
                                <div class="override__product-info">
                                    <div class="override__product-img">
                                        <img v-bind:src="(variant.image ? variant.image : appUrl+ '/images/default.png')" alt="">
                                    </div>
                                    <div class="override__product-title">
                                        <h2>{{ variant.title }}</h2>
                                        <p>SKU: {{ variant.sku }}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="icon-swap">
                                <i class="mdi mdi-swap-horizontal"></i>
                            </div>
                            <div class="override__product-varriant-new dropdown box-dropdown">
                                <div class="override__product-info" data-toggle="dropdown">
                                    <div class="override__product-img">
                                        <img class="override__product-img_img" v-bind:src="appUrl+ '/images/backend/select-variant-update.png'">
                                    </div>
                                    <div class="override__product-title">
                                        <h2 class="override__product-title_2">Select variants to update</h2>
                                    </div>
                                </div>
                                <div class="dropdown-menu box-dropdown-menu">
                                    <ul class="product__variant_new" v-bind:data-id="variant.id">
                                        <li class="product-variant-enable" v-for="(sku_ali,k) in current_product.skus" v-bind:data-value="k ? k : 'fire_apps'" @click="selectProductVariant(variant.id, $event)">
                                            <div class="product__variant_override">
                                                <div class="productvariant-type-block">
                                                    <div class="productvariant-type-image">
                                                        <img v-bind:src="sku_ali.image" alt="">
                                                    </div>
                                                    <p class="product-variant-title">{{ sku_ali.title }} - {{ sku_ali.price }} $</p>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="product-variant-enable" @click="selectProductVariant(variant.id, $event)">
                                            <div class="product__variant_override">
                                                <div class="productvariant-type-block">
                                                    <div class="productvariant-type-image">
                                                        <img v-bind:src="'https://aliorders.fireapps.io/images/do-not-image.png'" alt="">
                                                    </div>
                                                    <p class="product-variant-title">Do not update this variant</p>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal" @click="reloadWindow">Don't update variants</button>
                    <button class="modal__ok_button" type="button" @click="addVariantFinish" v-bind:disabled=" ! is_choose">Update variants</button>
                </div>
                <div class="vue__loaders_wrapper" v-show="loading_page">
                    <vue_loaders_circle></vue_loaders_circle>
                </div>
            </div>
        </div>
    </div>
</template>



<script type="text/javascript">
    import 'vue-loaders/dist/vue-loaders.css';
    import vue_loaders_circle from '../../components/common/vue_loaders_circle';
    export  default {
        name: 'add_variant_aliexpress',
        props: ['current_product'],
        data: function () {
            return {
                appUrl: window.appUrl,
                is_choose: false,
                variants: [],
                skus : {},
                validate_message : {},
                current_product: this.current_product,
                loading_page: false,
                add_variant_link: null,
            }
        },
        mounted() {
            $('#addVariantAliexpress').on('show.bs.modal', function () {
                $('img.override__product-img_img').attr('src', appUrl + '/images/backend/select-variant-update.png')
                $('h2.override__product-title_h2').text('Select variants to update')
            })
        },
        methods: {
            reloadWindow: function() {
                location.reload();
            },
            addVariantAliexpress: function () {
                let self = this;
                if( ! aliexpressValidateUrl(this.add_variant_link))
                {
                    this.current_product.supplier_name = '';
                    this.current_product.supplier_url = '';
                    this.current_product.skus = [];

                    this.validate_message = Object.assign({}, this.validate_message, {aliexpress_link : 'Please input AliExpress link'});
                    return false;
                }
                this.add_variant_link = self.formatURL(this.add_variant_link)
                this.validate_message.aliexpress_link = '';
                this.loading_page = true

                this.$emit('input_aliexress', this.add_variant_link);

                window.postMessage({ action: 'ACTION_GET_ALIEXPRESS_PRODUCT_DETAIL', payload:{aliLink: this.add_variant_link}  }, '*');
            },
            formatURL:function(link){
                let id=0;
                let url = new window.URL(link);
                url.search = '?';
                let beforeString = url.href;

                let array_url = beforeString.split("/")

                array_url.forEach(function (e) {

                    if(e.search('.html') != -1){
                        e = e.replace('.html','')
                        if(e.search('_') == -1){
                            id = e

                        }else{
                            e = e.split("_")
                            id = e[1]
                        }
                    }
                })

                return 'https://www.aliexpress.com/item/-/'+id+'.html'
            },
            addVariantFinish : function () {
                let _this = this
                this.loading_page = true
                axios.post(appUrl+'/extension/mergeVariant', {variant : this.skus, product_id: this.current_product.product_id}, {
                        onUploadProgress: (e) => {
                            _this.loading_page = true
                        }
                    }).then(function (response) {
                        _this.loading_page = false
                        location.reload();
                    })
                    .catch(function (error) {
                        alert('merge error');
                        _this.loading_page = false
                    });
            },
            selectProductVariant: function(variantId, event) {
                let _this = this;
                let target = event.currentTarget;
                let _text = $(target).find('.product-variant-title').text();
                let _src = $(target).find('img').attr('src');
                $(target).parents('.override__product-varriant-new').find('.override__product-title').find('h2').text(_text);
                $(target).parents('.override__product-varriant-new').find('.override__product-img').find('img').attr('src', _src);
                if($(target).data('value')) {
                    this.skus[variantId] = Object.assign({}, this.current_product.skus[$(target).data('value')], {
                        source_product_link: (this.add_variant_link) ? this.add_variant_link : null,
                        supplier_id: (this.current_product.supplier_id) ? this.current_product.supplier_id : null
                    })
                } else {
                    delete this.skus[variantId]
                }
                //Check self.skus is choose
                if(Object.keys(this.skus).length > 0)
                    this.is_choose = true
                else
                    this.is_choose = false

            }
        },
        components: {
            vue_loaders_circle
        },
        watch: {
            current_product: {
                handler(current_product){
                    let _this = this
                    _this.add_variant_link = current_product.source_product_link
                    console.log(current_product.source_product_link)
                    if(current_product.listen_variant_aliexpress) {
                        current_product.listen_variant_aliexpress = false
                        current_product.source_product_link = _this.add_variant_link
                        axios.post(appUrl+'/extension/importVariant', _this.current_product, {
                            onUploadProgress: (e) => {
                                _this.loading_page = true
                            }
                        }).then(function (response) {
                            // $('#addVariantAliexpress').loading_finish();
                            _this.loading_page = false;
                            if((response.data.product_variant_ali_option_null).length > 0) {
                                _this.$nextTick(function () {
                                    _this.variants = response.data.product_variant_ali_option_null;
                                })

                                _this.current_product.step = 'merge';
                                console.log('merge')
                            } else {
                                $('#addVariantAliexpress').modal('toggle')
                                notify('success', 'Update link and variants successfully')
                                // _this.current_product.step = 'success';
                                setTimeout(function(){
                                    location.reload();
                                }, 1500)

                            }
                        })
                        .catch(function (error) {
                            _this.loading_page = false;
                        });
                    }
                },
                deep: true
            }
        }
    };
</script>
