<template>
    <div id="overrideProductModal" class="modal fade" role="dialog">
        <!-- Modal Add Variant Product -->
        <div class="modal-dialog" v-bind:class="(page === 'override_form') ? 'modal-lg-1170' : (page === 'add_variant') ? 'max-width-517' : 'modal-sm'">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" data-dismiss="modal" class="close"><i class="mdi mdi-close"></i></button>
                    <h4 class="modal-title">Override Product</h4>
                </div>
                <div class="modal-body">
                    <div class="product-add-aliexpress-modal-wrap" v-if="'input_link' === page">
                        <div class="override__product-wrap">
                            <div class="override__product-box">
                                <h2>Current Product</h2>
                                <div class="override__product-info">
                                    <div class="override__product-img">
                                        <img v-bind:src="current_product.product_image" width="100px" v-bind:alt="current_product.product_title">
                                    </div>
                                    <div class="override__product-title">
                                        <h2>
                                            <a class="alink" v-bind:href="current_product.source_product_link" target="_blank" v-text="current_product.product_title"></a>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                            <div class="override__product_optional" v-show="Object.values(override_product).length === 0">
                                <div class="form-group m-b-0">
                                    <label class="form__group-title">Override with</label>
                                    <input type="text" @keyup.enter="inputLinkAliexpress"  v-model="override_link" placeholder="Enter Aliexpress link of product here">
                                    <label class="error" v-text="validate_message.aliexpress_link"></label>
                                </div>
                            </div>
                        </div>
                        <div v-show="Object.values(override_product).length > 0">
                            <div class="override__product-box m-b-0">
                                <h2>New Product</h2>
                                <div class="override__product-info">
                                    <div class="override__product-img">
                                        <img v-bind:src="($lodash.has(override_product,'mainBigPic')) ? override_product.mainBigPic : '' " width="100px" v-bind:alt="($lodash.has(override_product, 'product.title')) ? override_product.product.title : ''">
                                    </div>
                                    <div class="override__product-title">
                                        <h2>
                                            <a class="alink" v-bind:href="override_link" target="_blank" v-text="( $lodash.has(override_product, 'title')) ? override_product.title : ''"></a>
                                        </h2>
                                    </div>
                                </div>
                            </div>

                            <div class="m-t-20 container-tooltip-replace">
                                <label class="checkbox-style checkbox-style-modal" for="override-title-desc">
                                    <input id="override-title-desc" v-model="override_option.title" type="checkbox">
                                    <span class="checked-style"></span>
                                    Override Title and Description <i data-toggle="tooltip" data-placement="right" data-original-title="Replace your existing product title and description with the title/description from the overriding product"  class="mdi mdi-alert-circle tooltip-overide-replace color-skin fz-15"></i>
                                </label>
                                <!--<span class="override-product-tooltip" data-toggle="tooltip" data-placement="top" title="Replace your existing product title and description with the title/description from the overriding product">
                                <i class="icon-ali icon-icon_alert-circle-exc"></i>
                                </span>-->
                            </div>
                            <div class="m-t-20 container-tooltip-delete">
                                <label class="checkbox-style checkbox-style-modal" for="override-images">
                                    <input id="override-images" v-model="override_option.image" type="checkbox">
                                    <span class="checked-style"></span>
                                    Override Images 
                                    <i data-toggle="tooltip" data-placement="right" data-original-title="DELETE ALL of your existing product images and will replace them with the images from the overriding product." class="mdi mdi-alert-circle tooltip-overide-delete color-skin fz-15"></i>
                                </label>
                                <!--<span class="override-product-tooltip" data-toggle="tooltip" data-placement="top" title="DELETE ALL of your existing product images and will replace them with the images from the overriding product."><i class="icon-ali icon-icon_alert-circle-exc"></i></span>-->
                            </div>
                        </div>
                    </div>
                    <div v-else-if="page === 'override_form'">
                        <!--Start override product-->
                        <override_form v-bind:override_product="override_product"
                                       v-bind:current_product="current_product"
                                       v-on:show-modal-images="showModalImages"
                                       v-bind:override_option="override_option"
                                       v-on:finish-override="finishOverride"></override_form>
                        <!--End form override-->
                    </div>
                    <div v-else-if="page === 'add_variant'">
                        <merge_variant v-on:choose_variant="chooseVariant"
                                        v-bind:old_variants="variant_has_order"
                                       v-bind:new_variants="override_product.variants"></merge_variant>
                    </div>

                    <div class="vue__loaders_wrapper" v-show="loading_page">
                        <vue_loaders_circle></vue_loaders_circle>
                    </div>
                </div>
                <div class="modal-footer" v-if="page === 'input_link'">
                    <button class="modal__cancel_button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" v-bind:disabled="Object.values(override_product).length === 0" @click.prevent="addVariantAliexpress()">Override</button>
                </div>
                <div class="modal-footer" v-else-if="page === 'add_variant'">
                    <button class="modal__cancel_button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click.prevent="finishOverrideAndMerge()">Override</button>
                </div>
            </div>
        </div>
        <modal_item_image v-bind:props_product_images="override_product.images" v-show="override_product.modal_images" v-on:close-modal-images="closeModalImages" v-on:add-variant-image="addVariantImage"></modal_item_image>
    </div>
</template>


<script type="text/javascript">
    import override_form from './override/override_form'
    import merge_variant  from './override/merge_variant'
    import 'vue-loaders/dist/vue-loaders.css';
    import lodash from 'lodash'
    import vue_loaders_circle from '../../components/common/vue_loaders_circle';
    Object.defineProperty(Vue.prototype, '$lodash', { value: lodash });
    import modal_item_image from '../../components/common/modal_item_image'
    export  default {
        name: 'override_product',
        props: {
            current_product: {},
            settings: {},
            page: {
                required: false,
                default: 'input_link'
            }
        },
        data: function () {
            return {
                override_product: { },
                validate_message: {
                    aliexpress_link: ''
                },
                override_link: '',
                settings: {},
                override_option: {
                    title: false,
                    image: false,
                },
                variant_has_order: [],
                variant_merge: [],
                page: this.page,
                loading_page: false,
            }
        },
        mounted: function () {
            let _this = this
            window.overrideProductExtension = function (args) {
                _this.filterOverrideProduct(args)
            }

            $('#overrideProductModal').on('hidden.bs.modal', function () {
                _this.removeOverrideData();
                Vue.nextTick(function () {
                    _this.validate_message.aliexpress_link = '';
                })
            })

            $(document.body).on('click', function(event) {

                if (!$(event.target).closest('.product__images_modal_overlay').length) {
                    _this.current_product.modal_images = false;
                }
            });

            // $('.tooltip-overide-delete').tooltip({'container':'.container-tooltip-delete'})
            // $('.tooltip-overide-replace').tooltip({'container':'.container-tooltip-replace'})
            
        },
        components: {
            override_form,
            merge_variant,
            modal_item_image,
            vue_loaders_circle
        },
        methods: {
            addVariantAliexpress: function () {
                this.page = 'override_form'
            },
            inputLinkAliexpress: function () {
                let _this = this
                _this.loading_page = true
                if( ! aliexpressValidateUrl(this.override_link))
                {
                    _this.loading_page = false
                    this.validate_message = Object.assign({}, this.validate_message, {aliexpress_link : 'Please enter a valid url address'})
                    return false
                }
                this.override_link = _this.formatURL(this.override_link)

                _this.validate_message = {}

                window.postMessage({action: 'ACTION_OVERRIDE_PRODUCT', payload: {aliLink: this.override_link}}, '*')
            },

            formatURL:function(link){
                let id=0;
                let url = new window.URL(link);
                url.search = '?';
                let beforeString = url.href;

                let array_url = beforeString.split("/")

                array_url.forEach(function (e) {

                    if(e.search('.html') != -1){
                        e = e.replace('.html','')
                        if(e.search('_') == -1){
                            id = e

                        }else{
                            e = e.split("_")
                            id = e[1]
                        }
                    }
                })

                return 'https://www.aliexpress.com/item/-/'+id+'.html'
            },
            replaceOverrideProduct: function () {
                this.override_product = {}
                this.override_link = ''
            },

            filterOverrideProduct: function (override_product) {
                // console.log(override_product)
                let _this = this
                let count = 0
                const {images, product, supplier, variants, mainBigPic} = override_product
                product['source_product_link'] = _this.override_link
                product['aliexpress_product_id'] = getAliexressProductId(_this.override_link)
                product['auto_update_price'] = parseInt(_this.current_product.auto_update_price)
                product['title_source'] = product['title']
                product['types'] = {
                    city: null,
                    country: null,
                    province: null
                }
                let tmp_images = []

                let tmp_variants = variants.map(function (variant) {
                    let tmp = {
                        selected: false
                    }
                    tmp['source_product_link'] = _this.override_link
                    tmp['aliexpress_product_id'] = getAliexressProductId(_this.override_link)
                    if(variant.source_quantity > 0 && count < 100)
                    {
                        count = count + 1
                        tmp.selected =  true
                        tmp_images.push({
                            aliexpress_options: variant.aliexpress_options,
                            src: variant.image,
                            status: true
                        })
                    }
                    let price = setPrice(variant.source_price, _this.settings.price_rule, _this.settings.rest_of_the_price_ranges, _this.settings.is_compared_price)

                    return Object.assign({}, variant, tmp, price)
                })

                images.forEach(function (image) {
                    tmp_images.push(image)
                })

                _this.override_product = Object.assign({},
                    {images: tmp_images},
                    product,
                    {supplier: supplier},
                    {variants: tmp_variants},
                    {mainBigPic: mainBigPic} )

                _this.override_product.price_range = {minPrice: _this.override_product.minPrice , maxPrice: _this.override_product.maxPrice }

                _this.override_product.freights=[]

            },
            finishOverride: function () {
                let _this = this
                this.loading_page = true

                _this.override_product = _this.setOptions(_this.override_product)

                axios.post(appUrl+'/products/override_product',
                    {
                        override: this.override_product,
                        current: this.current_product,
                        options: this.override_option})
                    .then(function (response) {
                        let {status, variant_has_order = []} = response.data

                        if( ! status)
                        {
                            notify('error', 'Error')
                            return false
                        }
                        if(variant_has_order.length === 0)
                        {
                            _this.$emit('override_process', _this.current_product, _this.override_product)
                            _this.page = 'successfully'
                            _this.override_product = {}
                            _this.override_link = ''
                            return false
                        }

                        _this.page = 'add_variant'
                        _this.variant_has_order = variant_has_order
                        _this.loading_page = false
                    })
                    .catch(function (error) {
                        console.log(error)
                        _this.loading_page = false
                    })
            },
            chooseVariant: function (old_variant, new_variant) {
                let _this = this
                let new_variants_set = new_variant

                new_variants_set = Object.assign({}, new_variant, {
                    id: old_variant.id
                })

                _this.variant_merge[old_variant.id] = new_variants_set
            },
            finishOverrideAndMerge: function () {
                let _this = this
                // let variant_merge
                if(this.variant_has_order.length > Object.values(this.variant_merge).length)
                {
                    notify('error', 'Please choose all variants')
                    return false
                }
                this.loading_page = true
                _this.override_product = _this.setOptions(_this.override_product)
                axios.post(appUrl+'/products/override_product', {
                        variant_merge: Object.values(_this.variant_merge),
                        override: _this.override_product,
                        current: _this.current_product,
                        options: _this.override_option})
                    .then(function (response) {
                        let {status, variant_has_order = []} = response.data
                        if( ! status)
                        {
                            notify('error', 'Error')
                            return false
                        }
                        _this.$emit('override_process', _this.current_product)
                        _this.page = 'successfully'
                        _this.override_product = {}
                        _this.override_link = ''
                        _this.loading_page = false
                    })
                    .catch(function (error) {
                        console.log(error)
                        _this.loading_page = false
                    })
            },

            setOptions: function (product) {
                let product_options = []
                if(product.variants) {
                    product.variants.map((variant) => {
                        let { options } = variant
                        let key = Object.keys(options)
                        let value = Object.values(options)

                        if(key[0]) {
                            variant.option1 = value[0]
                            product_options[0] =  {'name' : key[0],  'position' : 1}
                        }

                        if(key[1]) {
                            variant.option2 = value[1]
                            product_options[1] = {'name' : key[1],  'position' : 2}
                        }

                        if(key[2]) {
                            variant.option3 = value[2]
                            product_options[2] = {'name' : key[2], 'position' : 3}
                        }
                    })
                }
                product.options = product_options
                return product
            },
            removeOverrideData: function () {
                this.page = 'input_link'
                this.override_product = {}
                this.override_link = ''
            },
            showModalImages: function(obj_variant) {
                console.log('obj_variant', obj_variant)
                let _this = this
                this.$nextTick(function() {
                    _this.override_product = Object.assign({}, _this.override_product, {
                        modal_images: true,
                        variant_image: obj_variant
                    })
                })
            },
            closeModalImages: function(obj_modal_images) {
                let _this = this
                this.$nextTick(function() {
                    _this.override_product = Object.assign({}, _this.override_product, {
                        modal_images: obj_modal_images.status
                    })
                })
            },
            addVariantImage: function(obj_image) {
                let _this = this
                this.$nextTick(function() {
                    _this.override_product.variants = _this.override_product.variants.map(function(variant) {
                        if(variant.index === _this.override_product.variant_image.index) {
                            variant = Object.assign({}, variant, {
                                image_status: true,
                                image_id: obj_image.index,
                                image: obj_image.src
                            })
                        }
                        return variant
                    })

                    _this.override_product.images = _this.override_product.images.map(function(product_image) {
                        if(product_image.index === obj_image.index) {
                            product_image = Object.assign({}, product_image, {
                                status: true
                            })
                        }
                        return product_image
                    })
                    _this.override_product = Object.assign({}, _this.override_product, {
                        modal_images: false
                    })
                })
            }
        },
        watch: {
            override_product: function(value) {
                if( Object.values(value).length > 0 ) {
                    this.loading_page = false
                }
            },
            override_link: function () {
                this.inputLinkAliexpress();
            }
        }
    };
</script>
