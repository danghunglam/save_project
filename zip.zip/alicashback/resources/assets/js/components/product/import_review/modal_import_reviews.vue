<template>
    <!-- Modal -->
    <div id="import-reviews-modal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" data-dismiss="modal" class="close"><i class="mdi mdi-close"></i></button>
                    <h4 class="modal-title">Get AliExpress Reviews</h4>
                </div>
                <div class="modal-body">
                    <div class="import__reviews_product">
                        <div class="override__product-info">
                            <div class="override__product-img">
                                <img v-bind:src="product_reviews.image" width="100px" v-bind:alt="product_reviews.title">
                            </div>
                            <div class="override__product-title">
                                <h2>
                                    <a class="alink" v-bind:href="'https://'+shopDomain+'/admin/products/'+product_reviews.id" target="_blank" v-text="product_reviews.title"></a>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="import__reviews_option m-t-25">
                        <div class="reviews__option_default">
                            <label class="checkbox-style checkbox-style-modal" for="default-filter-settings">
                                <input id="default-filter-settings" type="checkbox" v-model="useDefaultReview"/>
                                <span class="checked-style"></span>
                                Use <span class="fw-600 color-skin">Default Fliter Setting</span>
                            </label>
                        </div>
                        <div class="reviews__option_removeall">
                            <label class="checkbox-style checkbox-style-modal" for="remove-all-exits">
                                <input id="remove-all-exits" type="checkbox" v-model="remove_old_reviews"/>
                                <span class="checked-style"></span>
                                Remove all exits reviews
                            </label>
                        </div>
                    </div>

                    <div class="import__reviews_language m-t-25">
                        <div class="import__reviews_max p-r-15">
                            <div class="form-group m-b-0">
                                <label class="fw-500" for="">Max number of reviews</label>
                                <input type="number" min="1" v-model="settings.get_max_number_review" v-on:keydown="checkNumber" v-on:input="handleChangeNumberReviews">
                            </div>
                        </div>
                        <!-- <div v-show="errors['Max_number_get_reviews'] != undefined " role="alert" style="color:red;font-size:12px;font-style: italic">
                            <p>{{ errors['Max_number_get_reviews'] }}</p>
                        </div> -->
                        <div class="import__reviews_country">
                            <div class="form-group m-b-0">
                                <label class="fw-500">Language reviews</label>
                                <select name="language_of_reviews" id="language-of-reviews" multiple class="language-of-reviews" v-model="settings.country_get_review">
                                    <option v-for="(value, key) in alireviews_countries" :value="key">{{ value }}</option>
                                </select>
                            </div>
                        </div>
                        <!-- <div v-show="errors['Country_get_review'] != undefined " role="alert" style="color:red;font-size:12px;font-style: italic">
                            <p>{{ errors['Country_get_review'] }}</p>
                        </div> -->
                    </div>

                    <div v-show="!useDefaultReview">
                        <div class="reviews__star_picture m-t-25">
                            <div class="reviews__star_option">
                                <label class="fw-600 m-b-0">Star Options</label>
                                <div class="m-t-10">
                                    <label class="checkbox-style checkbox-style-modal" for="5-stars-reviews">
                                        <input id="5-stars-reviews" type="checkbox" value="5" v-model="settings.get_only_star"/>
                                        <span class="checked-style"></span>
                                        Get <span class="fw-600 color-skin">5 stars</span> reviews
                                    </label>
                                </div>
                                <div class="m-t-10">
                                    <label class="checkbox-style checkbox-style-modal" for="4-stars-reviews">
                                        <input id="4-stars-reviews" type="checkbox" value="4" v-model="settings.get_only_star"/>
                                        <span class="checked-style"></span>
                                        Get <span class="fw-600 color-skin">4 stars</span> reviews
                                    </label>
                                </div>
                            </div>
                            <div class="reviews__picture_option">
                                <label class="fw-600 m-b-0">Picture options</label>
                                <div class="m-t-10">
                                    <label class="checkbox-style checkbox-style-modal" for="review-with-picture">
                                        <input id="review-with-picture" type="checkbox" value="true" v-model="settings.get_only_picture"/>
                                        <span class="checked-style"></span>
                                        Reviews <span class="fw-600 color-skin">with pictures</span>
                                    </label>
                                </div>
                                <div class="m-t-10">
                                    <label class="checkbox-style checkbox-style-modal" for="review-without-picture">
                                        <input id="review-without-picture" type="checkbox" value="false" v-model="settings.get_only_picture"/>
                                        <span class="checked-style"></span>
                                        Reviews <span class="fw-600 color-skin">without pictures</span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="reviews__content_translate m-t-20">
                            <div class="reviews__content_option">
                                <label class="fw-600 m-b-0">Content options</label>
                                <div class="m-t-10">
                                    <label class="checkbox-style checkbox-style-modal" for="review-with-content">
                                        <input id="review-with-content" type="checkbox" value="true" v-model="settings.get_only_content"/>
                                        <span class="checked-style"></span>
                                        Reviews <span class="fw-600 color-skin">with content</span>
                                    </label>
                                </div>
                                <div class="m-t-10">
                                    <label class="checkbox-style checkbox-style-modal" for="review-without-content">
                                        <input id="review-without-content" type="checkbox" value="false" v-model="settings.get_only_content"/>
                                        <span class="checked-style"></span>
                                        Reviews <span class="fw-600 color-skin">without content</span>
                                    </label>
                                </div>
                            </div>
                            <div class="reviews__translate_option">
                                <label class="fw-600 m-b-0">Translate option</label>
                                <div class="m-t-10">
                                    <label class="checkbox-style checkbox-style-modal" for="using-aliexpress-translate">
                                        <input id="using-aliexpress-translate" type="checkbox" value="1" :false-value="0" :true-value="1" v-model="settings.translate_reviews"/>
                                        <span class="checked-style"></span>
                                        <span class="fw-600 color-skin">English</span> using AliExpress translate
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click.prevent="submitGetReview()">Get Reviews</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
    export  default {
        props: {
            alireviews_default_setting : {
                type: Object,
                default: {}
            },
            shopify_domain: {
                type: String,
                default: ''
            },
            product_reviews: {
                required: true,
                type: Object
            },
            // product_id: {
            //     type: String,
            //     default: ''
            // },
            alireviews_api_url : {
                type: String,
                default: ''
            }
        },
        data(){
            return {
                errors: {},
                settings: Object.assign({}, this.alireviews_default_setting),
                formValid: true,
                productIsReview: false,
                useDefaultReview: true,
                selectedCountries: [],
                alireviews_countries: {},
                remove_old_reviews: false,
                shopDomain: window.shopDomain
            }
        },
        created: function() {
            let _this = this;
            axios.get(appUrl+'/reviews/countries-review')
                .then(function (res) {
                    let data = res.data;
                    if(data.status) {
                        _this.alireviews_countries = data.countries;
                    }
                })
                .catch(function (error) {
                    console.log(error)
                });
        },
        computed: {
            getCountryCode: function () {
                let _this = this;
                return Object.keys(_this.alireviews_countries);
            }
        },
        updated(){
            $('.language-of-reviews').multiselect('rebuild');
        },
        mounted: function() {
            let _this = this;
            $('.language-of-reviews').multiselect(
                {
                    enableHTML: true,
                    enableFiltering: true,
                    includeSelectAllOption: true,
                    nonSelectedText: 'Select language',
                    buttonContainer: '<div class="selected-parents-container"></div>'
                })
                .change(function (event) {
                    _this.settings.country_get_review = $(event.currentTarget).val();
                    _this.validateFormGetReview();
                });
            $('#import-reviews-modal').on('hidden.bs.modal', function () {
               _this.resetDefault();
            })

            $('#import-reviews-modal').on('shown.bs.modal', function () {
                if(_this.product_reviews.id)
                    _this.checkIsReview(_this.product_reviews.id)
            })
        },
        methods: {
            handleChangeNumberReviews: function() {
                let _this = this;
                _this.validateFormGetReview();
            },
            resetDefault: function() {
                let _this = this;
                _this.settings = Object.assign({}, _this.alireviews_default_setting);
                _this.filterSetting(_this.settings);
                _this.remove_old_reviews = false;
                _this.formValid = true;
                _this.errors = {};
            },
            filterSetting: function(settings) {
                let _this = this;
                if( !settings.country_get_review.length) {
                    settings.country_get_review = _this.getCountryCode
                }
                return settings
            },
            filterSettingBeforeSend: function(settings) {
                let _this = this;
                let allCountries = _this.getCountryCode;
                let tmp = Object.assign({}, settings)
                if(tmp.country_get_review.length == allCountries.length) {
                    tmp.country_get_review = []
                }
                tmp.get_max_number_review = parseInt(tmp.get_max_number_review);
                return tmp
            },
            checkNumber: function(event) {
                let _this = this;
                if(event.keyCode === 189 || event.keyCode === 190) {
                    event.preventDefault()
              }
            },
            validateFormGetReview: function() {
                let _this = this;
                _this.formValid = true;
                _this.errors = {};
                if(_this.settings.get_max_number_review > 1500) {
                    _this.formValid = false;
                    _this.errors.Max_number_get_reviews = 'Max reviews per import is 1500';
                }
                if(_this.settings.get_max_number_review == 0 || _this.settings.get_max_number_review === '') {
                    _this.formValid = false;
                    _this.errors.Max_number_get_reviews = 'Max reviews per import must greater than zero';
                }
                if(_this.settings.country_get_review.length === 0) {
                    _this.formValid = false;
                    _this.errors.Country_get_review = 'Please select country';
                }
            },
            submitGetReview: function () {
                let _this = this;
                if(!_this.formValid) {
                    return false;
                }
                let filter_settings = _this.filterSettingBeforeSend(_this.settings)
                let port = chrome.runtime.connect(chromeExtensionId);
                const payloadMessage = {
                    data: {
                        action: 'ACTION_GET_PRODUCTS_REVIEW',
                        payload: {
                            'settings': {
                                'remove_old_reviews': _this.remove_old_reviews,
                                'shop_domain': _this.shopify_domain,
                                'shop_id': window.shopId,
                                'setting': filter_settings
                            },
                            'products': [
                                {
                                    'aliorders_product_id': _this.product_reviews.id,
                                    'aliexpress_product_id': _this.product_reviews.aliexpress_product_id,
                                    'source_product_link': _this.product_reviews.source_product_link,
                                    'product_handle': _this.product_reviews.handle,
                                    'product_image': _this.product_reviews.image,
                                    'product_title': _this.product_reviews.title
                                }
                            ]
                        }
                    }
                };
                port.postMessage(payloadMessage);
                port.disconnect();
                $('#import-reviews-modal').modal('hide');
                notify('success', 'Getting reviews');
            },
            checkIsReview: function (product_id) {
                let _this = this;
                let subDomain = _this.shopify_domain.substr(0, _this.shopify_domain.length - 14);
                let checkProductRequest = _this.alireviews_api_url+'/v1/shops/'+ subDomain +'/products/'+ product_id +'/reviews/exist_import_review';
                fetch(checkProductRequest)
                    .then((response) => response.json())
                    .then((responseJSON) => {
                        let {result, status} = responseJSON;
                        if(status) {
                            _this.productIsReview = result.exists;
                        }
                    })
                    .catch(function (error) {
                        console.log(error)
                    });

            }
        },
        watch: {
            product_reviews: {
                handler: function(val, oldVal) {
                    this.product_reviews = val
                    console.log('val this.product_reviews', this.product_reviews)
                },
                deep: true
            },
            alireviews_countries: function (value) {
                let _this = this;
                if(value) {
                    Object.assign({}, _this.filterSetting(_this.settings));
                }
            }
        }
    }
</script>
