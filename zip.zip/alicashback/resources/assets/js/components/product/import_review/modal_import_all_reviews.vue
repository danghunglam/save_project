<template>
    <!-- Modal -->
    <div id="import-all-reviews-modal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" data-dismiss="modal" class="close"><i class="mdi mdi-close"></i></button>
                    <h4 class="modal-title">Reviews Import Options</h4>
                </div>
                <div class="modal-body">
                    <p>All products from selected page will be updated</p>
                    <div class="bulk__reviews_content">
                        <label class="fw-600 m-b-0">Content options</label>
                        <div class="m-t-10" v-for="options in window.alireviews.multi_product.paged_option">
                            <label class="radio-style radio-style-modal" v-bind:for="'page-options-'+options.value">
                                <input  v-bind:id="'page-options-'+options.value" v-bind:value="options.value" v-model="filters.paged_option" type="radio" />
                                <span class="checked-style"></span>{{ options.label }}
                            </label>
                        </div>
                    </div>

                    <div class="bulk__reviews_content m-t-20">
                        <label class="fw-600 m-b-0">Content options</label>
                        <div class="m-t-10" v-for="options in window.alireviews.multi_product.keep_reviews">
                            <label class="radio-style radio-style-modal" v-bind:for="'keep-reviews-'+options.value">
                                <input v-bind:id="'keep-reviews-'+options.value" type="radio" v-bind:value="options.value" v-model="filters.keep_reviews" />
                                <span class="checked-style"></span>{{ options.label }}
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" type="button" data-dismiss="modal">Cancel</button>
                    <button class="modal__ok_button" type="button" @click.prevent="getReviews" :disabled="is_load" v-text="is_load ? 'Get Reviews...' : 'Get Reviews'">Get Reviews</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
    import install_alireview from './modal_install_alireviews'
    export  default {
        props: ['current_page','shop_id','filters_products','alireviews_default_setting','shopify_domain'],
        data: function() {
            return {
                errors: {},
                filters: {
                    paged_option: 2,
                    keep_reviews: 1,
                    current_page: this.current_page
                },
                oneProductSettings: {
                    'shop_domain': this.shopify_domain,
                    'shop_id': window.shopId,
                    'style': 3,
                    'get_only_picture': [],
                    'get_only_content': [],
                    'get_only_star': [],
                    'get_max_number_review': 200,
                    'country_get_review': [],
                    'except_keyword': '',
                    'translate_reviews': 1
                },
                window: window,
                shop_id : this.shop_id,
                shop_domain:this.shopify_domain,
                is_load: false,
                alireviews_default_setting: this.alireviews_default_setting
            }
        },
        mounted: function () {
            // this.form_options = this.window.
            console.log(this.window)
        },
        components: {
            install_alireview
        },

        methods: {
            getReviews: function () {
                let _this = this
                _this.is_load = true

                let checkProductId=''
                //get Product
                axios.get(appUrl+'/products/place/all', {
                    params: {
                        filters_products:_this.filters_products,
                        filters_options:_this.filters
                    }
                }).then(function(response) {

                    if( ! checkExtension())
                        return false

                    _this.is_load = false
                    if(response.data.status){

                        //response.data.products.settings.push(_this.oneProductSettings)
                        response.data.products.settings.setting = _this.alireviews_default_setting
                        response.data.products.settings.shop_id = _this.shop_id
                        response.data.products.settings.shop_domain = _this.shopify_domain

                        console.log(response.data.products)

                        let port = chrome.runtime.connect(chromeExtensionId);
                        const payloadMessage = {
                            data: {
                                action: 'ACTION_GET_PRODUCTS_REVIEW',
                                payload: response.data.products
                            }
                        }
                        port.postMessage(payloadMessage);
                        port.disconnect()
                        $('#import-all-reviews-modal').modal('hide')
                        notify('success', 'Get reviews success')
                    }else {
                        if( response.data.products==null || response.data.products.products.length <=0 ){
                            $('#import-all-reviews-modal').modal('hide')
                            notify('error', 'Product is null');
                        }
                    }

                }).catch(function(error) {
                    _this.is_load = false
                    console.log(error)
                })
            },
            getSetting:function (shop_id) {
                let _this = this
                axios.get(appUrl+'/setting_review/'+shop_id).then(function (response) {
                    _this.settings = [response.data.data]
                    console.log(_this.settings)
                })
            },
        },
    }
</script>