<template>
    <div id="popup-install-alireview" class="modal fade popup-install-app-alireview" role="dialog">
        <div class="modal-dialog modal-xs">
            <!-- Modal content-->
            <div class="modal-content modal__content_icon">
                <div class="modal-header">
                    <button class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <div class="modal__header_icon">
                        <span>
                            <i class="mdi-emoticon-chrome">
                                <img v-bind:src="appUrl+'/images/backend/alireviews_logo.png'" alt="">
                            </i>
                        </span>
                    </div>
                </div>
                <div class="modal-body">
                    <h2 class="modal__body_title">Ali Reviews Require!</h2>
                    <p>Please install <b>Ali Reviews</b> to continue<br/>importing reviews for this product</p>
                </div>
                <div class="modal-footer">
                    <button class="modal__cancel_button" data-dismiss="modal">Cancel</button>
                    <a class="modal__ok_button" href="https://apps.shopify.com/ali-reviews" target="_blank">Install Now</a>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                appUrl: window.appUrl,
                alireviews_url : window.alireviews_url,
            }
        }
    }
</script>