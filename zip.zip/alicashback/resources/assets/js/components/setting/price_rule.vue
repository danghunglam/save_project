<template>
    <div>
        <div id="settings-pricing-rules" class="settings-pricing-rules-wrap">
            <!-- <label class="switch-style" for="advanced-pricing-rules">
                <input id="advanced-pricing-rules" type="checkbox"  >
                <span class="switch-button">
                    <span class="fz-15 fw-600">Advanced pricing rules<br/><span class="fz-13 fw-400">Set your product markup depending on cost ranges.</span></span>
                    <span class="fz-15 fw-600">Advanced pricing rules<br/><span class="fz-13 fw-400">Set your product markup depending on cost ranges.</span></span>
                </span>
            </label> -->
            <div class="pricing-rules-block pricing-rules-block-header">
                <div class="row-pricing-rules">
                    <div class="col-pricing-rules">
                        <p class="pricing-rules-title">Product Cost</p>
                    </div>
                    <div class="col-pricing-rules">
                        <p class="pricing-rules-title">
                            Product Price
                            <span class="tooltip-style-wrap color-skin" data-toggle="tooltip" title="The Price value is calculated based on Cost value">
                                <i class="mdi mdi-alert-circle"></i>
                            </span>
                        </p>
                    </div>
                    <div class="col-pricing-rules">
                        <label class="checkbox-style pricing-rules-title" for="pricing_compared_price">
                            <input id="pricing_compared_price" type="checkbox" :checked="is_compared_price" @click="checkIsComparedPrice">
                            <span class="checked-style"></span>
                            Compare At Price
                            <span class="tooltip-style-wrap color-skin" data-toggle="tooltip" title="The Compare At Price value is calculated based on Cost value">
                                <i class="mdi mdi-alert-circle"></i>
                            </span>
                        </label>
                    </div>
                    <div class="col-pricing-rules col-pricing-rules-delete">
                        <p class="pricing-rules-title">Delete</p>
                    </div>
                </div>
            </div>

            <div class="pricing-rules-block pricing-rule-block-count" v-for="(price, k) in price_rule" v-bind:key="k">
                <div class="row-pricing-rules">
                    <div class="col-pricing-rules">
                        <div class="row-cost-range">
                            <div class="col-xs-6">
                                <div class="input-group" v-bind:class="{'form-group-errors': (settings_errors['price_rule'][k] && typeof settings_errors['price_rule'][k].min !== 'undefined' && (price.min < 0 || price.min === '') )}">
                                    <input type="text" step="0.01" class="form-control cost_range_min" @keyup="isNumberKeyup($event, k, 'min')" @keypress="isNumber($event)" @blur="validPricesRule()" v-model="price.min" data-toggle="tooltip" v-bind:title="price.min + 'x'">
                                    <span class="input-group-addon">USD</span>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="input-group" v-bind:class="{'form-group-errors': (settings_errors['price_rule'][k] && typeof settings_errors['price_rule'][k].max !== 'undefined' && price.max <= 0)}">
                                    <input type="text" step="0.01" class="form-control cost_range_max" @keyup="isNumberKeyup($event, k, 'max')" @keypress="isNumber($event)" @blur="validPricesRule()" v-model="price.max">
                                    <span class="input-group-addon">USD</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-pricing-rules">
                        <div class="cost_range_item_price_block">
                            <div class="input-group" v-bind:class="{'form-group-errors': (settings_errors['price_rule'][k] && typeof settings_errors['price_rule'][k].item_price !== 'undefined' && price.item_price <= 0)}">
                                <input type="text" step="0.01" class="form-control form-control-select cost_range_item_price" @keyup="isNumberKeyup($event, k, 'item_price')" @keypress="isNumber($event)" :disabled="disableItemPrice(price, k)" v-model="price.item_price">
                                <span class="input-group-addon input-group-addon-select">
                                    <div class="select-style">
                                        <select v-model="price.item_price_type">
                                            <option value="multiply">Multiply</option>
                                            <option value="plus">Plus</option>
                                        </select>
                                    </div>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-pricing-rules">
                        <div class="cost_range_compared_price_block"  v-show="is_compared_price">
                            <div class="input-group" v-bind:class="{'form-group-errors' : (settings_errors['price_rule'][k] && typeof settings_errors['price_rule'][k].compared_price !== 'undefined' && price.compared_price <= 0)}">
                                <input type="text" step="0.01" class="form-control form-control-select cost_range_compared_price" @keyup="isNumberKeyup($event, k, 'compared_price')" @keypress="isNumber($event)" :disabled="disableItemPrice(price, k)" v-model="price.compared_price">
                                <span class="input-group-addon input-group-addon-select">
                                <div class="select-style">
                                    <select v-model="price.compared_price_type">
                                        <option value="multiply">Multiply</option>
                                        <option value="plus">Plus</option>
                                    </select>
                                </div>
                            </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-pricing-rules col-pricing-rules-delete">
                        <span class="delete-pricing-rules-btn" @click.prevent="deletePricingRules(k)">
                            <i class="mdi mdi-delete-forever"></i>
                        </span>
                    </div>
                </div>

            </div>


            <!--Rest of cost range-->
            <div class="pricing-rules-block rest-of-pricing-rules-block">
                <div class="row-pricing-rules">
                    <div class="col-pricing-rules">
                        <div class="rest-cost-range-wrap">
                            <p>
                                Rest of the price ranges
                                <!--<span class="tooltip-style-wrap color-skin" data-toggle="tooltip" title="These markups will be used for the rest of the price ranges">-->
                                    <!--<i class="mdi mdi-alert-circle"></i>-->
                                <!--</span>-->
                            </p>
                        </div>
                    </div>
                    <div class="col-pricing-rules">
                        <div class="input-group" v-bind:class="{'form-group-errors': (settings_errors['rest_of_the_price_ranges'] && typeof settings_errors['rest_of_the_price_ranges'].item_price !== 'undefined' && rest_of_the_price_ranges.item_price <= 0)}">
                            <input type="text" class="form-control form-control-select rest_cost_range_item_price" @keyup="isNumberRestKeyup($event, 'item_price')" @keypress="isNumber($event)" v-model="rest_of_the_price_ranges.item_price">
                            <span class="input-group-addon input-group-addon-select">
                                <div class="select-style">
                                    <select v-model="rest_of_the_price_ranges.item_price_type">
                                        <option value="multiply">Multiply</option>
                                        <option value="plus">Plus</option>
                                    </select>
                                </div>
                            </span>
                        </div>
                    </div>
                    <div class="col-pricing-rules">
                        <div class="cost_range_compared_price_block" v-show="is_compared_price">
                            <div class="input-group" v-bind:class="{'form-group-errors' : (settings_errors['rest_of_the_price_ranges'] && typeof settings_errors['rest_of_the_price_ranges'].compared_price !== 'undefined' && rest_of_the_price_ranges.compared_price <= 0)}">
                                <input type="text" class="form-control form-control-select rest_cost_range_compared_price" @keyup="isNumberRestKeyup($event, 'compared_price')" @keypress="isNumber($event)" v-model="rest_of_the_price_ranges.compared_price">
                                <span class="input-group-addon input-group-addon-select">
                                    <div class="select-style">
                                        <select v-model="rest_of_the_price_ranges.compared_price_type">
                                            <option value="multiply">Multiply</option>
                                            <option value="plus">Plus</option>
                                        </select>
                                    </div>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="col-pricing-rules col-pricing-rules-delete">
                    </div>
                </div>
            </div>
        </div>
        <div class="button-add-cost-range" style="margin-top: 12px;">
            <span class="button-style-sm-o" @click="addPriceRule">+ Add cost range</span>
        </div>


        <div v-if="(message_validate_price_rule.length > 0)" class="alert alert-danger" role="alert" style="margin-top: 25px">
            <ul>
                <li v-for="message in message_validate_price_rule">
                    {{ message }}
                </li>
            </ul>
        </div>
    </div>
</template>

<script type="text/javascript">
    export default {
        props: {
            price_rule : {
                required: false,
                default: [{
                    min: 0,
                    max: 10,
                    item_price: 1.5,
                    compared_price: 2,
                    item_price_type: 'multiply',
                    compared_price_type: 'multiply'
                }]
            },
            rest_of_the_price_ranges: {
                required: false,
                default: {
                    item_price : 1.5,
                    compared_price : 2,
                    item_price_type: 'multiply',
                    compared_price_type: 'multiply'
                }
            },
            is_compared_price: {
                required: false,
                default: false
            },
            settings_errors: {
                required: false
            }
        },
        data: () => {
            return {
                price_rule_plus : {
                    min: 0,
                    max: 0,
                    item_price: 0,
                    compared_price: 0,
                    item_price_type: 'multiply',
                    compared_price_type: 'multiply'
                },
                init_price_rule_plus: false,
                message_validate_price_rule: [],
                maxRule: 20
            }
        },
        mounted: function () {
            this.setPriceRule()
            this.setRestPriceRule()
            $('[data-toggle="tooltip"]').tooltip({
                html: true,
                container: 'body'
            });
        },

        methods: {
            setPriceRule: function () {
                this.price_rule = this.price_rule.map(function (rule) {
                    return {
                        min: rule.min,
                        max: rule.max,
                        item_price: rule.item_price,
                        compared_price: rule.compared_price,
                        item_price_type: rule.item_price_type ? rule.item_price_type : 'multiply',
                        compared_price_type: rule.compared_price_type ? rule.compared_price_type : 'multiply'
                    }
                })
            },
            setRestPriceRule: function () {
                this.rest_of_the_price_ranges = {
                    min: this.rest_of_the_price_ranges.min,
                    max: this.rest_of_the_price_ranges.max,
                    item_price: this.rest_of_the_price_ranges.item_price,
                    compared_price: this.rest_of_the_price_ranges.compared_price,
                    item_price_type: this.rest_of_the_price_ranges.item_price_type ? this.rest_of_the_price_ranges.item_price_type : 'multiply',
                    compared_price_type: this.rest_of_the_price_ranges.compared_price_type ? this.rest_of_the_price_ranges.compared_price_type : 'multiply'
                }
            },
            deletePricingRules: function(k) {
                let price_rule = []
                for(let i = 0; i < this.price_rule.length; i++)
                {
                    if(i !== k)
                        price_rule.push(this.price_rule[i])
                }
                this.price_rule = price_rule
                this.validPricesRule();
                this.$emit('price_rule', this.price_rule)
            },
            disableItemPrice: function (price, key) {
                if(key === 0)
                    return ! (parseFloat(price.min) >= 0 && parseFloat(price.max) > parseFloat(price.min))
                else
                    return ! (parseFloat(price.min) > 0 && parseFloat(price.max) > parseFloat(price.min))
            },
            addItemPrice: function (price_rule_plus) {
                let lastPriceRuleMax = typeof _.last(this.price_rule) !== 'undefined' ? _.last(this.price_rule).max : 0;
                if((parseFloat(price_rule_plus.max) > parseFloat(price_rule_plus.min)) && parseFloat(price_rule_plus.min) && parseFloat(price_rule_plus.min) > lastPriceRuleMax ) {
                    this.price_rule.push({
                        min: price_rule_plus.min,
                        max: price_rule_plus.max,
                        item_price: price_rule_plus.item_price,
                        compared_price: price_rule_plus.compared_price,
                        item_price_type: 'multiply',
                        compared_price_type: 'multiply'
                    })
                }
            },
            validPricesRule: function() {
                this.message_validate_price_rule = []
                let prices = this.price_rule
                let price_plus = this.price_rule_plus

                for (let i = 0; i < prices.length; i++)
                {
                    if( parseFloat(prices[i].min) > parseFloat(prices[i].max) )
                    {
                        this.message_validate_price_rule.push('Cost range end value must be greater than the starting value.')
                    }
                    if(i > 0) {
                        if( parseFloat(prices[i]['min']) < parseFloat(prices[i-1]['max']) )
                        {
                            this.message_validate_price_rule.push('Your ranges overlap.')
                        }
                    }
                }
                this.$emit('valid_price_rule', this.message_validate_price_rule)
            },
            checkIsComparedPrice: function (event) {
                const currentTarget = $(event.currentTarget)
                let is_compared_price = currentTarget.prop('checked')
                this.$emit('check_is_compared_price', is_compared_price)
            },
            isNumber: function(evt) {
                evt = (evt) ? evt : window.event;
                let charCode = (evt.which) ? evt.which : evt.keyCode;
                if ((charCode >= 48 && charCode <= 57) || charCode === 46) {
                    return true
                } else {
                    evt.preventDefault()
                }
            },
            isNumberKeyup: function(event, key, name) {
                let val = $(event.currentTarget).val()
                // if(isNaN(val)){
                //     this.price_rule[key][name] = val.substr(0,val.length-1)
                //     return false
                // }
                let str_split = val.split('.');
                if(str_split[0] == '') {
                    this.rest_of_the_price_ranges[name] = ''
                }
                if( str_split[1] != undefined && (str_split[1].length >= 3 || str_split.length > 2)) {
                    let last = str_split[1].slice(0, 2)
                    let first = str_split[0] + '.'
                    val = first.concat(last)
                    this.price_rule[key][name] = val
                }
            },
            isNumberRestKeyup: function(event, name) {
                let val = $(event.currentTarget).val()
                // if(isNaN(val)){
                //     console.log('val', val)
                //     this.rest_of_the_price_ranges[name] = val.substr(0,val.length-1)
                //     return false
                // }
                let str_split = val.split('.');
                if(str_split[0] == '') {
                    this.rest_of_the_price_ranges[name] = ''
                }
                if( str_split[1] != undefined && (str_split[1].length >= 3 || str_split.length > 2)) {
                    let last = str_split[1].slice(0, 2)
                    let first = str_split[0] + '.'
                    val = first.concat(last)
                    this.rest_of_the_price_ranges[name] = val
                }
            },
            addPriceRule() {
                if(this.price_rule.length < this.maxRule) {
                    let min = ''
                    if(this.price_rule.length > 0 && _.last(this.price_rule).max) {
                        min = (parseFloat(_.last(this.price_rule).max) + 0.01).toFixed(2)
                    }

                    this.price_rule.push({
                        min: min,
                        max: '',
                        item_price: '',
                        compared_price: '',
                        item_price_type: 'multiply',
                        compared_price_type: 'multiply'
                    });
                } else {
                    this.$emit('show_notify', {type: 'error', content: 'You can only create up to ' + this.maxRule.toString() + ' rules'})
                }
            },
        },
        watch: {
            price_rule: {
                handler(new_price_rule) {
                    let _this = this
                    this.validPricesRule()
                    this.$emit('price_rule', new_price_rule)
                },
                deep: true
            },
            rest_of_the_price_ranges: {
                handler(new_rest_of_the_price_ranges) {
                    let _this = this
                    this.$emit('rest_of_price_ranges', new_rest_of_the_price_ranges)
                },
                deep: true
            },
            settings_errors: {
                handler(val) {
                    this.settings_errors = val
                },
                deep: true
            }
        }
    }
</script>
