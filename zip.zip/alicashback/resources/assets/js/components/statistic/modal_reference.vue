<template>
    <div id="modal-show-more-reference" class="modal fade" role="dialog">
        <!-- Modal Add Variant Product -->
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content modal-content-add-aliexpress">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <h4 class="modal-title">Reference</h4>
                </div>
                <div class="modal-body">
                    <div v-show="orders.length === 0">
                        Loading...
                    </div>
                    <div v-show="orders.length !== 0">
                        <div class="statistic-reference-table">
                            <div class="ars-table">
                                <div class="ars-table-head">
                                    <div class="ars-table-col">Date</div>
                                    <div class="ars-table-col">Total Orders</div>
                                    <div class="ars-table-col">Sales</div>
                                    <div class="ars-table-col">Cost</div>
                                    <!-- <div class="ars-table-col">Earning</div> -->
                                </div>
                                <div class="ars-table-body">
                                    <div class="ars-table-row" v-for="order in orders">
                                        <div class="ars-table-col" v-text="order.time"></div>
                                        <div class="ars-table-col" v-text="order.order"></div>
                                        <div class="ars-table-col" v-text="'$'+order.sale"></div>
                                        <div class="ars-table-col" v-text="'$'+order.cost"></div>
                                        <!-- <div class="ars-table-col" v-text="'$'+order.earning"></div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pagination-wrap" v-show="pages > 1 && isLoading === false">
                            <pagination
                                    :pagination="{total : total_order, last_page: pages, current_page: paged}"
                                    :offset="6"
                                    @paginate="clickPagination"></pagination>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
    import pagination from '../common/pagination'
    export default {
        data: function () {
            return {
                between_date: 0,
                orders: [],
                paged: 1,
                pages: 0,
                isLoading: false,
                per_page : 10
            }
        },
        created: function () {
            let _this = this
            this.getTotalOrder()
        },
        components: {
            pagination
            // Pagination
        },
        methods: {
            getTotalOrder: function() {
                let _this = this
                axios.get(aliorders_es+'/api/order/get_min_max_date/'+window.shopId)
                    .then(function(response) {
                        let { status = false, min_date = null, max_date = null, days = 0 } =  response.data
                        if(status) {
                            _this.between_date = days
                            _this.pages = Math.ceil(_this.between_date/_this.per_page)
                            setTimeout(function() {
                                _this.getReference()
                            }, 0)

                        }
                    })
            },
            getReference: function (paged = 1) {
                let _this = this
                let plus_to = null
                let plus_from = null
                if(paged === 1) {
                    plus_to = this.per_page * paged - this.per_page
                    plus_from = this.per_page * paged
                }
                else {
                    plus_to = this.per_page * paged - this.per_page + 1
                    plus_from = this.per_page * paged
                }
                

                let date_to = moment(this.date_to).add(-plus_to, 'day').format('YYYY/MM/DD');
                let date_from = moment(this.date_to).add(-plus_from, 'day').format('YYYY/MM/DD');

                _this.orders = []
                axios.post(aliorders_es+'/api/order/reference_history', {shop: window.shopId ,from: date_from, to: date_to})
                    .then(function (response) {
                        let { status = true, dateList = [], orders = [], revenue = [], cost = [], earning = [] } = response.data
                        dateList = dateList.reverse()
                        orders = orders.reverse()
                        revenue = revenue.reverse()
                        cost = cost.reverse()
                        earning = earning.reverse()
                        _this.orders = []
                        dateList.forEach(function (date, key) {
                            _this.orders.push({
                                time: date,
                                order: orders[key],
                                sale: revenue[key],
                                cost: cost[key],
                                earning: earning[key],
                            })
                        })
                        _this.isLoading = false
                    })
                    .catch(function(error) {
                        _this.isLoading = false
                    })


            },
            clickPagination: function (paged) {
                if(!this.isLoading) {
                    this.isLoading = true
                    this.paged = paged
                    this.getReference(paged)
                }
                
            }
        }
    }
</script>
