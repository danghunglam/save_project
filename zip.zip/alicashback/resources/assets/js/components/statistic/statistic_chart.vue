<template>
    <div class="statistic-chart-wrap">
        <div class="statistic-chart-header">
            <div class="revenue-chart-wrap">
                <div class="revenue-chart-total-head">
                    <p>Statistic</p>
                    <div class="filter-date-wrap">

                        <div class="filter-order-date" style="margin-right: 20px">
                            <div class="order-date-form">
                                <input id="filter_date_from" v-model="date_from" name="filter_date_from"  class="datepicker" type="button">
                            </div>
                            <span class="order-date-dash">-</span>
                            <div class="order-date-to">
                                <input id="filter_date_to" v-model="date_to" name="filter_date_to"  class="datepicker" type="button">
                            </div>
                            <div class="filter-order-date-dropdown" @click="showFilterDatePicker">
                                <span><i class="mdi mdi-chevron-down"></i></span>
                            </div>
                            <div id="filter-date-time-picker" style="padding-bottom: 20px" v-show="show_filter_date_picker">
                                <div id="filter-date-time-picker-from"></div>
                                <div id="filter-date-time-picker-to"></div>
                                <div id="filter-date-time-apply">
                                    <button type="button" @click="filterOrdersDate">Apply</button>
                                </div>
                            </div>
                        </div>

                        <div class="order-filter-range-date">
                            <select class="chosen-single-date-range">
                                <option v-for="(range, key) in date_ranges" v-bind:value="key" v-text="range"></option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="canvas-line-chart-wrap">
                    <canvas id="canvas-line-chart" style="height:300px; width:100%"></canvas>
                    <div id="legend-line-chart" class="legend"></div>
                    <div id="chartjs-tooltip" class="chartjs-tooltip">
                        <table></table>
                    </div>
                </div>
            </div>
        </div>
        <!--<div class="line-scale-loader-wrap" v-show="chart_loading">
            <line-scale-loader color="#f63665" size="24px"></line-scale-loader>
        </div>-->

        <div class="line-scale-loader-wrap flex-box" v-show="chart_loading">
            <vue_loaders_circle loading="Loading..."></vue_loaders_circle>
        </div>
    </div>
</template>

<script type="text/javascript">
    import {chart_line} from "../../option_chart";
    import 'vue-loaders/dist/vue-loaders.css';
    import { LineScaleLoader } from 'vue-loaders';
    import vue_loaders_circle from '../../components/common/vue_loaders_circle'
    export default {
        props: ['chart_loading'],
        data: function () {
            return {
                date_ranges : {
                    '' : 'Select date range',
                    last_7days : 'Last 7 days',
                    last_30days : 'Last 30 days',
                    last_90days : 'Last 90 days',
                    week_to_date : 'Week to date',
                    month_to_date : 'Month to date',
                    year_to_date : 'Year to date'
                },
                date_range : '',
                show_filter_date_picker: false,
                date_from : moment(this.date_to).add(-30, 'day').format('MMM DD, YYYY'),
                date_to   : moment().format('MMM DD, YYYY'),
            }
        },
        mounted: function () {

            let _this = this

            $('#filter_date_from').datetimepicker({
                widgetParent: '#filter-date-time-picker-from',
                format: 'MMM DD, YYYY',
                keepOpen: true,
                debug: true,
                inline: true,
                sideBySide: true,
                /*maxDate: date.getMonth()+' '+date.getDate()+', '+date.getFullYear()*/
            });

            /*$('#filter_date_from').daterangepicker({
                autoUpdateInput: false,
                locale: {
                    cancelLabel: 'Clear'
                }
            });*/

            $('#filter_date_to').datetimepicker({
                widgetParent: '#filter-date-time-picker-to',
                format: 'MMM DD, YYYY',
                keepOpen: true,
                debug: true,
                inline: true,
                sideBySide: true,
                /*maxDate: date.getMonth()+' '+date.getDate()+', '+date.getFullYear()*/
            });

            $("#filter_date_from").on("dp.change", function (e) {
                _this.date_from = e.date.format('MMM DD, YYYY')
                /*_this.chart_loading = true;*/
                // _this.renderChart(_this.date_from, _this.date_to)
                $('#filter_date_to').data("DateTimePicker").minDate(e.date);
            });

            $("#filter_date_to").on("dp.change", function (e) {
                _this.date_to = e.date.format('MMM DD, YYYY')
                /*_this.chart_loading = true;*/
                // _this.renderChart(_this.date_from, _this.date_to)
            });
            // $('#filter_date_from').datepicker({
            //     format: 'yyyy-mm-dd',
            //     autoclose: true
            // }).change(function (event) {
            //     let current = $(event.currentTarget)
            //     _this.date_from = current.val()
            //     _this.chart_loading = true;
            //     _this.renderChart(_this.date_from, _this.date_to)
            // })
            // $('#filter_date_to').datepicker({
            //     format: 'yyyy-mm-dd',
            //     autoclose: true
            // }).change(function (event) {
            //     let current = $(event.currentTarget)
            //     _this.date_to = current.val()
            //     _this.chart_loading = true;
            //     _this.renderChart(_this.date_from, _this.date_to)
            // })

            $('.chosen-single-date-range').multiselect({
                enableHTML: true,
                nonSelectedText: 'Select date range',
                buttonContainer: '<div class="selected-parents-container select-no-checked"></div>',
            }).change(function (event) {
                let current = $(event.currentTarget);
                _this.date_range = current.val();
                _this.date_now = moment().format();
                _this.date_to = moment().format('MMM DD, YYYY');

                switch (_this.date_range) {
                    case 'today' :
                        _this.date_to = _this.date_from = moment().format('MMM DD, YYYY');
                        break;
                    case 'yesterday' :
                        _this.date_from = _this.date_to = moment().add(-1, 'day').format('MMM DD, YYYY');
                        break;
                    case 'last_7days' :
                        _this.date_from = moment(_this.date_now).add(-7, 'days').format('MMM DD, YYYY');
                        break;
                    case 'last_30days' :
                        _this.date_from = moment(_this.date_now).add(-30, 'days').format('MMM DD, YYYY');
                        break;
                    case 'last_90days' :
                        _this.date_from = moment(_this.date_now).add(-90, 'days').format('MMM DD, YYYY');
                        break;
                    case 'week_to_date':
                        _this.date_from = moment(_this.date_now).add(-1, 'week').format('MMM DD, YYYY');
                        break;
                    case 'month_to_date' :
                        _this.date_from = moment(_this.date_now).add(-30, 'day').format('MMM DD, YYYY');
                        break;
                    case 'year_to_date' :
                        _this.date_from = moment(_this.date_now).add(-1, 'year').format('MMM DD, YYYY');
                        break;
                    default :
                        _this.date_from = moment(_this.date_now).add(-30, 'days').format('MMM DD, YYYY');
                        break;
                }
                $('#filter_date_from').val(_this.date_from);
                $('#filter_date_to').val(_this.date_to);
                _this.date_range = ''
                _this.chart_loading = true;
                _this.renderChart(_this.date_from, _this.date_to)
            });

            $(document.body).on('click', function(event) {
                if (!$(event.target).closest('.filter-order-date').length) {
                    _this.show_filter_date_picker = false
                }
            });
        },
        methods: {
            renderChart: function (from, to) {
                let _this = this;
                axios.post(aliorders_es+'/api/order/aggregations_date_histogram', {shop:window.shopId, from: from, to: to})
                    .then(function (response) {
                        let { status = true, dateList = [], orders = [], revenue = [], cost = [], earning = [] } = response.data
                        if( ! status)
                            console.log('Cannot load data')

                        //Build chart statistic

                        let chart_statistic = Object.assign({}, {
                            data: {
                                labels: dateList,
                                datasets: [
                                    {
                                        data: revenue,
                                    },
                                    {
                                        data: cost,
                                    },
                                    {
                                        data: earning,
                                    }
                                ]
                            }
                        })
                        _this.$emit('chart_statistic', chart_statistic);
                        _this.chart_loading = false
                    })
                    .catch(function (error) {
                        console.log(error)
                    })
            },
            choiceDateRange: function () {
                // console.log('choice date range')
            },
            showFilterDatePicker: function() {
                if(this.show_filter_date_picker == true)
                    this.show_filter_date_picker = false
                else
                    this.show_filter_date_picker = true
            },
            filterOrdersDate: function () {
                if(this.show_filter_date_picker == true)
                    this.show_filter_date_picker = false
                else
                    this.show_filter_date_picker = true

                /*select data range no value*/
                $('.chosen-single-date-range').multiselect('select',Object.keys(this.date_ranges)[0],true);
                $('.chosen-single-date-range').multiselect('refresh')
                this.renderChart(this.date_from, this.date_to)
            }

        },
        components: {
            'line-scale-loader': LineScaleLoader,
            'vue_loaders_circle': vue_loaders_circle
        }
    }
</script>
