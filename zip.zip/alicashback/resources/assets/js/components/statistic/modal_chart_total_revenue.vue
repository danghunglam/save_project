<template>
    <div id="modal-chart-revenue" class="modal fade" role="dialog">
        <!--Modal Add Variant Product-->
        <div class="modal-dialog modal-full-60">
            <!-- Modal content-->
            <div class="modal-content modal-content-add-aliexpress">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><i class="icon-ali icon-ic-highlight-off-24px"></i></button>
                    <h4 class="modal-title">This Month Revenue</h4>
                </div>
                <div class="modal-body">
                    <div class="canvas-line-chart-wrap">
                        <canvas id="canvas-chart-revenue" style="height:350px; width:100%"></canvas>
                        <div id="legend-line-chart-revenue" class="legend"></div>
                        <div id="chartjs-tooltip-revenue" class="chartjs-tooltip">
                            <table></table>
                        </div>
                    </div>
                    <div class="line-scale-loader-wrap" v-show="chart_modal_loading">
                        <line-scale-loader color="#f63665" size="24px"></line-scale-loader>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>

<script type="text/javascript">
    import 'vue-loaders/dist/vue-loaders.css';
    import { LineScaleLoader } from 'vue-loaders';

    export default {
        props: ['chart_modal_loading'],
        created: function () {

        },
        components: {
            'line-scale-loader': LineScaleLoader,
        }
    }
</script>
