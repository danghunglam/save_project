<template>
    <div id="modal-show-more-sale-report" class="modal-show-more-sale-report modal fade" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content modal-content-add-aliexpress">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><i class="mdi mdi-close"></i></button>
                    <h4 class="modal-title">Sale Report</h4>
                </div>
                <div class="modal-body">
                    <div class="statistic-sale-report">
                        <div class="table-product">
                            <div class="ars-table">
                                <div class="ars-table-head">
                                    <div class="ars-table-col">PRODUCT</div>
                                    <div class="ars-table-col">AVAILABILITY</div>
                                    <div class="ars-table-col">TOTAL</div>
                                </div>
                                <div class="ars-table-body">
                                    <div class="ars-table-row">
                                        <div class="ars-table-col">
                                            <a href="">
                                                <img v-bind:src="appURL+'/images/statistic/sale-report-product.png'" alt="sale report product">
                                                <span>Women’s Vintage Peacoat</span>
                                            </a>
                                        </div>
                                        <div class="ars-table-col"><span class="availability instock">320 In Stock</span></div>
                                        <div class="ars-table-col">$29,192</div>
                                    </div>
                                    <div class="ars-table-row">
                                        <div class="ars-table-col">
                                            <a href="">
                                                <img v-bind:src="appURL+'/images/statistic/sale-report-product.png'" alt="sale report product">
                                                <span>Women’s Vintage Peacoat</span>
                                            </a>
                                        </div>
                                        <div class="ars-table-col"><span class="availability outstock">Out Stock</span></div>
                                        <div class="ars-table-col">$29,192</div>
                                    </div>
                                    <div class="ars-table-row">
                                        <div class="ars-table-col">
                                            <a href="">
                                                <img v-bind:src="appURL+'/images/statistic/sale-report-product.png'" alt="sale report product">
                                                <span>Women’s Vintage Peacoat</span>
                                            </a>
                                        </div>
                                        <div class="ars-table-col"><span class="availability instock">320 In Stock</span></div>
                                        <div class="ars-table-col">$29,192</div>
                                    </div>
                                    <div class="ars-table-row">
                                        <div class="ars-table-col">
                                            <a href="">
                                                <img v-bind:src="appURL+'/images/statistic/sale-report-product.png'" alt="sale report product">
                                                <span>Women’s Vintage Peacoat</span>
                                            </a>
                                        </div>
                                        <div class="ars-table-col"><span class="availability instock">320 In Stock</span></div>
                                        <div class="ars-table-col">$29,192</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/javascript">
    export default {
        data() {
            return {
                appURL: window.appUrl
            }
        }

    }
</script>
