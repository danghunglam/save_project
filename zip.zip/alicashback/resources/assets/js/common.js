import swal from 'sweetalert2'

localStorage.removeItem('CHECK_INSTALL_EXTENSION')
localStorage.removeItem('CHECK_INSTALL_REFRESH')

window.jsUcfirst = function(string)
{
    let char = '';
    if(string)
        char =  string.charAt(0).toUpperCase() + string.slice(1);

    return char
};

/**
 * Valid number
 * @param number
 * @returns {boolean}
 */
window.validNumber = function (number) {
    let regex = RegExp('^[0-9]+(\.)?[0-9]*$')
    return regex.test(number)
    // return ! isNaN(parseFloat(number)) && isFinite(number) && parseFloat(number) > 0
};

/**
 * Valid aliexpress url
 * @param aliexpress
 * @returns {boolean}
 */
window.aliexpressValidateUrl =  function (aliexpress) {
    const pattern = /^((http:\/\/)|(https:\/\/))((www\.)|(ru\.)|(pt\.)|(es\.)|(fr\.)|(de\.)|(it\.)|(nl\.)|(tr\.)|(ja\.)|(ko\.)|(th\.)|(vi\.)|(ar\.)|(he\.)|(pl\.))(aliexpress\.com\/)((item\/)|(store\/product\/)|(store\/product\/-\/)|(item\/\/)|(item\/-\/))\w/;
    return pattern.test(aliexpress);
};
//Convert utf-8 to ascii
window.change_alias = function(str) {
    if( ! str)
        return ''

    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ|ï/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ|ü/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "A");
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "E");
    str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "I");
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "O");
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ|Ü/g, "U");
    str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "Y");
    str = str.replace(/Đ/g, "D");
    str = str.replace(/ç/g, "c");
    str = str.replace(/Ç/g, "C");
    return str;
};


window.checkExtension = function() {
    if ( ! is_chrome){
        if($('#modal-chrome-extension').length > 0)
            $('#modal-chrome-extension').modal('show')
        return false;
    } else{
        const { extensionAliOdersId = false } = window;
        if ( ! extensionAliOdersId || (extensionAliOdersId && (extensionAliOdersId != chromeExtensionId))) {
            if($('#modal-chrome-extension').length > 0)
                $('#modal-chrome-extension').modal('show')
            // if($('.inline-install-chrome-extension').length > 0)
            //     $('.inline-install-chrome-extension').show();
            // show pop up extension
            return false;
        }
    }

    return true
};

window.checkAlireviewsExtension = function() {
    if ( ! is_chrome){
        if($('#modal-chrome-extension').length > 0)
            $('#modal-chrome-extension').modal('show')
        return false;
    } else{
        const { extensionId = false } = window;
        if ( ! extensionId || (extensionId && (extensionId != chromeAlireviewsExtensionId))) {
            if($('#modal-alireview-extension').length > 0)
                $('#modal-alireview-extension').modal('show')
            // if($('.inline-install-chrome-extension').length > 0)
            //     $('.inline-install-chrome-extension').show();
            // show pop up extension
            return false;
        }
    }

    return true
};

const checkTimeout = setTimeout(function(){
    const { extensionAliOdersId = false } = window;
    if ( ! extensionAliOdersId || (extensionAliOdersId && (extensionAliOdersId != chromeExtensionId))) {
        $("#extension-install-on-page").css({ 'display': 'block' });
    }
    clearTimeout(checkTimeout)
}, 1000)


window.notify = function (type, message) {
    new Noty({
        type: type,
        text: message,
        layout   : 'topRight',
        theme    : 'relax',
        closeWith: ['click'],
        timeout: 1500,
        animation: {
            open: "animated fadeIn",
            close: "animated fadeOut"
        }
        // animation: {
        //     open: function (promise) {
        //         var n = this;
        //         var Timeline = new mojs.Timeline();
        //         var body = new mojs.Html({
        //             el        : n.barDom,
        //             x         : {500: 0, delay: 0, duration: 500, easing: 'elastic.out'},
        //             isForce3d : true,
        //             onComplete: function () {
        //                 promise(function(resolve) {
        //                     resolve();
        //                 })
        //             }
        //         });

        //         var parent = new mojs.Shape({
        //             parent: n.barDom,
        //             width      : 200,
        //             height     : n.barDom.getBoundingClientRect().height,
        //             radius     : 0,
        //             x          : {[150]: -150},
        //             duration   : 1.2 * 500,
        //             isShowStart: true
        //         });

        //         n.barDom.style['overflow'] = 'visible';
        //         parent.el.style['overflow'] = 'hidden';

        //         var burst = new mojs.Burst({
        //             parent  : parent.el,
        //             count   : 10,
        //             top     : n.barDom.getBoundingClientRect().height + 75,
        //             degree  : 90,
        //             radius  : 75,
        //             angle   : {[-90]: 40},
        //             children: {
        //                 fill     : '#EBD761',
        //                 delay    : 'stagger(500, -50)',
        //                 radius   : 'rand(8, 25)',
        //                 direction: -1,
        //                 isSwirl  : true
        //             }
        //         });

        //         var fadeBurst = new mojs.Burst({
        //             parent  : parent.el,
        //             count   : 2,
        //             degree  : 0,
        //             angle   : 75,
        //             radius  : {0: 100},
        //             top     : '90%',
        //             children: {
        //                 fill     : '#EBD761',
        //                 pathScale: [.65, 1],
        //                 radius   : 'rand(12, 15)',
        //                 direction: [-1, 1],
        //                 delay    : .8 * 500,
        //                 isSwirl  : true
        //             }
        //         });

        //         Timeline.add(body, burst, fadeBurst, parent);
        //         Timeline.play();
        //     },
        //     close: function (promise) {
        //         var n = this;
        //         new mojs.Html({
        //             el        : n.barDom,
        //             x         : {0: 500, delay: 10, duration: 500, easing: 'cubic.out'},
        //             skewY     : {0: 10, delay: 10, duration: 500, easing: 'cubic.out'},
        //             isForce3d : true,
        //             onComplete: function () {
        //                 promise(function(resolve) {
        //                     resolve();
        //                 })
        //             }
        //         }).play();
        //     }
        // }
    }).show()
}


window.setPrice = function(sourcePrice, priceRule, restPriceRule, isComparedPrice)
{
    let flag = false;
    let newPrice = {
        source_price: sourcePrice,
        compare_at_price:null
    }


    if(typeof priceRule === 'object')
    {
        for (let i = 0; i < priceRule.length; i++)
        {
            let item_price_type = priceRule[i].item_price_type ? priceRule[i].item_price_type : 'multiply'
            let compared_price_type = priceRule[i].compared_price_type ? priceRule[i].compared_price_type : 'multiply'
            let source_price = parseFloat(sourcePrice)
            let item_price = parseFloat(priceRule[i].item_price)
            let compared_price = parseFloat(priceRule[i].compared_price)
            let min_price_rule =  priceRule[i].min
            let max_price_rule = priceRule[i].max
            if(source_price >= min_price_rule && source_price <= max_price_rule) {
                if(item_price_type === 'multiply')
                    newPrice = Object.assign(newPrice, {
                        item_price: (source_price * item_price).toFixed(2)
                    })
                else if(item_price_type === 'plus')
                {
                    newPrice = Object.assign(newPrice, {
                        item_price: (source_price + item_price).toFixed(2)
                    })
                }

                if(isComparedPrice)
                    if(compared_price_type === 'multiply')
                        newPrice = Object.assign(newPrice, {
                            compare_at_price: (source_price * compared_price).toFixed(2)
                        })
                    else if(compared_price_type === 'plus')
                        newPrice = Object.assign(newPrice, {
                            compare_at_price: (source_price + compared_price).toFixed(2)
                        })

                flag = true
            }
        }
    }

    if(typeof restPriceRule === 'object')
    {
        if( ! flag)
        {
            let rest_item_price_type = restPriceRule.item_price_type ? restPriceRule.item_price_type : 'multiply'
            let rest_compared_price_type = restPriceRule.compared_price_type ? restPriceRule.compared_price_type : 'multiply'
            let source_price = parseFloat(sourcePrice)
            let rest_item_price = parseFloat(restPriceRule.item_price)
            let rest_compared_price = parseFloat(restPriceRule.compared_price)
            if(rest_item_price_type === 'multiply')
                newPrice = Object.assign(newPrice, {
                    item_price: (source_price * rest_item_price).toFixed(2)
                })
            else if(rest_item_price_type === 'plus')
                newPrice = Object.assign(newPrice, {
                    item_price: (source_price + rest_item_price).toFixed(2)
                })

            if(isComparedPrice)
            {
                if(rest_compared_price_type === 'multiply')
                    newPrice = Object.assign(newPrice, {
                        compare_at_price: (source_price * rest_compared_price).toFixed(2)
                    })
                else if(rest_compared_price_type === 'plus')
                    newPrice = Object.assign(newPrice, {
                        compare_at_price: (source_price + rest_compared_price).toFixed(2)
                    })
            }
        }
    }

    return newPrice;
}

window.getAliexressProductId = function (aliexpress_link) {
    const preg = '/[0-9]*\.html/'
    let text = []
    let match = aliexpress_link.match(/[0-9]*.html/g)

    if(match[0])
        text = match[0].split('.')


    return (text[0]) ? text[0] : false
}

window.redirectOberloProduct = function () {
    console.log('redirectOberloProduct');

    if( ! checkExtension() ) {
        return false;
    }

    document.querySelector('.oberlo-app-wrap').classList.add('active')
    document.querySelector('#ao__sync_product_prect').innerText = '0'
    document.querySelector('#ao__circle_sync_product').setAttribute('style', '')
    let port = chrome.runtime.connect(chromeExtensionId);

    let payloadMessage = {
        data: {
            action: 'ACTION_SYNC_ORDERS_PRODUCT_FROM_OBERLO',
            payload: {
                public_token: publicToken,
                shop_domain: window.shopDomain,
                from_date: '2009-01-01',
                to_date: moment().format('MMM DD, YYYY'),
                response_info: true
            }
        }
    }
    port.postMessage(payloadMessage);
    port.disconnect()
}

window.redirectAliExpress = function () {

    if( ! checkExtension() ) {
        return false;
    }

    window.open('https://www.aliexpress.com', '_blank');
}


window.installChrome = function() {
    // console.log('installChrome')
    window.open('https://chrome.google.com/webstore/detail/'+chromeExtensionId, '_blank');
    // chrome.webstore.install('https://chrome.google.com/webstore/detail/'+chromeExtensionId, function () {
    //     location.reload();
    // }, function () {
    //     window.open('https://chrome.google.com/webstore/detail/'+chromeExtensionId, '_blank');
    // });
}

window.installAlireviewExtension = function() {
    window.open('https://chrome.google.com/webstore/detail/ali-reviews-aliexpress-re/bbaogjaeflnjolejjcpceoapngapnbaj', '_blank');
}

window.mergeLineItem = function (line_item) {
    let args = []
    line_item.forEach(function (item) {
        let match = {ali_ext_id: item.ali_ext_id, product_ext_id: item.product_ext_id}
        let value = Object.values(line_item)
        console.log(match)
        console.log(value)
        let key = _.indexOf(Object.values(line_item), match)
        console.log(key)
        // console.log(item)

        if(key > -1)
        {
            args[key] = Object.assign({}, args[key], {
                quantity: parseInt(args[key].quantity) + parseInt(item.quantity)
            })
        } else
            args.push(item)

        console.log(args)
    })
    return args

}

window.notifyExtensiond = function({type, message}) {
    notify(type, message)
    document.querySelector('.oberlo-app-wrap').classList.remove('active')
    $('body').find('.loading-blur-o').remove();

}

window.drawSector = function(percent) {
    var activeBorder = document.querySelector("#ao__sync_product_loading");
    document.querySelector('.ao__circle_prec').innerText = percent
    if (percent >= 100)
        percent = 100;
    var deg = percent*3.6;
    if (deg <= 180){
        activeBorder.setAttribute('style', 'background-image: linear-gradient(' + deg + 'deg, transparent 50%, #D3B4FF 50%), linear-gradient(0deg, #D3B4FF 50%, transparent 50%);');
    }
    else{
        activeBorder.setAttribute('style', 'background-image:   linear-gradient(' + (deg-180) + 'deg, transparent 50%, #7009FF 50%),linear-gradient(0deg, #D3B4FF 50%, transparent 50%);');
    }
    
    var startDeg = document.querySelector(".ao__circle_start").getAttribute('data-deg')
    var currentStyle = activeBorder.getAttribute('style');
    activeBorder.setAttribute('style',currentStyle + 'transform: rotate(' + startDeg + 'deg);');

    document.querySelector(".ao__circle").setAttribute('style', 'transform: rotate(' + (-startDeg) + 'deg)');
}

window.notifySyncProductOrderResult = function( msg ) {
    if( msg.type =='sync_product_order_oberlo' ) {
        console.log(msg.percent)
        drawSector(msg.percent)
    }
    if( msg.type == 'sync_product_order_oberlo' && parseInt(msg.percent) == 100 ) {
        console.log('msg', msg)
        console.log('products', msg.products)
        let productLengthText = `${msg.products.length} products`
        if(msg.products.length == 1) {
            productLengthText = '1 product'
        }
        let productFailLengthText = `${msg.product_fail.length} products`
        if(msg.product_fail.length == 1) {
            productFailLengthText = '1 product'
        }
        let productFailHtml = `<p class="ao__information_outline"><span><i class="mdi mdi-information-outline"></i></span>${productFailLengthText} need to be manually update</p>`
        if(msg.product_fail.length == 0) {
            productFailHtml = ''
        }
        swal({
            title:'<span class="sweetalert-icon"><i class="mdi mdi-checkbox-marked-circle"></i></span>',
            html: `<h4 class="text-left sweetalert-title-delete">Transfer Complete</h4><div class="text-left ao__sync_product_order_result"><p><span><i class="mdi mdi-check"></i></span>${productLengthText} are update AliExpress Link.</p>${productFailHtml}</div>`,
            showCloseButton: true,
            showCancelButton: true,
            focusConfirm: false,
            showConfirmButton: false,
            position: 'top',
            cancelButtonText: `<span class="text-button-remove ao__sync_product_order_done">Done</span>`,
            width: '350px',
            customClass: "ao__swal2_transfer_complete",
            backdrop: false
        })
        .then(function (action) {
            location.reload()
        })
    }
}
