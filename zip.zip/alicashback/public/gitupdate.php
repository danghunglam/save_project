 <?php
// Turn off error reporting
error_reporting(1);

try
{
    // Decode the payload json string
    $payload    = json_decode($_REQUEST['payload']);

    // Log the payload object
    //@file_put_contents('github-logs.txt', print_r($payload, TRUE), FILE_APPEND);
}
catch(Exception $e)
{
    exit;
}


function pull($p){
    if( is_dir($p) ) {
        $newurl = $p . "\r\n";
        @file_put_contents('result.txt', $newurl, FILE_APPEND);
        `cd {$p}; sudo git pull > log.txt 2>&1`;
    }
}
$branch = explode("/",$payload->ref);
//

switch (end($branch)) {
    case 'release':
        //pull('/home/alireview.shopboostify.com/public_html');
        //@file_put_contents('branch.txt', end($branch), FILE_APPEND);
        break;
    case 'develop':
        pull('/home/alicashback-dev.fireapps.io/public_html');
        //@file_put_contents('branch.txt', end($branch), FILE_APPEND);
        break;
    default:
        break;
}
?>
