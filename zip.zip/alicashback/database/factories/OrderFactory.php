<?php

use Faker\Generator as Faker;

$factory->define(\App\Models\OrdersModel::class, function (Faker $faker) {
    $shop = \App\Models\ShopModel::all(['id'])->random()->id;
    return [
        'id' => $faker->unique()->randomNumber(6),
        'order_number' => $faker->randomNumber(4),
        'shop_id' => $shop,
        'note' => $faker->text('40'),
        'first_name' => $faker->firstName,
        'last_name' => $faker->lastName,
        'city' => $faker->city,
        'country' => $faker->countryCode,
        'address' => $faker->address,
        'zip' => $faker->text('6'),
        'phone' => $faker->phoneNumber,
        'email' => $faker->email,
        'created_at' => $faker->dateTimeBetween('-1 years','now'),
        'updated_at' => $faker->dateTimeBetween('-1 years','now')
    ];
});
