<?php

use Faker\Generator as Faker;


$factory->define(\App\Models\ProductVariantModel::class, function (Faker $faker) {
    $product  = \App\Models\ProductModel::all(['id'])->random()->id;
    return [
        'id' => $faker->unique()->randomNumber(6),
        'aliexpress_sku_property' => $faker->unique()->randomNumber(3),
        'aliexpress_options' => json_encode(['123,45673']),
        'inventory_quantity' => random_int(1,100),
        'product_id' => $product,
        'created_at' => $faker->dateTimeBetween('-1 years','now'),
        'updated_at' => $faker->dateTimeBetween('-1 years','now')
    ];
});
