<?php

use Faker\Generator as Faker;

$factory->define(\App\Models\LineItemModel::class, function (Faker $faker) {
    $productValiant = \App\Models\ProductVariantModel::all(['id'])->random()->id;
    $orders = \App\Models\OrdersModel::all(['id'])->random()->id;
    return [
	    'id' => $faker->unique()->randomNumber(6),
        'orders_id' => $orders,
        'product_variant_id' => $productValiant,
        'status' => 1,
        'quality' => $faker->randomNumber(1),
        'price' => $faker->randomNumber(2),
        'aliexpress_order_no' => $faker->text(100),
        //'aliexpress_order_id' => $faker->ean8,
        'tracking_code' => $faker->ean8,
        'variant_sku' => $faker->text(10),
        'variant_title' => $faker->text(10),
//        'variant_image' => $faker->imageUrl(500,500),
        'created_at' => $faker->dateTimeBetween('-1 years','now'),
        'updated_at' => $faker->dateTimeBetween('-1 years','now')
    ];
});
