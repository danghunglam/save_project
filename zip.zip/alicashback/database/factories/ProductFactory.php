<?php

use Faker\Generator as Faker;

$factory->define(\App\Models\ProductModel::class, function (Faker $faker) {
    $shop = \App\Models\ShopModel::all(['id'])->random()->id;
    $supplier = \App\Models\SupplierModel::all(['id'])->random()->id;
    return [
        'id' => $faker->unique()->randomNumber(6),
        'title' => $faker->name('male'),
        'slug' => $faker->name('male'),
        'image' => $faker->imageUrl(500,500),
        'status' => 1,
        'aliexpress_product_id' => $faker->unique()->randomNumber(6),
        'source' => 'aliexpress',
        'source_product_link' => 'https://www.aliexpress.com/item/YuooMuoo-New-Brand-Fashion-Women-Elegant-Office-Dress-Front-Split-OL-Pencil-Work-Dress-European-Design/32791149189.html?spm=2114.search0104.3.10.RToOgW&ws_ab_test=searchweb0_0,searchweb201602_4_10152_10065_10151_10068_10344_10345_10342_10343_10340_10341_10307_10060_10155_10154_10056_10055_10054_10059_10536_10534_10533_10532_100031_10099_10338_10103_10102_5590020_10052_10053_10142_10107_10050_10051_10325_10084_10083_5370020_10080_10082_10081_10110_10175_10111_10112_10113_10114_5610015_10312_10313_10314_10317_10318_10078_10079_10073-10317,searchweb201603_17,ppcSwitch_5&btsid=388914f7-ffe8-441d-abec-8a3a7529ea1e&algo_expid=976b02fc-e84c-4f25-b413-8f4826f0ae86-1&algo_pvid=976b02fc-e84c-4f25-b413-8f4826f0ae86',
        'supplier_id' => $supplier,
        'shop_id' => $shop
    ];
});
