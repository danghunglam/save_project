<?php

use Faker\Generator as Faker;

$factory->define(\App\Models\SubscribeModel::class, function (Faker $faker) {
    $shop = \App\Models\ShopModel::all(['id'])->random()->id;
    $plan = \App\Models\PlanModel::all(['id'])->random()->id;
    return [
        'shop_id' => $shop,
        'plan_id' => $plan,
        'subscribe_date' => $faker->dateTime,
        'start_charged_date' => $faker->dateTime,
        'unsubscribe_date' => $faker->dateTime,
        'created_at' => $faker->dateTimeBetween('-1 years','now'),
        'updated_at' => $faker->dateTimeBetween('-1 years','now')
    ];
});
