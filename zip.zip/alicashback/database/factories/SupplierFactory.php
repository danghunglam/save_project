<?php

use Faker\Generator as Faker;

$factory->define(\App\Models\SupplierModel::class, function (Faker $faker) {
    return [
        'id' => $faker->unique()->randomNumber(6),
        'name' => $faker->company,
        'url' => $faker->url,
        'created_at' => $faker->dateTimeBetween('-1 years','now'),
        'updated_at' => $faker->dateTimeBetween('-1 years','now')
    ];
});
