<?php

use Faker\Generator as Faker;

$factory->define(\App\Models\PlanModel::class, function (Faker $faker) {
    return [
        'id' => $faker->unique()->randomNumber(6),
        'plan_name' => $faker->name,
        'trial' => 7,
        'price' => 9,
        'is_free' => 1,
        'created_at' => $faker->dateTimeBetween('-1 years','now'),
        'updated_at' => $faker->dateTimeBetween('-1 years','now')
    ];
});
