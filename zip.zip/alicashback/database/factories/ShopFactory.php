<?php

use Faker\Generator as Faker;

$factory->define(\App\Models\ShopModel::class, function (Faker $faker) {
    return [
        'id' => $faker->unique()->randomNumber(6),
        'name' => $faker->name,
        'email' => $faker->email,
        'domain' => $faker->domainName,
        'country' => $faker->countryCode,
        'province' => $faker->state,
        'address1' => $faker->city,
        'zip' => $faker->randomNumber(6),
        'city' => $faker->city,
        'phone' => $faker->phoneNumber,
        'currency' => $faker->currencyCode,
        'iana_timezone' => $faker->timezone,
        'shop_owner' => $faker->name(),
        'plan_name' => $faker->text('10'),
        'myshopify_domain' => $faker->domainWord,
        'status' => 1,
        'is_version_app' => 'v2',
        'created_at' => $faker->dateTimeBetween('-1 years','now'),
        'updated_at' => $faker->dateTimeBetween('-1 years','now')
    ];
});
