<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ImportProductVariant extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('import_product_variant', function (Blueprint $table) {
            $table->increments('id');
            $table->string('aliexpress_options')->nullable();
            $table->unsignedInteger('product_id');
            $table->unsignedInteger('image_id')->nullable();
            $table->string('option1')->nullable();
            $table->string('option2')->nullable();
            $table->string('option3')->nullable();
            $table->string('options', 500)->nullable();
            $table->string('title', 1500)->nullable();
            $table->string('sku')->nullable();
            $table->integer('source_quantity')->default(0);
            $table->decimal('source_price', 65,2)->nullable();
            $table->decimal('price', 65,2)->nullable();
            $table->decimal('compare_at_price', 65, 2)->nullable();
            $table->boolean('selected')->default(0);

            $table->timestamps();

            $table->index('id');

            $table->foreign('product_id')->references('id')->on('import_product')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('image_id')->references('id')->on('import_product_image')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('import_product_variant');
    }
}
