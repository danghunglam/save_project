<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Product extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product', function (Blueprint $table) {
            $table->bigInteger('id');
            $table->string('title', 1000);
            $table->string('handle', 1000)->nullable();
            $table->text('body_html')->nullable();
            $table->string('image', 2000)->nullable();
            $table->string('custom_collection', 2000)->nullable();
            $table->string('tag', 2000)->nullable();
            $table->tinyInteger('status')->nullable();
            $table->string('source')->default('aliexpress');
            $table->string('aliexpress_product_id')->nullable();
            $table->string('source_product_link', 1000)->nullable();
            $table->bigInteger('supplier_id')->nullable();
            $table->bigInteger('shop_id');
            $table->boolean('auto_update_price')->default(0);
            $table->timestamps();
            $table->softDeletes();

            $table->primary('id');
            $table->index('id');

            $table->foreign('supplier_id')->references('id')->on('supplier')->onUpdate('cascade');
            $table->foreign('shop_id')->references('id')->on('shop')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product');
    }
}
