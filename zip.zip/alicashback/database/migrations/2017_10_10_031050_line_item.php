<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class LineItem extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('line_item', function (Blueprint $table) {
            $table->bigInteger('id');
            $table->bigInteger('orders_id');
            $table->bigInteger('product_variant_id');
            $table->tinyInteger('status')->nullable();
            $table->integer('quality');
            $table->decimal('price', 65,2)->nullable();
            $table->decimal('fee_ship',65,2)->default(0);
            $table->decimal('price_order_aliexpress', 65,2)->default(0);
            $table->string('aliexpress_order_no')->nullable();
            $table->string('tracking_code')->nullable();
            $table->string('fulfillment_status')->nullable();
            $table->timestamps();

            $table->primary('id');
            $table->index('id');

            $table->foreign('orders_id')->references('id')->on('orders')->onUpdate('cascade');
            $table->foreign('product_variant_id')->references('id')->on('product_variant')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('line_item');
    }
}
