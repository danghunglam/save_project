<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddPriceOrders extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->decimal('total_price', 65, 2)->default(0);
            $table->decimal('subtotal_price', 65, 2)->default(0);
            $table->decimal('total_tax', 65, 2)->default(0);
            $table->decimal('total_discounts', 65, 2)->default(0);
            $table->decimal('total_line_items_price', 65, 2)->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

    }
}
