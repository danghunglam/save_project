<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddComlumnProductTypeIntoImportProduct extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(!Schema::hasColumn('import_product', 'product_type')) {
            Schema::table('import_product', function (Blueprint $table) {
                $table->string('product_type')->nullable();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('import_product', function (Blueprint $table) {
            $table->dropColumn('product_type');
        });
    }
}
