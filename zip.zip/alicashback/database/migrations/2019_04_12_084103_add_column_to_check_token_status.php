<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnToCheckTokenStatus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasColumn('shop', 'token_status')) {
            Schema::table('shop', function (Blueprint $table) {
                $table->boolean('token_status')->default(0);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasColumn('shop', 'token_status')) {
            Schema::table('shop', function (Blueprint $table) {
                $table->dropColumn('token_status')->default(0);
            });
        }
    }
}
