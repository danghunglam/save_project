<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ProductVariant extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_variant', function (Blueprint $table) {
            $table->bigInteger('id');
            $table->string('aliexpress_options')->nullable();
            $table->bigInteger('product_id');
            $table->bigInteger('image_id')->nullable();
            $table->string('option1')->nullable();
            $table->string('option2')->nullable();
            $table->string('option3')->nullable();
            $table->string('options', 500)->nullable();
            $table->string('title', 1500)->nullable();
            $table->string('sku')->nullable();
            $table->integer('source_quantity')->default(0);
            $table->decimal('source_price', 65,2)->nullable();
            $table->decimal('price', 65,2)->nullable();
            $table->decimal('compare_at_price', 65,2)->nullable();
            $table->string('source')->default('aliexpress');
            $table->string('aliexpress_product_id')->nullable();
            $table->string('source_product_link', 1000)->nullable();
            $table->bigInteger('supplier_id')->nullable();

            $table->timestamps();
	        $table->softDeletes();

            $table->primary('id');
            $table->index('id');

            $table->foreign('supplier_id')->references('id')->on('supplier')->onUpdate('cascade');
            $table->foreign('product_id')->references('id')->on('product')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('image_id')->references('id')->on('product_image')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_variant');
    }
}
