<?php

use Illuminate\Database\Seeder;

class ShopTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Add Shop
        factory(\App\Models\ShopModel::class, 1)->create();
        //Add Plan
        factory(\App\Models\PlanModel::class, 2)->create();
        //Add subscribe
        factory(\App\Models\SubscribeModel::class, 20)->create();
        //Add Supplier
        factory(\App\Models\SupplierModel::class, 10)->create();
        //Add Product
        factory(\App\Models\ProductModel::class, 1000)->create();
        //Add Product variant
        factory(\App\Models\ProductVariantModel::class, 1000)->create();
        //Add Order
        factory(\App\Models\OrdersModel::class, 1000)->create();
        //Add line item
        factory(\App\Models\LineItemModel::class, 1000)->create();
    }
}
