<?php
return [
    'app_version' => '1.0',
	'status' => [
		'publish' => 1,
		'unpublish' => 0
	],
    'paginate_default' => 12,
    'paginate_import_product' => 20,
    'default_image' => 'https://aliorders.fireapps.io/images/default.png',
    'aliexpress_options_default' => 'fire_apps',
    'product_image_id_default' => 'fire_apps'
];