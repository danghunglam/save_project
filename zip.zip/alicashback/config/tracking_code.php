<?php
    return [
        'ali_order_no' => [
            1 => 'All',
            2 => 'Ali Order No',
            3 => 'None'
        ],
        'tracking_code' => [
            1 => 'All',
            2 => 'Tracking code',
            3 => 'None'
        ],
        'aliexpress_status' => [
            1 => 'Awaiting payment',
            2 => 'Awaiting Cancellation',
            3 => 'Awaiting Shipment',
            4 => 'Partial Shipment',
            5 => 'Awaiting delivery',
            6 => 'Grouping',
            7 => 'Order Completed',
            8 => 'Dispute Orders',
            9 => 'Frozen Orders',
            10 => 'Payment not yet confirmed',
            11 => 'Payment being verified'
        ],
        'sort_by' => [
            1 => 'Sort by lastest',
            2 => 'Sort by default'
        ]
    ];