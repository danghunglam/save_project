<?php
return [
    'name' => 'Full options only 9$',
    'price' => 9,
    'trial_days' => 7,
    'test' => ((env('APP_ENV') == 'local') ? true :  null),
    'plan' => [
        'basic' => [
            'products' => 1000,
            'orders' => 250
        ],
        'professional' => [
            'products' => 30000,
            'orders' => 1500
        ],
        'unlimited' => [
            'products' => 50000,
            'orders' => 'unlimited'
        ]
    ]
];