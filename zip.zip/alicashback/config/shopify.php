<?php
return [
    'scopes' => [
        'read_products',
        'write_products',
        'read_orders',
        'write_orders',
        'read_inventory',
        'write_inventory',
        'read_themes',
        'write_themes',
       'read_fulfillments'
//        'write_fulfillments'
    ],
    'redirect_before_install' => env('APP_URL').'/auth',
    'redirect_switch_install' => env('APP_URL').'/switch',
    'redirect_add_install' => env('APP_URL').'/add',
    'redirect_get_token_install' => env('APP_URL').'/get_token',
    'mail_from' => env('MAIL_FROM'),
    'pricing_start_date' => '2019-03-01 00:00:00',
    'product_had_link' => 'product_had_link'
];