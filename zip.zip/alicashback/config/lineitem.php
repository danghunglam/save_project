<?php
return [
    'fulfillment_status' => [
        'null' => 1, //=>unfulfillment
        'fulfilled' => 2,
        'partial' => 3
    ]
];