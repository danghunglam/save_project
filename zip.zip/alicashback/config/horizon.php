<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Horizon Redis Connection
    |--------------------------------------------------------------------------
    |
    | This is the name of the Redis connection where Horizon will store the
    | meta information required for it to function. It includes the list
    | of supervisors, failed jobs, job metrics, and other information.
    |
    */

    'use' => 'default',

    /*
    |--------------------------------------------------------------------------
    | Horizon Redis Prefix
    |--------------------------------------------------------------------------
    |
    | This prefix will be used when storing all Horizon data in Redis. You
    | may modify the prefix when you are running multiple installations
    | of Horizon on the same server so that they don't have problems.
    |
    */

    'prefix' => env('HORIZON_PREFIX', 'aliorders:'),

    /*
    |--------------------------------------------------------------------------
    | Queue Wait Time Thresholds
    |--------------------------------------------------------------------------
    |
    | This option allows you to configure when the LongWaitDetected event
    | will be fired. Every connection / queue combination may have its
    | own, unique threshold (in seconds) before this event is fired.
    |
    */

    'waits' => [
        'redis:default' => 60,
    ],

    /*
    |--------------------------------------------------------------------------
    | Job Trimming Times
    |--------------------------------------------------------------------------
    |
    | Here you can configure for how long (in minutes) you desire Horizon to
    | persist the recent and failed jobs. Typically, recent jobs are kept
    | for one hour while all failed jobs are stored for an entire week.
    |
    */

    'trim' => [
        'recent' => 60,
        'failed' => 10080,
    ],

    /*
    |--------------------------------------------------------------------------
    | Queue Worker Configuration
    |--------------------------------------------------------------------------
    |
    | Here you may define the queue worker settings used by your application
    | in all environments. These supervisors and settings handle all your
    | queued jobs and will be provisioned by Horizon during deployment.
    |
    */

    'environments' => [
        'production' => [
            'supervisor-prod-1' => [
                'connection' => 'redis',
                'queue' => ['default', 'bulk_import_aliexpress_oberlo', 'update_tracking_code_oberlo',
                    'tracking_code_aliexpress', 'send_email_marketing'],
                'balance' => 'auto',
                'processes' => 3,
                'tries' => 3,
                'timeout' => 1000
            ],
            'init_app' => [
                'connection' => 'redis',
                'queue' => ['init_app','sync_order','affiliate','add_variant','add_rule_product'],
                'balance' => 'auto',
                'processes' => 5,
                'tries' => 3,
                'timeout' => 1000
            ],
            'import_product_aliexpress' => [
                'connection' => 'redis',
                'queue' => ['import_product_aliexpress'],
                'balance' => 'auto',
                'processes' => 4,
                'tries' => 3,
                'timeout' => 1000
            ],
            'import_product' => [
                'connection' => 'redis',
                'queue' => ['import_product'],
                'balance' => 'auto',
                'processes' => 30,
                'tries' => 1,
                'timeout' => 1000
            ],
            'once_tries' => [
                'connection' => 'redis',
                'queue' => [
                    'import_update_variant_image', 'override_product',
                    'edit_product', 'import_all_product',
                    'update_options_all_product', 'update_total_quantity',
                    'refulfill_by_shop', 'refulfill', 'post_variant_from_db', 'post_variant_from_trash',
                    'fulfillment_with_tracking_code'
                ],
                'balance' => 'auto',
                'processes' => 5,
                'tries' => 1,
                'timeout' => 1000
            ],
            'supervisor-prod-2' => [
                'connection' => 'redis',
                'queue' => ['init_app_before'],
                'balance' => 'simple',
                'processes' => 5,
                'tries' => 2,
                'timeout' => 1000
            ],
            'webhook' => [
                'connection' => 'redis',
                'queue' => ['webhook_order_update', 'add_webhook_aliorders', 'webhook_update_product'],
                'balance' => 'simple',
                'processes' => 10,
                'tries' => 2,
                'timeout' => 1000
            ],
            'elastic' => [
                'connection' => 'redis',
                'queue' => ['line_item_index'],
                'balance' => 'auto',
                'processes' => 5,
                'tries' => 2,
                'timeout' => 1000
            ],
            'hard_sync' => [
                'connection' => 'redis',
                'queue' => ['hand_sync'],
                'balance' => 'auto',
                'processes' => 1,
                'tries' => 3,
                'timeout' => 2000
            ]
        ],
        'staging' => [
            'supervisor-prod-1' => [
                'connection' => 'redis',
                'queue' => [
                    'default', 'bulk_import_aliexpress_oberlo',
                    'update_tracking_code_oberlo', 'tracking_code_aliexpress', 'send_email_marketing','affiliate'],
                'balance' => 'auto',
                'processes' => 25,
                'tries' => 3,
                'timeout' => 500
            ],
            'init_app' => [
                'connection' => 'redis',
                'queue' => ['init_app', 'sync_order'],
                'balance' => 'auto',
                'processes' => 25,
                'tries' => 3,
                'timeout' => 1000
            ],
            'import_product_aliexpress' => [
                'connection' => 'redis',
                'queue' => ['import_product_aliexpress'],
                'balance' => 'auto',
                'processes' => 10,
                'tries' => 3,
                'timeout' => 1000
            ],
            'import_product' => [
                'connection' => 'redis',
                'queue' => ['import_product'],
                'balance' => 'auto',
                'processes' => 15,
                'tries' => 1,
                'timeout' => 1000
            ],
            'once_tries' => [
                'connection' => 'redis',
                'queue' => [
                    'import_update_variant_image', 'override_product',
                    'edit_product', 'import_all_product',
                    'update_options_all_product', 'update_total_quantity',
                    'fulfillment_with_tracking_code'
                ],
                'balance' => 'auto',
                'processes' => 5,
                'tries' => 1,
                'timeout' => 1000
            ],
            'supervisor-prod-2' => [
                'connection' => 'redis',
                'queue' => ['init_app_before'],
                'balance' => 'simple',
                'processes' => 5,
                'tries' => 3,
                'timeout' => 1000
            ],
            'webhook' => [
                'connection' => 'redis',
                'queue' => ['webhook_order_update', 'add_webhook_aliorders', 'webhook_update_product'],
                'balance' => 'simple',
                'processes' => 5,
                'tries' => 3,
                'timeout' => 1000
            ],
            'elastic' => [
                'connection' => 'redis',
                'queue' => ['line_item_index'],
                'balance' => 'auto',
                'processes' => 3,
                'tries' => 3,
                'timeout' => 1000
            ],
            'hard_sync' => [
                'connection' => 'redis',
                'queue' => ['hand_sync'],
                'balance' => 'auto',
                'processes' => 1,
                'tries' => 3,
                'timeout' => 1000
            ]
        ],
        'local' => [
            'supervisor-prod-1' => [
                'connection' => 'redis',
                'queue' => [
                    'init_app', 'default', 'bulk_import_aliexpress_oberlo',
                    'update_tracking_code_oberlo', 'tracking_code_aliexpress',
                    'sync_order', 'send_email_marketing','affiliate'],
                'balance' => 'auto',
                'processes' => 15,
                'tries' => 3,
                'timeout' => 500
            ],
            'import_product_aliexpress' => [
                'connection' => 'redis',
                'queue' => ['import_product_aliexpress'],
                'balance' => 'auto',
                'processes' => 10,
                'tries' => 3,
                'timeout' => 1000
            ],
            'import_product' => [
                'connection' => 'redis',
                'queue' => ['import_product'],
                'balance' => 'auto',
                'processes' => 30,
                'tries' => 1,
                'timeout' => 1000
            ],
            'once_tries' => [
                'connection' => 'redis',
                'queue' => [
                    'import_update_variant_image', 'override_product',
                    'edit_product', 'import_all_product',
                    'update_options_all_product', 'update_total_quantity',
                    'refulfill_by_shop', 'refulfill', 'post_variant_from_db',
                    'post_variant_from_trash', 'fulfillment_with_tracking_code'
                ],
                'balance' => 'auto',
                'processes' => 5,
                'tries' => 1,
                'timeout' => 1000
            ],
            'supervisor-prod-2' => [
                'connection' => 'redis',
                'queue' => ['init_app_before'],
                'balance' => 'simple',
                'processes' => 5,
                'tries' => 3,
                'timeout' => 1000
            ],
            'webhook' => [
                'connection' => 'redis',
                'queue' => ['webhook_order_update', 'add_webhook_aliorders', 'webhook_update_product'],
                'balance' => 'simple',
                'processes' => 5,
                'tries' => 3,
                'timeout' => 1000
            ],
            'elastic' => [
                'connection' => 'redis',
                'queue' => ['line_item_index'],
                'balance' => 'auto',
                'processes' => 3,
                'tries' => 3,
                'timeout' => 1000
            ],
            'hard_sync' => [
                'connection' => 'redis',
                'queue' => ['hand_sync'],
                'balance' => 'auto',
                'processes' => 1,
                'tries' => 3,
                'timeout' => 1000
            ]
        ],
    ],
];
