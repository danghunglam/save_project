<?php
return [
    'notification_email_customer_fulfillment' => true,
    'default_fulfillment_tracking_url' => '',
    'automation_fulfillment' => true,
    'auto_update_when_product_no_longer_available_aliexpress' => 1,
    'auto_update_when_product_no_longer_available_aliexpress_notify' => true,
    'auto_update_when_product_variant_no_longer_available_aliexpress' => 1,
    'auto_update_when_product_variant_no_longer_available_aliexpress_notify' => true,
    'auto_update_when_product_cost_change_aliexpress' => 1,
    'auto_update_when_product_cost_change_aliexpress_notify' => true,
    'when_one_product_is_out_of_stock_on_aliexpress' => 1,
    'when_one_product_is_out_of_stock_on_aliexpress_notify' => true,
    'price_rule' => [
        [
            'min' => 0,
            'max' => 10,
            'item_price' => 10,
            'compared_price' => 15,
            'item_price_type' => 'plus',
            'compared_price_type' => 'plus'
        ],
        [
            'min' => 10.01,
            'max' => 20,
            'item_price' => 2,
            'compared_price' => 3,
            'item_price_type' => 'multiply',
            'compared_price_type' => 'multiply'
        ]
    ],
    'rest_of_the_price_ranges' => [
        'item_price' => 2,
        'compared_price' => 3,
        'item_price_type' => 'multiply',
        'compared_price_type' => 'multiply'
    ],
    'is_compared_price' => true,
    'is_convert_currency' => true,
    'cheapest_default_shipping_method' => 0,
    'default_shipping_method' => 'EMS_ZX_ZX_US',
    'cheapest_backup_shipping_method' => 1,
    'backup_shipping_method' => 'DHL',
    'default_phone_number_aliexpress_checkout' => '',
    'note_supplier_aliexpress_checkout' => 'We are dropshipping! Please don\'t include any invoices or promo materials into the package.',
	'receive_reports_via_email' => 1,
	'primary_email_address' => '',
	'time_zone' => 'Etc/UTC',
    'shipping_max_price_alert' =>  0,
    'is_shipping_max_price_alert' => false,
    'assign_cent_price_check' => false,
    'assign_cent_price' => '',
    'assign_cent_compare_at_check' => false,
    'assign_cent_compare_at' => '',
    'auto_completed_order' => true,
    'stop_total_cost_option' => '',
    'stop_total_order_processed_option' => '6',
    'stop_charge_failed_option' => false,
    'skip_shipping_fee_option' => '3',
    'skip_product_price_option' => '',
    'skip_earning_lower_option' => '4',
    'skip_cannot_fulfilled_option' => false
];