<?php
return [
    'multi_product' => [
        'paged_option' => [
            'all_pages_products' => [
                'value' => 1,
                'label' => 'All pages products'
            ],
            'this_page_products' => [
                'value' => 2,
                'label' => 'This pages products'
            ]
        ],
        'keep_reviews' => [
            'keep_all_imported_review' => [
                'value' => 1,
                'label' => 'Keep all imported reviews'
            ],
            'remove_all_imported_reviews' => [
                'value' => 2,
                'label' => 'Remove all imported reviews'
            ],
            'get_reviews_for_products_has_no_reviews' => [
                'value' => 3,
                'label' => 'Get reviews for products has no reviews only'
            ]

        ]

    ]
];