<?php
return [
	'auto_update_when_product_no_longer_available_aliexpress' => [
		'do_nothing'           => 1,
		'unpublish_product'    => 2,
		'set_quantity_to_zero' => 3
	],
	'auto_update_when_product_variant_no_longer_available_aliexpress' => [
		'do_nothing'           => 1,
		'remove_variant'       => 2,
		'set_quantity_to_zero' => 3
	],
	'auto_update_when_product_cost_change_aliexpress' => [
		'do_nothing'           => 1,
		'update_automatically' => 2,
	],
    'when_one_product_is_out_of_stock_on_aliexpress' => [
        'do_nothing'           => 1,
        'set_quantity_to_zero' => 3
    ],
	'shipping' => [
	    // 'none'          => 'None',
		'EMS_ZX_ZX_US'   => 'ePacket',
		'UPS'       => 'UPS',
		'FEDEX'     => 'FedEx',
		'DHL'       => 'DHL',
		'TNT'       => 'TNT',
		'EMS'       => 'EMS',
		'USPS'      => 'USPS',
        'SGP'       => 'Singapore Post',
        'CPAM'      => 'China Post Registered Air Mail',
        'CAINIAO_STANDARD' => 'AliExpress Standard Shipping'
	],
	'receive_reports_via_email' => [
		'daily'   => 1,
		'weekly'  => 2,
		'monthly' => 3
	]
];