<?php
return [
    'status' => [
        'to_order' => 1,
        'order_placed' => 2,
        'shipped' => 3,
        'pending' => 4
    ],
    'financial_status' => [
        'pending' => 1,
        'paid' => 2,
        'partially_paid' => 3,
        'refunded' => 4,
        'partially_refunded' => 5,
    ],
    'fulfillment_status' => [
        'null' => 1, //=>unfulfillment
        'fulfilled' => 2,
        'partial' => 3
    ],
    'flags' => [
        'none' => [
            'class' => 'flags-icon-class-white',
            'title' => 'None'
        ],
        'grey' => [
            'class' => 'flags-icon-class-grey',
            'title' => 'Grey'
        ],
        'purple' => [
            'class' => 'flags-icon-class-purple',
            'title' => 'Purple'
        ],
        'red' => [
            'class' => 'flags-icon-class-red',
            'title' => 'Red'
        ]
    ],
    'status_filter' => [
        1 => 'To Order',
        2 => 'Order Placed',
        3 => 'Shipped',
        4 => 'Pending'
    ],
    'financial_status_filter' => [
        2 => 'Paid',
        4 => 'Refunded',
        5 => 'Partially Refund'
    ],
    'fulfillment_status_filter' => [
        1 => 'Unfulfilled',
        2 => 'Fulfilled',
        3 => 'Partially Fulfilled'
    ],
    'date_range' => [
        'today'         => 'Today',
        'yesterday'     => 'Yesterday',
        'last_7days'    => 'Last 7 days',
        'last_30days'   => 'Last 30 days',
        'last_90days'   => 'Last 90 days',
        'week_to_date'  => 'Week to date',
        'month_to_date' => 'Month to date',
        'year_to_date'  => 'Year to date'
    ],
    'place_order_page' => [

    ]
];
