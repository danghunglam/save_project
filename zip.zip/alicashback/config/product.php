<?php
return [
   'status' => [
       'available' => 1,
       'low_stock' => 4,
       'out_of_stock' => 2,
       'Gone_from_AliExpress' => 3,

   ],
    'auto_update_price' => [
        'automatic_price_updates_on' => 1,
        'price_update_off' => 2
    ],
    'source_product_link' => [
      'AliExpress' => 1,
      'Unknown' => 2,
    ],
    'type_notify' => [
        'product_miss_link' => 'Missing Link',
        'product_miss_variant' => 'Variant Disappears',
        'product_change_cost' => 'Cost Change',
        'product_out_of_stock'=> 'Out of stock',

    ]
];