<?php
return [
    'type_notify' => [
        'product_miss_link' => 'Missing Link',
        'product_miss_variant' => 'Variant Disappears',
        'product_change_cost' => 'Cost Change',
        'product_out_of_stock'=> 'Out of stock',

    ]
];