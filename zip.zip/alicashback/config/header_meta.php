<?php
return [
    'apps_installData' => [
        'title' => 'Installing',
        'breadcrumb' => 'Installing'
    ],
    'apps_installApp' => [
        'title' => 'Install App',
        'breadcrumb' => 'Install App'
    ],
    'apps_loading' => [
        'title' => 'Please wait...',
        'breadcrumb' => 'Loading'
    ],
    'products_index' => [
        'title' => 'Product List',
        'breadcrumb' => 'Product List'
    ],
    'products_status' => [
        'title' => 'Product Status',
        'breadcrumb' => 'Product Status'
    ],
    'products_settings' => [
        'title' => 'Product Settings',
        'breadcrumb' => 'Product Settings'
    ],
    'orders_index' => [
        'title' => 'Order List',
        'breadcrumb' => 'Order List'
    ],
    'orders_settings' => [
        'title' => 'Order Settings',
        'breadcrumb' => 'Order Settings'
    ],
    'setting_index' => [
        'title' => 'Settings',
        'breadcrumb' => 'General Settings'
    ],
    'setting_manage_account'=>[
        'title' => 'Setting manage account',
        'breadcrumb' => 'Setting manage account'
    ],
    'setting_pricing_rule' => [
        'title' => 'Settings Pricing Rule',
        'breadcrumb' => 'Import Settings'
    ],
    'setting_supplier' => [
        'title' => 'Settings Supplier',
        'breadcrumb' => 'Settings'
    ],
    'setting_api' => [
        'title' => 'Settings API',
        'breadcrumb' => 'Settings'
    ],
    'import_index' => [
        'title' => 'Import List',
        'breadcrumb' => 'Import List'
    ],
    'import_settings' => [
        'title' => 'Import Settings',
        'breadcrumb' => 'Import Settings'
    ],
    'dashboard_index' => [
        'title' => 'Dashboard',
        'breadcrumb' => 'Dashboard'
    ],
    'tracking_code_index' => [
        'title' => 'Tracking Code',
        'breadcrumb' => 'Tracking Code'
    ],
    'products_edit' => [
        'title' => 'Edit Product',
        'breadcrumb' => 'Edit Product'
    ]

];
