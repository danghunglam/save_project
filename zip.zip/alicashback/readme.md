## About AliOrders
- Live: http://aliorders.fireapps.io/
- Labs: https://aliorders-dev.fireapps.io/
- Git: https://github.com/YoungWorldTechnology/alicashback
- Chrome Extension Live: neokioeagiejddfoakliiiphcenemobk

## Enviroment
- Up PHP 7.1.17
- MySQL 5.7
- Redis
- NodeJS v8.11.1
- Npm 6.1.0
- Bower
- Composer
- Job using horizon https://laravel.com/docs/5.5/horizon
- BroadcastBROADCAST_DRIVER: Pusher https://pusher.com/
- Mail Driver: Mailgun https://app.mailgun.com/
- Currency Convert: https://apilayer.com/
- Shopify API
    + SHOPIFY_API_KEY: 
    + SHOPIFY_SECRET_KEY: 
    
## Docker Eviroment
- URL https://github.com/YoungWorldTechnology/aliorders

## Step Deploy
- Clone project to local
- Copy file .env.example to .env, Config file .env
- Run `composer install`
- Run `npm install` _install node_modules_
- Run `npm install -g bower` _install global bower_
- Run `npm run prod` _mix and min file css, js resource to public_
- Run `bower install --allow-root` _install library_
- Run `php artisan migrate` _if is live, please dump database_
- Run Job:
    + If dev: run `php artisan horizon`
    + If live: using supervisor
    ```dotenv
    [program:laravel-worker]
    process_name=%(program_name)s_%(process_num)02d
    command=php /home/aliorders.fireapps.io/public_html/artisan horizon
    autostart=true
    autorestart=true
    user=aliorders
    numprocs=8
    redirect_stderr=true
    stdout_logfile=/home/forge/app.com/worker.log
    ```
- Run schedule:
    + If live: Add `* * * * * php /home/aliorders.fireapps.io/artisan schedule:run >> /dev/null 2>&1
` to __cronjob__